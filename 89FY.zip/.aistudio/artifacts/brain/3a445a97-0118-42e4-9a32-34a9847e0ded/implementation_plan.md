# 89 FITNESS & YOGA — Hệ Thống Quản Lý Vận Hành & Tài Chính

Ứng dụng Android Native chuyên biệt dành cho chủ cơ sở và quản lý **89 FITNESS & YOGA**, hoạt động theo kiến trúc **Offline-first** với cơ sở dữ liệu lưu trữ trực tiếp trên thiết bị, hỗ trợ **Đăng nhập Google & Sao lưu/Khôi phục Google Drive**, tính toán phân bổ doanh thu chính xác đến từng ngày hiệu lực và xuất báo cáo **PDF / Excel** chuẩn tiếng Việt.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> Dưới đây là các quy tắc nghiệp vụ cốt lõi đã được chốt từ phản hồi của bạn cùng các thiết lập mặc định cho những điểm mở còn lại trong PRD để đảm bảo tính toàn vẹn dữ liệu tuyệt đối.

- **Đã xác nhận 1 — Doanh thu PT (50% phần Gym) & Vé ngày/tuần**:
  - **PT**: Doanh thu phân bổ trong tháng thuộc về Gym (50%) = `ROUND((Giá trị hợp đồng PT × 50%) ÷ Tổng số buổi đăng ký × Số buổi thực tập trong tháng)`. Huấn luyện viên mặc định: **Hà Đức** (50% còn lại).
  - **Vé ngày & Vé tuần**: Ghi nhận **100% doanh thu vào đúng ngày bán** (thuộc tháng bán vé), không cần tạo hồ sơ hội viên, lấy đơn giá từ cấu hình Bảng giá trong Cài đặt.
- **Đã xác nhận 2 — Hủy hợp đồng & Điều chỉnh doanh thu phân bổ**:
  - Khi hủy hợp đồng và hoàn tiền (số tiền hoàn do nhân viên tự nhập, không tự động khấu trừ theo ngày đã tập), hợp đồng chỉ ghi nhận **phần tiền giữ lại sau hoàn tiền** (`Giá trị hợp đồng − Số tiền thực hoàn`) phân bổ trong kỳ trước khi hủy và **dừng hoàn toàn** việc phát sinh doanh thu ở các tháng tiếp theo. Hồ sơ và hợp đồng hủy chuyển vào **Thùng rác** nhưng bảo toàn 100% lịch sử thanh toán và hoàn tiền.
- **Đã xác nhận 3 — Quy tắc ngày hết hạn cuối tháng (29, 30, 31) & Đóng băng hợp đồng**:
  - Hợp đồng tính theo tháng dương lịch (ví dụ: đăng ký 15/01 gói 1 tháng -> sử dụng hết 14/02, ngày hết hạn là 15/02). Nếu đăng ký vào ngày 29, 30, 31 mà tháng kết thúc không có ngày tương ứng (hoặc tháng 2 năm nhuận/không nhuận), ngày hết hạn tự động lùi về **ngày cuối cùng của tháng đó**.
  - Hỗ trợ tính năng **Tạm dừng (Đóng băng) hợp đồng**: Lưu lịch sử đóng băng, cộng bù số ngày tạm dừng vào ngày hết hạn và điều chỉnh tương ứng các ngày hiệu lực khi tính doanh thu phân bổ.
- **Đã xác nhận 4 — Sao lưu Google Drive & Phân quyền**:
  - Sử dụng **cùng một quyền quản lý đầy đủ** trên ứng dụng.
  - Hỗ trợ **Đăng nhập Google (Google Sign-In)** và **Sao lưu / Khôi phục thủ công qua Google Drive** (đóng gói toàn bộ dữ liệu SQLite, lịch sử giao dịch và ảnh đại diện nén WebP/JPEG kèm kiểm tra mã định danh UUID duy nhất để không trùng lặp giao dịch).
- **Thiết lập mặc định cho các điểm mở khác trong PRD**:
  - **Thống kê số lượng hội viên (Mục 27.6)**: Tính theo **số hồ sơ hội viên duy nhất** (Unique Member Profiles) trong từng lĩnh vực (Gym riêng, Yoga riêng).
  - **Liên kết hồ sơ PT sang Gym (Mục 27.7)**: Khi khách PT chuyển sang đăng ký gói Gym tháng, hệ thống tạo hồ sơ Gym riêng có liên kết với hồ sơ PT, tự động phân loại hợp đồng Gym đầu tiên là **Gia hạn** đúng quy tắc PRD, và đồng bộ số điện thoại khi chỉnh sửa thông tin liên hệ chung.
  - **Thông tin nhóm giá Nam / Nữ / Trẻ em (Mục 27.13)**: Hồ sơ hội viên Gym có trường phân loại nhóm đối tượng (`Nam`, `Nữ`, `Trẻ em`) để lọc nhanh bảng giá tương ứng khi tạo hợp đồng.

---

## 1. Overview & Core Concept

- **What It Does**: Thay thế hoàn toàn quy trình quản lý Excel thủ công tại 89 FITNESS & YOGA bằng một hệ thống quản lý di động tách biệt độc lập hai mảng nghiệp vụ **Gym** và **Yoga**. Ứng dụng kiểm soát trọn vẹn vòng đời hội viên, hợp đồng mới/gia hạn, gói PT theo buổi, vé ngày/tuần, công nợ đa phương thức thanh toán, thùng rác xóa mềm, phân bổ doanh thu theo ngày hiệu lực thực tế (vượt qua bài kiểm thử chuẩn 237.868 VNĐ cho tháng 10/2026), xuất tệp Excel/PDF và sao lưu đám mây qua Google Drive.
- **Target Audience / Persona**: Chủ cơ sở và nhân viên quản lý tại quầy của 89 FITNESS & YOGA — cần thao tác một chạm cực nhanh khi tra cứu hội viên, gia hạn, thu nợ, chấm buổi PT và đối soát báo cáo tài chính cuối tháng.
- **Key Value**:
  - **Chính xác tài chính tuyệt đối**: Tách biệt hoàn toàn *Doanh thu phân bổ theo ngày hiệu lực* và *Dòng tiền thực thu / Công nợ*.
  - **Không dữ liệu giả**: Khởi chạy sạch hoàn toàn; nếu bảng giá chưa cấu hình, ứng dụng hướng dẫn người dùng thiết lập bảng giá thực tế trước khi tạo hợp đồng.
  - **An toàn dữ liệu Offline-first**: Mọi thay đổi được ghi nhận tức thời vào cơ sở dữ liệu Room trên máy với UUID chống trùng lặp và có thể sao lưu/khôi phục lên Google Drive bất cứ lúc nào.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Trang chủ (Dashboard 7 Phân Hệ)**:
   - Hiển thị thanh trạng thái đồng bộ/sao lưu Google Drive ở đầu trang, tiếp theo là lưới 7 thẻ phân hệ rõ ràng: **(1) Danh sách Gym**, **(2) Danh sách Yoga**, **(3) Tạo hợp đồng**, **(4) Doanh thu**, **(5) Theo dõi**, **(6) Cài đặt**, **(7) Thùng rác**.
2. **Danh sách Hội viên (Gym & Yoga riêng biệt)**:
   - Giao diện hàng 2 dòng tối ưu hiển thị:
     - *Dòng 1*: `01. Nguyễn Văn A — Còn 91 ngày` (hoặc `Hết hạn hôm nay` / `Hết hạn 15 ngày` với nhãn màu trạng thái rõ ràng).
     - *Dòng 2*: `Hết hạn: 15/12/2026` bên trái và nút thao tác nổi bật `[Gia hạn]` (kích thước chuẩn $\ge 48\text{dp}$) bên phải.
   - Không tải ảnh đại diện ở danh sách để cuộn mượt tuyệt đối; chỉ tải ảnh nén WebP/JPEG khi mở màn hình **Chi tiết hội viên**.
   - Thanh tìm kiếm gọn theo Tên/SĐT, 4 chip lọc (`Tất cả`, `Còn hạn`, `Sắp hết hạn` 1–7 ngày, `Đã hết hạn`) và nút đảo chiều sắp xếp ngày hết hạn tăng/giảm dần.
3. **Quy trình Tạo & Chỉnh sửa Hợp đồng (4 bước)**:
   - *Bước 1*: Chọn lĩnh vực (`Gym` hoặc `Yoga`).
   - *Bước 2*: Chọn dịch vụ (`Đăng ký mới`, `Gia hạn`, `PT`, `Vé ngày`, `Vé tuần` cho Gym; `Đăng ký mới`, `Gia hạn` cho Yoga). Hệ thống tự động kiểm tra lịch sử khách hàng để áp dụng quy tắc bắt buộc: khách đã từng có hồ sơ trong lĩnh vực hoặc khách PT đăng ký Gym tháng đều được phân loại doanh thu là **Gia hạn**.
   - *Bước 3 & 4*: Chọn gói từ Bảng giá đã cấu hình (cho phép chỉnh sửa giá thỏa thuận thực tế), tách biệt rõ 4 mốc ngày (`Ngày thanh toán`, `Ngày tạo hợp đồng`, `Ngày bắt đầu hiệu lực`, `Ngày hết hạn` tự tính theo quy tắc gia hạn sớm/đúng hạn/muộn), nhập thanh toán lần đầu (Tiền mặt, Chuyển khoản, hoặc Kết hợp cả hai) và lưu.
4. **Quản lý PT & Chấm buổi tập (HLV Hà Đức)**:
   - Quản lý hồ sơ và hợp đồng PT riêng, chặn mua hợp đồng mới khi hợp đồng hiện tại còn buổi, ghi nhận từng buổi tập thực tế theo ngày (chặn ghi nhận quá số buổi còn lại) và tự động tổng hợp số buổi tập trong tháng để tính 50% doanh thu phân bổ cho Gym.
5. **Theo dõi Hội viên & Quản lý Công nợ**:
   - Phân hệ **Theo dõi** tách riêng Gym/Yoga cho cả **Tình trạng hội viên** (Tổng số, Còn hạn, Sắp hết hạn 7 ngày, Đã hết hạn) và **Công nợ** (Số hợp đồng nợ, Tổng tiền nợ, nút `[Thu tiền]` ghi nhận giao dịch thanh toán một phần/nhiều lần mà không tạo trùng doanh thu phân bổ, cảnh báo nếu sửa giá trị hợp đồng thấp hơn số tiền đã thu).
6. **Doanh thu & Xuất Báo cáo PDF / Excel**:
   - Chọn lĩnh vực (`Gym` 5 báo cáo / `Yoga` 3 báo cáo) và kỳ `Tháng/Năm`.
   - Xem trước bảng số liệu trực tiếp trên màn hình, sau đó xuất ra tệp **Excel (`.xlsx` / XML SpreadsheetML chuẩn bảng tính lọc & công thức)** hoặc **PDF (`PdfDocument` căn chỉnh cột chuẩn tiếng Việt)** và chia sẻ ngay qua `FileProvider` (Zalo, Gmail, Google Drive...).

### Visual Identity & Theme (Premium Modern Fitness Management)

- **Aesthetic Direction**: Phong cách **Athletic Precision & Executive Clarity** — kết hợp vẻ năng động, mạnh mẽ của phòng tập cao cấp với độ sắc nét, chuẩn xác của phần mềm tài chính chuyên nghiệp.
- **Color Palette & Mood**:
  - **Light Mode (Mặc định)**: Nền chính `#F8FAFC` (Cool Alabaster), bề mặt thẻ `#FFFFFF`, viền tinh tế `#E2E8F0`.
  - **Dark Mode (Chuyển đổi trong Cài đặt & lưu bền vững qua DataStore)**:Obsidian Slate `#0B0F17`, bề mặt thẻ `#151C28`, viền `#263244`.
  - **Semantic Accents**:
    - Nhánh **Gym**: Energetic Emerald (`#059669` Light / `#10B981` Dark) — biểu trưng sức mạnh và tăng trưởng tài chính.
    - Nhánh **Yoga**: Mindful Indigo (`#4F46E5` Light / `#6366F1` Dark) — giúp nhân viên nhận diện tức thời đang thao tác ở phân hệ Gym hay Yoga, tránh nhầm lẫn dữ liệu.
    - Trạng thái: Còn hạn (`#16A34A`), Sắp hết hạn 1–7 ngày (`#D97706` Amber), Đã hết hạn / Công nợ / Hủy (`#DC2626` Crimson).
- **Typography & Hierarchy**:
  - Cài đặt bộ font Google Fonts tĩnh qua `font-util`: **Plus Jakarta Sans** (hoặc **Montserrat**) cho tiêu đề phân hệ và số liệu tài chính lớn; **Be Vietnam Pro** (hoặc **Inter**) cho nội dung tiếng Việt và bảng biểu, đảm bảo dấu tiếng Việt rõ nét và chữ số thẳng hàng (tabular numerals).

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Lưu trữ Offline-First bằng Room SQLite kết hợp Google Drive Backup**
  - *Chosen Approach*: Toàn bộ dữ liệu nghiệp vụ được lưu trong cơ sở dữ liệu quan hệ **Room (SQLite)** ngay trên điện thoại. Tính năng Sao lưu/Khôi phục đóng gói toàn bộ snapshot dữ liệu (JSON có kiểm tra toàn vẹn + tệp ảnh đại diện nén) đẩy lên thư mục ứng dụng trên **Google Drive REST API** thông qua tài khoản Google đã đăng nhập.
  - *Why*: Đảm bảo tốc độ phản hồi tức thì (0ms độ trễ mạng) khi nhân viên tra cứu hội viên hoặc thu tiền lúc mất mạng, đồng thời cho phép chuyển thiết bị hoặc khôi phục toàn bộ dữ liệu an toàn qua Google Drive đúng theo yêu cầu của bạn.
- **Decision 2: Tính toán Doanh thu phân bổ Động (On-the-fly Deterministic Engine) có Kiểm thử Tự động**
  - *Chosen Approach*: Xây dựng bộ máy tính toán `RevenueAllocationEngine` thuần khiết (pure function) dựa trên dữ liệu gốc của hợp đồng, lịch sử đóng băng và thông tin hủy hợp đồng, thực hiện làm tròn đến đơn vị đồng (`ROUND_HALF_UP`) cho **từng hợp đồng trước khi cộng tổng**.
  - *Why*: Khi người dùng chỉnh sửa bất kỳ thông tin hợp đồng nào (giá trị, ngày bắt đầu, thời hạn, đóng băng, hủy), toàn bộ báo cáo doanh thu của mọi tháng liên quan tự động phản ánh chính xác ngay lập tức mà không bao giờ bị lệch dữ liệu cache hay ảnh hưởng đến lịch sử thanh toán.
- **Decision 3: Xuất Báo cáo PDF & Excel Native trên Android**
  - *Chosen Approach*: Sử dụng `android.graphics.pdf.PdfDocument` với font chữ tiếng Việt nhúng trực tiếp để vẽ bảng báo cáo PDF sắc nét không mất cột, kết hợp trình tạo tệp bảng tính Excel tương thích Microsoft Excel / Google Sheets hỗ trợ lọc, sắp xếp và định dạng tiền tệ VNĐ.
  - *Why*: Hoạt động 100% offline trên thiết bị, không phụ thuộc máy chủ bên ngoài và giữ nguyên vẹn tiếng Việt có dấu.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

### Architecture & Component Diagram

```
┌────────────────────────────────────────────────────────────────────────────┐
│                     UI LAYER (Jetpack Compose + Material 3)                │
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐ ┌───────────────────┐  │
│  │  Home 7-Tile │ │ Gym / Yoga   │ │ 4-Step       │ │ PT Management &   │  │
│  │  Dashboard   │ │ Member Lists │ │ Contract Wiz │ │ Session Tracker   │  │
│  └──────┬───────┘ └──────┬───────┘ └──────┬───────┘ └─────────┬─────────┘  │
│  ┌──────┴───────┐ ┌──────┴───────┐ ┌──────┴───────┐ ┌─────────┴─────────┐  │
│  │ Revenue &    │ │ Tracking &   │ │ Trash & Soft │ │ Settings, Pricing │  │
│  │ PDF/Excel Ex │ │ Debt Collect │ │ Delete Recov │ │ & Drive Backup UI │  │
│  └──────┬───────┘ └──────┬───────┘ └──────┬───────┘ └─────────┬─────────┘  │
└─────────┼────────────────┼────────────────┼───────────────────┼────────────┘
          │                │                │                   │
          ▼                ▼                ▼                   ▼
┌────────────────────────────────────────────────────────────────────────────┐
│                 DOMAIN & BUSINESS RULES ENGINE (ViewModels)                │
│  ┌─────────────────────────┐  ┌───────────────────────┐  ┌──────────────┐  │
│  │ RevenueAllocationEngine │  │ ContractDate & Freeze │  │ PDF & Excel  │  │
│  │ (Daily Proration/Round) │  │ Calculator (29/30/31) │  │ Exporter     │  │
│  └────────────┬────────────┘  └───────────┬───────────┘  └──────┬───────┘  │
└───────────────┼───────────────────────────┼─────────────────────┼──────────┘
                │                           │                     │
                ▼                           ▼                     ▼
┌────────────────────────────────────────────────────────────────────────────┐
│                  DATA & PERSISTENCE LAYER (Offline-First)                  │
│  ┌────────────────────────────────────┐  ┌──────────────────────────────┐  │
│  │ Room SQLite Database (UUID Keys)   │  │ Google Auth & Google Drive   │  │
│  │ • Members (Gym/Yoga Isolated)      │  │ Backup/Restore Manager       │  │
│  │ • Contracts & Freeze Logs          │  │ • Credential Manager Sign-In │  │
│  │ • PT Profiles, Contracts, Sessions │  │ • Full DB Snapshot + Avatars │  │
│  │ • Short-Term Tickets (Day/Week)    │  │ • Conflict-Safe UUID Merge   │  │
│  │ • Payments, Refunds & Audit Logs   │  └──────────────────────────────┘  │
│  │ • Price Catalogs (Gym/Yoga/PT)     │  ┌──────────────────────────────┐  │
│  └────────────────────────────────────┘  │ DataStore (Theme & Config)   │  │
│                                          └──────────────────────────────┘  │
└────────────────────────────────────────────────────────────────────────────┘
```

### Data Model & State

1. **`PricePlanEntity` (Bảng giá cấu hình)**:
   - Lưu tách biệt theo `domain` (`GYM` hoặc `YOGA`), `category` (`NAM`, `NU`, `TRE_EM`, `VE_NGAY`, `VE_TUAN`, `PT`, `YOGA_STANDARD`), `durationMonths` hoặc `sessionCount`, `priceVnd`, và trạng thái `isActive` (vô hiệu hóa thay vì xóa khi đã có hợp đồng sử dụng).
2. **`MemberEntity` (Hồ sơ Hội viên Gym / Yoga độc lập)**:
   - `id` (UUID), `displayIndex` (STT), `domain` (`GYM` | `YOGA`), `fullName`, `phoneNumber`, `genderGroup` (`NAM` | `NU` | `TRE_EM`), `avatarLocalPath` (chỉ tải khi xem chi tiết), `linkedPtClientId` (nếu chuyển từ PT sang Gym), `isDeleted` (xóa mềm vào Thùng rác), `deletedAt`, `deleteReason`.
3. **`ContractEntity` (Hợp đồng Hội viên Gym / Yoga)**:
   - `id` (UUID), `contractCode` (duy nhất, bất biến), `memberId`, `domain` (`GYM` | `YOGA`), `contractType` (`NEW` | `RENEWAL` — tự động gán `RENEWAL` nếu hội viên đã từng có hợp đồng hoặc liên kết từ PT), `planNameSnapshot`, `durationMonths`, `agreedValueVnd` (lưu độc lập bảng giá), `paymentDate`, `createdDate`, `startDate`, `endDate`, `totalFrozenDays`, `status` (`ACTIVE`, `CANCELLED`), `cancelledDate`, `cancelReason`, `retainedAmountVnd`, `isDeleted`.
4. **`ContractFreezeEntity` (Lịch sử Tạm dừng / Đóng băng)**:
   - `id` (UUID), `contractId`, `freezeStartDate`, `freezeEndDate`, `daysFrozen`, `note`.
5. **`PtClientEntity`, `PtContractEntity` & `PtSessionEntity` (Phân hệ PT — HLV Hà Đức)**:
   - Hồ sơ khách PT riêng biệt, hợp đồng PT (`totalSessions`, `usedSessions`, `agreedValueVnd`, `trainerName = "Hà Đức"`, trạng thái), và bản ghi từng buổi tập (`sessionDate`, `sessionsCount`, gắn chặt với `ptContractId`).
6. **`ShortTermTicketEntity` (Vé ngày / Vé tuần Gym)**:
   - `id` (UUID), `ticketCode`, `ticketType` (`DAILY` | `WEEKLY`), `saleDate`, `quantity`, `unitPriceVnd`, `totalAmountVnd`, `cashAmountVnd`, `transferAmountVnd`.
7. **`PaymentTransactionEntity` & `RefundTransactionEntity` (Giao dịch Thu tiền & Hoàn tiền)**:
   - Mỗi lần thu tiền hoặc hoàn tiền có mã giao dịch UUID riêng, lưu rõ `cashAmountVnd` (Tiền mặt) và `transferAmountVnd` (Chuyển khoản) để hỗ trợ thanh toán kết hợp.
8. **`EditAuditLogEntity` (Lịch sử chỉnh sửa tài chính)**:
   - Ghi vết mọi chỉnh sửa thủ công trên hợp đồng, giá trị, ngày hiệu lực để phục vụ kiểm tra đối soát.

### Interactive Component & State Mapping

- **Tự động tính ngày bắt đầu khi Gia hạn (`RenewalDateCalculator`)**:
  - Nếu `Ngày gia hạn < Ngày hết hạn cũ`: `Ngày bắt đầu mới = Ngày hết hạn cũ` (bảo toàn 100% số ngày còn lại).
  - Nếu `Ngày gia hạn >= Ngày hết hạn cũ`: `Ngày bắt đầu mới = Ngày gia hạn thực tế`.
- **Bộ máy phân bổ doanh thu (`RevenueAllocationEngine`)**:
  - Hợp đồng đang hoạt động: `Doanh thu tháng = ROUND(Giá trị hợp đồng ÷ Tổng số ngày hiệu lực × Số ngày hiệu lực nằm trong tháng)`.
  - Hợp đồng đã hủy: Chỉ phân bổ phần tiền giữ lại (`Giá trị hợp đồng − Tổng tiền hoàn`) cho các ngày hiệu lực trước thời điểm hủy và bằng `0 VNĐ` cho mọi tháng sau tháng hủy.
  - Hợp đồng PT: `Doanh thu Gym tháng = ROUND((Giá trị hợp đồng PT × 0.5) ÷ Tổng số buổi hợp đồng × Tổng số buổi tập trong tháng)`.
  - Vé ngày/tuần: Cộng 100% `totalAmountVnd` vào ngày `saleDate` thuộc tháng báo cáo.
- **Bảo vệ toàn vẹn khi Sửa Hợp đồng & Khôi phục Thùng rác**:
  - Khi sửa `agreedValueVnd` thấp hơn tổng tiền đã thanh toán, UI hiển thị cảnh báo nổi bật **"Thanh toán vượt giá trị hợp đồng"** và hướng dẫn nhân viên kiểm tra/xử lý.
  - Khi khôi phục từ Thùng rác: Phân biệt rõ bản ghi `Xóa nhầm` (khôi phục về trạng thái trước khi xóa) và `Hợp đồng đã hủy & hoàn tiền` (khôi phục thông tin để tra cứu nhưng giữ nguyên trạng thái `Đã hủy`, không biến thành hợp đồng đang hoạt động).
