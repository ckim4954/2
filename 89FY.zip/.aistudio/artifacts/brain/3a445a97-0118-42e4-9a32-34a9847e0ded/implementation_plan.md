# Nâng Cấp 89 FITNESS & YOGA — Compact UI, Chuẩn Hóa Nghiệp Vụ & Bảo Toàn Dữ Liệu

Kế hoạch nâng cấp trực tiếp trên mã nguồn hiện tại của ứng dụng **89 FITNESS & YOGA** nhằm tối ưu giao diện theo hướng **Compact UI (nhỏ gọn, mật độ thông tin cao, không khoảng trắng dư thừa)**, chuẩn hóa logic thời hạn hợp đồng và doanh thu, lưu tệp **Excel / PDF** thực tế vào bộ nhớ thiết bị và **bảo toàn 100% cơ sở dữ liệu hiện có**.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> Toàn bộ phương án nâng cấp dưới đây tuân thủ nghiêm ngặt PRD nâng cấp và 3 quyết định bạn vừa xác nhận:

- **Đã xác nhận 1 — Xuất & Lưu file Excel / PDF thực tế vào thiết bị**:
  - Sử dụng cơ chế **Android Storage Access Framework (`ActivityResultContracts.CreateDocument`)** mở hộp thoại chọn thư mục lưu của Android mỗi lần người dùng nhấn Xuất Excel hoặc Xuất PDF, với tên file tự động đặt sẵn theo phân hệ, loại báo cáo và kỳ báo cáo.
  - Sau khi ghi dữ liệu thực tế vào file người dùng đã chọn, ứng dụng hiển thị thông báo kết quả lưu thành công kèm vị trí file và cung cấp nút **Mở file** hoặc **Chia sẻ file** (tách biệt rõ hành động Xuất lưu file và Chia sẻ file).
- **Đã xác nhận 2 — Quy tắc Ngày hết hạn chỉnh tay & Tự động tính số ngày hiệu lực**:
  - Mặc định khi tạo hợp đồng mới, `Ngày hết hạn` tự động tính theo gói tập và `Ngày bắt đầu hiệu lực` (xử lý chuẩn xác tháng 28, 29, 30, 31 ngày, năm nhuận và chuyển tháng/năm).
  - Khi người dùng **chỉnh tay Ngày hết hạn** (qua hộp thoại lịch Android native), ứng dụng bật trạng thái giữ nguyên ngày hết hạn đã chỉnh tay đó **kể cả khi thay đổi Ngày bắt đầu**. Chỉ tính lại `Ngày hết hạn` theo gói tập khi người dùng chủ động nhấn nút **"Tính tự động lại"**.
  - **Số ngày hiệu lực**, **Trạng thái thời hạn** (`Còn X ngày`, `Hết hạn hôm nay`, `Hết hạn X ngày`) và **Doanh thu phân bổ** tự động cập nhật thống nhất theo `Ngày bắt đầu` và `Ngày hết hạn` hiện tại ở mọi màn hình.
- **Đã xác nhận 3 — Tự động nạp sẵn 14 gói giá chuẩn Gym & Yoga**:
  - Tự động kiểm tra và nạp sẵn (idempotent seed, không ghi đè hay làm mất các gói đã có) đúng **14 gói giá chuẩn** trong PRD cho **Gym — Nam** (3 gói), **Gym — Nữ** (4 gói), **Gym — Trẻ em** (4 gói) và **Yoga** (3 gói). Không tự tạo thêm giá gói PT hoặc gói ngoài danh sách khi chưa được người dùng nhập.

---

## 1. Overview & Core Concept (Báo Cáo Audit & Phạm Vi Nâng Cấp)

- **Bảo toàn 100% Dữ liệu & Kiến trúc**:
  - Giữ nguyên cơ sở dữ liệu Room SQLite (`fitness89_management.db`), giữ nguyên toàn bộ khóa định danh `UUID` và mối liên hệ giữa Hội viên (`members`), Hợp đồng (`contracts`), Thanh toán (`payment_transactions`), Hoàn tiền (`refund_transactions`), PT (`pt_clients`, `pt_contracts`, `pt_sessions`), Vé ngắn hạn (`short_term_tickets`) và Bảng giá (`price_plans`).
  - Bổ sung an toàn trường `note` (ghi chú hợp đồng) và trạng thái xóa mềm cho gói tập (`isDeleted` trên `price_plans`) bằng cơ chế tương thích ngược không làm mất bất kỳ bản ghi cũ nào.
- **Triết lý Giao diện Mới (Compact UI & High Information Density)**:
  - Loại bỏ toàn bộ banner lớn, tiêu đề lặp lại, subtitle mô tả dài, nhãn `Step 1, Step 2, Step 3, Step 4` và khoảng trắng lãng phí.
  - Tăng diện tích hiển thị danh sách thực tế trên màn hình điện thoại, đồng thời bảo toàn đầy đủ mọi thông tin và nút thao tác nghiệp vụ.

---

## 2. User Experience & Visual Design (Chi Tiết Chuẩn Hóa Từng Module)

### 2.1. Trang Chủ (Lưới Menu 3 Ô Vuông / Hàng)
- Loại bỏ banner giới thiệu lớn ở đầu trang.
- Sử dụng lưới **3 ô vuông trên mỗi hàng (`GridCells.Fixed(3)`)** với kích thước đồng nhất (`aspectRatio(1f)`), icon rõ ràng, tên chức năng ngắn gọn (*Gym*, *Yoga*, *Tạo hợp đồng*, *Doanh thu*, *Theo dõi*, *PT*, *Cài đặt*, *Thùng rác*) điều hướng trực tiếp vào module tương ứng.

### 2.2. Module Gym & Yoga — Danh Sách Hội Viên
- **Header nhỏ gọn**: Chỉ hiển thị tên phân hệ và số lượng ngắn gọn `"X hội viên"` (bỏ kiểu `"Danh sách Hội viên 1/1 hội viên"`).
- **Hàng hội viên 2 dòng nhỏ gọn (không avatar)**:
  - *Dòng 1*: `STT — Họ tên — Trạng thái thời hạn` (`Còn X ngày`, `Hết hạn X ngày`, `Hết hạn hôm nay`).
  - *Dòng 2*: `Ngày hết hạn (dd/mm/yyyy)` bên trái — Nút `Gia hạn` nhỏ gọn bên phải.
- **Tìm kiếm 3 tiêu chí**: Hỗ trợ tìm chính xác theo `STT` (ví dụ `"01"` hoặc `"1"`), `Họ tên đầy đủ`, và `Số điện thoại` với placeholder ghi rõ: `"Tìm theo STT, Họ tên, SĐT..."`.
- **Loại bỏ bộ lọc thời hạn khỏi Danh sách hội viên**: Toàn bộ bộ lọc thời hạn chỉ đặt tại module **Theo dõi** đúng theo mục 5.1 của PRD.
- **Xuất toàn bộ danh sách hội viên**: Giữ 2 nút xuất **Excel** và **PDF**, tạo file thực tế cho toàn bộ hội viên thuộc phân hệ và lưu vào thiết bị qua hộp thoại chọn thư mục lưu.

### 2.3. Module Tạo Hợp Đồng & Quy Tắc Chỉnh Sửa Chỉ Đọc (Read-Only Default)
- **Giao diện gọn theo trình tự nghiệp vụ**:
  - Loại bỏ toàn bộ các thẻ hướng dẫn và nhãn `Step 1, Step 2, Step 3, Step 4`.
  - Bao gồm đầy đủ các trường nghiệp vụ: Phân hệ Gym/Yoga, Dịch vụ, Thông tin hội viên, Gói tập, Ngày hợp đồng, Ngày thanh toán, Ngày bắt đầu hiệu lực, Ngày hết hạn (có nút *"Tính tự động lại"* khi đã chỉnh tay), Giá trị hợp đồng, Số tiền đã thanh toán (Tiền mặt / Chuyển khoản), Công nợ còn lại, Phương thức thanh toán và **Ghi chú**.
- **Chọn ngày kiểu lịch Android Native (`DatePickerDialog`)**:
  - Nhấn vào bất kỳ trường ngày nào sẽ mở hộp thoại lịch Android native cho phép chọn ngày/tháng/năm, điều hướng tháng trước/sau, có nút `Hủy` và `OK`, hiển thị chuẩn `dd/mm/yyyy`.
- **Chế độ Chỉ đọc (Read-only) mặc định cho hợp đồng đã lưu**:
  - Khi mở xem chi tiết hội viên và hợp đồng đã lưu, tất cả các trường thông tin đều ở chế độ **Chỉ đọc** (không hiển thị con trỏ nhập liệu).
  - Chỉ khi người dùng nhấn nút **"Sửa hợp đồng"** (hoặc **"Sửa hồ sơ"**), các trường mới chuyển sang chế độ cho phép chỉnh sửa.

### 2.4. Module Cài Đặt (Gọn 4 Nhóm Chức Năng Chính)
- Loại bỏ thanh tìm kiếm và các đoạn mô tả dài.
- Màn hình chính Cài đặt hiển thị gọn 4 mục:
  1. **Bảng giá & Gói tập**: Quản lý riêng Gym (*Nam*, *Nữ*, *Trẻ em*, *Vé ngày/tuần*, *PT*) và Yoga với 14 gói giá chuẩn được nạp sẵn. Hỗ trợ Thêm gói, Sửa tên/thời hạn/giá, Ngừng sử dụng (ẩn gói nếu đã có hợp đồng cũ tham chiếu để bảo toàn lịch sử) hoặc Xóa gói vào Thùng rác (có hộp thoại xác nhận).
  2. **Giao diện & Chủ đề**: Chuyển đổi nhanh Light Mode / Dark Mode.
  3. **Dữ liệu & Sao lưu**: Sao lưu & Khôi phục dữ liệu qua Google Drive / tệp sao lưu trên máy, kèm hộp thoại cảnh báo và xác nhận trước thao tác khôi phục để tránh ghi đè ngoài ý muốn.
  4. **Thùng rác**: Mở trực tiếp cùng một module **Thùng rác thống nhất** như từ Trang chủ.

### 2.5. Module Doanh Thu (3 Ô Vuông Chức Năng & 8 Báo Cáo)
- **Màn hình chính Doanh thu**: Thiết kế dạng **3 ô vuông chức năng** đồng nhất với Trang chủ:
  1. **Doanh thu Gym**: Bộ chọn tháng/năm nhỏ gọn + danh sách gọn 6 chỉ tiêu kiểm tra (*Doanh thu hội viên mới*, *Doanh thu gia hạn*, *Doanh thu PT*, *Doanh thu vé ngày*, *Doanh thu vé tuần*, *Tổng doanh thu Gym*) và danh sách chi tiết từng khoản.
  2. **Doanh thu Yoga**: Bộ chọn tháng/năm nhỏ gọn + danh sách độc lập với Gym (*Doanh thu hội viên mới*, *Doanh thu gia hạn*, *Tổng doanh thu Yoga*).
  3. **Xuất báo cáo**: Chọn kỳ tháng/năm nhỏ gọn và xuất đúng **8 báo cáo** chuẩn (5 báo cáo Gym + 3 báo cáo Yoga) ra file **Excel** hoặc **PDF** thực tế lưu vào thiết bị, hiển thị thông báo sau khi lưu thành công kèm nút **Mở file** và **Chia sẻ file**.

### 2.6. Module Theo Dõi (Tối Ưu Diện Tích & Đầy Đủ Nhóm Thời Hạn)
- Thu gọn tối đa header, bỏ subtitle dư thừa và khoảng trắng để hiển thị nhiều hội viên hơn trên màn hình.
- Bảo toàn đầy đủ **Theo dõi Gym**, **Theo dõi Yoga** và **Theo dõi Công nợ**.
- Hiển thị các chỉ số thống kê (`Tổng hội viên`, `Còn hạn`, `Sắp hết hạn`, `Đã hết hạn`) và đầy đủ các chip bộ lọc trạng thái thời hạn theo mục 8 của PRD:
  - `Tất cả`
  - `Còn hạn`
  - `Hôm nay hết hạn` (`signedDays == 0`)
  - `Sắp hết hạn 1–7 ngày` (`signedDays in 1..7`)
  - `Sắp hết hạn 8–15 ngày` (`signedDays in 8..15`)
  - `Đã hết hạn` (`signedDays <= 0`)
- Hỗ trợ tìm kiếm theo `STT`, `Họ tên`, `Số điện thoại` và nút đảo chiều sắp xếp theo ngày hết hạn.

### 2.7. Module Thùng Rác Thống Nhất & Xác Nhận Xóa Toàn Ứng Dụng
- Cùng một module và cùng tập dữ liệu dù mở từ **Trang chủ** hay từ **Cài đặt**.
- Lưu trữ vô thời hạn (không tự xóa sau 7, 30 hay 90 ngày) các mục đã xóa: Hội viên, Hợp đồng, Gói tập, Hồ sơ PT, Giao dịch vé.
- **Khôi phục từng mục**: Đưa về đúng vị trí và trạng thái trước khi xóa, bảo toàn quan hệ hội viên – hợp đồng – lịch sử thanh toán (không tự kích hoạt lại hợp đồng đã hủy trước khi xóa).
- **Xóa vĩnh viễn theo lựa chọn có xác nhận**:
  1. Người dùng tích chọn từng mục (hoặc nhiều mục) qua checkbox.
  2. Nhấn nút **Xóa vĩnh viễn mục đã chọn**.
  3. Hiển thị hộp thoại xác nhận nêu rõ số lượng và phạm vi dữ liệu sắp xóa vĩnh viễn.
  4. Chỉ thực hiện xóa khi người dùng nhấn xác nhận (tuyệt đối không xóa toàn bộ ngay lập tức khi bấm một nút).
- **Xác nhận xóa trên toàn ứng dụng**: Mọi thao tác xóa hội viên, xóa hợp đồng, xóa gói tập, xóa dữ liệu nghiệp vụ đều bắt buộc qua hộp thoại xác nhận.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Lưu File Thực Tế bằng Storage Access Framework (`CreateDocument`) + Tùy chọn Mở/Chia sẻ**
  - *Chosen Approach*: Khi người dùng nhấn Xuất Excel hoặc Xuất PDF, ứng dụng tạo dữ liệu file và gọi `CreateDocument` để người dùng chọn thư mục lưu trên thiết bị, đồng thời lưu một bản trong bộ nhớ ứng dụng để hỗ trợ nút **Mở file** (`ACTION_VIEW`) hoặc **Chia sẻ** (`ACTION_SEND`) ngay trên thanh thông báo kết quả.
  - *Why*: Tuân thủ tuyệt đối yêu cầu lưu file thực tế vào thiết bị của PRD nâng cấp, hoạt động ổn định trên mọi phiên bản Android mà không cần quyền bộ nhớ nhạy cảm.
- **Decision 2: Cờ `isEndDateManuallyEdited` cho Ngày Hết Hạn Hợp Đồng**
  - *Chosen Approach*: Thêm trạng thái kiểm soát việc chỉnh tay ngày hết hạn. Khi người dùng chọn một ngày hết hạn tùy chỉnh từ lịch `DatePickerDialog`, hệ thống khóa giữ nguyên ngày hết hạn đó ngay cả khi đổi ngày bắt đầu, chỉ tính lại theo số tháng của gói khi người dùng nhấn nút *"Tính tự động lại"*.
  - *Why*: Giải quyết triệt để hiện tượng ngày hết hạn tự nhảy lại ngoài ý muốn hoặc không khớp với mô tả thời hạn.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

### Architecture & Upgrade Mapping Diagram

```
┌────────────────────────────────────────────────────────────────────────────┐
│                   COMPACT UI LAYER (Jetpack Compose)                       │
│  ┌──────────────────────┐  ┌──────────────────────┐  ┌──────────────────┐  │
│  │ Home 3x3 Square Grid │  │ Gym/Yoga Compact List│  │ Contract Form +  │  │
│  │ (No Banner/Subtitle) │  │ (STT/Name/Phone Srch)│  │ Read-Only Detail │  │
│  └──────────┬───────────┘  └──────────┬───────────┘  └────────┬─────────┘  │
│  ┌──────────┴───────────┐  ┌──────────┴───────────┘  ┌────────┴─────────┐  │
│  │ Revenue 3-Tile Hub   │  │ Compact Tracking     │  │ 4-Item Settings  │  │
│  │ (Gym / Yoga / Export)│  │ (Today/1-7d/8-15d/Ex)│  │ & Multi-Sel Trash│  │
│  └──────────┬───────────┘  └──────────┬───────────┘  └────────┬─────────┘  │
└─────────────┼─────────────────────────┼───────────────────────┼────────────┘
              │                         │                       │
              ▼                         ▼                       ▼
┌────────────────────────────────────────────────────────────────────────────┐
│             NATIVE ANDROID DIALOGS & FILE STORAGE SERVICES                 │
│  • Native DatePickerDialog (dd/mm/yyyy, Month Nav, Cancel / OK)            │
│  • SAF CreateDocument File Saver (.xls & .pdf) + Open / Share Actions      │
│  • Universal Delete & Restore Confirmation Dialogs                         │
└───────────────────────────────────────┬────────────────────────────────────┘
                                        │
                                        ▼
┌────────────────────────────────────────────────────────────────────────────┐
│          EXISTING ROOM SQLITE DATABASE (100% DATA PRESERVATION)            │
│  • Auto-Seeds 14 Standard Gym (Nam/Nữ/Trẻ em) & Yoga Price Plans           │
│  • Preserves All Members, Contracts, Payments, Refunds, PT & Audit Logs    │
└────────────────────────────────────────────────────────────────────────────┘
```

### Data Model & Safe Schema Continuity

- **Bảo toàn Schema & Migration an toàn**:
  - Bảng `contracts`: Bổ sung trường `note: String = ""` với `@ColumnInfo(defaultValue = "''")` và tăng version kèm `Migration(1, 2)` chạy lệnh `ALTER TABLE contracts ADD COLUMN note TEXT NOT NULL DEFAULT ''` và `ALTER TABLE price_plans ADD COLUMN isDeleted INTEGER NOT NULL DEFAULT 0`. Nhờ đó **100% dữ liệu hiện có trên máy được giữ nguyên vẹn tuyệt đối**.
- **Bộ kiểm thử tự động (Unit Tests) mở rộng**:
  - Kiểm thử tính ngày bắt đầu, ngày hết hạn, chuyển tháng (28, 29, 30, 31 ngày), năm nhuận, gia hạn sớm/đúng hạn/muộn, chỉnh tay ngày hết hạn.
  - Kiểm thử thanh toán nhiều lần, công nợ, hủy hợp đồng và hoàn tiền.
  - Kiểm thử doanh thu phân bổ Gym, Yoga, 8 báo cáo thành phần và tổng hợp khớp nhau 100%.
