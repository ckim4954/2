# Nâng Cấp Hệ Thống Xuất Báo Cáo Tài Chính (PDF & Excel XLSX) — 89 FITNESS & YOGA

Nâng cấp toàn diện hệ thống tính toán đối chiếu, thiết kế lại báo cáo PDF quản trị đa trang không cắt chữ và triển khai bộ xuất Excel `.xlsx` chuẩn OpenXML đa Sheet (thay thế hoàn toàn CSV), đồng thời bổ sung xuất Báo cáo Dòng tiền tháng (PDF & XLSX) mà vẫn bảo toàn tuyệt đối cấu trúc dữ liệu và giao diện hiện có.

## User Review & Critical Decisions

> [!IMPORTANT]
> Các quyết định thiết kế dưới đây đã được chốt dựa trên yêu cầu của bạn và kết quả rà soát mã nguồn hiện tại:

- **Quyết định 1 (Kích hoạt xuất Báo cáo Dòng tiền PDF & XLSX)**: Bổ sung thanh nút xuất **PDF / Excel (.xlsx) / Chia sẻ** ngay trong tab **Dòng tiền tháng** và thêm tùy chọn xuất **Báo cáo dòng tiền tháng** trong tab **Xuất báo cáo**, giữ nguyên toàn bộ bố cục và thứ tự 8 mục báo cáo phân bổ hiện có.
- **Quyết định 2 (Chuyển toàn bộ nút xuất Excel sang chuẩn `.xlsx` thực sự)**: Thay thế toàn bộ tính năng xuất `.csv` ở cả màn hình **Doanh thu** (Báo cáo phân bổ & Dòng tiền) và màn hình **Danh sách Hội viên GYM/YOGA** sang tạo file `.xlsx` chuẩn OpenXML (`application/vnd.openxmlformats-officedocument.spreadsheetml.sheet`), mở trực tiếp trên Microsoft Excel, Google Sheets và LibreOffice.
- **Quyết định 3 (Kiến trúc tạo `.xlsx` Offline 100%, không làm phình APK)**: Triển khai bộ tạo OpenXML `.xlsx` thuần Kotlin/Java (`XlsxWorkbookWriter`) đóng gói chuẩn cấu trúc ZIP OOXML (`[Content_Types].xml`, `xl/workbook.xml`, `xl/styles.xml`, `xl/worksheets/sheet*.xml`) hỗ trợ định dạng tiền tệ VND (`#,##0 "đ"`), ngày tháng (`dd/mm/yyyy`), đóng băng hàng tiêu đề (`Freeze Panes`), bộ lọc tự động (`AutoFilter`), tự giãn độ rộng cột, đường viền và công thức `SUM(...)` kèm giá trị cache chính xác.

---

## 1. Bảng Kiểm Tra & Truy Vết Mã Nguồn Hiện Tại

| Hạng mục kiểm tra | Công thức & Logic hiện tại | Nguồn dữ liệu đầu vào | Phân loại & Làm tròn | Lỗi / Hạn chế xác minh được | Phần giữ nguyên |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **1. Doanh thu phân bổ GYM & YOGA** | `Giá trị HĐ × Số ngày hiệu lực trong kỳ / Tổng số ngày hiệu lực HĐ` (tính cả ngày bắt đầu & ngày kết thúc theo UTC) | `ContractRecord` (`!isDeleted`, `serviceType` = `GYM`/`YOGA`, `packageValue` lịch sử, `startDate`, `endDate`) | • `isRenewal == false` → Còn hạn & ĐK mới<br>• `isRenewal == true` → Gia hạn<br>• Làm tròn `roundToLong()` đến hàng đồng cho từng HĐ trước khi cộng | `AllocatedLineItem` chưa lưu tách biệt `startDateIso`, `endDateIso`, `totalUnits`, `monthUnits` để xuất bảng chi tiết & đối chiếu đa cột trên PDF/XLSX | Giữ nguyên công thức phân bổ theo ngày, cách làm tròn `roundToLong()`, phân loại theo `isRenewal`, không khử trùng theo hội viên giữa 2 báo cáo |
| **2. Doanh thu phân bổ PT (50% phòng tập)** | `(Giá trị HĐ / Tổng số buổi) × Số buổi hoàn thành trong kỳ × 50%` | `ContractRecord` (`serviceType == "PT"`, `!isDeleted`) + `PtSessionRecord` (`!isDeleted`, `contractId == contract.id`, `sessionDate` thuộc tháng) | • Không dùng `endDate` cố định<br>• Làm tròn `roundToLong()` cho từng HĐ trước khi cộng | Cần khử trùng ID buổi tập (`distinctBy { it.id }`) và chặn trần tổng số buổi lũy kế không vượt quá `contract.totalSessions`; bổ sung danh sách buổi tập hoàn thành trong kỳ để xuất Sheet Chi tiết buổi tập PT | Giữ nguyên công thức 50% phòng tập, không áp dụng công thức phân bổ theo ngày cho PT |
| **3. Doanh thu Vé lẻ** | `totalAmount = quantity × unitPrice` của các vé bán trong tháng | `SingleTicketRecord` (`!isDeleted`, `saleDate` thuộc tháng) | Ghi nhận vào mục `4. Doanh thu phân bổ GYM — Vé lẻ` và `Dòng tiền tháng` | Không có sai lệch công thức; cần truyền thêm thông tin phương thức thanh toán & số lượng vào Sheet Chi tiết vé lẻ | Giữ nguyên toàn bộ công thức và cách ghi nhận vé lẻ |
| **4. Báo cáo Dòng tiền tháng (`MonthlyCashflowSummary`)** | Ghi nhận theo `paymentDate` (HĐ) và `saleDate` (Vé lẻ) thuộc tháng báo cáo | `ContractRecord` (`!isDeleted`) + `SingleTicketRecord` (`!isDeleted`) | Phân loại theo dịch vụ (`GYM`, `YOGA`, `PT`, `VE_LE`) và phương thức (`CASH`, `TRANSFER`, `COMBINED`) | 1. Chưa có cơ chế phát hiện và cảnh báo chênh lệch khi `Tổng thực thu != Tiền mặt + Chuyển khoản` (hoặc giao dịch `COMBINED` có `cashAmount + transferAmount != paidAmount`).<br>2. Chưa có chức năng xuất PDF & XLSX cho Báo cáo Dòng tiền. | Giữ nguyên nguyên tắc ghi nhận theo ngày thanh toán thực tế; tuyệt đối không tự ý sửa hay làm khớp giả tạo số liệu khi có lệch |
| **5. Xuất PDF (`ReportExporter`)** | Dùng `android.graphics.pdf.PdfDocument` vẽ từng dòng cố định tọa độ `y` | `AllocatedMonthlySummary` hoặc `List<MemberCardSummary>` | Khổ A4 dọc (`595 × 842 pt`) | 1. Đang cắt chuỗi tên hội viên (`.take(28)`) và mã HĐ (`.take(18)`).<br>2. Sang trang mới không lặp lại tiêu đề báo cáo & tiêu đề cột.<br>3. Thiếu chân trang đánh số `Trang X / Y`, thiếu bảng tổng kết đầu trang, thiếu dòng `TỔNG CỘNG` cuối bảng, tiền tệ chưa căn phải. | Giữ nguyên cơ chế tạo PDF offline bằng `PdfDocument` và chia sẻ qua `FileProvider` |
| **6. Xuất Excel (`ReportExporter`)** | Xuất chuỗi văn bản `.csv` kèm UTF-8 BOM | `AllocatedMonthlySummary` hoặc `List<MemberCardSummary>` | File `.csv` đơn phẳng | Đang dùng CSV giả dạng Excel (`.csv`), không có định dạng cột, không có nhiều Sheet, không có `Freeze Panes`, `AutoFilter` hay công thức `SUM`. | Thay thế hoàn toàn bằng bộ tạo `.xlsx` chuẩn OpenXML |

---

## 2. Trải Nghiệm Người Dùng & Thiết Kế Báo Cáo (PDF & XLSX)

### 2.1. Thiết kế File PDF Quản Trị Chuyên Nghiệp
- **Khổ trang & Bố cục**: A4 chuẩn (`595 × 842 pt`), lề chuẩn quản trị, ưu tiên mật độ dữ liệu rõ ràng:
  1. **Khối Tiêu đề (Header)**:
     - Tên đơn vị: `89 FITNESS & YOGA`
     - Tên báo cáo (in đậm, rõ ràng theo đúng tên chuẩn).
     - Kỳ báo cáo (`Tháng MM/YYYY`), Ngày xuất (`dd/MM/yyyy`), Đơn vị tiền tệ (`VND`).
  2. **Khối Tổng hợp số liệu (Executive Summary Box)**:
     - Hiển thị các chỉ tiêu tổng hợp thực tế của báo cáo ngay đầu trang 1 (Tổng số hợp đồng/giao dịch, Tổng giá trị hợp đồng, Tổng doanh thu phân bổ hoặc Tổng thực thu, Tiền mặt, Chuyển khoản, Trạng thái đối chiếu).
  3. **Bảng dữ liệu chi tiết đa trang**:
     - **Tự động xuống dòng (Multi-line text wrapping)**: Đo chiều rộng thực tế bằng `Paint.measureText` để tự động ngắt dòng tên hội viên và mã hợp đồng dài, tuyệt đối không dùng `.take(...)` cắt mất chữ.
     - **Tính chiều cao dòng động**: Kiểm tra chiều cao dòng trước khi vẽ; nếu vượt quá vùng trang hiện tại thì chuyển sang trang mới trọn vẹn (không cắt đôi dòng dữ liệu giữa 2 trang).
     - **Lặp lại tiêu đề trên mỗi trang**: Khi sang trang `2..N`, tự động vẽ lại thanh tiêu đề thu gọn của báo cáo và hàng tiêu đề cột của bảng.
     - **Căn lề chuẩn tài chính**: Căn giữa `STT`, `Ngày tháng`; căn trái `Mã hợp đồng`, `Hội viên`; căn phải toàn bộ cột số tiền (`Giá trị hợp đồng`, `Doanh thu phân bổ`, `Thực thu`, `Tiền mặt`, `Chuyển khoản`).
     - **Dòng TỔNG CỘNG cuối bảng**: Nền nhấn nhẹ, chữ in đậm, căn phải tổng số tiền khớp tuyệt đối với khối Tổng hợp.
  4. **Chân trang (Footer)**:
     - Kẻ đường phân cách mảnh ở cuối mỗi trang, ghi tên báo cáo, thời점 xuất và số trang chính xác `Trang X / Tổng số trang` (nhờ bước tiền tính toán bố cục trang trước khi render).

### 2.2. Thiết kế Workbook Excel `.xlsx` Thực Sự
- Mỗi file `.xlsx` là một gói OpenXML hợp lệ (`.xlsx`) có:
  - **Định dạng chuyên nghiệp**: Phông chữ chuẩn hỗ trợ tiếng Việt Unicode, hàng tiêu đề màu sắc tiết chế theo nhóm dịch vụ, đường viền mảnh cho toàn bộ ô dữ liệu, định dạng số tiền `#,##0 "đ"`, định dạng ngày `dd/MM/yyyy`.
  - **Tiện ích bảng tính**:
    - **Freeze Panes**: Cố định hàng tiêu đề bảng khi cuộn dọc.
    - **AutoFilter**: Bật bộ lọc tự động trên toàn bộ các cột của bảng dữ liệu chi tiết.
    - **Auto-Fit Column Width**: Tự động tính độ rộng cột dựa trên độ dài nội dung thực tế (không làm khuất tên hội viên, mã hợp đồng hay số tiền lớn).
    - **Công thức Excel (`SUM`)**: Dòng tổng cộng sử dụng công thức `SUM(...)` kèm giá trị đã tính sẵn, bảo đảm khớp 100% với số liệu trên ứng dụng và PDF.
- **Cấu trúc Sheet theo từng loại báo cáo**:
  1. **Báo cáo Doanh thu phân bổ GYM / YOGA (Mục 1, 2, 5, 6, 7, 8)**:
     - `Sheet 1 - Tổng quan`: Thông tin đơn vị, kỳ báo cáo, bảng tổng hợp số lượng khoản mục và tổng doanh thu phân bổ theo từng nhóm.
     - `Sheet 2 - Chi tiết hợp đồng`: Đầy đủ cột `STT dòng`, `Mã hợp đồng`, `Mã STT HV`, `Hội viên`, `Hạng mục`, `Ngày bắt đầu`, `Ngày kết thúc`, `Giá trị hợp đồng (VND)`, `Tổng ngày/buổi`, `Thực tế trong kỳ`, `Doanh thu phân bổ (VND)` và dòng `TỔNG CỘNG` (`=SUM(...)`).
     - `Sheet 3 - Đối chiếu`: Đối chiếu tổng doanh thu phân bổ từ bảng chi tiết với tổng từng nhóm hạng mục trên ứng dụng (`Chênh lệch = 0`).
  2. **Báo cáo Doanh thu phân bổ PT — 50% phòng tập (Mục 3)**:
     - `Sheet 1 - Tổng quan`: Tổng số hợp đồng PT phát sinh buổi tập trong tháng, tổng số buổi hoàn thành trong kỳ, tổng giá trị phân bổ 50% phòng tập.
     - `Sheet 2 - Phân bổ theo HĐ PT`: Chi tiết từng hợp đồng PT (`Mã hợp đồng`, `Mã STT HV`, `Hội viên`, `Ngày đăng ký`, `Giá trị hợp đồng`, `Tổng số buổi`, `Buổi hoàn thành trong kỳ`, `Tỷ lệ phòng tập (50%)`, `Doanh thu phân bổ (VND)`).
     - `Sheet 3 - Chi tiết buổi tập PT`: Danh sách từng buổi tập hoàn thành trong kỳ (`STT`, `Ngày tập`, `Mã hợp đồng`, `Mã STT HV`, `Hội viên`, `Ghi chú buổi tập`, `Giá trị phân bổ buổi (50%)`).
  3. **Báo cáo Doanh thu Vé lẻ (Mục 4)**:
     - `Sheet 1 - Tổng quan`: Tổng số giao dịch vé ngày, vé tuần, tổng số lượng vé bán và tổng doanh thu vé lẻ trong kỳ.
     - `Sheet 2 - Chi tiết vé lẻ`: `STT`, `Ngày bán`, `Loại vé`, `Số lượng`, `Đơn giá (VND)`, `Thành tiền (VND)`, `Phương thức thanh toán`.
  4. **Báo cáo Dòng tiền tháng**:
     - `Sheet 1 - Tổng quan`: Tổng thực thu, Thực thu Tiền mặt, Thực thu Chuyển khoản, Doanh thu thực thu theo dịch vụ (`GYM`, `YOGA`, `PT`, `Vé lẻ`) và theo phương thức (`Tiền mặt`, `Chuyển khoản`, `Kết hợp`).
     - `Sheet 2 - Chi tiết giao dịch`: `STT`, `Ngày thanh toán`, `Dịch vụ`, `Mã HĐ / Loại vé`, `Hội viên / Nội dung`, `Phương thức TT`, `Tiền mặt (VND)`, `Chuyển khoản (VND)`, `Số tiền thanh toán (VND)`.
     - `Sheet 3 - Đối chiếu TM & CK`: Kiểm tra công thức bắt buộc `Tổng thực thu = Tiền mặt + Chuyển khoản` trên toàn kỳ và từng giao dịch; liệt kê chi tiết bất kỳ giao dịch nào có chênh lệch (nếu có) mà không tự ý sửa số liệu gốc.
  5. **Danh sách Hội viên GYM / YOGA**:
     - `Sheet 1 - Tổng quan`: Tổng số hồ sơ, số hội viên còn hạn, sắp hết hạn, hết hạn hôm nay, quá hạn.
     - `Sheet 2 - Danh sách hội viên`: Chi tiết từng hội viên kèm hợp đồng hiện tại, ngày đăng ký, ngày hết hạn, trạng thái và số ngày còn/quá hạn.

---

## 3. Kiến Trúc Kỹ Thuật & Luồng Dữ Liệu

```
┌─────────────────────────────────────────────────────────────────────────┐
│                   Room SQLite Local Database (Offline)                  │
│   ContractRecord  │  PtSessionRecord  │  SingleTicketRecord  │  Member  │
└─────────┬───────────────────┬────────────────────┬───────────────┬──────┘
          │                   │                    │               │
          ▼                   ▼                    ▼               ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                         FitnessCalculator.kt                            │
│  • computeAllocatedMonthlySummary() -> AllocatedMonthlySummary          │
│    - GYM/YOGA: packageValue * overlapDays / totalDays (roundToLong)     │
│    - PT: (packageValue / totalSessions) * completedInMonth * 50%        │
│    - SingleTicket: unitPrice * quantity                                 │
│  • computeMonthlyCashflow() -> MonthlyCashflowSummary                   │
│    - Kiểm tra bắt buộc: totalCashflow == actualCash + actualTransfer    │
│    - Phát hiện & ghi nhận CashflowDiscrepancy (không tự ý sửa dữ liệu)  │
└─────────────────────────┬───────────────────────────────┬───────────────┘
                          │                               │
                          ▼                               ▼
┌───────────────────────────────────────┐ ┌───────────────────────────────┐
│        ReportExporter (PDF)           │ │  XlsxWorkbookWriter (.xlsx)   │
│  • Bố cục quản trị A4 đa trang        │ │  • Chuẩn OpenXML ZIP (.xlsx)  │
│  • Tự động ngắt dòng (không cắt chữ)  │ │  • Multi-sheet theo nghiệp vụ │
│  • Lặp lại Header mỗi trang           │ │  • Định dạng VND & dd/MM/yyyy │
│  • Căn phải số tiền + Dòng TỔNG CỘNG  │ │  • AutoFilter + Freeze Panes  │
│  • Chân trang "Trang X / Y"           │ │  • Công thức SUM() + Đối chiếu│
└───────────────────────────────────────┘ └───────────────────────────────┘
```

---

## 4. Kế Hoạch Kiểm Thử & Đối Chiếu Tự Động (Robolectric)

Bộ kiểm thử tự động trong `ExampleRobolectricTest.kt` sẽ kiểm tra đầy đủ tất cả các kịch bản bắt buộc trong Mục 7 của đề bài:
1. **Doanh thu phân bổ GYM/YOGA (7 kịch bản)**:
   - Hợp đồng mới trong kỳ, hợp đồng cũ giao một phần kỳ, hợp đồng gia hạn trong kỳ, một hội viên xuất hiện đồng thời ở cả báo cáo Còn hạn & ĐK mới và báo cáo Gia hạn (2 hợp đồng nối tiếp trong cùng tháng), hợp đồng ngoài kỳ, hợp đồng xóa mềm, và bảo toàn giá lịch sử khi bảng giá Settings thay đổi.
2. **Doanh thu phân bổ PT (8 kịch bản)**:
   - Hợp đồng PT cố định số buổi, tập nhiều buổi trong tháng, không tập trong tháng, buổi hoàn thành, buổi bị xóa mềm, khử trùng buổi tập, hợp đồng tập hết số buổi, và kiểm tra tỷ lệ 50% phòng tập.
3. **Báo cáo Dòng tiền & Đối chiếu (6 kịch bản)**:
   - Tiền mặt, chuyển khoản, kết hợp, ngày thanh toán khác tháng đăng ký, đối chiếu `Tổng thực thu = Tiền mặt + Chuyển khoản`, và phát hiện cảnh báo khi có giao dịch lệch (`CashflowDiscrepancy`) mà không tự ý sửa dữ liệu gốc.
4. **Kiểm thử File xuất PDF & XLSX (10 kịch bản)**:
   - Xuất PDF 1 trang và nhiều trang (dữ liệu lớn > 60 dòng), tên hội viên dài, mã hợp đồng dài; kiểm tra cấu trúc ZIP OpenXML `.xlsx` hợp lệ (`[Content_Types].xml`, `xl/workbook.xml`, `xl/styles.xml`, các `sheet*.xml`), kiểm tra đầy đủ các Sheet và đối chiếu tổng tiền trên PDF, XLSX khớp tuyệt đối 100% với `AllocatedMonthlySummary` và `MonthlyCashflowSummary`.
