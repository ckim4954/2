# Kế Hoạch Chuyển Đổi Kiến Trúc Offline-First (Room SQLite) & Bỏ Đăng Nhập Bắt Buộc Khi Khởi Động

## 1. Mục Tiêu Cốt Lõi
- **Vào thẳng Màn hình chính (8 Menu) ngay khi mở ứng dụng**: Loại bỏ hoàn toàn màn hình đăng nhập Google bắt buộc khi khởi động (`AuthScreen` không còn chặn ở `MainActivity`). Ứng dụng hoạt động 100% khi không có Internet và chưa đăng nhập Google.
- **Cơ sở dữ liệu Local bền vững (Room SQLite) là Nguồn dữ liệu chính (Single Source of Truth)**:
  - Toàn bộ 8 menu (1. GYM, 2. YOGA, 3. Tạo hợp đồng, 4. Doanh thu, 5. Theo dõi hội viên, 6. Quản lí PT, 7. Cài đặt, 8. Thùng rác) chỉ đọc và ghi trực tiếp vào **Room Database** (`89_fitness_local.db`) lưu trên bộ nhớ thiết bị.
  - Khi đóng ứng dụng, tắt mạng hoặc khởi động lại điện thoại, toàn bộ dữ liệu hội viên, hợp đồng, buổi tập PT, vé lẻ, thùng rác và bảng giá đều còn nguyên vẹn.
- **Chuyển Đăng nhập Google vào duy nhất mục Cài đặt → 3. Đồng bộ – Sao lưu – Khôi phục**:
  - Không tự động gọi Google Sign-In khi mở app.
  - Khi chưa đăng nhập: Hiển thị nút **"Đăng nhập Google để sử dụng đồng bộ và sao lưu"**.
  - Khi đã đăng nhập: Hiển thị email tài khoản Google đang kết nối, trạng thái đồng bộ, thời gian đồng bộ gần nhất, các nút **Sao lưu lên Cloud**, **Khôi phục từ Cloud** (có cảnh báo xác nhận trước), **Lưu lên Google Drive** và **Đăng xuất Google** (đăng xuất không xóa dữ liệu local).

---

## 2. Thiết Kế Kiến Trúc Kỹ Thuật (Offline-First)

### A. Tầng Dữ Liệu Local — Room Database (`app/src/main/java/com/example/data/local/`)
1. **Kích hoạt Room & KSP trong `app/build.gradle.kts`**:
   - Bỏ comment các dependency Room đã có sẵn trong Version Catalog:
     - `implementation(libs.androidx.room.runtime)`
     - `implementation(libs.androidx.room.ktx)`
     - `"ksp"(libs.androidx.room.compiler)`
2. **Định nghĩa 5 Bảng Entity trong `FitnessLocalEntities.kt`**:
   - `LocalMemberEntity` (bảng `members`): lưu hồ sơ GYM, YOGA, PT, STT bất biến, trạng thái xóa mềm (`isDeleted`, `deletedAtEpoch`, `deletedBatchId`), `updatedAtEpoch`.
   - `LocalContractEntity` (bảng `contracts`): lưu hợp đồng GYM, YOGA, PT, bản chụp thông tin hội viên lúc tạo, giá trị gói, thanh toán, số buổi PT, trạng thái xóa mềm, `updatedAtEpoch`.
   - `LocalPtSessionEntity` (bảng `pt_sessions`): lưu buổi tập PT, ngày tập, ghi chú, trạng thái xóa mềm, `updatedAtEpoch`.
   - `LocalSingleTicketEntity` (bảng `single_tickets`): lưu giao dịch vé ngày/vé tuần, số lượng, đơn giá, phương thức thanh toán, trạng thái xóa mềm, `updatedAtEpoch`.
   - `LocalStudioConfigEntity` (bảng `studio_config`, khóa chính `"main_config"`): lưu bộ đếm STT tự tăng (`lastGymStt`, `lastYogaStt`, `lastPtStt`), bảng giá 4 khung (GYM Nam, GYM Nữ, Trẻ em, YOGA), chế độ Sáng/Tối (`isDarkMode`), thời điểm đồng bộ/sao lưu gần nhất (`lastSyncEpoch`).
3. **DAO & Database (`FitnessLocalDao.kt` & `FitnessLocalDatabase.kt`)**:
   - Cung cấp các `Flow<List<...>>` phản ứng tức thì cho giao diện Compose và các hàm `@Transaction` đảm bảo tính toàn vẹn khi tạo hội viên + hợp đồng, ghi/xóa buổi tập PT, xóa mềm đồng bộ vào Thùng rác và khôi phục.
4. **Kiểm tra tính toàn vẹn dữ liệu (`BackupBundle` & `IntegrityValidator`)**:
   - Trước khi xuất sao lưu hoặc trước khi khôi phục (từ file `.json` hoặc từ Cloud), hệ thống kiểm tra tính hợp lệ của cấu trúc gói sao lưu (phiên bản, danh sách hồ sơ, hợp đồng, buổi tập, vé lẻ, cấu hình bảng giá, đối chiếu bộ đếm STT tối thiểu) để không bao giờ ghi dữ liệu hỏng vào Room Database.

### B. Tầng Repository Offline-First & Đồng Bộ Cloud Tùy Chọn (`FitnessRepository.kt`)
1. **Mọi thao tác nghiệp vụ đọc/ghi trên Local Room Database**:
   - `observeMembers()`, `observeContracts()`, `observePtSessions()`, `observeSingleTickets()`, `observeStudioConfig()` đọc trực tiếp từ `FitnessLocalDao` — hoạt động tức thì với độ trễ bằng 0 và không cần Internet hay tài khoản Firebase.
2. **Đồng bộ & Sao lưu Cloud tùy chọn (chỉ chạy khi người dùng bấm nút trong Cài đặt)**:
   - `backupLocalToCloud()`: Kiểm tra đã đăng nhập Google chưa -> Kiểm tra tính toàn vẹn dữ liệu local -> Đẩy bản sao lưu từ Room Database lên Firestore dưới không gian `/users/{uid}/...` -> Cập nhật `lastSyncEpoch`.
   - `fetchCloudBackupPreview()` & `restoreFromCloudToLocal()`: Tải dữ liệu từ Firestore của tài khoản Google đã đăng nhập, kiểm tra tính toàn vẹn và chỉ cập nhật vào Room Database **sau khi người dùng xác nhận hộp thoại cảnh báo**.
   - Đăng nhập Google thành công chỉ kết nối tài khoản, **tuyệt đối không tự động ghi đè hay xóa dữ liệu local**.

### C. Luồng Khởi Động & Giao Diện Cài Đặt (`MainActivity.kt`, `HomeScreen.kt`, `SettingsScreen.kt`)
1. **`MainActivity.kt`**:
   - Loại bỏ hoàn toàn nhánh kiểm tra `if (user == null) AuthScreen(...)`.
   - Khi mở app, khởi tạo ngay `FitnessViewModel` gắn với `FitnessLocalDatabase` và hiển thị thẳng `HomeScreen` (8 menu).
2. **`HomeScreen.kt`**:
   - Cập nhật dòng trạng thái dưới tiêu đề thành trạng thái dữ liệu Local bền vững (kèm trạng thái đã liên kết Google nếu có), bỏ nút đăng xuất ở màn hình chính để gom toàn bộ quản lý tài khoản Google về đúng mục **Cài đặt**.
3. **`SettingsScreen.kt` (Mục 3: Đồng bộ — Sao lưu — Khôi phục)**:
   - **Trạng thái Chưa đăng nhập Google**:
     - Hiển thị rõ: *"Đang sử dụng chế độ Offline (dữ liệu lưu an toàn trên thiết bị)"*.
     - Hiển thị nút **"Đăng nhập Google để sử dụng đồng bộ và sao lưu"**.
   - **Trạng thái Đã đăng nhập Google**:
     - Hiển thị email tài khoản Google đang kết nối.
     - Hiển thị trạng thái đồng bộ và thời gian đồng bộ gần nhất.
     - Nút **"Sao lưu dữ liệu Local lên Cloud"**, **"Khôi phục từ Cloud về máy"** (luôn cảnh báo & yêu cầu xác nhận trước), **"Lưu file lên Google Drive"**, và nút **"Đăng xuất Google"** (giữ nguyên toàn bộ dữ liệu local).

---

## 3. Kiểm Thử Bắt Buộc (Robolectric & Unit Tests)
Bổ sung kiểm thử tự động trong `ExampleRobolectricTest.kt` để xác minh cả 7 kịch bản bắt buộc:
1. Mở app mới chưa đăng nhập Google -> vào thẳng màn hình chính 8 menu.
2. Môi trường Offline -> tạo hội viên GYM/YOGA/PT, tạo hợp đồng, ghi buổi tập PT, bán vé lẻ, tính doanh thu, xóa mềm vào Thùng rác và khôi phục hoạt động đầy đủ.
3. Đóng và mở lại Database instance -> dữ liệu đã lưu trên Room SQLite vẫn còn nguyên vẹn.
4. Kiểm tra mục Cài đặt hiển thị đúng nút `"Đăng nhập Google để sử dụng đồng bộ và sao lưu"` khi chưa đăng nhập.
5. Đăng nhập thất bại hoặc đăng xuất Google -> dữ liệu local trong Room Database không bị ảnh hưởng hay mất mát.
6. Sao lưu ra gói `.json` (hoặc Cloud bundle), kiểm tra tính toàn vẹn và khôi phục lại vào Room Database chính xác 100%.
