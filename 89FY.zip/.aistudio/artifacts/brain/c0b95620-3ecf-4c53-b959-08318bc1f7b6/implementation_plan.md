# 89 FITNESS & YOGA — Kế Hoạch Triển Khai Ứng Dụng Quản Lý Phòng Tập

Ứng dụng quản lý vận hành toàn diện dành riêng cho **89 FITNESS & YOGA**, chuẩn hóa quy trình quản lý hồ sơ hội viên GYM/YOGA/PT, tạo hợp đồng & vé lẻ, tính toán doanh thu phân bổ theo ngày/buổi tách biệt với dòng tiền thực nhận, xuất báo cáo PDF/Excel và sao lưu đồng bộ an toàn.

---

## Xác Nhận Nghiệp Vụ & Quyết Định Quan Trọng

> [!IMPORTANT]
> Toàn bộ 6 điểm cần làm rõ trong tài liệu nghiệm thu (`04_Giao_dien_va_nghiem_thu.md`) đã được xác nhận và khóa quy tắc trước khi lập trình:

- **Chính sách làm tròn doanh thu phân bổ**: Làm tròn đến **hàng đồng (VND)** cho từng hợp đồng riêng lẻ (`roundToLong()`) trước khi cộng vào tổng báo cáo tháng.
- **Xử lý khi xóa hồ sơ hội viên**: Thực hiện **xóa mềm đồng bộ (cascade soft-delete)** — khi xóa hồ sơ, cả hồ sơ và các hợp đồng/buổi tập liên quan đều được chuyển vào đúng danh mục tương ứng trong **Thùng rác** và gắn mã liên kết để khi khôi phục sẽ phục hồi nguyên vẹn quan hệ.
- **Hiệu lực hợp đồng PT & quyền sửa/xóa buổi tập**: Khi số buổi đã tập đạt tổng số buổi của gói (`buổi còn lại = 0`), hợp đồng PT **tự động chuyển sang trạng thái hết hiệu lực (Hoàn thành)** để mở khóa cho phép tạo hợp đồng PT gia hạn mới. Cho phép **chỉnh sửa ngày/ghi chú hoặc xóa mềm buổi tập PT** (có bước xác nhận trước khi lưu/xóa) và tự động tính lại số buổi đã tập/còn lại cùng trạng thái hợp đồng.
- **Đồng bộ Online & xử lý xung đột**: Hỗ trợ **đồng bộ Cloud tự động (Firebase Firestore kèm xác thực Google)** kết hợp **sao lưu/khôi phục file trên Google Drive & Offline**, áp dụng quy tắc **ưu tiên bản ghi có thời점 cập nhật mới nhất (`updatedAt` — Last-Write-Wins)** khi nhiều thiết bị cùng chỉnh sửa, và luôn cảnh báo + yêu cầu xác nhận trước khi khôi phục đè dữ liệu.
- **Phạm vi hủy hợp đồng & hoàn tiền**: **Không thêm chức năng hủy hợp đồng hoặc hoàn tiền** ngoài phạm vi PRD; mọi điều chỉnh thông tin hoặc thanh toán được thực hiện qua chức năng **Chỉnh sửa hợp đồng/hồ sơ có bước Xem lại & Xác nhận**.

---

## 1. Tổng Quan & Giá Trị Cốt Lõi

- **Mục tiêu sản phẩm**: Cung cấp công cụ quản lý chuẩn xác trên điện thoại Android cho chủ phòng tập và quản lý vận hành **89 FITNESS & YOGA**, tách bạch rõ ràng giữa các phân khu GYM, YOGA, PT và Vé lẻ.
- **Đối tượng sử dụng**: Chủ phòng tập và nhân viên quản lý quầy lễ tân tại 89 Fitness & Yoga thao tác hàng ngày trên điện thoại.
- **Giá trị cốt lõi**:
  - **Bảo toàn định danh & lịch sử**: STT tự tăng độc lập cho từng mảng (`GYM`, `YOGA`, `PT`), mã hợp đồng bất biến (`<LOẠI>-STT<n>-<số thứ tự HĐ>`), gia hạn hoặc đổi bảng giá không bao giờ làm thay đổi STT hay ghi đè hợp đồng lịch sử.
  - **Tài chính minh bạch kép**: Tách biệt hoàn toàn **Doanh thu phân bổ tháng** (tính theo số ngày hiệu lực thực tế giao với tháng báo cáo hoặc 50% giá trị buổi PT thực tập trong tháng) và **Doanh thu dòng tiền tháng** (tính theo ngày thực tế nhận tiền mặt/chuyển khoản/kết hợp).
  - **An toàn dữ liệu tuyệt đối**: Mọi thao tác thêm/sửa đều qua màn hình **Xem lại & Xác nhận**; mọi thao tác xóa đều là **xóa mềm vào Thùng rác 8 danh mục** trước khi có thể xóa vĩnh viễn.

---

## 2. Trải Nghiệm Người Dùng & Thiết Kế Giao Diện

### Luồng Điều Hướng 8 Menu Chính
Màn hình Trang chủ (`89 FITNESS & YOGA`) hiển thị đúng **8 menu chính** (không tự ý thêm menu cấp cao ngoài quy định):
1. **GYM**: Tổng số hồ sơ GYM (đếm hồ sơ, không đếm hợp đồng), nút xuất Excel/PDF, thanh tìm kiếm 1 dòng (`STT / Họ tên / SĐT`), nút mũi tên mở **5 nhóm tùy chọn** (Sắp xếp, Lọc thời hạn, Lọc nhóm Nam/Nữ/Trẻ em, Lọc ngày đăng ký, Tùy chọn hiển thị) và nút Thêm (`+`). Danh sách thẻ hội viên hiển thị đầy đủ họ tên không cắt cụt, trạng thái xanh lá (còn hạn) / đỏ (hết hạn hoặc hết hạn hôm nay), ngày hết hạn và nút **Gia hạn**. Nhấn vào hội viên mở **Chi tiết hội viên** gồm: Thông tin cá nhân, Hợp đồng hiện tại và Lịch sử hợp đồng (nhấn vào từng hợp đồng cũ xem đầy đủ chi tiết gốc tại thời điểm tạo).
2. **YOGA**: Cấu trúc tương đồng GYM nhưng mang chủ đề **màu Tím**, dùng dãy STT YOGA độc lập và **không có bộ lọc nhóm Nam/Nữ/Trẻ em** (chỉ có 4 nhóm tùy chọn: Sắp xếp, Lọc thời hạn, Lọc ngày đăng ký, Tùy chọn hiển thị).
3. **TẠO HỢP ĐỒNG**: Có đúng 4 lựa chọn: **GYM**, **YOGA**, **PT**, **VÉ LẺ**.
   - Với **GYM / YOGA**: Không hiển thị danh sách mặc định; người dùng tìm kiếm trước theo STT/tên/SĐT. Nếu tìm thấy hồ sơ cũ → hiển thị thông tin + lịch sử và chuyển sang tạo hợp đồng gia hạn (giữ nguyên STT, tăng đuôi mã hợp đồng `-002`, `-003`...). Nếu chưa có → tạo hồ sơ mới, cấp STT tiếp theo và tạo hợp đồng đầu tiên (`-001`).
   - Với **PT**: Tìm hồ sơ PT hoặc tạo mới (cấp STT PT). Kiểm tra ràng buộc **mỗi hội viên chỉ có tối đa 1 hợp đồng PT đang hiệu lực**. Nếu đã có hợp đồng còn buổi, hệ thống chặn tạo hợp đồng song song. Nếu đủ điều kiện, nhập số buổi tùy chỉnh, giá trị gói, ngày đăng ký, số tiền thanh toán và phương thức thanh toán.
   - Với **VÉ LẺ**: Chọn loại vé (Vé ngày / Vé tuần), ngày bán (Date Picker), số lượng (mặc định 1, có nút `+/-`), đơn giá, tổng tiền tự động (`Số lượng × Đơn giá`), phương thức thanh toán. Không tạo hồ sơ hay STT.
4. **DOANH THU**: Có đúng 3 nhánh:
   - **Doanh thu phân bổ**: Chọn Tháng/Năm, xem **8 báo cáo** gồm 5 báo cáo GYM (`Còn hạn và đăng ký mới`, `Gia hạn`, `PT (50% phần phòng tập)`, `Vé lẻ`, `Tổng doanh thu phân bổ GYM`) và 3 báo cáo YOGA (`Còn hạn và đăng ký mới`, `Gia hạn`, `Tổng doanh thu phân bổ YOGA`).
   - **Doanh thu dòng tiền tháng**: Chọn Tháng/Năm, tổng hợp tiền thực nhận theo ngày giao dịch, bóc tách theo dịch vụ (`GYM / YOGA / PT / Vé lẻ`) và theo phương thức (`Tiền mặt / Chuyển khoản / Kết hợp`) kèm danh sách giao dịch chi tiết.
   - **Xuất báo cáo**: Chọn 1 trong 8 báo cáo doanh thu phân bổ → chọn Tháng/Năm → chọn 1 trong 3 thao tác riêng biệt: **PDF**, **Excel (.xlsx/.csv tương thích Excel)**, hoặc **Chia sẻ nhanh** (mở Android Share Sheet gửi qua Zalo, Gmail...).
5. **THEO DÕI HỘI VIÊN**: Bắt buộc bước 1 chọn **GYM** hoặc **YOGA**; bước 2 chọn 1 trong 3 loại danh sách: **Còn hạn**, **Hết hạn**, **Sắp hết hạn trong 7 ngày**. Danh sách không tự sinh khi mới mở menu và không có mục "Tất cả". Sau khi tạo danh sách có thanh tìm kiếm nhanh bên trong.
6. **QUẢN LÍ PT**: Chia làm 3 tab/nhóm chức năng:
   - **Hội viên PT**: Tìm kiếm, xem và chỉnh sửa hồ sơ hội viên PT.
   - **Hợp đồng PT**: Xem hợp đồng hiện tại, lịch sử hợp đồng, số buổi đã tập/còn lại, tạo hợp đồng gia hạn khi hợp đồng cũ đã hết buổi.
   - **Buổi tập**: Chọn hội viên → kiểm tra hợp đồng hiệu lực và kiểm tra ràng buộc **tối đa 1 buổi PT/người/ngày** → ghi nhận buổi tập mới hoặc sửa/xóa mềm buổi tập đã ghi nhận (có xác nhận), cập nhật tức thời số buổi đã tập/còn lại.
7. **CÀI ĐẶT**: Đúng 3 mục:
   - **Bảng giá**: Hiển thị 4 khung có viền và màu sắc đặc trưng: **GYM Nam (Xanh lá)**, **GYM Nữ (Hồng)**, **Trẻ em (Cam)**, **YOGA (Tím)**. Cho phép sửa giá kèm bước xác nhận trước khi lưu; chỉ áp dụng cho hợp đồng tạo mới.
   - **Giao diện sáng/tối**: Chuyển đổi tức thời Light / Dark Mode toàn ứng dụng và lưu trạng thái bền vững.
   - **Đồng bộ — Sao lưu — Khôi phục**: Gồm chế độ **Offline** (Xuất file sao lưu JSON/ZIP ra bộ nhớ máy, Chọn file nhập & Khôi phục) và **Online** (Kết nối tài khoản Google, Đồng bộ tự động & thủ công lên Cloud/Google Drive, Khôi phục từ bản sao lưu online, hiển thị rõ trạng thái đồng bộ thực tế).
8. **THÙNG RÁC**: Đúng 8 danh mục độc lập: `1. Hội viên GYM`, `2. Hội viên YOGA`, `3. Hợp đồng GYM`, `4. Hợp đồng YOGA`, `5. Hồ sơ PT`, `6. Hợp đồng PT`, `7. Vé lẻ`, `8. Dữ liệu khác` (bao gồm các buổi tập PT đã xóa mềm). Cho phép **Khôi phục** (tái lập đầy đủ liên kết) hoặc **Xóa vĩnh viễn** (có hộp thoại cảnh báo xác nhận).

### Định Hướng Thẩm Mỹ & Hệ Màu Sắc
- **Phong cách thiết kế**: *Athletic Precision* — hiện đại, sắc nét, độ tương phản cao, tối ưu thao tác một tay trên màn hình dọc điện thoại.
- **Bảng màu ngữ nghĩa (Semantic Color Tokens)**:
  - **GYM Primary**: Xanh lá năng lượng (`#16A34A` Light / `#4ADE80` Dark).
  - **YOGA Primary**: Tím thanh lịch (`#7C3AED` Light / `#C084FC` Dark).
  - **Khung bảng giá**: GYM Nam Xanh lá (`#16A34A`), GYM Nữ Hồng (`#EC4899`), Trẻ em Cam (`#F97316`), YOGA Tím (`#7C3AED`).
  - **Trạng thái thời hạn**: Còn hạn Xanh lá (`#15803D`), Sắp hết hạn Vàng cam (`#D97706`), Hết hạn / Hết hạn hôm nay Đỏ (`#DC2626`).
- **Typography & Bố cục**:
  - Sử dụng bộ font Google Fonts cài đặt cục bộ (`Be Vietnam Pro` hoặc `Montserrat` cho tiêu đề & con số tài chính, `Plus Jakarta Sans` / `Open Sans` cho nội dung tiếng Việt rõ dấu).
  - Tên hội viên trên mọi thẻ (`Card`) sử dụng `softWrap = true`, `maxLines = Int.MAX_VALUE`, tuyệt đối không dùng `TextOverflow.Ellipsis` cắt cụt tên.

---

## 3. Quyết Định Sản Phẩm & Đánh Đổi Kỹ Thuật

- **Quyết định 1: Kiến trúc Lưu trữ Offline-First kết hợp Cloud Sync**
  - *Giải pháp chọn*: Lưu trữ cục bộ tức thời kết hợp đồng bộ tự động lên **Firebase Firestore** (theo tài khoản Google đăng nhập) và xuất/nhập gói dữ liệu sao lưu chuẩn JSON (hỗ trợ lưu vào Google Drive thông qua SAF / Share hoặc Cloud Backup snapshot).
  - *Lý do*: Đảm bảo ứng dụng hoạt động mượt mà ngay cả khi mạng yếu tại phòng tập, đồng thời đáp ứng đầy đủ yêu cầu kết nối Google để đồng bộ/khôi phục online với quy tắc ưu tiên bản mới nhất (`updatedAt`).
- **Quyết định 2: Bộ tính toán Thời hạn & Doanh thu phân bổ tách rời (Pure Domain Calculator)**
  - *Giải pháp chọn*: Xây dựng động cơ tính toán độc lập xử lý lịch ngày-tháng-năm (`java.time.LocalDate`), quy tắc ngày đăng ký 29/30/31 rơi vào cuối tháng đích (không cộng bù), tính giao thoa khoảng ngày `[startDate, endDate]` với `[firstDayOfMonth, lastDayOfMonth]` tính cả 2 đầu mút, và làm tròn đến hàng đồng cho từng hợp đồng trước khi cộng tổng.
  - *Lý do*: Đảm bảo độ chính xác 100% theo công thức PRD, không làm thay đổi dữ liệu gốc khi xem báo cáo bất kỳ tháng/năm nào.
- **Quyết định 3: Quản lý STT tự tăng bất biến bằng bảng bộ đếm riêng (`SequenceCounter`)**
  - *Giải pháp chọn*: Duy trì bộ đếm `lastIssuedStt` riêng cho `GYM`, `YOGA`, `PT` và `contractSeq` riêng trên từng hồ sơ hội viên.
  - *Lý do*: Ngay cả khi người dùng lọc danh sách, xóa mềm hồ sơ vào Thùng rác hoặc xóa vĩnh viễn, STT đã cấp và các STT tiếp theo không bao giờ bị trùng lặp hay nhảy lùi.

---

## 4. Kiến Trúc Kỹ Thuật & Mô Hình Dữ Liệu

### Sơ Đồ Kiến Trúc Hệ Thống

```
┌───────────────────────────────────────────────────────────────────────────┐
│                   GIAO DIỆN JETPACK COMPOSE (MATERIAL 3)                  │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────────────┐  │
│  │ 1. GYM      │ │ 2. YOGA     │ │ 3. TẠO HĐ   │ │ 4. DOANH THU        │  │
│  │ (Xanh lá)   │ │ (Tím)       │ │ (4 nhánh)   │ │ (Phân bổ/Dòng tiền) │  │
│  └──────┬──────┘ └──────┬──────┘ └──────┬──────┘ └──────────┬──────────┘  │
│  ┌──────┴──────┐ ┌──────┴──────┐ ┌──────┴──────┐ ┌──────────┴──────────┐  │
│  │ 5. THEO DÕI │ │ 6. QUẢN LÍ  │ │ 7. CÀI ĐẶT  │ │ 8. THÙNG RÁC        │  │
│  │ HỘI VIÊN    │ │ PT (3 nhóm) │ │ (Giá/Theme) │ │ (8 danh mục)        │  │
│  └──────┬──────┘ └──────┬──────┘ └──────┬──────┘ └──────────┬──────────┘  │
└─────────┼───────────────┼───────────────┼───────────────────┼─────────────┘
          │               │               │                   │
          ▼               ▼               ▼                   ▼
┌───────────────────────────────────────────────────────────────────────────┐
│                TẦNG QUẢN LÝ TRẠNG THÁI & NGHIỆP VỤ (VIEWMODEL)            │
│  • Bộ kiểm tra hợp lệ (Validation & Bước Xem Lại / Xác Nhận Trước Lưu)    │
│  • Bộ tính thời hạn (29/30/31 -> cuối tháng đích) & phân bổ làm tròn đồng │
│  • Bộ xuất báo cáo PDF (PdfDocument) / Excel (.csv UTF-8 BOM) / Share     │
└────────────────────────────────────┬──────────────────────────────────────┘
                                     │
                                     ▼
┌───────────────────────────────────────────────────────────────────────────┐
│                     TẦNG DỮ LIỆU & ĐỒNG BỘ (REPOSITORY)                   │
│  ┌─────────────────────────────────┐   ┌───────────────────────────────┐  │
│  │ Cơ sở dữ liệu Local & Bộ đếm STT│◄─►│ Đồng bộ Cloud (Google Auth +  │  │
│  │ (Hồ sơ, HĐ, Buổi PT, Vé lẻ, Giá)│   │ Firestore + File Backup/Drive)│  │
│  └─────────────────────────────────┘   └───────────────────────────────┘  │
└───────────────────────────────────────────────────────────────────────────┘
```

### Mô Hình Thực Thể Cốt Lõi
1. **Hồ sơ hội viên (`MemberProfile`)**:
   - `id` (UUID bất biến), `type` (`GYM` | `YOGA` | `PT`), `stt` (Int bất biến theo từng `type`), `fullName`, `phone`, `memberGroup` (`NAM` | `NU` | `TRE_EM` cho GYM, `NONE` cho YOGA/PT), `nextContractSeq` (bộ đếm số thứ tự hợp đồng của hồ sơ), `isDeleted`, `deletedAt`, `deletedBatchId`, `updatedAt`.
2. **Hợp đồng (`ContractRecord`)**:
   - `id` (UUID), `contractCode` (`<LOẠI>-STT<n>-<001>`, bất biến), `memberId` (liên kết `MemberProfile.id`), `memberSttSnapshot`, `memberNameSnapshot`, `memberPhoneSnapshot` (bản chụp thông tin tại thời điểm tạo để sửa hồ sơ không làm sai lịch sử hợp đồng).
   - `serviceType` (`GYM` | `YOGA` | `PT`), `isRenewal` (`false` = Đăng ký mới, `true` = Gia hạn).
   - Với **GYM / YOGA**: `memberGroup`, `durationMonths` (1, 2, 3, 12), `startDate` (`yyyy-MM-dd`), `endDate` (`yyyy-MM-dd`, tính cả ngày đầu & cuối).
   - Với **PT**: `totalSessions` (số buổi tùy chỉnh), `usedSessions` (tự động cập nhật), `ptStatus` (`ACTIVE` khi `usedSessions < totalSessions`, tự động chuyển `COMPLETED` khi hết buổi).
   - Tài chính & Thanh toán: `packageValue` (giá trị gói VND), `paidAmount` (số tiền thanh toán VND), `paymentMethod` (`TRANSFER` mặc định | `CASH` | `COMBINED`), `cashAmount`, `transferAmount` (bắt buộc `cashAmount + transferAmount == paidAmount` khi chọn Kết hợp), `paymentDate`.
   - Xóa mềm: `isDeleted`, `deletedAt`, `deletedBatchId`, `updatedAt`.
3. **Buổi tập PT (`PtSessionRecord`)**:
   - `id`, `contractId`, `memberId`, `sessionDate` (`yyyy-MM-dd` — ràng buộc duy nhất `(memberId, sessionDate)` đối với bản ghi chưa xóa để đảm bảo tối đa 1 buổi/người/ngày), `note`, `isDeleted`, `deletedAt`, `deletedBatchId`, `updatedAt`. When xóa mềm vào Thùng rác sẽ nằm ở danh mục **8. Dữ liệu khác**.
4. **Vé lẻ (`SingleTicketRecord`)**:
   - `id`, `ticketType` (`DAILY` = Vé ngày | `WEEKLY` = Vé tuần), `saleDate` (`yyyy-MM-dd`), `quantity` (mặc định 1), `unitPrice`, `totalAmount` (`quantity * unitPrice`), `paymentMethod`, `cashAmount`, `transferAmount`, `isDeleted`, `deletedAt`, `updatedAt`.
5. **Cấu hình Bảng giá & Cài đặt (`PriceConfig` & `AppSettings`)**:
   - Lưu bảng giá chốt mặc định (GYM Nam: 300k/550k/800k/3tr; GYM Nữ: 250k/450k/700k/2.8tr; Trẻ em: 300k/500k/700k/2.5tr; YOGA: 500k/1tr/1.5tr) có thể chỉnh sửa và đồng bộ, cùng cấu hình giao diện Sáng/Tối.

### Ánh Xạ Tương Tác & Công Thức Nghiệp Vụ
- **Công thức ngày hết hạn GYM/YOGA**:
  - Cộng `durationMonths` vào tháng của `startDate`. Nếu ngày đăng ký là 29/30/31 mà tháng đích không có ngày tương ứng thì lấy ngày cuối tháng đích (không cộng bù). Nếu ngày đăng ký thông thường, ngày hết hạn là ngày tương ứng trừ 1 ngày sao cho khoảng hiệu lực tính cả ngày bắt đầu và ngày kết thúc (như ví dụ PRD: đăng ký 1 tháng từ `15/10` đến `14/11` = 31 ngày hiệu lực; từ `20/11` đến `19/12` = 30 ngày hiệu lực; nếu đăng ký ngày `31/01` gói 1 tháng thì ngày kết thúc theo quy tắc 29/30/31 là cuối tháng 2). Cho phép người dùng xem rõ và chỉnh trên Date Picker trước khi xác nhận.
- **Công thức Doanh thu phân bổ GYM/YOGA (làm tròn đồng từng HĐ)**:
  - Với mỗi hợp đồng chưa xóa có khoảng `[startDate, endDate]` giao với tháng báo cáo `[monthStart, monthEnd]`:
    - `totalValidDays = ChronoUnit.DAYS.between(startDate, endDate) + 1`
    - `overlapDays = ChronoUnit.DAYS.between(max(startDate, monthStart), min(endDate, monthEnd)) + 1` (nếu `> 0`)
    - `allocatedContractRevenue = ((packageValue.toDouble() / totalValidDays) * overlapDays).roundToLong()`
  - Phân loại vào báo cáo `Còn hạn và đăng ký mới` nếu `isRenewal == false`, hoặc `Gia hạn` nếu `isRenewal == true`.
- **Công thức Doanh thu phân bổ PT (50% phần phòng tập, làm tròn đồng từng HĐ)**:
  - Đếm số buổi PT thực tế chưa xóa (`sessionsInMonth`) của hợp đồng đó có `sessionDate` thuộc tháng báo cáo:
    - `ptGrossAllocated = (packageValue.toDouble() / totalSessions) * sessionsInMonth`
    - `gymShareAllocated = (ptGrossAllocated * 0.5).roundToLong()`
  - Chỉ hiển thị và cộng phần 50% của phòng tập vào báo cáo `Doanh thu phân bổ GYM — PT` và `Tổng doanh thu phân bổ GYM`.
- **Cơ chế Xóa mềm đồng bộ & Khôi phục 8 danh mục Thùng rác**:
  - Khi xóa 1 Hồ sơ hội viên (`MemberProfile`), hệ thống sinh một `deletedBatchId` chung, đánh dấu `isDeleted = true` cho hồ sơ đó (vào danh mục 1/2/5) và toàn bộ hợp đồng liên quan (vào danh mục 3/4/6) cùng buổi tập PT liên quan (vào danh mục 8).
  - Khi người dùng bấm **Khôi phục** hồ sơ từ Thùng rác, hệ thống tự động khôi phục các hợp đồng/buổi tập cùng `deletedBatchId`. Nếu người dùng khôi phục lẻ 1 hợp đồng mà hồ sơ gốc đang nằm trong Thùng rác, hệ thống tự động khôi phục luôn hồ sơ gốc để đảm bảo không bao giờ có hợp đồng mồ côi.
