# Kế Hoạch Cập Nhật `google-services.json` (APK Release) & Khắc Phục Luồng Đăng Nhập Google

## 1. Kết Quả Kiểm Tra Hiện Trạng Dự Án
1. **Vị trí chuẩn của `google-services.json`**:
   - Trong cấu trúc dự án Android Gradle hiện tại, vị trí duy nhất mà plugin `com.google.gms.google-services` đọc là `/app/google-services.json`.
   - File hiện tại ở `/app/google-services.json` mới chỉ có 1 OAuth Client (`client_type: 1`) cho khóa Debug (`aedd8ce8672249de3cb203ab40dd6bd9b6b42375`), thiếu OAuth Client của khóa Release (`ae906a9e1e1a0923b6ed90c4457535fd9854280e`).
   - File mới bạn gửi đã có đầy đủ cả 2 khóa SHA-1 (`ae906a9e1e1a0923b6ed90c4457535fd9854280e` cho Release và `aedd8ce8672249de3cb203ab40dd6bd9b6b42375` cho Debug) cùng Web Client ID (`client_type: 3`: `977271810075-327vipthvpio8jtnjsm2tfp7g820ap2o.apps.googleusercontent.com`).
2. **Kiểm tra `package_name` / `applicationId`**:
   - Trong `/app/build.gradle.kts`, `defaultConfig.applicationId` đang là `"com.aistudio.fitness89.k9m2xp"`, khớp chính xác 100% với `"package_name": "com.aistudio.fitness89.k9m2xp"` trong `google-services.json`.
3. **Kiểm tra Gradle Plugin & Dependencies**:
   - Đã khai báo đầy đủ plugin `alias(libs.plugins.google.services)` và bộ 4 thư viện chuẩn trong `/app/build.gradle.kts`:
     - `implementation(libs.firebase.auth)`
     - `implementation(libs.androidx.credentials)`
     - `implementation(libs.androidx.credentials.play.services)`
     - `implementation(libs.googleid)`
4. **Nguyên nhân ứng dụng quay lại màn hình đăng nhập sau khi chọn tài khoản Google**:
   - **Nguyên nhân 1 (Cấu hình OAuth SHA-1 trên APK Release)**: Trước khi cập nhật `google-services.json` mới, APK Release được ký bằng keystore Release có SHA-1 `ae906a9e...` chưa nằm trong `app/google-services.json`. Khi chọn tài khoản Google, Google Play Services từ chối cấp ID Token và đóng hộp thoại chọn tài khoản kèm ngoại lệ `GetCredentialCancellationException` / `GetCredentialException`.
   - **Nguyên nhân 2 (Luồng xử lý trong `AuthScreen.kt` & `MainActivity.kt`)**:
     - Trong `AuthScreen.kt`, hàm `attemptAutoSignIn` tự động chạy trong `LaunchedEffect(Unit)` cùng lúc người dùng có thể bấm nút đăng nhập, dễ gây xung đột request trên `CredentialManager`.
     - Khi `GetSignInWithGoogleOption` trả về ngoại lệ hoặc bị hủy do lỗi cấu hình (`28444` / `DEVELOPER_ERROR` / `16`), khối `catch (e: GetCredentialCancellationException)` đang âm thầm tắt trạng thái loading mà không thử phương thức dự phòng (`GetGoogleIdOption`) hoặc hiển thị thông báo rõ ràng, khiến giao diện quay về màn hình đăng nhập mà không rõ lý do.
     - Trong `MainActivity.kt`, việc chuyển sang màn hình chính phụ thuộc vào việc đọc lại `Firebase.auth.currentUser` thay vì nhận trực tiếp `FirebaseUser` trả về từ `signInWithCredential(...).await()`.
     - Cần bổ sung hàm giải nén `Activity` an toàn từ `Context` (`ContextWrapper`) thay vì ép kiểu cứng `context as Activity`.

---

## 2. Các Công Việc Sẽ Thực Hiện Trên Source Code
1. **Cập nhật `/app/google-services.json` & Dọn dẹp file thừa**:
   - Ghi đè `/app/google-services.json` bằng nội dung file `google-services.json` mới nhất bạn vừa cung cấp.
   - Xóa bản sao đính kèm tạm tại `/public/assets/aistudio/google-services_cf34e22a.json` để không tạo bản sao dư thừa trong dự án.
2. **Củng cố luồng Đăng nhập Google -> Firebase Auth -> Màn hình chính (`AuthScreen.kt` & `MainActivity.kt`)**:
   - Thêm hàm `Context.findActivity(): Activity?` an toàn qua `ContextWrapper`.
   - Tách biệt rõ ràng luồng tự động đăng nhập (`attemptAutoSignIn`) và luồng bấm nút đăng nhập (`onGoogleSignInClicked`), tránh chạy chồng chéo.
   - Hỗ trợ fallback tự động từ `GetSignInWithGoogleOption` sang `GetGoogleIdOption(filterByAuthorizedAccounts = false)` nếu thiết bị/Play Services gặp lỗi tương thích với bottom sheet mặc định.
   - Lấy trực tiếp đối tượng `FirebaseUser` từ kết quả `Firebase.auth.signInWithCredential(authCredential).await().user` và truyền thẳng lên `MainActivity` (`onAuthSuccess(user)`) để chuyển ngay lập tức vào màn hình chính không bị trễ hoặc văng ngược lại màn hình đăng nhập.
   - Hiển thị thông báo chi tiết nếu Firebase Authentication hoặc Google Play Services trả về lỗi cấu hình (ví dụ: chưa bật Google Sign-In provider trên Firebase Console hoặc lệch SHA-1 keystore).
3. **Giữ nguyên 100% giao diện và nghiệp vụ hiện có**:
   - Không thay đổi `applicationId`, không thay đổi giao diện hay logic của 8 menu quản lý hội viên, hợp đồng, doanh thu, PT, cài đặt, thùng rác và dữ liệu Firestore.
4. **Kiểm tra Build & Báo cáo hướng dẫn GitHub Actions**:
   - Chạy `compile_applet` để đảm bảo resource từ `google-services.json` mới (`default_web_client_id`, `project_id`, `google_app_id`) được sinh chính xác và APK biên dịch thành công.
   - Cung cấp báo cáo chi tiết các file đã thay đổi, trạng thái Firebase Authentication, và danh sách các GitHub Secrets / bước cấu hình cần thiết để build APK Release trên GitHub Actions.
