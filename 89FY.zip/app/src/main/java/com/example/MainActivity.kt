package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.AppScreen
import com.example.ui.FitnessViewModel
import com.example.ui.screens.*
import com.example.ui.theme.Fitness89Theme
import com.example.ui.theme.StatusActiveGreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: FitnessViewModel = viewModel(
                factory = FitnessViewModel.Factory(applicationContext)
            )
            Fitness89App(viewModel = viewModel)
        }
    }
}

@Composable
fun Fitness89App(viewModel: FitnessViewModel) {
    val preferences by viewModel.preferencesState.collectAsStateWithLifecycle()
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val snapshot by viewModel.dataSnapshot.collectAsStateWithLifecycle()
    val gymMembers by viewModel.gymMembersFlow.collectAsStateWithLifecycle()
    val yogaMembers by viewModel.yogaMembersFlow.collectAsStateWithLifecycle()
    val ptClients by viewModel.ptClientSummariesFlow.collectAsStateWithLifecycle()
    val gymDebts by viewModel.gymDebtContractsFlow.collectAsStateWithLifecycle()
    val yogaDebts by viewModel.yogaDebtContractsFlow.collectAsStateWithLifecycle()
    val snackbarMessage by viewModel.snackbarMessage.collectAsStateWithLifecycle()
    val pendingExportRequest by viewModel.pendingExportRequest.collectAsStateWithLifecycle()
    val lastSavedExportResult by viewModel.lastSavedExportResult.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    // Android System Folder/File Save Picker (Confirmed Decision 1: CreateDocument)
    val saveExcelLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/vnd.ms-excel")
    ) { uri ->
        if (uri != null) {
            viewModel.completeExportFileToUri(uri)
        } else {
            viewModel.cancelPendingExportRequest()
        }
    }

    val savePdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        if (uri != null) {
            viewModel.completeExportFileToUri(uri)
        } else {
            viewModel.cancelPendingExportRequest()
        }
    }

    LaunchedEffect(pendingExportRequest) {
        val req = pendingExportRequest ?: return@LaunchedEffect
        if (req.asExcel) {
            saveExcelLauncher.launch(req.suggestedFileName)
        } else {
            savePdfLauncher.launch(req.suggestedFileName)
        }
    }

    LaunchedEffect(snackbarMessage) {
        val msg = snackbarMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearMessage()
        }
    }

    // Handle system Back navigation on all secondary screens
    BackHandler(enabled = currentScreen != AppScreen.HomeDashboard) {
        viewModel.navigateBack()
    }

    val trashCount = remember(snapshot) {
        snapshot.members.count { it.isDeleted } +
            snapshot.contracts.count { it.isDeleted } +
            snapshot.pricePlans.count { it.isDeleted } +
            snapshot.ptClients.count { it.isDeleted } +
            snapshot.shortTermTickets.count { it.isDeleted }
    }

    Fitness89Theme(darkTheme = preferences.isDarkMode) {
        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
        ) { _ ->
            Box(modifier = Modifier.fillMaxSize()) {
                when (val screen = currentScreen) {
                    is AppScreen.HomeDashboard -> {
                        HomeDashboardScreen(
                            gymMembers = gymMembers,
                            yogaMembers = yogaMembers,
                            ptClients = ptClients,
                            trashCount = trashCount,
                            preferences = preferences,
                            onNavigate = { viewModel.navigateTo(it) }
                        )
                    }

                    is AppScreen.MemberList -> {
                        val members = if (screen.domain == "GYM") gymMembers else yogaMembers
                        MemberListScreen(
                            domain = screen.domain,
                            initialFilter = screen.initialFilter,
                            members = members,
                            onBack = { viewModel.navigateBack() },
                            onMemberClick = { memberId ->
                                viewModel.navigateTo(AppScreen.MemberDetail(memberId))
                            },
                            onRenewClick = { memberId ->
                                viewModel.navigateTo(
                                    AppScreen.CreateContract(
                                        preselectedDomain = screen.domain,
                                        preselectedService = "RENEWAL",
                                        renewalMemberId = memberId
                                    )
                                )
                            },
                            onCreateNewClick = {
                                viewModel.navigateTo(
                                    AppScreen.CreateContract(
                                        preselectedDomain = screen.domain,
                                        preselectedService = "NEW"
                                    )
                                )
                            },
                            onExportMemberList = { table, asExcel ->
                                viewModel.requestExportFileToDevice(table, asExcel)
                            }
                        )
                    }

                    is AppScreen.MemberDetail -> {
                        val memberSummary = gymMembers.firstOrNull { it.member.id == screen.memberId }
                            ?: yogaMembers.firstOrNull { it.member.id == screen.memberId }
                        MemberDetailScreen(
                            summary = memberSummary,
                            onBack = { viewModel.navigateBack() },
                            onRenewClick = { memberId ->
                                val dom = memberSummary?.member?.domain ?: "GYM"
                                viewModel.navigateTo(
                                    AppScreen.CreateContract(
                                        preselectedDomain = dom,
                                        preselectedService = "RENEWAL",
                                        renewalMemberId = memberId
                                    )
                                )
                            },
                            onPickAvatar = { uri, onSaved ->
                                viewModel.saveAndCompressAvatar(uri, onSaved)
                            },
                            onUpdateProfile = { id, name, phone, group, avatar ->
                                viewModel.updateMemberProfile(id, name, phone, group, avatar)
                            },
                            onUpdateContract = { cId, planName, months, agreedVnd, payIso, createIso, startIso, customEndIso, isManualEnd, note ->
                                viewModel.updateContractDetails(
                                    cId,
                                    planName,
                                    months,
                                    agreedVnd,
                                    payIso,
                                    createIso,
                                    startIso,
                                    customEndIso,
                                    isManualEnd,
                                    note
                                )
                            },
                            onFreezeContract = { cId, freezeStart, days, reason ->
                                viewModel.freezeContract(cId, freezeStart, days, reason)
                            },
                            onRecordPayment = { cId, payIso, cash, transfer, note ->
                                viewModel.recordContractPayment(cId, payIso, cash, transfer, note)
                            },
                            onCancelContractAndRefund = { cId, cancelIso, refundIso, reason, rCash, rTrans, note ->
                                viewModel.cancelContractAndRefund(
                                    cId,
                                    cancelIso,
                                    refundIso,
                                    reason,
                                    rCash,
                                    rTrans,
                                    note
                                )
                            },
                            onSoftDeleteContract = { cId ->
                                viewModel.softDeleteContract(cId)
                            },
                            onSoftDeleteMember = { memberId ->
                                viewModel.softDeleteMember(memberId)
                            }
                        )
                    }

                    is AppScreen.CreateContract -> {
                        CreateContractScreen(
                            preselectedDomain = screen.preselectedDomain,
                            preselectedService = screen.preselectedService,
                            renewalMemberId = screen.renewalMemberId,
                            fromPtClientId = screen.fromPtClientId,
                            pricePlans = snapshot.pricePlans,
                            gymMembers = gymMembers,
                            yogaMembers = yogaMembers,
                            ptClients = ptClients,
                            onBack = { viewModel.navigateBack() },
                            onOpenSettingsToConfigurePrices = {
                                viewModel.navigateTo(AppScreen.Settings)
                            },
                            onOpenPtManagement = {
                                viewModel.navigateTo(AppScreen.PtManagement)
                            },
                            onSaveMemberContract = { dom, existId, ptId, name, phone, group, avatar, planId, planSnap, months, agreed, payIso, createIso, startIso, customEndIso, isManualEnd, cash, transfer, note, onDone ->
                                viewModel.createMemberContract(
                                    dom,
                                    existId,
                                    ptId,
                                    name,
                                    phone,
                                    group,
                                    avatar,
                                    planId,
                                    planSnap,
                                    months,
                                    agreed,
                                    payIso,
                                    createIso,
                                    startIso,
                                    customEndIso,
                                    isManualEnd,
                                    cash,
                                    transfer,
                                    note,
                                    onDone
                                )
                            },
                            onSavePtContract = { existPtId, name, phone, regIso, payIso, sessions, agreed, cash, transfer, onDone ->
                                viewModel.createPtContract(
                                    existPtId,
                                    name,
                                    phone,
                                    regIso,
                                    payIso,
                                    sessions,
                                    agreed,
                                    cash,
                                    transfer,
                                    onDone
                                )
                            },
                            onSaveTicket = { type, saleIso, qty, unitPrice, cash, transfer, onDone ->
                                viewModel.sellShortTermTicket(
                                    type,
                                    saleIso,
                                    qty,
                                    unitPrice,
                                    cash,
                                    transfer,
                                    onDone
                                )
                            }
                        )
                    }

                    is AppScreen.PtManagement -> {
                        PtManagementScreen(
                            ptClients = ptClients,
                            onBack = { viewModel.navigateBack() },
                            onCreateNewPtContractClick = {
                                viewModel.navigateTo(
                                    AppScreen.CreateContract(
                                        preselectedDomain = "GYM",
                                        preselectedService = "PT"
                                    )
                                )
                            },
                            onTransitionPtToGymClick = { ptClientId ->
                                viewModel.navigateTo(
                                    AppScreen.CreateContract(
                                        preselectedDomain = "GYM",
                                        preselectedService = "RENEWAL",
                                        fromPtClientId = ptClientId
                                    )
                                )
                            },
                            onRecordPtSession = { contract, usedCount, dateIso, sessionsUsed, note ->
                                viewModel.recordPtSession(contract, usedCount, dateIso, sessionsUsed, note)
                            },
                            onUpdatePtContract = { contract, totalSessions, agreedVnd, regDateIso, usedCount ->
                                viewModel.updatePtContract(contract, totalSessions, agreedVnd, regDateIso, usedCount)
                            },
                            onSoftDeletePtClient = { clientId ->
                                viewModel.softDeletePtClient(clientId)
                            }
                        )
                    }

                    is AppScreen.Revenue -> {
                        RevenueScreen(
                            initialSubScreen = screen.initialSubScreen,
                            snapshot = snapshot,
                            onBack = { viewModel.navigateBack() },
                            onExportReport = { table, asExcel ->
                                viewModel.requestExportFileToDevice(table, asExcel)
                            }
                        )
                    }

                    is AppScreen.Tracking -> {
                        TrackingAndDebtScreen(
                            initialDomain = screen.initialDomain,
                            initialSubTab = screen.initialSubTab,
                            gymMembers = gymMembers,
                            yogaMembers = yogaMembers,
                            gymDebts = gymDebts,
                            yogaDebts = yogaDebts,
                            onBack = { viewModel.navigateBack() },
                            onMemberClick = { memberId ->
                                viewModel.navigateTo(AppScreen.MemberDetail(memberId))
                            },
                            onRenewClick = { memberId ->
                                val dom = if (gymMembers.any { it.member.id == memberId }) "GYM" else "YOGA"
                                viewModel.navigateTo(
                                    AppScreen.CreateContract(
                                        preselectedDomain = dom,
                                        preselectedService = "RENEWAL",
                                        renewalMemberId = memberId
                                    )
                                )
                            },
                            onRecordPayment = { contractId, payDateIso, cash, transfer, note ->
                                viewModel.recordContractPayment(contractId, payDateIso, cash, transfer, note)
                            }
                        )
                    }

                    is AppScreen.Settings -> {
                        SettingsScreen(
                            preferences = preferences,
                            pricePlans = snapshot.pricePlans,
                            trashCount = trashCount,
                            onBack = { viewModel.navigateBack() },
                            onOpenTrash = { viewModel.navigateTo(AppScreen.Trash) },
                            onToggleDarkMode = { viewModel.setDarkMode(it) },
                            onSavePricePlan = { id, dom, cat, name, months, sessions, price ->
                                viewModel.savePricePlan(id, dom, cat, name, months, sessions, price)
                            },
                            onTogglePlanActive = { viewModel.togglePricePlanActive(it) },
                            onDeleteOrDeactivatePricePlan = { viewModel.deleteOrDeactivatePricePlan(it) },
                            onSignInGoogle = { ctx -> viewModel.signInWithGoogle(ctx) },
                            onConnectGoogleManual = { email, token ->
                                viewModel.connectGoogleEmailManual(email, token)
                            },
                            onSignOutGoogle = { viewModel.signOutGoogle() },
                            onBackupToDrive = { viewModel.backupToGoogleDriveAndShare() },
                            onRestoreFromUri = { uri -> viewModel.restoreFromSelectedUri(uri) },
                            onRestoreLocalSnapshot = { viewModel.restoreFromLocalSnapshot() }
                        )
                    }

                    is AppScreen.Trash -> {
                        TrashScreen(
                            snapshot = snapshot,
                            onBack = { viewModel.navigateBack() },
                            onRestoreItem = { item -> viewModel.restoreTrashItem(item) },
                            onPermanentlyDeleteItems = { items -> viewModel.permanentlyDeleteSelectedTrashItems(items) }
                        )
                    }
                }

                // Saved File Confirmation Dialog/Banner (Section 5.1.3 & Section 7.4: notify location + Open / Share)
                lastSavedExportResult?.let { saved ->
                    AlertDialog(
                        onDismissRequest = { viewModel.dismissSavedExportBanner() },
                        title = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = StatusActiveGreen
                                )
                                Text("Đã lưu tệp thành công")
                            }
                        },
                        text = {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = "Tên tệp: ${saved.fileName}",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Vị trí lưu: ${saved.displayLocation}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        },
                        confirmButton = {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(
                                    onClick = {
                                        viewModel.shareSavedExportFile(saved)
                                        viewModel.dismissSavedExportBanner()
                                    },
                                    modifier = Modifier.testTag("share_saved_export_btn")
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Chia sẻ")
                                }
                                Button(
                                    onClick = {
                                        viewModel.openSavedExportFile(saved)
                                        viewModel.dismissSavedExportBanner()
                                    },
                                    modifier = Modifier.testTag("open_saved_export_btn")
                                ) {
                                    Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Mở tệp")
                                }
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { viewModel.dismissSavedExportBanner() }) {
                                Text("Đóng")
                            }
                        }
                    )
                }
            }
        }
    }
}
