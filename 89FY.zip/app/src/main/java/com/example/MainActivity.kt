package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.credentials.CredentialManager
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.MemberProfile
import com.example.ui.auth.AuthScreen
import com.example.ui.auth.signOut
import com.example.ui.screens.ContractCreationBranch
import com.example.ui.screens.CreateContractScreen
import com.example.ui.screens.GymYogaMemberScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MainMenuDestination
import com.example.ui.screens.MemberTrackingScreen
import com.example.ui.screens.PtManagementScreen
import com.example.ui.screens.RevenueScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.TrashScreen
import com.example.ui.theme.Fitness89Theme
import com.example.ui.viewmodel.FitnessViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AppRoot()
        }
    }
}

@Composable
fun AppRoot() {
    var currentUser by remember { mutableStateOf(Firebase.auth.currentUser) }

    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { auth ->
            currentUser = auth.currentUser
        }
        Firebase.auth.addAuthStateListener(listener)
        onDispose {
            Firebase.auth.removeAuthStateListener(listener)
        }
    }

    val user = currentUser
    if (user == null) {
        Fitness89Theme(darkTheme = false) {
            AuthScreen(
                onAuthSuccess = { signedInUser ->
                    currentUser = signedInUser
                }
            )
        }
    } else {
        AuthenticatedAppContent(
            currentUserId = user.uid,
            userEmail = user.email,
            onSignedOut = {
                currentUser = null
            }
        )
    }
}

@Composable
private fun AuthenticatedAppContent(
    currentUserId: String,
    userEmail: String?,
    onSignedOut: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }

    val viewModel: FitnessViewModel = viewModel(
        key = currentUserId,
        factory = FitnessViewModel.provideFactory(currentUserId)
    )

    val appState by viewModel.appState.collectAsStateWithLifecycle()
    val toastMessage by viewModel.toastMessage.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(toastMessage) {
        val msg = toastMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearToast()
        }
    }

    var currentMenu by remember { mutableStateOf<MainMenuDestination?>(null) }
    var createBranchOverride by remember { mutableStateOf<ContractCreationBranch?>(null) }
    var preselectedMemberForContract by remember { mutableStateOf<MemberProfile?>(null) }

    val performSignOut: () -> Unit = {
        signOut(
            credentialManager = credentialManager,
            scope = scope,
            onSignOutComplete = onSignedOut
        )
    }

    Fitness89Theme(darkTheme = appState.config.isDarkMode) {
        Scaffold(
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (currentMenu) {
                    null -> {
                        HomeScreen(
                            appState = appState,
                            userEmail = userEmail,
                            onSelectMenu = { dest ->
                                createBranchOverride = null
                                preselectedMemberForContract = null
                                currentMenu = dest
                            },
                            onToggleDarkMode = { enabled ->
                                viewModel.toggleDarkMode(enabled)
                            },
                            onSignOut = performSignOut
                        )
                    }

                    MainMenuDestination.GYM -> {
                        GymYogaMemberScreen(
                            serviceType = "GYM",
                            appState = appState,
                            viewModel = viewModel,
                            onBack = { currentMenu = null },
                            onNavigateToCreateOrRenew = { member ->
                                createBranchOverride = ContractCreationBranch.GYM
                                preselectedMemberForContract = member
                                currentMenu = MainMenuDestination.CREATE_CONTRACT
                            }
                        )
                    }

                    MainMenuDestination.YOGA -> {
                        GymYogaMemberScreen(
                            serviceType = "YOGA",
                            appState = appState,
                            viewModel = viewModel,
                            onBack = { currentMenu = null },
                            onNavigateToCreateOrRenew = { member ->
                                createBranchOverride = ContractCreationBranch.YOGA
                                preselectedMemberForContract = member
                                currentMenu = MainMenuDestination.CREATE_CONTRACT
                            }
                        )
                    }

                    MainMenuDestination.CREATE_CONTRACT -> {
                        CreateContractScreen(
                            appState = appState,
                            viewModel = viewModel,
                            initialBranch = createBranchOverride,
                            preselectedMember = preselectedMemberForContract,
                            onBack = {
                                createBranchOverride = null
                                preselectedMemberForContract = null
                                currentMenu = null
                            }
                        )
                    }

                    MainMenuDestination.REVENUE -> {
                        RevenueScreen(
                            appState = appState,
                            onBack = { currentMenu = null }
                        )
                    }

                    MainMenuDestination.MEMBER_TRACKING -> {
                        MemberTrackingScreen(
                            appState = appState,
                            onBack = { currentMenu = null },
                            onNavigateToRenew = { member ->
                                createBranchOverride = if (member.type == "YOGA") {
                                    ContractCreationBranch.YOGA
                                } else {
                                    ContractCreationBranch.GYM
                                }
                                preselectedMemberForContract = member
                                currentMenu = MainMenuDestination.CREATE_CONTRACT
                            }
                        )
                    }

                    MainMenuDestination.PT_MANAGEMENT -> {
                        PtManagementScreen(
                            appState = appState,
                            viewModel = viewModel,
                            onBack = { currentMenu = null },
                            onNavigateToCreateOrRenewPt = { member ->
                                createBranchOverride = ContractCreationBranch.PT
                                preselectedMemberForContract = member
                                currentMenu = MainMenuDestination.CREATE_CONTRACT
                            }
                        )
                    }

                    MainMenuDestination.SETTINGS -> {
                        SettingsScreen(
                            appState = appState,
                            viewModel = viewModel,
                            userEmail = userEmail,
                            onSignOut = performSignOut,
                            onBack = { currentMenu = null }
                        )
                    }

                    MainMenuDestination.TRASH -> {
                        TrashScreen(
                            appState = appState,
                            viewModel = viewModel,
                            onBack = { currentMenu = null }
                        )
                    }
                }
            }
        }
    }
}
