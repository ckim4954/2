package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.credentials.CredentialManager
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.MemberProfile
import com.example.ui.auth.signOut
import com.example.ui.screens.ContractCreationBranch
import com.example.ui.screens.CreateContractScreen
import com.example.ui.screens.GymYogaMemberScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MainMenuDestination
import com.example.ui.screens.MemberTrackingScreen
import com.example.ui.screens.PtManagementScreen
import com.example.ui.screens.RevenueScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.TrashScreen
import com.example.ui.theme.Fitness89Theme
import com.example.ui.viewmodel.FitnessViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AppRoot()
        }
    }
}

/**
 * Kiến trúc khởi động Offline-first:
 * - Khi mở app, đi thẳng vào màn hình chính (8 menu) mà KHÔNG kiểm tra hay chặn bởi Google Login / Firebase Auth.
 * - Toàn bộ dữ liệu đọc/ghi trực tiếp trên cơ sở dữ liệu Local Room SQLite bền vững.
 * - Đăng nhập Google chỉ nằm trong mục Cài đặt -> Đồng bộ – Sao lưu – Khôi phục.
 */
@Composable
fun AppRoot(
    viewModel: FitnessViewModel = viewModel(factory = FitnessViewModel.provideFactory())
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    // Theo dõi trạng thái tài khoản Google (nếu người dùng chủ động đăng nhập trong Cài đặt).
    // Tuyệt đối không dùng trạng thái này để chặn quyền truy cập ứng dụng.
    var googleUserEmail by remember {
        mutableStateOf(runCatching { Firebase.auth.currentUser?.email }.getOrNull())
    }

    DisposableEffect(Unit) {
        val authInstance = runCatching { Firebase.auth }.getOrNull()
        val listener = FirebaseAuth.AuthStateListener { auth ->
            googleUserEmail = auth.currentUser?.email
        }
        authInstance?.addAuthStateListener(listener)
        onDispose {
            authInstance?.removeAuthStateListener(listener)
        }
    }

    val appState by viewModel.appState.collectAsStateWithLifecycle()
    val toastMessage by viewModel.toastMessage.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(toastMessage) {
        val msg = toastMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearToast()
        }
    }

    var currentMenu by remember { mutableStateOf<MainMenuDestination?>(null) }
    var createBranchOverride by remember { mutableStateOf<ContractCreationBranch?>(null) }
    var preselectedMemberForContract by remember { mutableStateOf<MemberProfile?>(null) }

    val performGoogleSignOut: () -> Unit = {
        signOut(
            credentialManager = credentialManager,
            scope = scope,
            onSignOutComplete = {
                googleUserEmail = null
                viewModel.updateSyncActionStatus("Đã ngắt kết nối tài khoản Google (Dữ liệu Local trên máy được giữ nguyên)")
                viewModel.showToast("Đã đăng xuất Google. Dữ liệu trên thiết bị của bạn được giữ nguyên 100%.")
            }
        )
    }

    Fitness89Theme(darkTheme = appState.config.isDarkMode) {
        Scaffold(
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (currentMenu) {
                    null -> {
                        HomeScreen(
                            appState = appState,
                            userEmail = googleUserEmail,
                            onSelectMenu = { dest ->
                                createBranchOverride = null
                                preselectedMemberForContract = null
                                currentMenu = dest
                            },
                            onToggleDarkMode = { enabled ->
                                viewModel.toggleDarkMode(enabled)
                            }
                        )
                    }

                    MainMenuDestination.GYM -> {
                        GymYogaMemberScreen(
                            serviceType = "GYM",
                            appState = appState,
                            viewModel = viewModel,
                            onBack = { currentMenu = null },
                            onNavigateToCreateOrRenew = { member ->
                                createBranchOverride = ContractCreationBranch.GYM
                                preselectedMemberForContract = member
                                currentMenu = MainMenuDestination.CREATE_CONTRACT
                            }
                        )
                    }

                    MainMenuDestination.YOGA -> {
                        GymYogaMemberScreen(
                            serviceType = "YOGA",
                            appState = appState,
                            viewModel = viewModel,
                            onBack = { currentMenu = null },
                            onNavigateToCreateOrRenew = { member ->
                                createBranchOverride = ContractCreationBranch.YOGA
                                preselectedMemberForContract = member
                                currentMenu = MainMenuDestination.CREATE_CONTRACT
                            }
                        )
                    }

                    MainMenuDestination.CREATE_CONTRACT -> {
                        CreateContractScreen(
                            appState = appState,
                            viewModel = viewModel,
                            initialBranch = createBranchOverride,
                            preselectedMember = preselectedMemberForContract,
                            onBack = {
                                createBranchOverride = null
                                preselectedMemberForContract = null
                                currentMenu = null
                            }
                        )
                    }

                    MainMenuDestination.REVENUE -> {
                        RevenueScreen(
                            appState = appState,
                            onBack = { currentMenu = null }
                        )
                    }

                    MainMenuDestination.MEMBER_TRACKING -> {
                        MemberTrackingScreen(
                            appState = appState,
                            onBack = { currentMenu = null },
                            onNavigateToRenew = { member ->
                                createBranchOverride = if (member.type == "YOGA") {
                                    ContractCreationBranch.YOGA
                                } else {
                                    ContractCreationBranch.GYM
                                }
                                preselectedMemberForContract = member
                                currentMenu = MainMenuDestination.CREATE_CONTRACT
                            }
                        )
                    }

                    MainMenuDestination.PT_MANAGEMENT -> {
                        PtManagementScreen(
                            appState = appState,
                            viewModel = viewModel,
                            onBack = { currentMenu = null },
                            onNavigateToCreateOrRenewPt = { member ->
                                createBranchOverride = ContractCreationBranch.PT
                                preselectedMemberForContract = member
                                currentMenu = MainMenuDestination.CREATE_CONTRACT
                            }
                        )
                    }

                    MainMenuDestination.SETTINGS -> {
                        SettingsScreen(
                            appState = appState,
                            viewModel = viewModel,
                            userEmail = googleUserEmail,
                            onGoogleConnected = { email ->
                                googleUserEmail = email
                                viewModel.updateSyncActionStatus(
                                    "Đã kết nối tài khoản Google ($email). Chưa thực hiện đồng bộ tự động — hãy chọn Sao lưu hoặc Khôi phục khi cần."
                                )
                                viewModel.showToast("Đã kết nối tài khoản Google: $email")
                            },
                            onSignOut = performGoogleSignOut,
                            onBack = { currentMenu = null }
                        )
                    }

                    MainMenuDestination.TRASH -> {
                        TrashScreen(
                            appState = appState,
                            viewModel = viewModel,
                            onBack = { currentMenu = null }
                        )
                    }
                }
            }
        }
    }
}
