package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.AppScreen
import com.example.ui.FitnessViewModel
import com.example.ui.screens.*
import com.example.ui.theme.Fitness89Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: FitnessViewModel = viewModel(
                factory = FitnessViewModel.Factory(applicationContext)
            )
            Fitness89App(viewModel = viewModel)
        }
    }
}

@Composable
fun Fitness89App(viewModel: FitnessViewModel) {
    val preferences by viewModel.preferencesState.collectAsStateWithLifecycle()
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val snapshot by viewModel.dataSnapshot.collectAsStateWithLifecycle()
    val gymMembers by viewModel.gymMembersFlow.collectAsStateWithLifecycle()
    val yogaMembers by viewModel.yogaMembersFlow.collectAsStateWithLifecycle()
    val ptClients by viewModel.ptClientSummariesFlow.collectAsStateWithLifecycle()
    val gymDebts by viewModel.gymDebtContractsFlow.collectAsStateWithLifecycle()
    val yogaDebts by viewModel.yogaDebtContractsFlow.collectAsStateWithLifecycle()
    val snackbarMessage by viewModel.snackbarMessage.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(snackbarMessage) {
        val msg = snackbarMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearMessage()
        }
    }

    // Handle system Back navigation on all secondary screens
    BackHandler(enabled = currentScreen != AppScreen.HomeDashboard) {
        viewModel.navigateBack()
    }

    val trashCount = remember(snapshot) {
        snapshot.members.count { it.isDeleted } +
            snapshot.contracts.count { it.isDeleted } +
            snapshot.ptClients.count { it.isDeleted } +
            snapshot.shortTermTickets.count { it.isDeleted }
    }

    Fitness89Theme(darkTheme = preferences.isDarkMode) {
        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
        ) { _ ->
            Box(modifier = Modifier.fillMaxSize()) {
                when (val screen = currentScreen) {
                    is AppScreen.HomeDashboard -> {
                        HomeDashboardScreen(
                            gymMembers = gymMembers,
                            yogaMembers = yogaMembers,
                            ptClients = ptClients,
                            trashCount = trashCount,
                            preferences = preferences,
                            onNavigate = { viewModel.navigateTo(it) }
                        )
                    }

                    is AppScreen.MemberList -> {
                        val members = if (screen.domain == "GYM") gymMembers else yogaMembers
                        MemberListScreen(
                            domain = screen.domain,
                            initialFilter = screen.initialFilter,
                            members = members,
                            onBack = { viewModel.navigateBack() },
                            onMemberClick = { memberId ->
                                viewModel.navigateTo(AppScreen.MemberDetail(memberId))
                            },
                            onRenewClick = { memberId ->
                                viewModel.navigateTo(
                                    AppScreen.CreateContract(
                                        preselectedDomain = screen.domain,
                                        preselectedService = "RENEWAL",
                                        renewalMemberId = memberId
                                    )
                                )
                            },
                            onCreateNewClick = {
                                viewModel.navigateTo(
                                    AppScreen.CreateContract(
                                        preselectedDomain = screen.domain,
                                        preselectedService = "NEW"
                                    )
                                )
                            },
                            onExportMemberList = { table, asExcel ->
                                viewModel.exportReportAndShare(table, asExcel)
                            }
                        )
                    }

                    is AppScreen.MemberDetail -> {
                        val memberSummary = gymMembers.firstOrNull { it.member.id == screen.memberId }
                            ?: yogaMembers.firstOrNull { it.member.id == screen.memberId }
                        MemberDetailScreen(
                            summary = memberSummary,
                            onBack = { viewModel.navigateBack() },
                            onRenewClick = { memberId ->
                                val dom = memberSummary?.member?.domain ?: "GYM"
                                viewModel.navigateTo(
                                    AppScreen.CreateContract(
                                        preselectedDomain = dom,
                                        preselectedService = "RENEWAL",
                                        renewalMemberId = memberId
                                    )
                                )
                            },
                            onPickAvatar = { uri, onSaved ->
                                viewModel.saveAndCompressAvatar(uri, onSaved)
                            },
                            onUpdateProfile = { id, name, phone, group, avatar ->
                                viewModel.updateMemberProfile(id, name, phone, group, avatar)
                            },
                            onUpdateContract = { cId, planName, months, agreedVnd, payIso, createIso, startIso, customEndIso ->
                                viewModel.updateContractDetails(
                                    cId,
                                    planName,
                                    months,
                                    agreedVnd,
                                    payIso,
                                    createIso,
                                    startIso,
                                    customEndIso
                                )
                            },
                            onFreezeContract = { cId, freezeStart, days, reason ->
                                viewModel.freezeContract(cId, freezeStart, days, reason)
                            },
                            onRecordPayment = { cId, payIso, cash, transfer, note ->
                                viewModel.recordContractPayment(cId, payIso, cash, transfer, note)
                            },
                            onCancelContractAndRefund = { cId, cancelIso, refundIso, reason, rCash, rTrans, note ->
                                viewModel.cancelContractAndRefund(
                                    cId,
                                    cancelIso,
                                    refundIso,
                                    reason,
                                    rCash,
                                    rTrans,
                                    note
                                )
                            },
                            onSoftDeleteMember = { memberId ->
                                viewModel.softDeleteMember(memberId)
                            }
                        )
                    }

                    is AppScreen.CreateContract -> {
                        CreateContractScreen(
                            preselectedDomain = screen.preselectedDomain,
                            preselectedService = screen.preselectedService,
                            renewalMemberId = screen.renewalMemberId,
                            fromPtClientId = screen.fromPtClientId,
                            pricePlans = snapshot.pricePlans,
                            gymMembers = gymMembers,
                            yogaMembers = yogaMembers,
                            ptClients = ptClients,
                            onBack = { viewModel.navigateBack() },
                            onOpenSettingsToConfigurePrices = {
                                viewModel.navigateTo(AppScreen.Settings)
                            },
                            onOpenPtManagement = {
                                viewModel.navigateTo(AppScreen.PtManagement)
                            },
                            onSaveMemberContract = { dom, existId, ptId, name, phone, group, avatar, planId, planSnap, months, agreed, payIso, createIso, startIso, cash, transfer, onDone ->
                                viewModel.createMemberContract(
                                    dom,
                                    existId,
                                    ptId,
                                    name,
                                    phone,
                                    group,
                                    avatar,
                                    planId,
                                    planSnap,
                                    months,
                                    agreed,
                                    payIso,
                                    createIso,
                                    startIso,
                                    cash,
                                    transfer,
                                    onDone
                                )
                            },
                            onSavePtContract = { existPtId, name, phone, regIso, payIso, sessions, agreed, cash, transfer, onDone ->
                                viewModel.createPtContract(
                                    existPtId,
                                    name,
                                    phone,
                                    regIso,
                                    payIso,
                                    sessions,
                                    agreed,
                                    cash,
                                    transfer,
                                    onDone
                                )
                            },
                            onSaveTicket = { type, saleIso, qty, unitPrice, cash, transfer, onDone ->
                                viewModel.sellShortTermTicket(
                                    type,
                                    saleIso,
                                    qty,
                                    unitPrice,
                                    cash,
                                    transfer,
                                    onDone
                                )
                            }
                        )
                    }

                    is AppScreen.PtManagement -> {
                        PtManagementScreen(
                            ptClients = ptClients,
                            onBack = { viewModel.navigateBack() },
                            onCreateNewPtContractClick = {
                                viewModel.navigateTo(
                                    AppScreen.CreateContract(
                                        preselectedDomain = "GYM",
                                        preselectedService = "PT"
                                    )
                                )
                            },
                            onTransitionPtToGymClick = { ptClientId ->
                                viewModel.navigateTo(
                                    AppScreen.CreateContract(
                                        preselectedDomain = "GYM",
                                        preselectedService = "RENEWAL",
                                        fromPtClientId = ptClientId
                                    )
                                )
                            },
                            onRecordPtSession = { contract, usedCount, dateIso, sessionsUsed, note ->
                                viewModel.recordPtSession(contract, usedCount, dateIso, sessionsUsed, note)
                            },
                            onUpdatePtContract = { contract, totalSessions, agreedVnd, regDateIso, usedCount ->
                                viewModel.updatePtContract(contract, totalSessions, agreedVnd, regDateIso, usedCount)
                            },
                            onSoftDeletePtClient = { clientId ->
                                viewModel.softDeletePtClient(clientId)
                            }
                        )
                    }

                    is AppScreen.Revenue -> {
                        RevenueScreen(
                            initialDomain = screen.initialDomain,
                            snapshot = snapshot,
                            onBack = { viewModel.navigateBack() },
                            onExportReport = { table, asExcel ->
                                viewModel.exportReportAndShare(table, asExcel)
                            }
                        )
                    }

                    is AppScreen.Tracking -> {
                        TrackingAndDebtScreen(
                            initialDomain = screen.initialDomain,
                            initialSubTab = screen.initialSubTab,
                            gymMembers = gymMembers,
                            yogaMembers = yogaMembers,
                            gymDebts = gymDebts,
                            yogaDebts = yogaDebts,
                            onBack = { viewModel.navigateBack() },
                            onMemberClick = { memberId ->
                                viewModel.navigateTo(AppScreen.MemberDetail(memberId))
                            },
                            onRenewClick = { memberId ->
                                val dom = if (gymMembers.any { it.member.id == memberId }) "GYM" else "YOGA"
                                viewModel.navigateTo(
                                    AppScreen.CreateContract(
                                        preselectedDomain = dom,
                                        preselectedService = "RENEWAL",
                                        renewalMemberId = memberId
                                    )
                                )
                            },
                            onRecordPayment = { contractId, payDateIso, cash, transfer, note ->
                                viewModel.recordContractPayment(contractId, payDateIso, cash, transfer, note)
                            }
                        )
                    }

                    is AppScreen.Settings -> {
                        SettingsScreen(
                            preferences = preferences,
                            pricePlans = snapshot.pricePlans,
                            onBack = { viewModel.navigateBack() },
                            onToggleDarkMode = { viewModel.setDarkMode(it) },
                            onSavePricePlan = { id, dom, cat, name, months, sessions, price ->
                                viewModel.savePricePlan(id, dom, cat, name, months, sessions, price)
                            },
                            onTogglePlanActive = { viewModel.togglePricePlanActive(it) },
                            onSignInGoogle = { ctx -> viewModel.signInWithGoogle(ctx) },
                            onConnectGoogleManual = { email, token ->
                                viewModel.connectGoogleEmailManual(email, token)
                            },
                            onSignOutGoogle = { viewModel.signOutGoogle() },
                            onBackupToDrive = { viewModel.backupToGoogleDriveAndShare() },
                            onRestoreFromUri = { uri -> viewModel.restoreFromSelectedUri(uri) },
                            onRestoreLocalSnapshot = { viewModel.restoreFromLocalSnapshot() }
                        )
                    }

                    is AppScreen.Trash -> {
                        TrashScreen(
                            snapshot = snapshot,
                            onBack = { viewModel.navigateBack() },
                            onRestoreMember = { viewModel.restoreMemberFromTrash(it) },
                            onPermanentlyDeleteMember = { viewModel.permanentlyDeleteMember(it) },
                            onRestoreContract = { viewModel.restoreContractFromTrash(it) },
                            onPermanentlyDeleteContract = { viewModel.permanentlyDeleteContract(it) },
                            onRestorePtClient = { viewModel.restorePtClient(it) },
                            onPermanentlyDeletePtClient = { viewModel.permanentlyDeletePtClient(it) },
                            onRestoreTicket = { viewModel.restoreTicket(it) },
                            onPermanentlyDeleteTicket = { viewModel.permanentlyDeleteTicket(it) },
                            onEmptyTrashAll = { viewModel.emptyTrashAll() }
                        )
                    }
                }
            }
        }
    }
}
