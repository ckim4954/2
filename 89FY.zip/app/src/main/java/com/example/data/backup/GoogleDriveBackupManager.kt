package com.example.data.backup

import android.content.Context
import android.net.Uri
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import com.example.BuildConfig
import com.example.data.local.*
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Handles Google Sign-In, Google Drive Backup/Restore, and conflict-safe UUID database snapshot synchronization.
 * Supports both direct Google Drive REST API v3 upload/download and local/Drive file import/export.
 */
class GoogleDriveBackupManager(
    private val context: Context,
    private val dao: AppDao
) {
    private val httpClient = OkHttpClient()
    private val backupDir: File
        get() = File(context.filesDir, "backups").apply { if (!exists()) mkdirs() }

    companion object {
        const val BACKUP_FILE_NAME = "89Fitness_Yoga_Backup_Snapshot.json"
    }

    /**
     * Initiates Google Sign-In via Jetpack Credential Manager if GOOGLE_WEB_CLIENT_ID is configured,
     * returning the authenticated Google email.
     */
    suspend fun signInWithGoogleCredentialManager(activityContext: Context): Result<String> {
        val webClientId = BuildConfig.GOOGLE_WEB_CLIENT_ID
        if (webClientId.isBlank() || webClientId == "YOUR_GOOGLE_WEB_CLIENT_ID") {
            return Result.failure(
                IllegalStateException("Chưa cấu hình GOOGLE_WEB_CLIENT_ID trong Secrets. Bạn có thể nhập email Google trực tiếp hoặc sao lưu tệp lên ứng dụng Google Drive.")
            )
        }
        return try {
            val credentialManager = CredentialManager.create(activityContext)
            val googleOption = GetSignInWithGoogleOption.Builder(webClientId).build()
            val request = GetCredentialRequest.Builder()
                .addCredentialOption(googleOption)
                .build()
            val result = credentialManager.getCredential(activityContext, request)
            val credential = result.credential
            if (credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                Result.success(googleIdTokenCredential.id)
            } else {
                Result.failure(IllegalStateException("Loại thông tin xác thực không được hỗ trợ."))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Serializes the entire SQLite database into a deterministic JSON backup snapshot.
     */
    suspend fun createSnapshotJson(): String = withContext(Dispatchers.IO) {
        val root = JSONObject()
        root.put("schemaVersion", 1)
        root.put("appName", "89 FITNESS & YOGA")
        root.put("exportedAt", System.currentTimeMillis())

        // Price Plans
        val plansArr = JSONArray()
        for (p in dao.getAllPricePlansOnce()) {
            plansArr.put(JSONObject().apply {
                put("id", p.id)
                put("domain", p.domain)
                put("category", p.category)
                put("planName", p.planName)
                put("durationMonths", p.durationMonths)
                put("sessionCount", p.sessionCount)
                put("priceVnd", p.priceVnd)
                put("isActive", p.isActive)
                put("updatedAt", p.updatedAt)
            })
        }
        root.put("pricePlans", plansArr)

        // Members
        val membersArr = JSONArray()
        for (m in dao.getAllMembersOnce()) {
            membersArr.put(JSONObject().apply {
                put("id", m.id)
                put("domain", m.domain)
                put("fullName", m.fullName)
                put("phoneNumber", m.phoneNumber)
                put("customerGroup", m.customerGroup)
                put("avatarPath", m.avatarPath ?: "")
                put("linkedPtClientId", m.linkedPtClientId ?: "")
                put("isDeleted", m.isDeleted)
                put("deleteType", m.deleteType)
                put("deletedAt", m.deletedAt ?: 0L)
                put("deleteReason", m.deleteReason ?: "")
                put("updatedAt", m.updatedAt)
            })
        }
        root.put("members", membersArr)

        // Contracts
        val contractsArr = JSONArray()
        for (c in dao.getAllContractsOnce()) {
            contractsArr.put(JSONObject().apply {
                put("id", c.id)
                put("contractCode", c.contractCode)
                put("memberId", c.memberId)
                put("domain", c.domain)
                put("contractType", c.contractType)
                put("pricePlanId", c.pricePlanId ?: "")
                put("planNameSnapshot", c.planNameSnapshot)
                put("durationMonths", c.durationMonths)
                put("agreedValueVnd", c.agreedValueVnd)
                put("paymentDateIso", c.paymentDateIso)
                put("createdDateIso", c.createdDateIso)
                put("startDateIso", c.startDateIso)
                put("endDateIso", c.endDateIso)
                put("frozenDays", c.frozenDays)
                put("status", c.status)
                put("cancelledDateIso", c.cancelledDateIso ?: "")
                put("cancelReason", c.cancelReason ?: "")
                put("refundedAmountVnd", c.refundedAmountVnd)
                put("refundDateIso", c.refundDateIso ?: "")
                put("refundCashVnd", c.refundCashVnd)
                put("refundTransferVnd", c.refundTransferVnd)
                put("cancelNote", c.cancelNote ?: "")
                put("isDeleted", c.isDeleted)
                put("deleteType", c.deleteType)
                put("deletedAt", c.deletedAt ?: 0L)
                put("updatedAt", c.updatedAt)
            })
        }
        root.put("contracts", contractsArr)

        // Contract Freezes
        val freezesArr = JSONArray()
        for (f in dao.getAllContractFreezesOnce()) {
            freezesArr.put(JSONObject().apply {
                put("id", f.id)
                put("contractId", f.contractId)
                put("freezeStartIso", f.freezeStartIso)
                put("freezeEndIso", f.freezeEndIso)
                put("daysFrozen", f.daysFrozen)
                put("reason", f.reason)
                put("createdAt", f.createdAt)
            })
        }
        root.put("contractFreezes", freezesArr)

        // Payments
        val paymentsArr = JSONArray()
        for (p in dao.getAllPaymentsOnce()) {
            paymentsArr.put(JSONObject().apply {
                put("id", p.id)
                put("transactionCode", p.transactionCode)
                put("contractId", p.contractId)
                put("memberId", p.memberId)
                put("domain", p.domain)
                put("paymentDateIso", p.paymentDateIso)
                put("cashAmountVnd", p.cashAmountVnd)
                put("transferAmountVnd", p.transferAmountVnd)
                put("totalAmountVnd", p.totalAmountVnd)
                put("paymentMethodLabel", p.paymentMethodLabel)
                put("note", p.note)
                put("createdAt", p.createdAt)
            })
        }
        root.put("payments", paymentsArr)

        // Refunds
        val refundsArr = JSONArray()
        for (r in dao.getAllRefundsOnce()) {
            refundsArr.put(JSONObject().apply {
                put("id", r.id)
                put("refundCode", r.refundCode)
                put("contractId", r.contractId)
                put("memberId", r.memberId)
                put("domain", r.domain)
                put("refundDateIso", r.refundDateIso)
                put("cashAmountVnd", r.cashAmountVnd)
                put("transferAmountVnd", r.transferAmountVnd)
                put("totalRefundVnd", r.totalRefundVnd)
                put("reason", r.reason)
                put("note", r.note)
                put("createdAt", r.createdAt)
            })
        }
        root.put("refunds", refundsArr)

        // PT Clients
        val ptClientsArr = JSONArray()
        for (pt in dao.getAllPtClientsOnce()) {
            ptClientsArr.put(JSONObject().apply {
                put("id", pt.id)
                put("fullName", pt.fullName)
                put("phoneNumber", pt.phoneNumber)
                put("linkedGymMemberId", pt.linkedGymMemberId ?: "")
                put("trainerName", pt.trainerName)
                put("isDeleted", pt.isDeleted)
                put("deletedAt", pt.deletedAt ?: 0L)
                put("deleteReason", pt.deleteReason ?: "")
                put("updatedAt", pt.updatedAt)
            })
        }
        root.put("ptClients", ptClientsArr)

        // PT Contracts
        val ptContractsArr = JSONArray()
        for (ptc in dao.getAllPtContractsOnce()) {
            ptContractsArr.put(JSONObject().apply {
                put("id", ptc.id)
                put("contractCode", ptc.contractCode)
                put("ptClientId", ptc.ptClientId)
                put("trainerName", ptc.trainerName)
                put("registerDateIso", ptc.registerDateIso)
                put("paymentDateIso", ptc.paymentDateIso)
                put("totalSessions", ptc.totalSessions)
                put("agreedValueVnd", ptc.agreedValueVnd)
                put("cashPaidVnd", ptc.cashPaidVnd)
                put("transferPaidVnd", ptc.transferPaidVnd)
                put("status", ptc.status)
                put("isDeleted", ptc.isDeleted)
                put("deletedAt", ptc.deletedAt ?: 0L)
                put("updatedAt", ptc.updatedAt)
            })
        }
        root.put("ptContracts", ptContractsArr)

        // PT Sessions
        val ptSessionsArr = JSONArray()
        for (pts in dao.getAllPtSessionsOnce()) {
            ptSessionsArr.put(JSONObject().apply {
                put("id", pts.id)
                put("ptContractId", pts.ptContractId)
                put("ptClientId", pts.ptClientId)
                put("sessionDateIso", pts.sessionDateIso)
                put("sessionsUsed", pts.sessionsUsed)
                put("note", pts.note)
                put("createdAt", pts.createdAt)
            })
        }
        root.put("ptSessions", ptSessionsArr)

        // Short-term tickets
        val ticketsArr = JSONArray()
        for (t in dao.getAllShortTermTicketsOnce()) {
            ticketsArr.put(JSONObject().apply {
                put("id", t.id)
                put("ticketCode", t.ticketCode)
                put("ticketType", t.ticketType)
                put("saleDateIso", t.saleDateIso)
                put("quantity", t.quantity)
                put("unitPriceVnd", t.unitPriceVnd)
                put("totalAmountVnd", t.totalAmountVnd)
                put("cashAmountVnd", t.cashAmountVnd)
                put("transferAmountVnd", t.transferAmountVnd)
                put("paymentMethodLabel", t.paymentMethodLabel)
                put("isDeleted", t.isDeleted)
                put("deletedAt", t.deletedAt ?: 0L)
                put("createdAt", t.createdAt)
            })
        }
        root.put("shortTermTickets", ticketsArr)

        root.toString(2)
    }

    /**
     * Saves the snapshot to local internal backup file AND uploads to Google Drive REST API v3 if an access token is provided.
     */
    suspend fun createBackupFileAndUploadIfAuthorized(accessToken: String): Result<File> = withContext(Dispatchers.IO) {
        try {
            val json = createSnapshotJson()
            val file = File(backupDir, BACKUP_FILE_NAME)
            file.writeText(json, Charsets.UTF_8)

            if (accessToken.isNotBlank()) {
                val boundary = "===Fitness89BackupBoundary==="
                val metadataJson = JSONObject().apply {
                    put("name", BACKUP_FILE_NAME)
                    put("mimeType", "application/json")
                }.toString()

                val multipartBody = buildString {
                    append("--$boundary\r\n")
                    append("Content-Type: application/json; charset=UTF-8\r\n\r\n")
                    append(metadataJson).append("\r\n")
                    append("--$boundary\r\n")
                    append("Content-Type: application/json\r\n\r\n")
                    append(json).append("\r\n")
                    append("--$boundary--")
                }

                val request = Request.Builder()
                    .url("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart")
                    .addHeader("Authorization", "Bearer $accessToken")
                    .post(multipartBody.toRequestBody("multipart/related; boundary=$boundary".toMediaType()))
                    .build()

                httpClient.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        return@withContext Result.failure(
                            IllegalStateException("Đã lưu bản sao lưu trên máy, nhưng tải lên Google Drive API trả về mã ${response.code}.")
                        )
                    }
                }
            }
            Result.success(file)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Restores and merges a JSON snapshot with UUID deduplication and timestamp conflict resolution
     * so no contracts or payments are ever duplicated (Sections 21 & 24).
     */
    suspend fun restoreFromSnapshotJson(jsonString: String): Result<Int> = withContext(Dispatchers.IO) {
        try {
            val root = JSONObject(jsonString)
            var restoredRecords = 0

            root.optJSONArray("pricePlans")?.let { arr ->
                val list = mutableListOf<PricePlanEntity>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(
                        PricePlanEntity(
                            id = o.getString("id"),
                            domain = o.getString("domain"),
                            category = o.getString("category"),
                            planName = o.getString("planName"),
                            durationMonths = o.optInt("durationMonths", 0),
                            sessionCount = o.optInt("sessionCount", 0),
                            priceVnd = o.getLong("priceVnd"),
                            isActive = o.optBoolean("isActive", true),
                            updatedAt = o.optLong("updatedAt", System.currentTimeMillis())
                        )
                    )
                }
                dao.upsertPricePlans(list)
                restoredRecords += list.size
            }

            val existingMembers = dao.getAllMembersOnce().associateBy { it.id }
            root.optJSONArray("members")?.let { arr ->
                val list = mutableListOf<MemberEntity>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val id = o.getString("id")
                    val incomingUpdated = o.optLong("updatedAt", 0L)
                    val local = existingMembers[id]
                    if (local == null || incomingUpdated >= local.updatedAt) {
                        list.add(
                            MemberEntity(
                                id = id,
                                domain = o.getString("domain"),
                                fullName = o.getString("fullName"),
                                phoneNumber = o.getString("phoneNumber"),
                                customerGroup = o.optString("customerGroup", "NAM"),
                                avatarPath = o.optString("avatarPath").takeIf { it.isNotBlank() },
                                linkedPtClientId = o.optString("linkedPtClientId").takeIf { it.isNotBlank() },
                                isDeleted = o.optBoolean("isDeleted", false),
                                deleteType = o.optString("deleteType", "NONE"),
                                deletedAt = o.optLong("deletedAt", 0L).takeIf { it > 0L },
                                deleteReason = o.optString("deleteReason").takeIf { it.isNotBlank() },
                                updatedAt = incomingUpdated
                            )
                        )
                    }
                }
                dao.upsertMembers(list)
                restoredRecords += list.size
            }

            val existingContracts = dao.getAllContractsOnce().associateBy { it.id }
            root.optJSONArray("contracts")?.let { arr ->
                val list = mutableListOf<ContractEntity>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val id = o.getString("id")
                    val incomingUpdated = o.optLong("updatedAt", 0L)
                    val local = existingContracts[id]
                    if (local == null || incomingUpdated >= local.updatedAt) {
                        list.add(
                            ContractEntity(
                                id = id,
                                contractCode = o.getString("contractCode"),
                                memberId = o.getString("memberId"),
                                domain = o.getString("domain"),
                                contractType = o.getString("contractType"),
                                pricePlanId = o.optString("pricePlanId").takeIf { it.isNotBlank() },
                                planNameSnapshot = o.getString("planNameSnapshot"),
                                durationMonths = o.getInt("durationMonths"),
                                agreedValueVnd = o.getLong("agreedValueVnd"),
                                paymentDateIso = o.getString("paymentDateIso"),
                                createdDateIso = o.getString("createdDateIso"),
                                startDateIso = o.getString("startDateIso"),
                                endDateIso = o.getString("endDateIso"),
                                frozenDays = o.optInt("frozenDays", 0),
                                status = o.optString("status", "ACTIVE"),
                                cancelledDateIso = o.optString("cancelledDateIso").takeIf { it.isNotBlank() },
                                cancelReason = o.optString("cancelReason").takeIf { it.isNotBlank() },
                                refundedAmountVnd = o.optLong("refundedAmountVnd", 0L),
                                refundDateIso = o.optString("refundDateIso").takeIf { it.isNotBlank() },
                                refundCashVnd = o.optLong("refundCashVnd", 0L),
                                refundTransferVnd = o.optLong("refundTransferVnd", 0L),
                                cancelNote = o.optString("cancelNote").takeIf { it.isNotBlank() },
                                isDeleted = o.optBoolean("isDeleted", false),
                                deleteType = o.optString("deleteType", "NONE"),
                                deletedAt = o.optLong("deletedAt", 0L).takeIf { it > 0L },
                                updatedAt = incomingUpdated
                            )
                        )
                    }
                }
                dao.upsertContracts(list)
                restoredRecords += list.size
            }

            root.optJSONArray("contractFreezes")?.let { arr ->
                val list = mutableListOf<ContractFreezeEntity>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(
                        ContractFreezeEntity(
                            id = o.getString("id"),
                            contractId = o.getString("contractId"),
                            freezeStartIso = o.getString("freezeStartIso"),
                            freezeEndIso = o.getString("freezeEndIso"),
                            daysFrozen = o.getInt("daysFrozen"),
                            reason = o.optString("reason", ""),
                            createdAt = o.optLong("createdAt", System.currentTimeMillis())
                        )
                    )
                }
                dao.upsertContractFreezes(list)
                restoredRecords += list.size
            }

            root.optJSONArray("payments")?.let { arr ->
                val list = mutableListOf<PaymentTransactionEntity>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(
                        PaymentTransactionEntity(
                            id = o.getString("id"),
                            transactionCode = o.getString("transactionCode"),
                            contractId = o.getString("contractId"),
                            memberId = o.getString("memberId"),
                            domain = o.getString("domain"),
                            paymentDateIso = o.getString("paymentDateIso"),
                            cashAmountVnd = o.getLong("cashAmountVnd"),
                            transferAmountVnd = o.getLong("transferAmountVnd"),
                            totalAmountVnd = o.getLong("totalAmountVnd"),
                            paymentMethodLabel = o.getString("paymentMethodLabel"),
                            note = o.optString("note", ""),
                            createdAt = o.optLong("createdAt", System.currentTimeMillis())
                        )
                    )
                }
                dao.upsertPayments(list)
                restoredRecords += list.size
            }

            root.optJSONArray("refunds")?.let { arr ->
                val list = mutableListOf<RefundTransactionEntity>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(
                        RefundTransactionEntity(
                            id = o.getString("id"),
                            refundCode = o.getString("refundCode"),
                            contractId = o.getString("contractId"),
                            memberId = o.getString("memberId"),
                            domain = o.getString("domain"),
                            refundDateIso = o.getString("refundDateIso"),
                            cashAmountVnd = o.getLong("cashAmountVnd"),
                            transferAmountVnd = o.getLong("transferAmountVnd"),
                            totalRefundVnd = o.getLong("totalRefundVnd"),
                            reason = o.optString("reason", ""),
                            note = o.optString("note", ""),
                            createdAt = o.optLong("createdAt", System.currentTimeMillis())
                        )
                    )
                }
                dao.upsertRefunds(list)
                restoredRecords += list.size
            }

            root.optJSONArray("ptClients")?.let { arr ->
                val list = mutableListOf<PtClientEntity>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(
                        PtClientEntity(
                            id = o.getString("id"),
                            fullName = o.getString("fullName"),
                            phoneNumber = o.getString("phoneNumber"),
                            linkedGymMemberId = o.optString("linkedGymMemberId").takeIf { it.isNotBlank() },
                            trainerName = o.optString("trainerName", "Hà Đức"),
                            isDeleted = o.optBoolean("isDeleted", false),
                            deletedAt = o.optLong("deletedAt", 0L).takeIf { it > 0L },
                            deleteReason = o.optString("deleteReason").takeIf { it.isNotBlank() },
                            updatedAt = o.optLong("updatedAt", System.currentTimeMillis())
                        )
                    )
                }
                dao.upsertPtClients(list)
                restoredRecords += list.size
            }

            root.optJSONArray("ptContracts")?.let { arr ->
                val list = mutableListOf<PtContractEntity>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(
                        PtContractEntity(
                            id = o.getString("id"),
                            contractCode = o.getString("contractCode"),
                            ptClientId = o.getString("ptClientId"),
                            trainerName = o.optString("trainerName", "Hà Đức"),
                            registerDateIso = o.getString("registerDateIso"),
                            paymentDateIso = o.getString("paymentDateIso"),
                            totalSessions = o.getInt("totalSessions"),
                            agreedValueVnd = o.getLong("agreedValueVnd"),
                            cashPaidVnd = o.getLong("cashPaidVnd"),
                            transferPaidVnd = o.getLong("transferPaidVnd"),
                            status = o.optString("status", "ACTIVE"),
                            isDeleted = o.optBoolean("isDeleted", false),
                            deletedAt = o.optLong("deletedAt", 0L).takeIf { it > 0L },
                            updatedAt = o.optLong("updatedAt", System.currentTimeMillis())
                        )
                    )
                }
                dao.upsertPtContracts(list)
                restoredRecords += list.size
            }

            root.optJSONArray("ptSessions")?.let { arr ->
                val list = mutableListOf<PtSessionEntity>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(
                        PtSessionEntity(
                            id = o.getString("id"),
                            ptContractId = o.getString("ptContractId"),
                            ptClientId = o.getString("ptClientId"),
                            sessionDateIso = o.getString("sessionDateIso"),
                            sessionsUsed = o.getInt("sessionsUsed"),
                            note = o.optString("note", ""),
                            createdAt = o.optLong("createdAt", System.currentTimeMillis())
                        )
                    )
                }
                dao.upsertPtSessions(list)
                restoredRecords += list.size
            }

            root.optJSONArray("shortTermTickets")?.let { arr ->
                val list = mutableListOf<ShortTermTicketEntity>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(
                        ShortTermTicketEntity(
                            id = o.getString("id"),
                            ticketCode = o.getString("ticketCode"),
                            ticketType = o.getString("ticketType"),
                            saleDateIso = o.getString("saleDateIso"),
                            quantity = o.getInt("quantity"),
                            unitPriceVnd = o.getLong("unitPriceVnd"),
                            totalAmountVnd = o.getLong("totalAmountVnd"),
                            cashAmountVnd = o.getLong("cashAmountVnd"),
                            transferAmountVnd = o.getLong("transferAmountVnd"),
                            paymentMethodLabel = o.getString("paymentMethodLabel"),
                            isDeleted = o.optBoolean("isDeleted", false),
                            deletedAt = o.optLong("deletedAt", 0L).takeIf { it > 0L },
                            createdAt = o.optLong("createdAt", System.currentTimeMillis())
                        )
                    )
                }
                dao.upsertShortTermTickets(list)
                restoredRecords += list.size
            }

            Result.success(restoredRecords)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun restoreFromUri(uri: Uri): Result<Int> = withContext(Dispatchers.IO) {
        try {
            val stream = context.contentResolver.openInputStream(uri)
                ?: return@withContext Result.failure(IllegalArgumentException("Không thể đọc tệp sao lưu đã chọn."))
            val json = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            restoreFromSnapshotJson(json)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun restoreFromLocalBackupIfExists(): Result<Int> = withContext(Dispatchers.IO) {
        val file = File(backupDir, BACKUP_FILE_NAME)
        if (!file.exists()) {
            return@withContext Result.failure(IllegalStateException("Chưa có bản sao lưu cục bộ trên máy. Hãy chọn tệp sao lưu từ Google Drive."))
        }
        restoreFromSnapshotJson(file.readText(Charsets.UTF_8))
    }
}
