package com.example.data.export

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.core.content.res.ResourcesCompat
import com.example.R
import com.example.domain.FormatUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

data class ReportTableData(
    val reportTitle: String,
    val subtitle: String,
    val fileNamePrefix: String,
    val headers: List<String>,
    val rows: List<List<String>>,
    val numericColumnIndices: Set<Int> = emptySet(),
    val summaryLines: List<Pair<String, String>> = emptyList()
)

data class SavedExportResult(
    val localFile: File,
    val savedUri: Uri?,
    val fileName: String,
    val displayLocation: String,
    val mimeType: String
)

/**
 * Generates real PDF and Excel files, saves them to the user-selected device folder via
 * Storage Access Framework (or internal app storage), and provides separate Open & Share actions
 * as required by Sections 5.1 & 7.4 of the Upgrade PRD.
 */
class ReportExportManager(private val context: Context) {

    private val reportsDir: File
        get() = File(context.cacheDir, "reports").apply { if (!exists()) mkdirs() }

    fun suggestedFileName(table: ReportTableData, asExcel: Boolean): String {
        val ext = if (asExcel) ".xls" else ".pdf"
        return sanitizeFileName(table.fileNamePrefix) + ext
    }

    suspend fun generateReportFile(table: ReportTableData, asExcel: Boolean): File {
        return if (asExcel) exportToExcel(table) else exportToPdf(table)
    }

    /**
     * Generates the actual Excel or PDF file AND writes it into the [targetUri] chosen by the user
     * in the Android system folder picker dialog.
     */
    suspend fun saveReportToDeviceUri(
        table: ReportTableData,
        asExcel: Boolean,
        targetUri: Uri
    ): Result<SavedExportResult> = withContext(Dispatchers.IO) {
        try {
            val localFile = generateReportFile(table, asExcel)
            context.contentResolver.openOutputStream(targetUri)?.use { outStream ->
                localFile.inputStream().use { inStream ->
                    inStream.copyTo(outStream)
                }
            } ?: return@withContext Result.failure(
                IllegalStateException("Không thể ghi dữ liệu vào thư mục đã chọn.")
            )

            val mime = if (asExcel) "application/vnd.ms-excel" else "application/pdf"
            val decodedPath = targetUri.lastPathSegment ?: localFile.name
            Result.success(
                SavedExportResult(
                    localFile = localFile,
                    savedUri = targetUri,
                    fileName = localFile.name,
                    displayLocation = decodedPath,
                    mimeType = mime
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun exportToPdf(table: ReportTableData): File = withContext(Dispatchers.IO) {
        val pdfDocument = PdfDocument()
        val pageWidth = 842
        val pageHeight = 595
        val margin = 32f

        val baseTypeface = try {
            ResourcesCompat.getFont(context, R.font.be_vietnam_pro) ?: Typeface.DEFAULT
        } catch (_: Exception) {
            Typeface.DEFAULT
        }
        val boldTypeface = Typeface.create(baseTypeface, Typeface.BOLD)

        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = boldTypeface
            textSize = 15f
            color = Color.rgb(15, 23, 42)
        }
        val subtitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = baseTypeface
            textSize = 10.5f
            color = Color.rgb(71, 85, 105)
        }
        val headerBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(5, 150, 105)
            style = Paint.Style.FILL
        }
        val headerTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = boldTypeface
            textSize = 9.5f
            color = Color.WHITE
        }
        val cellTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = baseTypeface
            textSize = 9f
            color = Color.rgb(15, 23, 42)
        }
        val summaryTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = boldTypeface
            textSize = 11f
            color = Color.rgb(5, 150, 105)
        }
        val zebraPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(248, 250, 252)
            style = Paint.Style.FILL
        }
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(203, 213, 225)
            strokeWidth = 0.8f
            style = Paint.Style.STROKE
        }

        val usableWidth = pageWidth - margin * 2
        val colCount = table.headers.size.coerceAtLeast(1)
        val colWidths = calculateColumnWidths(table.headers, table.rows, usableWidth, colCount)

        var pageNumber = 1
        var pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
        var page = pdfDocument.startPage(pageInfo)
        var canvas: Canvas = page.canvas
        var currentY = margin

        fun drawHeader(c: Canvas, startY: Float): Float {
            var y = startY
            c.drawText("89 FITNESS & YOGA", margin, y + 12f, subtitlePaint)
            y += 18f
            c.drawText(table.reportTitle, margin, y + 15f, titlePaint)
            y += 20f
            c.drawText(table.subtitle, margin, y + 12f, subtitlePaint)
            y += 18f

            val headerHeight = 24f
            c.drawRect(margin, y, margin + usableWidth, y + headerHeight, headerBgPaint)
            var x = margin
            for (i in table.headers.indices) {
                val text = ellipsizeText(table.headers[i], headerTextPaint, colWidths[i] - 8f)
                c.drawText(text, x + 4f, y + 16f, headerTextPaint)
                x += colWidths[i]
            }
            return y + headerHeight
        }

        currentY = drawHeader(canvas, currentY)
        val rowHeight = 21f

        for ((rowIdx, row) in table.rows.withIndex()) {
            if (currentY + rowHeight > pageHeight - margin - 56f) {
                pdfDocument.finishPage(page)
                pageNumber++
                pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
                page = pdfDocument.startPage(pageInfo)
                canvas = page.canvas
                currentY = drawHeader(canvas, margin)
            }

            if (rowIdx % 2 == 1) {
                canvas.drawRect(margin, currentY, margin + usableWidth, currentY + rowHeight, zebraPaint)
            }
            canvas.drawRect(margin, currentY, margin + usableWidth, currentY + rowHeight, borderPaint)

            var x = margin
            for (colIdx in table.headers.indices) {
                val cellValue = row.getOrNull(colIdx) ?: ""
                val fitted = ellipsizeText(cellValue, cellTextPaint, colWidths[colIdx] - 8f)
                canvas.drawText(fitted, x + 4f, currentY + 14.5f, cellTextPaint)
                canvas.drawLine(x, currentY, x, currentY + rowHeight, borderPaint)
                x += colWidths[colIdx]
            }
            currentY += rowHeight
        }

        currentY += 14f
        for ((label, value) in table.summaryLines) {
            if (currentY + 18f > pageHeight - margin) {
                pdfDocument.finishPage(page)
                pageNumber++
                pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
                page = pdfDocument.startPage(pageInfo)
                canvas = page.canvas
                currentY = margin + 18f
            }
            canvas.drawText("$label: $value", margin, currentY, summaryTextPaint)
            currentY += 18f
        }

        pdfDocument.finishPage(page)

        val safeName = sanitizeFileName(table.fileNamePrefix) + ".pdf"
        val outFile = File(reportsDir, safeName)
        FileOutputStream(outFile).use { fos ->
            pdfDocument.writeTo(fos)
        }
        pdfDocument.close()
        outFile
    }

    suspend fun exportToExcel(table: ReportTableData): File = withContext(Dispatchers.IO) {
        val safeName = sanitizeFileName(table.fileNamePrefix) + ".xls"
        val outFile = File(reportsDir, safeName)
        val sb = StringBuilder()
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
        sb.append("<?mso-application progid=\"Excel.Sheet\"?>\n")
        sb.append("<Workbook xmlns=\"urn:schemas-microsoft-com:office:spreadsheet\"\n")
        sb.append(" xmlns:o=\"urn:schemas-microsoft-com:office:office\"\n")
        sb.append(" xmlns:x=\"urn:schemas-microsoft-com:office:excel\"\n")
        sb.append(" xmlns:ss=\"urn:schemas-microsoft-com:office:spreadsheet\">\n")
        sb.append(" <Styles>\n")
        sb.append("  <Style ss:ID=\"Title\"><Font ss:Bold=\"1\" ss:Size=\"14\" ss:Color=\"#065F46\"/></Style>\n")
        sb.append("  <Style ss:ID=\"Header\"><Font ss:Bold=\"1\" ss:Color=\"#FFFFFF\"/><Interior ss:Color=\"#059669\" ss:Pattern=\"Solid\"/></Style>\n")
        sb.append("  <Style ss:ID=\"NumberCell\"><NumberFormat ss:Format=\"#,##0\"/></Style>\n")
        sb.append("  <Style ss:ID=\"Summary\"><Font ss:Bold=\"1\" ss:Size=\"11\" ss:Color=\"#059669\"/></Style>\n")
        sb.append(" </Styles>\n")
        sb.append(" <Worksheet ss:Name=\"BaoCao89Fitness\">\n")
        sb.append("  <Table>\n")

        sb.append("   <Row><Cell ss:StyleID=\"Title\"><Data ss:Type=\"String\">${escapeXml(table.reportTitle)}</Data></Cell></Row>\n")
        sb.append("   <Row><Cell><Data ss:Type=\"String\">${escapeXml(table.subtitle)}</Data></Cell></Row>\n")
        sb.append("   <Row/>\n")

        sb.append("   <Row>\n")
        for (h in table.headers) {
            sb.append("    <Cell ss:StyleID=\"Header\"><Data ss:Type=\"String\">${escapeXml(h)}</Data></Cell>\n")
        }
        sb.append("   </Row>\n")

        for (row in table.rows) {
            sb.append("   <Row>\n")
            for ((colIdx, cellVal) in row.withIndex()) {
                if (colIdx in table.numericColumnIndices) {
                    val numVal = FormatUtils.parseVndInput(cellVal)
                    sb.append("    <Cell ss:StyleID=\"NumberCell\"><Data ss:Type=\"Number\">$numVal</Data></Cell>\n")
                } else {
                    sb.append("    <Cell><Data ss:Type=\"String\">${escapeXml(cellVal)}</Data></Cell>\n")
                }
            }
            sb.append("   </Row>\n")
        }

        sb.append("   <Row/>\n")
        for ((label, value) in table.summaryLines) {
            sb.append("   <Row>\n")
            sb.append("    <Cell ss:StyleID=\"Summary\"><Data ss:Type=\"String\">${escapeXml(label)}</Data></Cell>\n")
            sb.append("    <Cell ss:StyleID=\"Summary\"><Data ss:Type=\"String\">${escapeXml(value)}</Data></Cell>\n")
            sb.append("   </Row>\n")
        }

        sb.append("  </Table>\n")
        val endRow = 4 + table.rows.size
        val endCol = table.headers.size.coerceAtLeast(1)
        sb.append("  <AutoFilter x:Range=\"R4C1:R${endRow}C${endCol}\" xmlns=\"urn:schemas-microsoft-com:office:excel\"/>\n")
        sb.append(" </Worksheet>\n")
        sb.append("</Workbook>\n")

        outFile.writeText(sb.toString(), Charsets.UTF_8)
        outFile
    }

    fun openSavedFile(result: SavedExportResult) {
        try {
            val uri = result.savedUri ?: FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                result.localFile
            )
            val viewIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, result.mimeType)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(viewIntent, "Mở tệp báo cáo").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } catch (_: Exception) {
            shareExportedFile(result.localFile, result.mimeType)
        }
    }

    fun shareExportedFile(file: File, mimeType: String) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, file.nameWithoutExtension)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(shareIntent, "Chia sẻ báo cáo 89 FITNESS & YOGA").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    }

    private fun calculateColumnWidths(
        headers: List<String>,
        rows: List<List<String>>,
        usableWidth: Float,
        colCount: Int
    ): FloatArray {
        val weights = FloatArray(colCount) { i ->
            val headerLen = headers.getOrNull(i)?.length ?: 6
            val maxCellLen = rows.maxOfOrNull { it.getOrNull(i)?.length ?: 0 } ?: 6
            maxOf(headerLen, maxCellLen, 5).toFloat().coerceIn(5f, 32f)
        }
        val totalWeight = weights.sum().coerceAtLeast(1f)
        return FloatArray(colCount) { i -> (weights[i] / totalWeight) * usableWidth }
    }

    private fun ellipsizeText(text: String, paint: Paint, maxWidth: Float): String {
        if (paint.measureText(text) <= maxWidth) return text
        var trimmed = text
        while (trimmed.length > 3 && paint.measureText("$trimmed…") > maxWidth) {
            trimmed = trimmed.dropLast(1)
        }
        return "$trimmed…"
    }

    private fun sanitizeFileName(raw: String): String {
        return raw.trim()
            .replace(Regex("[\\\\/:*?\"<>|\\s]+"), "_")
            .lowercase(Locale.ROOT)
    }

    private fun escapeXml(input: String): String {
        return input
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&apos;")
    }
}
