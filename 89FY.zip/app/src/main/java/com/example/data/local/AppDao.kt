package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {

    // --- Price Plans ---
    @Query("SELECT * FROM price_plans ORDER BY domain ASC, category ASC, durationMonths ASC, sessionCount ASC")
    fun observeAllPricePlans(): Flow<List<PricePlanEntity>>

    @Query("SELECT * FROM price_plans")
    suspend fun getAllPricePlansOnce(): List<PricePlanEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPricePlan(plan: PricePlanEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPricePlans(plans: List<PricePlanEntity>)

    // --- Members ---
    @Query("SELECT * FROM members ORDER BY fullName ASC")
    fun observeAllMembers(): Flow<List<MemberEntity>>

    @Query("SELECT * FROM members")
    suspend fun getAllMembersOnce(): List<MemberEntity>

    @Query("SELECT * FROM members WHERE id = :id LIMIT 1")
    suspend fun getMemberById(id: String): MemberEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMember(member: MemberEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMembers(members: List<MemberEntity>)

    @Update
    suspend fun updateMember(member: MemberEntity)

    @Query("DELETE FROM members WHERE id = :id")
    suspend fun hardDeleteMember(id: String)

    // --- Contracts ---
    @Query("SELECT * FROM contracts ORDER BY startDateIso DESC, createdDateIso DESC")
    fun observeAllContracts(): Flow<List<ContractEntity>>

    @Query("SELECT * FROM contracts")
    suspend fun getAllContractsOnce(): List<ContractEntity>

    @Query("SELECT * FROM contracts WHERE id = :id LIMIT 1")
    suspend fun getContractById(id: String): ContractEntity?

    @Query("SELECT * FROM contracts WHERE memberId = :memberId ORDER BY endDateIso DESC")
    suspend fun getContractsForMember(memberId: String): List<ContractEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertContract(contract: ContractEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertContracts(contracts: List<ContractEntity>)

    @Query("DELETE FROM contracts WHERE id = :id")
    suspend fun hardDeleteContract(id: String)

    @Query("DELETE FROM contracts WHERE memberId = :memberId")
    suspend fun hardDeleteContractsByMember(memberId: String)

    // --- Contract Freezes ---
    @Query("SELECT * FROM contract_freezes ORDER BY freezeStartIso DESC")
    fun observeAllContractFreezes(): Flow<List<ContractFreezeEntity>>

    @Query("SELECT * FROM contract_freezes")
    suspend fun getAllContractFreezesOnce(): List<ContractFreezeEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertContractFreeze(freeze: ContractFreezeEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertContractFreezes(freezes: List<ContractFreezeEntity>)

    // --- Payment Transactions ---
    @Query("SELECT * FROM payment_transactions ORDER BY paymentDateIso DESC, createdAt DESC")
    fun observeAllPayments(): Flow<List<PaymentTransactionEntity>>

    @Query("SELECT * FROM payment_transactions")
    suspend fun getAllPaymentsOnce(): List<PaymentTransactionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPayment(payment: PaymentTransactionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPayments(payments: List<PaymentTransactionEntity>)

    // --- Refund Transactions ---
    @Query("SELECT * FROM refund_transactions ORDER BY refundDateIso DESC, createdAt DESC")
    fun observeAllRefunds(): Flow<List<RefundTransactionEntity>>

    @Query("SELECT * FROM refund_transactions")
    suspend fun getAllRefundsOnce(): List<RefundTransactionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertRefund(refund: RefundTransactionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertRefunds(refunds: List<RefundTransactionEntity>)

    // --- PT Clients, Contracts & Sessions ---
    @Query("SELECT * FROM pt_clients ORDER BY fullName ASC")
    fun observeAllPtClients(): Flow<List<PtClientEntity>>

    @Query("SELECT * FROM pt_clients")
    suspend fun getAllPtClientsOnce(): List<PtClientEntity>

    @Query("SELECT * FROM pt_clients WHERE id = :id LIMIT 1")
    suspend fun getPtClientById(id: String): PtClientEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPtClient(client: PtClientEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPtClients(clients: List<PtClientEntity>)

    @Query("DELETE FROM pt_clients WHERE id = :id")
    suspend fun hardDeletePtClient(id: String)

    @Query("SELECT * FROM pt_contracts ORDER BY registerDateIso DESC")
    fun observeAllPtContracts(): Flow<List<PtContractEntity>>

    @Query("SELECT * FROM pt_contracts")
    suspend fun getAllPtContractsOnce(): List<PtContractEntity>

    @Query("SELECT * FROM pt_contracts WHERE id = :id LIMIT 1")
    suspend fun getPtContractById(id: String): PtContractEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPtContract(contract: PtContractEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPtContracts(contracts: List<PtContractEntity>)

    @Query("DELETE FROM pt_contracts WHERE id = :id")
    suspend fun hardDeletePtContract(id: String)

    @Query("SELECT * FROM pt_sessions ORDER BY sessionDateIso DESC, createdAt DESC")
    fun observeAllPtSessions(): Flow<List<PtSessionEntity>>

    @Query("SELECT * FROM pt_sessions")
    suspend fun getAllPtSessionsOnce(): List<PtSessionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPtSession(session: PtSessionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPtSessions(sessions: List<PtSessionEntity>)

    @Query("DELETE FROM pt_sessions WHERE id = :id")
    suspend fun deletePtSession(id: String)

    // --- Short-Term Tickets ---
    @Query("SELECT * FROM short_term_tickets ORDER BY saleDateIso DESC, createdAt DESC")
    fun observeAllShortTermTickets(): Flow<List<ShortTermTicketEntity>>

    @Query("SELECT * FROM short_term_tickets")
    suspend fun getAllShortTermTicketsOnce(): List<ShortTermTicketEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertShortTermTicket(ticket: ShortTermTicketEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertShortTermTickets(tickets: List<ShortTermTicketEntity>)

    @Query("DELETE FROM short_term_tickets WHERE id = :id")
    suspend fun hardDeleteShortTermTicket(id: String)

    // --- Audit Logs ---
    @Query("SELECT * FROM edit_audit_logs ORDER BY timestamp DESC")
    fun observeAuditLogs(): Flow<List<EditAuditLogEntity>>

    @Query("SELECT * FROM edit_audit_logs")
    suspend fun getAllAuditLogsOnce(): List<EditAuditLogEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(log: EditAuditLogEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAuditLogs(logs: List<EditAuditLogEntity>)
}
