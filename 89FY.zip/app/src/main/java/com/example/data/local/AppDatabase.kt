package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        PricePlanEntity::class,
        MemberEntity::class,
        ContractEntity::class,
        ContractFreezeEntity::class,
        PaymentTransactionEntity::class,
        RefundTransactionEntity::class,
        PtClientEntity::class,
        PtContractEntity::class,
        PtSessionEntity::class,
        ShortTermTicketEntity::class,
        EditAuditLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun appDao(): AppDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "fitness89_management.db"
                )
                    .fallbackToDestructiveMigration(true)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
