package com.example.data.local

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "price_plans")
data class PricePlanEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val domain: String, // "GYM" or "YOGA"
    val category: String, // "NAM", "NU", "TRE_EM", "VE_NGAY", "VE_TUAN", "PT", "YOGA"
    val planName: String,
    val durationMonths: Int = 0, // 1, 2, 3, 12 for memberships; 0 for PT/Tickets
    val sessionCount: Int = 0, // > 0 for PT packages
    val priceVnd: Long,
    val isActive: Boolean = true,
    val updatedAt: Long = System.currentTimeMillis(),
    @ColumnInfo(defaultValue = "0") val isDeleted: Boolean = false,
    @ColumnInfo(defaultValue = "NULL") val deletedAt: Long? = null
)

@Entity(
    tableName = "members",
    indices = [Index(value = ["domain", "isDeleted"]), Index(value = ["phoneNumber"])]
)
data class MemberEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val domain: String, // "GYM" or "YOGA" - strictly separated
    val fullName: String,
    val phoneNumber: String,
    val customerGroup: String = "NAM", // "NAM", "NU", "TRE_EM", "YOGA"
    val avatarPath: String? = null,
    val linkedPtClientId: String? = null,
    val isDeleted: Boolean = false,
    val deleteType: String = "NONE", // "NONE", "ACCIDENTAL", "CONTRACT_CANCELLED"
    val deletedAt: Long? = null,
    val deleteReason: String? = null,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "contracts",
    indices = [
        Index(value = ["contractCode"], unique = true),
        Index(value = ["memberId"]),
        Index(value = ["domain", "isDeleted"])
    ]
)
data class ContractEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val contractCode: String,
    val memberId: String,
    val domain: String, // "GYM" or "YOGA"
    val contractType: String, // "NEW" or "RENEWAL"
    val pricePlanId: String? = null,
    val planNameSnapshot: String,
    val durationMonths: Int,
    val agreedValueVnd: Long,
    val paymentDateIso: String,
    val createdDateIso: String,
    val startDateIso: String,
    val endDateIso: String,
    val frozenDays: Int = 0,
    val status: String = "ACTIVE", // "ACTIVE" or "CANCELLED"
    val cancelledDateIso: String? = null,
    val cancelReason: String? = null,
    val refundedAmountVnd: Long = 0L,
    val refundDateIso: String? = null,
    val refundCashVnd: Long = 0L,
    val refundTransferVnd: Long = 0L,
    val cancelNote: String? = null,
    val isDeleted: Boolean = false,
    val deleteType: String = "NONE", // "NONE", "ACCIDENTAL", "CONTRACT_CANCELLED"
    val deletedAt: Long? = null,
    val updatedAt: Long = System.currentTimeMillis(),
    @ColumnInfo(defaultValue = "''") val note: String = "",
    @ColumnInfo(defaultValue = "0") val isEndDateManuallyEdited: Boolean = false
)

@Entity(
    tableName = "contract_freezes",
    indices = [Index(value = ["contractId"])]
)
data class ContractFreezeEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val contractId: String,
    val freezeStartIso: String,
    val freezeEndIso: String,
    val daysFrozen: Int,
    val reason: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "payment_transactions",
    indices = [
        Index(value = ["transactionCode"], unique = true),
        Index(value = ["contractId"]),
        Index(value = ["memberId"])
    ]
)
data class PaymentTransactionEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val transactionCode: String,
    val contractId: String,
    val memberId: String,
    val domain: String, // "GYM" or "YOGA"
    val paymentDateIso: String,
    val cashAmountVnd: Long,
    val transferAmountVnd: Long,
    val totalAmountVnd: Long,
    val paymentMethodLabel: String, // "Tiền mặt", "Chuyển khoản", "Kết hợp"
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "refund_transactions",
    indices = [
        Index(value = ["refundCode"], unique = true),
        Index(value = ["contractId"])
    ]
)
data class RefundTransactionEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val refundCode: String,
    val contractId: String,
    val memberId: String,
    val domain: String,
    val refundDateIso: String,
    val cashAmountVnd: Long,
    val transferAmountVnd: Long,
    val totalRefundVnd: Long,
    val reason: String,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "pt_clients")
data class PtClientEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val fullName: String,
    val phoneNumber: String,
    val linkedGymMemberId: String? = null,
    val trainerName: String = "Hà Đức",
    val isDeleted: Boolean = false,
    val deletedAt: Long? = null,
    val deleteReason: String? = null,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "pt_contracts",
    indices = [
        Index(value = ["contractCode"], unique = true),
        Index(value = ["ptClientId"])
    ]
)
data class PtContractEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val contractCode: String,
    val ptClientId: String,
    val trainerName: String = "Hà Đức",
    val registerDateIso: String,
    val paymentDateIso: String,
    val totalSessions: Int,
    val agreedValueVnd: Long,
    val cashPaidVnd: Long,
    val transferPaidVnd: Long,
    val status: String = "ACTIVE", // "ACTIVE", "COMPLETED", "CANCELLED"
    val isDeleted: Boolean = false,
    val deletedAt: Long? = null,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "pt_sessions",
    indices = [Index(value = ["ptContractId"]), Index(value = ["ptClientId"])]
)
data class PtSessionEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val ptContractId: String,
    val ptClientId: String,
    val sessionDateIso: String,
    val sessionsUsed: Int = 1,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "short_term_tickets",
    indices = [Index(value = ["ticketCode"], unique = true)]
)
data class ShortTermTicketEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val ticketCode: String,
    val ticketType: String, // "VE_NGAY" or "VE_TUAN"
    val saleDateIso: String,
    val quantity: Int,
    val unitPriceVnd: Long,
    val totalAmountVnd: Long,
    val cashAmountVnd: Long,
    val transferAmountVnd: Long,
    val paymentMethodLabel: String,
    val isDeleted: Boolean = false,
    val deletedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "edit_audit_logs")
data class EditAuditLogEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val entityType: String,
    val entityId: String,
    val summary: String,
    val timestamp: Long = System.currentTimeMillis()
)
