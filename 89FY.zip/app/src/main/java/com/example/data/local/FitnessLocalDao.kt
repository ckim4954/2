package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface FitnessLocalDao {

    // --- StudioConfig ---
    @Query("SELECT * FROM studio_config WHERE id = 'main_config' LIMIT 1")
    fun observeConfig(): Flow<LocalStudioConfigEntity?>

    @Query("SELECT * FROM studio_config WHERE id = 'main_config' LIMIT 1")
    suspend fun getConfigOnce(): LocalStudioConfigEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertConfig(config: LocalStudioConfigEntity)

    // --- Members ---
    @Query("SELECT * FROM members ORDER BY stt ASC")
    fun observeAllMembers(): Flow<List<LocalMemberEntity>>

    @Query("SELECT * FROM members ORDER BY stt ASC")
    suspend fun getAllMembersOnce(): List<LocalMemberEntity>

    @Query("SELECT * FROM members WHERE id = :id LIMIT 1")
    suspend fun getMemberById(id: String): LocalMemberEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMember(member: LocalMemberEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMembers(members: List<LocalMemberEntity>)

    @Query("DELETE FROM members WHERE id = :id")
    suspend fun deleteMemberById(id: String)

    // --- Contracts ---
    @Query("SELECT * FROM contracts ORDER BY startDate DESC")
    fun observeAllContracts(): Flow<List<LocalContractEntity>>

    @Query("SELECT * FROM contracts ORDER BY startDate DESC")
    suspend fun getAllContractsOnce(): List<LocalContractEntity>

    @Query("SELECT * FROM contracts WHERE id = :id LIMIT 1")
    suspend fun getContractById(id: String): LocalContractEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertContract(contract: LocalContractEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertContracts(contracts: List<LocalContractEntity>)

    @Query("DELETE FROM contracts WHERE id = :id")
    suspend fun deleteContractById(id: String)

    // --- PT Sessions ---
    @Query("SELECT * FROM pt_sessions ORDER BY sessionDate DESC")
    fun observeAllPtSessions(): Flow<List<LocalPtSessionEntity>>

    @Query("SELECT * FROM pt_sessions ORDER BY sessionDate DESC")
    suspend fun getAllPtSessionsOnce(): List<LocalPtSessionEntity>

    @Query("SELECT * FROM pt_sessions WHERE id = :id LIMIT 1")
    suspend fun getPtSessionById(id: String): LocalPtSessionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPtSession(session: LocalPtSessionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPtSessions(sessions: List<LocalPtSessionEntity>)

    @Query("DELETE FROM pt_sessions WHERE id = :id")
    suspend fun deletePtSessionById(id: String)

    // --- Single Tickets ---
    @Query("SELECT * FROM single_tickets ORDER BY saleDate DESC")
    fun observeAllSingleTickets(): Flow<List<LocalSingleTicketEntity>>

    @Query("SELECT * FROM single_tickets ORDER BY saleDate DESC")
    suspend fun getAllSingleTicketsOnce(): List<LocalSingleTicketEntity>

    @Query("SELECT * FROM single_tickets WHERE id = :id LIMIT 1")
    suspend fun getSingleTicketById(id: String): LocalSingleTicketEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSingleTicket(ticket: LocalSingleTicketEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSingleTickets(tickets: List<LocalSingleTicketEntity>)

    @Query("DELETE FROM single_tickets WHERE id = :id")
    suspend fun deleteSingleTicketById(id: String)

    // --- Atomic Transactions ---
    @Transaction
    suspend fun createMemberAndContractTransaction(
        updatedConfig: LocalStudioConfigEntity,
        member: LocalMemberEntity,
        contract: LocalContractEntity
    ) {
        upsertConfig(updatedConfig)
        upsertMember(member)
        upsertContract(contract)
    }

    @Transaction
    suspend fun createRenewalContractTransaction(
        updatedMember: LocalMemberEntity,
        contract: LocalContractEntity
    ) {
        upsertMember(updatedMember)
        upsertContract(contract)
    }

    @Transaction
    suspend fun recordPtSessionTransaction(
        session: LocalPtSessionEntity,
        updatedContract: LocalContractEntity
    ) {
        upsertPtSession(session)
        upsertContract(updatedContract)
    }

    @Transaction
    suspend fun softDeleteMemberCascadeTransaction(
        updatedMember: LocalMemberEntity,
        updatedContracts: List<LocalContractEntity>,
        updatedSessions: List<LocalPtSessionEntity>
    ) {
        upsertMember(updatedMember)
        if (updatedContracts.isNotEmpty()) upsertContracts(updatedContracts)
        if (updatedSessions.isNotEmpty()) upsertPtSessions(updatedSessions)
    }

    @Transaction
    suspend fun permanentDeleteMemberCascadeTransaction(
        memberId: String,
        contractIds: List<String>,
        sessionIds: List<String>
    ) {
        sessionIds.forEach { deletePtSessionById(it) }
        contractIds.forEach { deleteContractById(it) }
        deleteMemberById(memberId)
    }
}
