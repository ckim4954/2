package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        LocalMemberEntity::class,
        LocalContractEntity::class,
        LocalPtSessionEntity::class,
        LocalSingleTicketEntity::class,
        LocalStudioConfigEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class FitnessLocalDatabase : RoomDatabase() {

    abstract fun fitnessDao(): FitnessLocalDao

    companion object {
        private const val DATABASE_NAME = "89_fitness_local.db"

        @Volatile
        private var INSTANCE: FitnessLocalDatabase? = null

        fun getDatabase(context: Context): FitnessLocalDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    FitnessLocalDatabase::class.java,
                    DATABASE_NAME
                )
                    .fallbackToDestructiveMigration(dropAllTables = true)
                    .build()
                INSTANCE = instance
                instance
            }
        }

        fun createInMemory(context: Context): FitnessLocalDatabase {
            return Room.inMemoryDatabaseBuilder(
                context.applicationContext,
                FitnessLocalDatabase::class.java
            )
                .allowMainThreadQueries()
                .build()
        }
    }
}
