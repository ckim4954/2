package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.ContractRecord
import com.example.data.model.MemberProfile
import com.example.data.model.PtSessionRecord
import com.example.data.model.SingleTicketRecord
import com.example.data.model.StudioConfig
import com.google.firebase.Timestamp
import java.util.Date

@Entity(tableName = "members")
data class LocalMemberEntity(
    @PrimaryKey val id: String,
    val userId: String = "local_user",
    val type: String = "GYM", // GYM, YOGA, PT
    val stt: Long = 1L,
    val fullName: String = "",
    val phone: String = "",
    val memberGroup: String = "NAM", // NAM, NU, TRE_EM, NONE
    val nextContractSeq: Long = 1L,
    val isDeleted: Boolean = false,
    val deletedAtEpoch: Long = 0L,
    val deletedBatchId: String = "",
    val createdAtEpoch: Long = System.currentTimeMillis(),
    val updatedAtEpoch: Long = System.currentTimeMillis()
) {
    fun toDomain(): MemberProfile = MemberProfile(
        id = id,
        userId = userId,
        type = type,
        stt = stt,
        fullName = fullName,
        phone = phone,
        memberGroup = memberGroup,
        nextContractSeq = nextContractSeq,
        isDeleted = isDeleted,
        deletedAtEpoch = deletedAtEpoch,
        deletedBatchId = deletedBatchId,
        createdAt = Timestamp(Date(createdAtEpoch)),
        updatedAt = Timestamp(Date(updatedAtEpoch))
    )

    companion object {
        fun fromDomain(model: MemberProfile, nowMs: Long = System.currentTimeMillis()): LocalMemberEntity {
            val createdMs = model.createdAt?.toDate()?.time ?: nowMs
            val updatedMs = model.updatedAt?.toDate()?.time ?: nowMs
            return LocalMemberEntity(
                id = model.id,
                userId = model.userId.ifBlank { "local_user" },
                type = model.type,
                stt = model.stt,
                fullName = model.fullName,
                phone = model.phone,
                memberGroup = model.memberGroup,
                nextContractSeq = model.nextContractSeq,
                isDeleted = model.isDeleted,
                deletedAtEpoch = model.deletedAtEpoch,
                deletedBatchId = model.deletedBatchId,
                createdAtEpoch = createdMs,
                updatedAtEpoch = updatedMs
            )
        }
    }
}

@Entity(tableName = "contracts")
data class LocalContractEntity(
    @PrimaryKey val id: String,
    val userId: String = "local_user",
    val contractCode: String = "",
    val memberId: String = "",
    val memberSttSnapshot: Long = 1L,
    val memberNameSnapshot: String = "",
    val memberPhoneSnapshot: String = "",
    val serviceType: String = "GYM", // GYM, YOGA, PT
    val isRenewal: Boolean = false,
    val memberGroup: String = "NAM",
    val durationMonths: Long = 1L,
    val startDate: String = "",
    val endDate: String = "",
    val totalSessions: Long = 0L,
    val usedSessions: Long = 0L,
    val ptStatus: String = "NONE", // NONE, ACTIVE, COMPLETED
    val packageValue: Long = 0L,
    val paidAmount: Long = 0L,
    val paymentMethod: String = "TRANSFER",
    val cashAmount: Long = 0L,
    val transferAmount: Long = 0L,
    val paymentDate: String = "",
    val isDeleted: Boolean = false,
    val deletedAtEpoch: Long = 0L,
    val deletedBatchId: String = "",
    val createdAtEpoch: Long = System.currentTimeMillis(),
    val updatedAtEpoch: Long = System.currentTimeMillis()
) {
    fun toDomain(): ContractRecord = ContractRecord(
        id = id,
        userId = userId,
        contractCode = contractCode,
        memberId = memberId,
        memberSttSnapshot = memberSttSnapshot,
        memberNameSnapshot = memberNameSnapshot,
        memberPhoneSnapshot = memberPhoneSnapshot,
        serviceType = serviceType,
        isRenewal = isRenewal,
        memberGroup = memberGroup,
        durationMonths = durationMonths,
        startDate = startDate,
        endDate = endDate,
        totalSessions = totalSessions,
        usedSessions = usedSessions,
        ptStatus = ptStatus,
        packageValue = packageValue,
        paidAmount = paidAmount,
        paymentMethod = paymentMethod,
        cashAmount = cashAmount,
        transferAmount = transferAmount,
        paymentDate = paymentDate,
        isDeleted = isDeleted,
        deletedAtEpoch = deletedAtEpoch,
        deletedBatchId = deletedBatchId,
        createdAt = Timestamp(Date(createdAtEpoch)),
        updatedAt = Timestamp(Date(updatedAtEpoch))
    )

    companion object {
        fun fromDomain(model: ContractRecord, nowMs: Long = System.currentTimeMillis()): LocalContractEntity {
            val createdMs = model.createdAt?.toDate()?.time ?: nowMs
            val updatedMs = model.updatedAt?.toDate()?.time ?: nowMs
            return LocalContractEntity(
                id = model.id,
                userId = model.userId.ifBlank { "local_user" },
                contractCode = model.contractCode,
                memberId = model.memberId,
                memberSttSnapshot = model.memberSttSnapshot,
                memberNameSnapshot = model.memberNameSnapshot,
                memberPhoneSnapshot = model.memberPhoneSnapshot,
                serviceType = model.serviceType,
                isRenewal = model.isRenewal,
                memberGroup = model.memberGroup,
                durationMonths = model.durationMonths,
                startDate = model.startDate,
                endDate = model.endDate,
                totalSessions = model.totalSessions,
                usedSessions = model.usedSessions,
                ptStatus = model.ptStatus,
                packageValue = model.packageValue,
                paidAmount = model.paidAmount,
                paymentMethod = model.paymentMethod,
                cashAmount = model.cashAmount,
                transferAmount = model.transferAmount,
                paymentDate = model.paymentDate,
                isDeleted = model.isDeleted,
                deletedAtEpoch = model.deletedAtEpoch,
                deletedBatchId = model.deletedBatchId,
                createdAtEpoch = createdMs,
                updatedAtEpoch = updatedMs
            )
        }
    }
}

@Entity(tableName = "pt_sessions")
data class LocalPtSessionEntity(
    @PrimaryKey val id: String,
    val userId: String = "local_user",
    val contractId: String = "",
    val memberId: String = "",
    val memberSttSnapshot: Long = 1L,
    val memberNameSnapshot: String = "",
    val contractCodeSnapshot: String = "",
    val sessionDate: String = "",
    val note: String = "",
    val isDeleted: Boolean = false,
    val deletedAtEpoch: Long = 0L,
    val deletedBatchId: String = "",
    val createdAtEpoch: Long = System.currentTimeMillis(),
    val updatedAtEpoch: Long = System.currentTimeMillis()
) {
    fun toDomain(): PtSessionRecord = PtSessionRecord(
        id = id,
        userId = userId,
        contractId = contractId,
        memberId = memberId,
        memberSttSnapshot = memberSttSnapshot,
        memberNameSnapshot = memberNameSnapshot,
        contractCodeSnapshot = contractCodeSnapshot,
        sessionDate = sessionDate,
        note = note,
        isDeleted = isDeleted,
        deletedAtEpoch = deletedAtEpoch,
        deletedBatchId = deletedBatchId,
        createdAt = Timestamp(Date(createdAtEpoch)),
        updatedAt = Timestamp(Date(updatedAtEpoch))
    )

    companion object {
        fun fromDomain(model: PtSessionRecord, nowMs: Long = System.currentTimeMillis()): LocalPtSessionEntity {
            val createdMs = model.createdAt?.toDate()?.time ?: nowMs
            val updatedMs = model.updatedAt?.toDate()?.time ?: nowMs
            return LocalPtSessionEntity(
                id = model.id,
                userId = model.userId.ifBlank { "local_user" },
                contractId = model.contractId,
                memberId = model.memberId,
                memberSttSnapshot = model.memberSttSnapshot,
                memberNameSnapshot = model.memberNameSnapshot,
                contractCodeSnapshot = model.contractCodeSnapshot,
                sessionDate = model.sessionDate,
                note = model.note,
                isDeleted = model.isDeleted,
                deletedAtEpoch = model.deletedAtEpoch,
                deletedBatchId = model.deletedBatchId,
                createdAtEpoch = createdMs,
                updatedAtEpoch = updatedMs
            )
        }
    }
}

@Entity(tableName = "single_tickets")
data class LocalSingleTicketEntity(
    @PrimaryKey val id: String,
    val userId: String = "local_user",
    val ticketType: String = "DAILY", // DAILY, WEEKLY
    val saleDate: String = "",
    val quantity: Long = 1L,
    val unitPrice: Long = 0L,
    val totalAmount: Long = 0L,
    val paymentMethod: String = "TRANSFER",
    val cashAmount: Long = 0L,
    val transferAmount: Long = 0L,
    val isDeleted: Boolean = false,
    val deletedAtEpoch: Long = 0L,
    val deletedBatchId: String = "",
    val createdAtEpoch: Long = System.currentTimeMillis(),
    val updatedAtEpoch: Long = System.currentTimeMillis()
) {
    fun toDomain(): SingleTicketRecord = SingleTicketRecord(
        id = id,
        userId = userId,
        ticketType = ticketType,
        saleDate = saleDate,
        quantity = quantity,
        unitPrice = unitPrice,
        totalAmount = totalAmount,
        paymentMethod = paymentMethod,
        cashAmount = cashAmount,
        transferAmount = transferAmount,
        isDeleted = isDeleted,
        deletedAtEpoch = deletedAtEpoch,
        deletedBatchId = deletedBatchId,
        createdAt = Timestamp(Date(createdAtEpoch)),
        updatedAt = Timestamp(Date(updatedAtEpoch))
    )

    companion object {
        fun fromDomain(model: SingleTicketRecord, nowMs: Long = System.currentTimeMillis()): LocalSingleTicketEntity {
            val createdMs = model.createdAt?.toDate()?.time ?: nowMs
            val updatedMs = model.updatedAt?.toDate()?.time ?: nowMs
            return LocalSingleTicketEntity(
                id = model.id,
                userId = model.userId.ifBlank { "local_user" },
                ticketType = model.ticketType,
                saleDate = model.saleDate,
                quantity = model.quantity,
                unitPrice = model.unitPrice,
                totalAmount = model.totalAmount,
                paymentMethod = model.paymentMethod,
                cashAmount = model.cashAmount,
                transferAmount = model.transferAmount,
                isDeleted = model.isDeleted,
                deletedAtEpoch = model.deletedAtEpoch,
                deletedBatchId = model.deletedBatchId,
                createdAtEpoch = createdMs,
                updatedAtEpoch = updatedMs
            )
        }
    }
}

@Entity(tableName = "studio_config")
data class LocalStudioConfigEntity(
    @PrimaryKey val id: String = "main_config",
    val userId: String = "local_user",
    val lastGymStt: Long = 0L,
    val lastYogaStt: Long = 0L,
    val lastPtStt: Long = 0L,
    val gymNam1M: Long = 300_000L,
    val gymNam2M: Long = 550_000L,
    val gymNam3M: Long = 800_000L,
    val gymNam12M: Long = 3_000_000L,
    val gymNu1M: Long = 250_000L,
    val gymNu2M: Long = 450_000L,
    val gymNu3M: Long = 700_000L,
    val gymNu12M: Long = 2_800_000L,
    val gymTreEm1M: Long = 300_000L,
    val gymTreEm2M: Long = 500_000L,
    val gymTreEm3M: Long = 700_000L,
    val gymTreEm12M: Long = 2_500_000L,
    val yoga1M: Long = 500_000L,
    val yoga2M: Long = 1_000_000L,
    val yoga3M: Long = 1_500_000L,
    val singleDailyPrice: Long = 50_000L,
    val singleWeeklyPrice: Long = 200_000L,
    val isDarkMode: Boolean = false,
    val lastSyncEpoch: Long = 0L,
    val createdAtEpoch: Long = System.currentTimeMillis(),
    val updatedAtEpoch: Long = System.currentTimeMillis()
) {
    fun toDomain(): StudioConfig = StudioConfig(
        id = id.ifBlank { "main_config" },
        userId = userId,
        lastGymStt = lastGymStt,
        lastYogaStt = lastYogaStt,
        lastPtStt = lastPtStt,
        gymNam1M = gymNam1M,
        gymNam2M = gymNam2M,
        gymNam3M = gymNam3M,
        gymNam12M = gymNam12M,
        gymNu1M = gymNu1M,
        gymNu2M = gymNu2M,
        gymNu3M = gymNu3M,
        gymNu12M = gymNu12M,
        gymTreEm1M = gymTreEm1M,
        gymTreEm2M = gymTreEm2M,
        gymTreEm3M = gymTreEm3M,
        gymTreEm12M = gymTreEm12M,
        yoga1M = yoga1M,
        yoga2M = yoga2M,
        yoga3M = yoga3M,
        singleDailyPrice = singleDailyPrice,
        singleWeeklyPrice = singleWeeklyPrice,
        isDarkMode = isDarkMode,
        lastSyncEpoch = lastSyncEpoch,
        createdAt = Timestamp(Date(createdAtEpoch)),
        updatedAt = Timestamp(Date(updatedAtEpoch))
    )

    companion object {
        fun fromDomain(model: StudioConfig, nowMs: Long = System.currentTimeMillis()): LocalStudioConfigEntity {
            val createdMs = model.createdAt?.toDate()?.time ?: nowMs
            val updatedMs = model.updatedAt?.toDate()?.time ?: nowMs
            return LocalStudioConfigEntity(
                id = model.id.ifBlank { "main_config" },
                userId = model.userId.ifBlank { "local_user" },
                lastGymStt = model.lastGymStt,
                lastYogaStt = model.lastYogaStt,
                lastPtStt = model.lastPtStt,
                gymNam1M = model.gymNam1M,
                gymNam2M = model.gymNam2M,
                gymNam3M = model.gymNam3M,
                gymNam12M = model.gymNam12M,
                gymNu1M = model.gymNu1M,
                gymNu2M = model.gymNu2M,
                gymNu3M = model.gymNu3M,
                gymNu12M = model.gymNu12M,
                gymTreEm1M = model.gymTreEm1M,
                gymTreEm2M = model.gymTreEm2M,
                gymTreEm3M = model.gymTreEm3M,
                gymTreEm12M = model.gymTreEm12M,
                yoga1M = model.yoga1M,
                yoga2M = model.yoga2M,
                yoga3M = model.yoga3M,
                singleDailyPrice = model.singleDailyPrice,
                singleWeeklyPrice = model.singleWeeklyPrice,
                isDarkMode = model.isDarkMode,
                lastSyncEpoch = model.lastSyncEpoch,
                createdAtEpoch = createdMs,
                updatedAtEpoch = updatedMs
            )
        }
    }
}
