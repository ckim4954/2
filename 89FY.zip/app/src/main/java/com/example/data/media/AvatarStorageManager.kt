package com.example.data.media

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

/**
 * Compresses and manages member avatars in internal storage (Section 4.1 & 22):
 * - Resizes to max 480x480
 * - Compresses as WebP (or JPEG) at 80% quality
 * - Stored separately from SQLite database to keep DB fast and lightweight
 */
class AvatarStorageManager(private val context: Context) {

    private val avatarDir: File
        get() = File(context.filesDir, "avatars").apply { if (!exists()) mkdirs() }

    suspend fun saveCompressedAvatar(sourceUri: Uri): String? = withContext(Dispatchers.IO) {
        try {
            val inputStream = context.contentResolver.openInputStream(sourceUri) ?: return@withContext null
            val original = BitmapFactory.decodeStream(inputStream)
            inputStream.close()
            if (original == null) return@withContext null

            val maxDim = 480
            val ratio = minOf(
                maxDim.toFloat() / original.width.coerceAtLeast(1),
                maxDim.toFloat() / original.height.coerceAtLeast(1),
                1.0f
            )
            val targetW = (original.width * ratio).toInt().coerceAtLeast(1)
            val targetH = (original.height * ratio).toInt().coerceAtLeast(1)
            val scaled = Bitmap.createScaledBitmap(original, targetW, targetH, true)

            val fileName = "avatar_${UUID.randomUUID()}.webp"
            val outFile = File(avatarDir, fileName)
            FileOutputStream(outFile).use { fos ->
                @Suppress("DEPRECATION")
                val format = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    Bitmap.CompressFormat.WEBP_LOSSY
                } else {
                    Bitmap.CompressFormat.WEBP
                }
                scaled.compress(format, 80, fos)
            }
            outFile.absolutePath
        } catch (e: Exception) {
            null
        }
    }
}
