package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp
import org.json.JSONArray
import org.json.JSONObject

enum class ServiceType(val code: String, val label: String) {
    GYM("GYM", "GYM"),
    YOGA("YOGA", "YOGA"),
    PT("PT", "PT");

    companion object {
        fun fromCode(code: String): ServiceType =
            entries.firstOrNull { it.code.equals(code, ignoreCase = true) } ?: GYM
    }
}

enum class MemberGroup(val code: String, val label: String) {
    NAM("NAM", "Nam"),
    NU("NU", "Nữ"),
    TRE_EM("TRE_EM", "Trẻ em"),
    NONE("NONE", "Chung");

    companion object {
        fun fromCode(code: String): MemberGroup =
            entries.firstOrNull { it.code.equals(code, ignoreCase = true) } ?: NONE
    }
}

enum class PaymentMethod(val code: String, val label: String) {
    TRANSFER("TRANSFER", "Chuyển khoản"),
    CASH("CASH", "Tiền mặt"),
    COMBINED("COMBINED", "Kết hợp");

    companion object {
        fun fromCode(code: String): PaymentMethod =
            entries.firstOrNull { it.code.equals(code, ignoreCase = true) } ?: TRANSFER
    }
}

enum class PtContractStatus(val code: String, val label: String) {
    NONE("NONE", "Không áp dụng"),
    ACTIVE("ACTIVE", "Đang hiệu lực"),
    COMPLETED("COMPLETED", "Hoàn thành (Hết buổi)");

    companion object {
        fun fromCode(code: String): PtContractStatus =
            entries.firstOrNull { it.code.equals(code, ignoreCase = true) } ?: NONE
    }
}

enum class SingleTicketType(val code: String, val label: String) {
    DAILY("DAILY", "Vé ngày"),
    WEEKLY("WEEKLY", "Vé tuần");

    companion object {
        fun fromCode(code: String): SingleTicketType =
            entries.firstOrNull { it.code.equals(code, ignoreCase = true) } ?: DAILY
    }
}

enum class TrashCategory(val index: Int, val title: String) {
    GYM_MEMBER(1, "1. Hội viên GYM"),
    YOGA_MEMBER(2, "2. Hội viên YOGA"),
    GYM_CONTRACT(3, "3. Hợp đồng GYM"),
    YOGA_CONTRACT(4, "4. Hợp đồng YOGA"),
    PT_MEMBER(5, "5. Hồ sơ PT"),
    PT_CONTRACT(6, "6. Hợp đồng PT"),
    SINGLE_TICKET(7, "7. Vé lẻ"),
    OTHER_DATA(8, "8. Dữ liệu khác")
}

@IgnoreExtraProperties
data class MemberProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val type: String = "GYM", // GYM, YOGA, PT
    val stt: Long = 1L,
    val fullName: String = "",
    val phone: String = "",
    val memberGroup: String = "NAM", // NAM, NU, TRE_EM, NONE
    val nextContractSeq: Long = 1L,
    @get:com.google.firebase.firestore.PropertyName("isDeleted")
    val isDeleted: Boolean = false,
    val deletedAtEpoch: Long = 0L,
    val deletedBatchId: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun formattedStt(): String = "STT${stt}"

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("userId", userId)
        put("type", type)
        put("stt", stt)
        put("fullName", fullName)
        put("phone", phone)
        put("memberGroup", memberGroup)
        put("nextContractSeq", nextContractSeq)
        put("isDeleted", isDeleted)
        put("deletedAtEpoch", deletedAtEpoch)
        put("deletedBatchId", deletedBatchId)
        put("updatedAtMs", (updatedAt ?: createdAt)?.toDate()?.time ?: System.currentTimeMillis())
    }

    companion object {
        fun fromJson(obj: JSONObject, overrideUserId: String): MemberProfile = MemberProfile(
            id = obj.optString("id", ""),
            userId = overrideUserId,
            type = obj.optString("type", "GYM"),
            stt = obj.optLong("stt", 1L),
            fullName = obj.optString("fullName", ""),
            phone = obj.optString("phone", ""),
            memberGroup = obj.optString("memberGroup", "NONE"),
            nextContractSeq = obj.optLong("nextContractSeq", 1L),
            isDeleted = obj.optBoolean("isDeleted", false),
            deletedAtEpoch = obj.optLong("deletedAtEpoch", 0L),
            deletedBatchId = obj.optString("deletedBatchId", "")
        )
    }
}

@IgnoreExtraProperties
data class ContractRecord(
    @DocumentId val id: String = "",
    val userId: String = "",
    val contractCode: String = "",
    val memberId: String = "",
    val memberSttSnapshot: Long = 1L,
    val memberNameSnapshot: String = "",
    val memberPhoneSnapshot: String = "",
    val serviceType: String = "GYM", // GYM, YOGA, PT
    @get:com.google.firebase.firestore.PropertyName("isRenewal")
    val isRenewal: Boolean = false,
    val memberGroup: String = "NAM", // NAM, NU, TRE_EM, NONE
    val durationMonths: Long = 1L,
    val startDate: String = "", // yyyy-MM-dd
    val endDate: String = "",   // yyyy-MM-dd
    val totalSessions: Long = 0L,
    val usedSessions: Long = 0L,
    val ptStatus: String = "NONE", // NONE, ACTIVE, COMPLETED
    val packageValue: Long = 0L,
    val paidAmount: Long = 0L,
    val paymentMethod: String = "TRANSFER", // TRANSFER, CASH, COMBINED
    val cashAmount: Long = 0L,
    val transferAmount: Long = 0L,
    val paymentDate: String = "", // yyyy-MM-dd
    @get:com.google.firebase.firestore.PropertyName("isDeleted")
    val isDeleted: Boolean = false,
    val deletedAtEpoch: Long = 0L,
    val deletedBatchId: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    @get:com.google.firebase.firestore.Exclude
    val remainingSessions: Long
        get() = (totalSessions - usedSessions).coerceAtLeast(0L)

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("userId", userId)
        put("contractCode", contractCode)
        put("memberId", memberId)
        put("memberSttSnapshot", memberSttSnapshot)
        put("memberNameSnapshot", memberNameSnapshot)
        put("memberPhoneSnapshot", memberPhoneSnapshot)
        put("serviceType", serviceType)
        put("isRenewal", isRenewal)
        put("memberGroup", memberGroup)
        put("durationMonths", durationMonths)
        put("startDate", startDate)
        put("endDate", endDate)
        put("totalSessions", totalSessions)
        put("usedSessions", usedSessions)
        put("ptStatus", ptStatus)
        put("packageValue", packageValue)
        put("paidAmount", paidAmount)
        put("paymentMethod", paymentMethod)
        put("cashAmount", cashAmount)
        put("transferAmount", transferAmount)
        put("paymentDate", paymentDate)
        put("isDeleted", isDeleted)
        put("deletedAtEpoch", deletedAtEpoch)
        put("deletedBatchId", deletedBatchId)
        put("updatedAtMs", (updatedAt ?: createdAt)?.toDate()?.time ?: System.currentTimeMillis())
    }

    companion object {
        fun fromJson(obj: JSONObject, overrideUserId: String): ContractRecord = ContractRecord(
            id = obj.optString("id", ""),
            userId = overrideUserId,
            contractCode = obj.optString("contractCode", ""),
            memberId = obj.optString("memberId", ""),
            memberSttSnapshot = obj.optLong("memberSttSnapshot", 1L),
            memberNameSnapshot = obj.optString("memberNameSnapshot", ""),
            memberPhoneSnapshot = obj.optString("memberPhoneSnapshot", ""),
            serviceType = obj.optString("serviceType", "GYM"),
            isRenewal = obj.optBoolean("isRenewal", false),
            memberGroup = obj.optString("memberGroup", "NONE"),
            durationMonths = obj.optLong("durationMonths", 0L),
            startDate = obj.optString("startDate", ""),
            endDate = obj.optString("endDate", ""),
            totalSessions = obj.optLong("totalSessions", 0L),
            usedSessions = obj.optLong("usedSessions", 0L),
            ptStatus = obj.optString("ptStatus", "NONE"),
            packageValue = obj.optLong("packageValue", 0L),
            paidAmount = obj.optLong("paidAmount", 0L),
            paymentMethod = obj.optString("paymentMethod", "TRANSFER"),
            cashAmount = obj.optLong("cashAmount", 0L),
            transferAmount = obj.optLong("transferAmount", 0L),
            paymentDate = obj.optString("paymentDate", ""),
            isDeleted = obj.optBoolean("isDeleted", false),
            deletedAtEpoch = obj.optLong("deletedAtEpoch", 0L),
            deletedBatchId = obj.optString("deletedBatchId", "")
        )
    }
}

@IgnoreExtraProperties
data class PtSessionRecord(
    @DocumentId val id: String = "",
    val userId: String = "",
    val contractId: String = "",
    val memberId: String = "",
    val memberSttSnapshot: Long = 1L,
    val memberNameSnapshot: String = "",
    val contractCodeSnapshot: String = "",
    val sessionDate: String = "", // yyyy-MM-dd
    val note: String = "",
    @get:com.google.firebase.firestore.PropertyName("isDeleted")
    val isDeleted: Boolean = false,
    val deletedAtEpoch: Long = 0L,
    val deletedBatchId: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("userId", userId)
        put("contractId", contractId)
        put("memberId", memberId)
        put("memberSttSnapshot", memberSttSnapshot)
        put("memberNameSnapshot", memberNameSnapshot)
        put("contractCodeSnapshot", contractCodeSnapshot)
        put("sessionDate", sessionDate)
        put("note", note)
        put("isDeleted", isDeleted)
        put("deletedAtEpoch", deletedAtEpoch)
        put("deletedBatchId", deletedBatchId)
        put("updatedAtMs", (updatedAt ?: createdAt)?.toDate()?.time ?: System.currentTimeMillis())
    }

    companion object {
        fun fromJson(obj: JSONObject, overrideUserId: String): PtSessionRecord = PtSessionRecord(
            id = obj.optString("id", ""),
            userId = overrideUserId,
            contractId = obj.optString("contractId", ""),
            memberId = obj.optString("memberId", ""),
            memberSttSnapshot = obj.optLong("memberSttSnapshot", 1L),
            memberNameSnapshot = obj.optString("memberNameSnapshot", ""),
            contractCodeSnapshot = obj.optString("contractCodeSnapshot", ""),
            sessionDate = obj.optString("sessionDate", ""),
            note = obj.optString("note", ""),
            isDeleted = obj.optBoolean("isDeleted", false),
            deletedAtEpoch = obj.optLong("deletedAtEpoch", 0L),
            deletedBatchId = obj.optString("deletedBatchId", "")
        )
    }
}

@IgnoreExtraProperties
data class SingleTicketRecord(
    @DocumentId val id: String = "",
    val userId: String = "",
    val ticketType: String = "DAILY", // DAILY, WEEKLY
    val saleDate: String = "", // yyyy-MM-dd
    val quantity: Long = 1L,
    val unitPrice: Long = 0L,
    val totalAmount: Long = 0L,
    val paymentMethod: String = "TRANSFER",
    val cashAmount: Long = 0L,
    val transferAmount: Long = 0L,
    @get:com.google.firebase.firestore.PropertyName("isDeleted")
    val isDeleted: Boolean = false,
    val deletedAtEpoch: Long = 0L,
    val deletedBatchId: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("userId", userId)
        put("ticketType", ticketType)
        put("saleDate", saleDate)
        put("quantity", quantity)
        put("unitPrice", unitPrice)
        put("totalAmount", totalAmount)
        put("paymentMethod", paymentMethod)
        put("cashAmount", cashAmount)
        put("transferAmount", transferAmount)
        put("isDeleted", isDeleted)
        put("deletedAtEpoch", deletedAtEpoch)
        put("deletedBatchId", deletedBatchId)
        put("updatedAtMs", (updatedAt ?: createdAt)?.toDate()?.time ?: System.currentTimeMillis())
    }

    companion object {
        fun fromJson(obj: JSONObject, overrideUserId: String): SingleTicketRecord = SingleTicketRecord(
            id = obj.optString("id", ""),
            userId = overrideUserId,
            ticketType = obj.optString("ticketType", "DAILY"),
            saleDate = obj.optString("saleDate", ""),
            quantity = obj.optLong("quantity", 1L),
            unitPrice = obj.optLong("unitPrice", 0L),
            totalAmount = obj.optLong("totalAmount", 0L),
            paymentMethod = obj.optString("paymentMethod", "TRANSFER"),
            cashAmount = obj.optLong("cashAmount", 0L),
            transferAmount = obj.optLong("transferAmount", 0L),
            isDeleted = obj.optBoolean("isDeleted", false),
            deletedAtEpoch = obj.optLong("deletedAtEpoch", 0L),
            deletedBatchId = obj.optString("deletedBatchId", "")
        )
    }
}

@IgnoreExtraProperties
data class StudioConfig(
    @DocumentId val id: String = "main_config",
    val userId: String = "",
    val lastGymStt: Long = 0L,
    val lastYogaStt: Long = 0L,
    val lastPtStt: Long = 0L,
    // Bảng giá đã chốt trong 01_Tong_quan.md:
    // GYM Nam: 1M=300.000, 2M=550.000, 3M=800.000, 12M=3.000.000
    val gymNam1M: Long = 300_000L,
    val gymNam2M: Long = 550_000L,
    val gymNam3M: Long = 800_000L,
    val gymNam12M: Long = 3_000_000L,
    // GYM Nữ: 1M=250.000, 2M=450.000, 3M=700.000, 12M=2.800.000
    val gymNu1M: Long = 250_000L,
    val gymNu2M: Long = 450_000L,
    val gymNu3M: Long = 700_000L,
    val gymNu12M: Long = 2_800_000L,
    // GYM Trẻ em: 1M=300.000, 2M=500.000, 3M=700.000, 12M=2.500.000
    val gymTreEm1M: Long = 300_000L,
    val gymTreEm2M: Long = 500_000L,
    val gymTreEm3M: Long = 700_000L,
    val gymTreEm12M: Long = 2_500_000L,
    // YOGA: 1M=500.000, 2M=1.000.000, 3M=1.500.000
    val yoga1M: Long = 500_000L,
    val yoga2M: Long = 1_000_000L,
    val yoga3M: Long = 1_500_000L,
    // Vé lẻ gợi ý mặc định (người dùng có thể sửa khi bán)
    val singleDailyPrice: Long = 50_000L,
    val singleWeeklyPrice: Long = 200_000L,
    @get:com.google.firebase.firestore.PropertyName("isDarkMode")
    val isDarkMode: Boolean = false,
    val lastSyncEpoch: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun getGymPrice(group: MemberGroup, months: Int): Long {
        return when (group) {
            MemberGroup.NAM -> when (months) {
                1 -> gymNam1M
                2 -> gymNam2M
                3 -> gymNam3M
                12 -> gymNam12M
                else -> gymNam1M
            }
            MemberGroup.NU -> when (months) {
                1 -> gymNu1M
                2 -> gymNu2M
                3 -> gymNu3M
                12 -> gymNu12M
                else -> gymNu1M
            }
            MemberGroup.TRE_EM -> when (months) {
                1 -> gymTreEm1M
                2 -> gymTreEm2M
                3 -> gymTreEm3M
                12 -> gymTreEm12M
                else -> gymTreEm1M
            }
            MemberGroup.NONE -> gymNam1M
        }
    }

    fun getYogaPrice(months: Int): Long {
        return when (months) {
            1 -> yoga1M
            2 -> yoga2M
            3 -> yoga3M
            else -> yoga1M
        }
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id.ifBlank { "main_config" })
        put("userId", userId)
        put("lastGymStt", lastGymStt)
        put("lastYogaStt", lastYogaStt)
        put("lastPtStt", lastPtStt)
        put("gymNam1M", gymNam1M)
        put("gymNam2M", gymNam2M)
        put("gymNam3M", gymNam3M)
        put("gymNam12M", gymNam12M)
        put("gymNu1M", gymNu1M)
        put("gymNu2M", gymNu2M)
        put("gymNu3M", gymNu3M)
        put("gymNu12M", gymNu12M)
        put("gymTreEm1M", gymTreEm1M)
        put("gymTreEm2M", gymTreEm2M)
        put("gymTreEm3M", gymTreEm3M)
        put("gymTreEm12M", gymTreEm12M)
        put("yoga1M", yoga1M)
        put("yoga2M", yoga2M)
        put("yoga3M", yoga3M)
        put("singleDailyPrice", singleDailyPrice)
        put("singleWeeklyPrice", singleWeeklyPrice)
        put("isDarkMode", isDarkMode)
        put("lastSyncEpoch", lastSyncEpoch)
    }

    companion object {
        fun fromJson(obj: JSONObject, overrideUserId: String): StudioConfig = StudioConfig(
            id = obj.optString("id", "main_config").ifBlank { "main_config" },
            userId = overrideUserId,
            lastGymStt = obj.optLong("lastGymStt", 0L),
            lastYogaStt = obj.optLong("lastYogaStt", 0L),
            lastPtStt = obj.optLong("lastPtStt", 0L),
            gymNam1M = obj.optLong("gymNam1M", 300_000L),
            gymNam2M = obj.optLong("gymNam2M", 550_000L),
            gymNam3M = obj.optLong("gymNam3M", 800_000L),
            gymNam12M = obj.optLong("gymNam12M", 3_000_000L),
            gymNu1M = obj.optLong("gymNu1M", 250_000L),
            gymNu2M = obj.optLong("gymNu2M", 450_000L),
            gymNu3M = obj.optLong("gymNu3M", 700_000L),
            gymNu12M = obj.optLong("gymNu12M", 2_800_000L),
            gymTreEm1M = obj.optLong("gymTreEm1M", 300_000L),
            gymTreEm2M = obj.optLong("gymTreEm2M", 500_000L),
            gymTreEm3M = obj.optLong("gymTreEm3M", 700_000L),
            gymTreEm12M = obj.optLong("gymTreEm12M", 2_500_000L),
            yoga1M = obj.optLong("yoga1M", 500_000L),
            yoga2M = obj.optLong("yoga2M", 1_000_000L),
            yoga3M = obj.optLong("yoga3M", 1_500_000L),
            singleDailyPrice = obj.optLong("singleDailyPrice", 50_000L),
            singleWeeklyPrice = obj.optLong("singleWeeklyPrice", 200_000L),
            isDarkMode = obj.optBoolean("isDarkMode", false),
            lastSyncEpoch = obj.optLong("lastSyncEpoch", 0L)
        )
    }
}

data class BackupBundle(
    val exportedAtEpoch: Long,
    val appVersion: String = "1.0",
    val config: StudioConfig,
    val members: List<MemberProfile>,
    val contracts: List<ContractRecord>,
    val ptSessions: List<PtSessionRecord>,
    val singleTickets: List<SingleTicketRecord>
) {
    /**
     * Kiểm tra tính toàn vẹn dữ liệu khi sao lưu và khôi phục:
     * - Kiểm tra mã định danh, STT dương, tên hội viên hợp lệ
     * - Kiểm tra hợp đồng có mã hợp đồng và giá trị không âm
     * - Kiểm tra bảng giá không âm
     */
    fun validateIntegrity(): Result<Unit> = runCatching {
        require(appVersion.isNotBlank()) { "Phiên bản gói sao lưu không hợp lệ." }
        require(
            config.gymNam1M >= 0L && config.gymNu1M >= 0L &&
                config.gymTreEm1M >= 0L && config.yoga1M >= 0L
        ) { "Dữ liệu bảng giá trong bản sao lưu bị hỏng (giá trị âm)." }

        members.forEach { m ->
            require(m.id.isNotBlank()) { "Phát hiện hồ sơ hội viên thiếu mã định danh (id)." }
            require(m.stt >= 1L) { "Phát hiện hồ sơ hội viên có STT không hợp lệ (${m.stt})." }
            require(m.fullName.isNotBlank()) { "Hồ sơ STT${m.stt} thiếu họ và tên." }
            require(m.type in setOf("GYM", "YOGA", "PT")) { "Loại dịch vụ hội viên không hợp lệ: ${m.type}" }
        }

        contracts.forEach { c ->
            require(c.id.isNotBlank()) { "Phát hiện hợp đồng thiếu mã định danh (id)." }
            require(c.contractCode.isNotBlank()) { "Phát hiện hợp đồng thiếu mã hợp đồng." }
            require(c.memberId.isNotBlank()) { "Hợp đồng ${c.contractCode} thiếu liên kết hội viên (memberId)." }
            require(c.packageValue >= 0L && c.paidAmount >= 0L) {
                "Hợp đồng ${c.contractCode} có số tiền âm không hợp lệ."
            }
        }

        ptSessions.forEach { s ->
            require(s.id.isNotBlank() && s.contractId.isNotBlank() && s.memberId.isNotBlank()) {
                "Phát hiện buổi tập PT thiếu liên kết hợp đồng hoặc hội viên."
            }
        }

        singleTickets.forEach { t ->
            require(t.id.isNotBlank() && t.quantity >= 1L && t.totalAmount >= 0L) {
                "Phát hiện giao dịch Vé lẻ không hợp lệ."
            }
        }
    }

    fun toJsonString(): String {
        validateIntegrity().getOrThrow()
        val root = JSONObject()
        root.put("exportedAtEpoch", exportedAtEpoch)
        root.put("appVersion", appVersion)
        root.put("recordCounts", JSONObject().apply {
            put("members", members.size)
            put("contracts", contracts.size)
            put("ptSessions", ptSessions.size)
            put("singleTickets", singleTickets.size)
        })
        root.put("config", config.toJson())
        root.put("members", JSONArray().apply { members.forEach { put(it.toJson()) } })
        root.put("contracts", JSONArray().apply { contracts.forEach { put(it.toJson()) } })
        root.put("ptSessions", JSONArray().apply { ptSessions.forEach { put(it.toJson()) } })
        root.put("singleTickets", JSONArray().apply { singleTickets.forEach { put(it.toJson()) } })
        return root.toString(2)
    }

    companion object {
        fun fromJsonString(json: String, overrideUserId: String = "local_user"): BackupBundle {
            val root = JSONObject(json)
            require(root.has("config") || root.has("members") || root.has("contracts")) {
                "Tệp JSON không đúng định dạng sao lưu của 89 Fitness & Yoga."
            }
            val exportedAt = root.optLong("exportedAtEpoch", System.currentTimeMillis())
            val configObj = root.optJSONObject("config") ?: JSONObject()
            val config = StudioConfig.fromJson(configObj, overrideUserId)

            val membersArr = root.optJSONArray("members") ?: JSONArray()
            val members = (0 until membersArr.length()).map {
                MemberProfile.fromJson(membersArr.getJSONObject(it), overrideUserId)
            }

            val contractsArr = root.optJSONArray("contracts") ?: JSONArray()
            val contracts = (0 until contractsArr.length()).map {
                ContractRecord.fromJson(contractsArr.getJSONObject(it), overrideUserId)
            }

            val sessionsArr = root.optJSONArray("ptSessions") ?: JSONArray()
            val ptSessions = (0 until sessionsArr.length()).map {
                PtSessionRecord.fromJson(sessionsArr.getJSONObject(it), overrideUserId)
            }

            val ticketsArr = root.optJSONArray("singleTickets") ?: JSONArray()
            val singleTickets = (0 until ticketsArr.length()).map {
                SingleTicketRecord.fromJson(ticketsArr.getJSONObject(it), overrideUserId)
            }

            val countsObj = root.optJSONObject("recordCounts")
            if (countsObj != null) {
                require(
                    members.size == countsObj.optInt("members", members.size) &&
                        contracts.size == countsObj.optInt("contracts", contracts.size) &&
                        ptSessions.size == countsObj.optInt("ptSessions", ptSessions.size) &&
                        singleTickets.size == countsObj.optInt("singleTickets", singleTickets.size)
                ) {
                    "Kiểm tra tính toàn vẹn thất bại: Số lượng bản ghi không khớp với metadata."
                }
            }

            val bundle = BackupBundle(
                exportedAtEpoch = exportedAt,
                config = config,
                members = members,
                contracts = contracts,
                ptSessions = ptSessions,
                singleTickets = singleTickets
            )
            bundle.validateIntegrity().getOrThrow()
            return bundle
        }
    }
}
