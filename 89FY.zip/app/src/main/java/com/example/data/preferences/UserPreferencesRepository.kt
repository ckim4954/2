package com.example.data.preferences

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "fitness89_prefs")

data class AppPreferencesState(
    val isDarkMode: Boolean = false,
    val googleAccountEmail: String = "",
    val googleAccessToken: String = "",
    val lastBackupTimestamp: Long = 0L,
    val lastSyncStatus: String = "Hoạt động Offline trên thiết bị"
)

class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val IS_DARK_MODE = booleanPreferencesKey("is_dark_mode")
        val GOOGLE_EMAIL = stringPreferencesKey("google_email")
        val GOOGLE_ACCESS_TOKEN = stringPreferencesKey("google_access_token")
        val LAST_BACKUP_TS = longPreferencesKey("last_backup_ts")
        val LAST_SYNC_STATUS = stringPreferencesKey("last_sync_status")
    }

    val preferencesFlow: Flow<AppPreferencesState> = context.dataStore.data.map { prefs ->
        AppPreferencesState(
            isDarkMode = prefs[Keys.IS_DARK_MODE] ?: false, // Default Light Mode per Section 16
            googleAccountEmail = prefs[Keys.GOOGLE_EMAIL] ?: "",
            googleAccessToken = prefs[Keys.GOOGLE_ACCESS_TOKEN] ?: "",
            lastBackupTimestamp = prefs[Keys.LAST_BACKUP_TS] ?: 0L,
            lastSyncStatus = prefs[Keys.LAST_SYNC_STATUS] ?: "Đã lưu an toàn trên thiết bị (Offline-first)"
        )
    }

    suspend fun setDarkMode(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.IS_DARK_MODE] = enabled
        }
    }

    suspend fun setGoogleAccount(email: String, accessToken: String = "") {
        context.dataStore.edit { prefs ->
            prefs[Keys.GOOGLE_EMAIL] = email
            if (accessToken.isNotBlank()) {
                prefs[Keys.GOOGLE_ACCESS_TOKEN] = accessToken
            }
            prefs[Keys.LAST_SYNC_STATUS] = if (email.isBlank()) {
                "Đã ngắt kết nối tài khoản Google"
            } else {
                "Đã kết nối: $email"
            }
        }
    }

    suspend fun updateBackupStatus(status: String, timestamp: Long = System.currentTimeMillis()) {
        context.dataStore.edit { prefs ->
            prefs[Keys.LAST_SYNC_STATUS] = status
            if (timestamp > 0L) {
                prefs[Keys.LAST_BACKUP_TS] = timestamp
            }
        }
    }
}
