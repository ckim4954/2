package com.example.data.repository

import com.example.data.local.*
import com.example.domain.DateCalculator
import com.example.domain.FormatUtils
import kotlinx.coroutines.flow.Flow

/**
 * Central Repository enforcing all mandatory business rules in the PRD & Upgrade PRD:
 * - Strict separation between GYM and YOGA
 * - Auto-seeding 14 standard Gym (Nam/Nữ/Trẻ em) and Yoga price plans without inventing PT/other prices
 * - Automatic classification of NEW vs RENEWAL (including PT -> Gym transition = RENEWAL)
 * - Early vs On-time vs Late renewal start date calculation
 * - Preserving manually edited contract endDate even when startDate changes unless user requests auto-recalc
 * - Contract editing recalculates revenue allocation and debt without altering payment history
 * - Safe price plan deletion (hides/deactivates if referenced by contracts; soft-deletes to Trash otherwise)
 * - Soft delete & multi-select permanent delete in unified Trash
 */
class FitnessRepository(private val dao: AppDao) {

    val pricePlansFlow: Flow<List<PricePlanEntity>> = dao.observeAllPricePlans()
    val membersFlow: Flow<List<MemberEntity>> = dao.observeAllMembers()
    val contractsFlow: Flow<List<ContractEntity>> = dao.observeAllContracts()
    val contractFreezesFlow: Flow<List<ContractFreezeEntity>> = dao.observeAllContractFreezes()
    val paymentsFlow: Flow<List<PaymentTransactionEntity>> = dao.observeAllPayments()
    val refundsFlow: Flow<List<RefundTransactionEntity>> = dao.observeAllRefunds()
    val ptClientsFlow: Flow<List<PtClientEntity>> = dao.observeAllPtClients()
    val ptContractsFlow: Flow<List<PtContractEntity>> = dao.observeAllPtContracts()
    val ptSessionsFlow: Flow<List<PtSessionEntity>> = dao.observeAllPtSessions()
    val shortTermTicketsFlow: Flow<List<ShortTermTicketEntity>> = dao.observeAllShortTermTickets()
    val auditLogsFlow: Flow<List<EditAuditLogEntity>> = dao.observeAuditLogs()

    /**
     * Seeds the 14 standard price plans specified in Section 6.1 of the Upgrade PRD
     * if they do not exist yet. Never invents PT or other unprovided prices.
     */
    suspend fun ensureStandardPricePlansSeeded() {
        val existing = dao.getAllPricePlansOnce()
        val standardSpecs = listOf(
            // Gym — Nam (3 plans)
            PricePlanEntity(id = "std_gym_nam_1m", domain = "GYM", category = "NAM", planName = "Gym Nam 1 tháng", durationMonths = 1, priceVnd = 300_000L),
            PricePlanEntity(id = "std_gym_nam_3m", domain = "GYM", category = "NAM", planName = "Gym Nam 3 tháng", durationMonths = 3, priceVnd = 800_000L),
            PricePlanEntity(id = "std_gym_nam_12m", domain = "GYM", category = "NAM", planName = "Gym Nam 12 tháng", durationMonths = 12, priceVnd = 3_000_000L),
            // Gym — Nữ (4 plans)
            PricePlanEntity(id = "std_gym_nu_1m", domain = "GYM", category = "NU", planName = "Gym Nữ 1 tháng", durationMonths = 1, priceVnd = 250_000L),
            PricePlanEntity(id = "std_gym_nu_2m", domain = "GYM", category = "NU", planName = "Gym Nữ 2 tháng", durationMonths = 2, priceVnd = 500_000L),
            PricePlanEntity(id = "std_gym_nu_3m", domain = "GYM", category = "NU", planName = "Gym Nữ 3 tháng", durationMonths = 3, priceVnd = 700_000L),
            PricePlanEntity(id = "std_gym_nu_12m", domain = "GYM", category = "NU", planName = "Gym Nữ 12 tháng", durationMonths = 12, priceVnd = 2_800_000L),
            // Gym — Trẻ em (4 plans)
            PricePlanEntity(id = "std_gym_treem_1m", domain = "GYM", category = "TRE_EM", planName = "Gym Trẻ em 1 tháng", durationMonths = 1, priceVnd = 300_000L),
            PricePlanEntity(id = "std_gym_treem_2m", domain = "GYM", category = "TRE_EM", planName = "Gym Trẻ em 2 tháng", durationMonths = 2, priceVnd = 500_000L),
            PricePlanEntity(id = "std_gym_treem_3m", domain = "GYM", category = "TRE_EM", planName = "Gym Trẻ em 3 tháng", durationMonths = 3, priceVnd = 700_000L),
            PricePlanEntity(id = "std_gym_treem_12m", domain = "GYM", category = "TRE_EM", planName = "Gym Trẻ em 12 tháng", durationMonths = 12, priceVnd = 2_400_000L),
            // Yoga (3 plans)
            PricePlanEntity(id = "std_yoga_1m", domain = "YOGA", category = "YOGA", planName = "Yoga 1 tháng", durationMonths = 1, priceVnd = 500_000L),
            PricePlanEntity(id = "std_yoga_2m", domain = "YOGA", category = "YOGA", planName = "Yoga 2 tháng", durationMonths = 2, priceVnd = 1_000_000L),
            PricePlanEntity(id = "std_yoga_3m", domain = "YOGA", category = "YOGA", planName = "Yoga 3 tháng", durationMonths = 3, priceVnd = 1_500_000L)
        )

        val toInsert = standardSpecs.filter { std ->
            existing.none { ex ->
                ex.id == std.id || (ex.domain == std.domain && ex.category == std.category && ex.durationMonths == std.durationMonths && !ex.isDeleted)
            }
        }
        if (toInsert.isNotEmpty()) {
            dao.upsertPricePlans(toInsert)
        }
    }

    // --- Price Plan Management (Section 6.1) ---
    suspend fun savePricePlan(plan: PricePlanEntity) {
        dao.upsertPricePlan(plan.copy(updatedAt = System.currentTimeMillis(), isDeleted = false, deletedAt = null))
        dao.insertAuditLog(
            EditAuditLogEntity(
                entityType = "PRICE_PLAN",
                entityId = plan.id,
                summary = "Lưu gói giá [${plan.domain}] ${plan.planName}: ${FormatUtils.formatVnd(plan.priceVnd)}"
            )
        )
    }

    suspend fun togglePricePlanActive(plan: PricePlanEntity) {
        val updated = plan.copy(isActive = !plan.isActive, updatedAt = System.currentTimeMillis())
        dao.upsertPricePlan(updated)
    }

    /**
     * Section 6.1: Never hard-delete a price plan referenced by an existing contract.
     * If referenced, marks as inactive/soft-deleted into Trash while preserving historical references.
     */
    suspend fun deleteOrDeactivatePricePlan(plan: PricePlanEntity): String {
        val allContracts = dao.getAllContractsOnce()
        val isReferenced = allContracts.any {
            it.pricePlanId == plan.id || (it.domain == plan.domain && it.planNameSnapshot == plan.planName)
        }
        val now = System.currentTimeMillis()
        dao.upsertPricePlan(
            plan.copy(
                isActive = false,
                isDeleted = true,
                deletedAt = now,
                updatedAt = now
            )
        )
        return if (isReferenced) {
            "Gói '${plan.planName}' đã có hợp đồng sử dụng nên được ngừng kinh doanh và chuyển vào Thùng rác (bảo toàn lịch sử hợp đồng)."
        } else {
            "Đã chuyển gói '${plan.planName}' vào Thùng rác."
        }
    }

    suspend fun restorePricePlanFromTrash(planId: String) {
        dao.getPricePlanById(planId)?.let { plan ->
            dao.upsertPricePlan(
                plan.copy(
                    isDeleted = false,
                    isActive = true,
                    deletedAt = null,
                    updatedAt = System.currentTimeMillis()
                )
            )
        }
    }

    suspend fun permanentlyDeletePricePlan(planId: String) {
        val allContracts = dao.getAllContractsOnce()
        val plan = dao.getPricePlanById(planId) ?: return
        val isReferenced = allContracts.any { it.pricePlanId == plan.id }
        if (isReferenced) {
            // Unlink pricePlanId on contracts while keeping planNameSnapshot & agreedValueVnd intact
            val updatedContracts = allContracts.filter { it.pricePlanId == plan.id }
                .map { it.copy(pricePlanId = null) }
            dao.upsertContracts(updatedContracts)
        }
        dao.hardDeletePricePlan(planId)
    }

    // --- Member & Contract Creation (Section 5.2) ---
    suspend fun createMemberContract(
        domain: String, // "GYM" or "YOGA"
        existingMemberId: String?,
        linkedPtClientId: String?,
        fullName: String,
        phoneNumber: String,
        customerGroup: String,
        avatarPath: String?,
        pricePlanId: String?,
        planNameSnapshot: String,
        durationMonths: Int,
        agreedValueVnd: Long,
        paymentDateIso: String,
        createdDateIso: String,
        requestedStartDateIso: String,
        customEndDateIso: String?,
        isEndDateManuallyEdited: Boolean,
        cashPaidVnd: Long,
        transferPaidVnd: Long,
        note: String = ""
    ): Result<ContractEntity> {
        if (fullName.isBlank()) return Result.failure(IllegalArgumentException("Vui lòng nhập họ và tên hội viên."))
        if (durationMonths <= 0) return Result.failure(IllegalArgumentException("Số tháng đăng ký phải lớn hơn 0."))
        if (agreedValueVnd < 0L) return Result.failure(IllegalArgumentException("Giá trị hợp đồng không hợp lệ."))

        val existingMember = existingMemberId?.let { dao.getMemberById(it) }
        val priorContracts = if (existingMember != null) {
            dao.getContractsForMember(existingMember.id)
        } else {
            emptyList()
        }

        val hasPriorHistoryInDomain = existingMember != null || priorContracts.isNotEmpty()
        val isFromPtTransition = domain == "GYM" && (!linkedPtClientId.isNullOrBlank() || !existingMember?.linkedPtClientId.isNullOrBlank())

        val contractType = if (hasPriorHistoryInDomain || isFromPtTransition) "RENEWAL" else "NEW"

        val memberToSave = if (existingMember != null) {
            existingMember.copy(
                fullName = fullName.trim(),
                phoneNumber = phoneNumber.trim(),
                customerGroup = customerGroup,
                avatarPath = avatarPath ?: existingMember.avatarPath,
                linkedPtClientId = linkedPtClientId ?: existingMember.linkedPtClientId,
                isDeleted = false,
                deleteType = "NONE",
                deletedAt = null,
                updatedAt = System.currentTimeMillis()
            )
        } else {
            MemberEntity(
                domain = domain,
                fullName = fullName.trim(),
                phoneNumber = phoneNumber.trim(),
                customerGroup = customerGroup,
                avatarPath = avatarPath,
                linkedPtClientId = linkedPtClientId
            )
        }
        dao.upsertMember(memberToSave)

        val effectivePtId = linkedPtClientId ?: memberToSave.linkedPtClientId
        if (domain == "GYM" && !effectivePtId.isNullOrBlank()) {
            dao.getPtClientById(effectivePtId)?.let { ptClient ->
                dao.upsertPtClient(
                    ptClient.copy(
                        linkedGymMemberId = memberToSave.id,
                        phoneNumber = phoneNumber.trim().ifBlank { ptClient.phoneNumber },
                        updatedAt = System.currentTimeMillis()
                    )
                )
            }
        }

        // Confirmed Decision 2: If end date was manually edited, preserve it; otherwise calculate from startDate + durationMonths
        val finalEndDateIso = if (isEndDateManuallyEdited && !customEndDateIso.isNullOrBlank() && DateCalculator.isValidIsoDate(customEndDateIso)) {
            customEndDateIso
        } else {
            DateCalculator.calculateEndDate(
                startIsoDate = requestedStartDateIso,
                months = durationMonths,
                extraFrozenDays = 0
            )
        }

        if (finalEndDateIso <= requestedStartDateIso) {
            return Result.failure(IllegalArgumentException("Ngày hết hạn (${DateCalculator.formatDisplay(finalEndDateIso)}) phải lớn hơn ngày bắt đầu hiệu lực (${DateCalculator.formatDisplay(requestedStartDateIso)})."))
        }

        val contractCode = FormatUtils.generateUniqueCode(if (domain == "GYM") "HDG" else "HDY")
        val contract = ContractEntity(
            contractCode = contractCode,
            memberId = memberToSave.id,
            domain = domain,
            contractType = contractType,
            pricePlanId = pricePlanId,
            planNameSnapshot = planNameSnapshot,
            durationMonths = durationMonths,
            agreedValueVnd = agreedValueVnd,
            paymentDateIso = paymentDateIso,
            createdDateIso = createdDateIso,
            startDateIso = requestedStartDateIso,
            endDateIso = finalEndDateIso,
            note = note.trim(),
            isEndDateManuallyEdited = isEndDateManuallyEdited
        )
        dao.upsertContract(contract)

        val totalPaid = cashPaidVnd + transferPaidVnd
        if (totalPaid > 0L) {
            val methodLabel = when {
                cashPaidVnd > 0L && transferPaidVnd > 0L -> "Kết hợp"
                transferPaidVnd > 0L -> "Chuyển khoản"
                else -> "Tiền mặt"
            }
            val payment = PaymentTransactionEntity(
                transactionCode = FormatUtils.generateUniqueCode("PTU"),
                contractId = contract.id,
                memberId = memberToSave.id,
                domain = domain,
                paymentDateIso = paymentDateIso,
                cashAmountVnd = cashPaidVnd,
                transferAmountVnd = transferPaidVnd,
                totalAmountVnd = totalPaid,
                paymentMethodLabel = methodLabel,
                note = note.trim().ifBlank { "Thanh toán khi tạo hợp đồng ${contract.contractCode}" }
            )
            dao.upsertPayment(payment)
        }

        dao.insertAuditLog(
            EditAuditLogEntity(
                entityType = "CONTRACT",
                entityId = contract.id,
                summary = "Tạo hợp đồng ${contract.contractCode} (${if (contractType == "NEW") "Đăng ký mới" else "Gia hạn"}) cho ${memberToSave.fullName} - Giá trị: ${FormatUtils.formatVnd(agreedValueVnd)}"
            )
        )
        return Result.success(contract)
    }

    suspend fun updateMemberProfile(
        memberId: String,
        fullName: String,
        phoneNumber: String,
        customerGroup: String,
        avatarPath: String?
    ): Result<Unit> {
        val existing = dao.getMemberById(memberId)
            ?: return Result.failure(IllegalArgumentException("Không tìm thấy hồ sơ hội viên."))
        val updated = existing.copy(
            fullName = fullName.trim(),
            phoneNumber = phoneNumber.trim(),
            customerGroup = customerGroup,
            avatarPath = avatarPath ?: existing.avatarPath,
            updatedAt = System.currentTimeMillis()
        )
        dao.upsertMember(updated)

        if (!updated.linkedPtClientId.isNullOrBlank()) {
            dao.getPtClientById(updated.linkedPtClientId)?.let { ptClient ->
                dao.upsertPtClient(
                    ptClient.copy(
                        fullName = fullName.trim(),
                        phoneNumber = phoneNumber.trim(),
                        updatedAt = System.currentTimeMillis()
                    )
                )
            }
        }

        dao.insertAuditLog(
            EditAuditLogEntity(
                entityType = "MEMBER",
                entityId = updated.id,
                summary = "Chỉnh sửa hồ sơ hội viên ${updated.fullName} (${updated.phoneNumber})"
            )
        )
        return Result.success(Unit)
    }

    /**
     * Edits an existing contract without modifying or creating payment transactions.
     * Enforces Confirmed Decision 2: If [isEndDateManuallyEdited] is true, keeps [customEndDateIso]
     * even if [startDateIso] changed. Only auto-calculates when [isEndDateManuallyEdited] is false.
     */
    suspend fun updateContractDetails(
        contractId: String,
        planNameSnapshot: String,
        durationMonths: Int,
        agreedValueVnd: Long,
        paymentDateIso: String,
        createdDateIso: String,
        startDateIso: String,
        customEndDateIso: String?,
        isEndDateManuallyEdited: Boolean,
        note: String
    ): Result<ContractEntity> {
        val existing = dao.getContractById(contractId)
            ?: return Result.failure(IllegalArgumentException("Không tìm thấy hợp đồng cần chỉnh sửa."))

        val finalEndIso = if (isEndDateManuallyEdited && !customEndDateIso.isNullOrBlank() && DateCalculator.isValidIsoDate(customEndDateIso)) {
            customEndDateIso
        } else {
            DateCalculator.calculateEndDate(
                startIsoDate = startDateIso,
                months = durationMonths,
                extraFrozenDays = existing.frozenDays
            )
        }

        if (finalEndIso <= startDateIso) {
            return Result.failure(IllegalArgumentException("Ngày hết hạn phải lớn hơn ngày bắt đầu hiệu lực."))
        }

        val updated = existing.copy(
            planNameSnapshot = planNameSnapshot.trim(),
            durationMonths = durationMonths,
            agreedValueVnd = agreedValueVnd,
            paymentDateIso = paymentDateIso,
            createdDateIso = createdDateIso,
            startDateIso = startDateIso,
            endDateIso = finalEndIso,
            note = note.trim(),
            isEndDateManuallyEdited = isEndDateManuallyEdited,
            updatedAt = System.currentTimeMillis()
        )
        dao.upsertContract(updated)
        dao.insertAuditLog(
            EditAuditLogEntity(
                entityType = "CONTRACT",
                entityId = updated.id,
                summary = "Sửa hợp đồng ${updated.contractCode}: Giá trị ${FormatUtils.formatVnd(existing.agreedValueVnd)} -> ${FormatUtils.formatVnd(agreedValueVnd)}, Hết hạn ${DateCalculator.formatDisplay(existing.endDateIso)} -> ${DateCalculator.formatDisplay(finalEndIso)}"
            )
        )
        return Result.success(updated)
    }

    suspend fun freezeContract(
        contractId: String,
        freezeStartIso: String,
        daysFrozen: Int,
        reason: String
    ): Result<Unit> {
        if (daysFrozen <= 0) return Result.failure(IllegalArgumentException("Số ngày đóng băng phải lớn hơn 0."))
        val contract = dao.getContractById(contractId)
            ?: return Result.failure(IllegalArgumentException("Không tìm thấy hợp đồng."))

        val freezeEndIso = DateCalculator.addDays(freezeStartIso, daysFrozen)
        val newTotalFrozen = contract.frozenDays + daysFrozen
        val newEndDateIso = if (contract.isEndDateManuallyEdited) {
            DateCalculator.addDays(contract.endDateIso, daysFrozen)
        } else {
            DateCalculator.calculateEndDate(
                startIsoDate = contract.startDateIso,
                months = contract.durationMonths,
                extraFrozenDays = newTotalFrozen
            )
        }

        val freezeRecord = ContractFreezeEntity(
            contractId = contract.id,
            freezeStartIso = freezeStartIso,
            freezeEndIso = freezeEndIso,
            daysFrozen = daysFrozen,
            reason = reason.ifBlank { "Hội viên xin tạm dừng tập" }
        )
        dao.upsertContractFreeze(freezeRecord)
        dao.upsertContract(
            contract.copy(
                frozenDays = newTotalFrozen,
                endDateIso = newEndDateIso,
                updatedAt = System.currentTimeMillis()
            )
        )
        dao.insertAuditLog(
            EditAuditLogEntity(
                entityType = "CONTRACT_FREEZE",
                entityId = contract.id,
                summary = "Đóng băng hợp đồng ${contract.contractCode} thêm $daysFrozen ngày (Hết hạn mới: ${DateCalculator.formatDisplay(newEndDateIso)})"
            )
        )
        return Result.success(Unit)
    }

    // --- Debt Collection / Payment Recording ---
    suspend fun recordContractPayment(
        contractId: String,
        paymentDateIso: String,
        cashAmountVnd: Long,
        transferAmountVnd: Long,
        note: String
    ): Result<PaymentTransactionEntity> {
        val total = cashAmountVnd + transferAmountVnd
        if (total <= 0L) return Result.failure(IllegalArgumentException("Số tiền thu phải lớn hơn 0."))
        val contract = dao.getContractById(contractId)
            ?: return Result.failure(IllegalArgumentException("Không tìm thấy hợp đồng."))

        val methodLabel = when {
            cashAmountVnd > 0L && transferAmountVnd > 0L -> "Kết hợp"
            transferAmountVnd > 0L -> "Chuyển khoản"
            else -> "Tiền mặt"
        }

        val payment = PaymentTransactionEntity(
            transactionCode = FormatUtils.generateUniqueCode("PTU"),
            contractId = contract.id,
            memberId = contract.memberId,
            domain = contract.domain,
            paymentDateIso = paymentDateIso,
            cashAmountVnd = cashAmountVnd,
            transferAmountVnd = transferAmountVnd,
            totalAmountVnd = total,
            paymentMethodLabel = methodLabel,
            note = note.ifBlank { "Thu công nợ hợp đồng ${contract.contractCode}" }
        )
        dao.upsertPayment(payment)
        dao.insertAuditLog(
            EditAuditLogEntity(
                entityType = "PAYMENT",
                entityId = payment.id,
                summary = "Thu tiền ${FormatUtils.formatVnd(total)} ($methodLabel) cho hợp đồng ${contract.contractCode}"
            )
        )
        return Result.success(payment)
    }

    // --- Contract Cancellation & Refund (Section 9.6) ---
    suspend fun cancelContractAndRefund(
        contractId: String,
        cancelDateIso: String,
        refundDateIso: String,
        reason: String,
        refundCashVnd: Long,
        refundTransferVnd: Long,
        note: String
    ): Result<Unit> {
        if (reason.isBlank()) return Result.failure(IllegalArgumentException("Vui lòng nhập lý do hủy hợp đồng."))
        val contract = dao.getContractById(contractId)
            ?: return Result.failure(IllegalArgumentException("Không tìm thấy hợp đồng."))

        val totalRefund = refundCashVnd + refundTransferVnd
        val now = System.currentTimeMillis()

        val updatedContract = contract.copy(
            status = "CANCELLED",
            cancelledDateIso = cancelDateIso,
            cancelReason = reason.trim(),
            refundedAmountVnd = totalRefund,
            refundDateIso = refundDateIso,
            refundCashVnd = refundCashVnd,
            refundTransferVnd = refundTransferVnd,
            cancelNote = note.trim(),
            isDeleted = true,
            deleteType = "CONTRACT_CANCELLED",
            deletedAt = now,
            updatedAt = now
        )
        dao.upsertContract(updatedContract)

        if (totalRefund > 0L) {
            val refundTx = RefundTransactionEntity(
                refundCode = FormatUtils.generateUniqueCode("HTN"),
                contractId = contract.id,
                memberId = contract.memberId,
                domain = contract.domain,
                refundDateIso = refundDateIso,
                cashAmountVnd = refundCashVnd,
                transferAmountVnd = refundTransferVnd,
                totalRefundVnd = totalRefund,
                reason = reason.trim(),
                note = note.trim()
            )
            dao.upsertRefund(refundTx)
        }

        dao.getMemberById(contract.memberId)?.let { member ->
            dao.upsertMember(
                member.copy(
                    isDeleted = true,
                    deleteType = "CONTRACT_CANCELLED",
                    deletedAt = now,
                    deleteReason = "Hủy hợp đồng ${contract.contractCode}: $reason",
                    updatedAt = now
                )
            )
        }

        dao.insertAuditLog(
            EditAuditLogEntity(
                entityType = "CONTRACT_CANCEL",
                entityId = contract.id,
                summary = "Hủy hợp đồng ${contract.contractCode}, hoàn tiền: ${FormatUtils.formatVnd(totalRefund)} (Lý do: $reason)"
            )
        )
        return Result.success(Unit)
    }

    // --- Soft Delete & Trash Recovery (Section 9) ---
    suspend fun softDeleteMember(memberId: String, reason: String = "Xóa vào Thùng rác") {
        val now = System.currentTimeMillis()
        dao.getMemberById(memberId)?.let { member ->
            dao.upsertMember(
                member.copy(
                    isDeleted = true,
                    deleteType = "ACCIDENTAL",
                    deletedAt = now,
                    deleteReason = reason,
                    updatedAt = now
                )
            )
        }
    }

    suspend fun softDeleteContract(contractId: String, reason: String = "Xóa hợp đồng vào Thùng rác") {
        val now = System.currentTimeMillis()
        dao.getContractById(contractId)?.let { contract ->
            dao.upsertContract(
                contract.copy(
                    isDeleted = true,
                    deleteType = if (contract.status == "CANCELLED") "CONTRACT_CANCELLED" else "ACCIDENTAL",
                    cancelReason = contract.cancelReason ?: reason,
                    deletedAt = now,
                    updatedAt = now
                )
            )
        }
    }

    suspend fun restoreMemberFromTrash(memberId: String) {
        val now = System.currentTimeMillis()
        dao.getMemberById(memberId)?.let { member ->
            dao.upsertMember(
                member.copy(
                    isDeleted = false,
                    deleteType = "NONE",
                    deletedAt = null,
                    updatedAt = now
                )
            )
            // Restore accidentally deleted contracts, but never reactivate CANCELLED contracts (Section 9.3)
            val memberContracts = dao.getContractsForMember(memberId)
            for (c in memberContracts) {
                if (c.isDeleted && c.status != "CANCELLED") {
                    dao.upsertContract(
                        c.copy(
                            isDeleted = false,
                            deleteType = "NONE",
                            deletedAt = null,
                            updatedAt = now
                        )
                    )
                }
            }
        }
    }

    suspend fun restoreContractFromTrash(contractId: String) {
        val now = System.currentTimeMillis()
        dao.getContractById(contractId)?.let { contract ->
            val restoredStatus = if (contract.deleteType == "CONTRACT_CANCELLED" || contract.status == "CANCELLED") {
                "CANCELLED"
            } else {
                "ACTIVE"
            }
            dao.upsertContract(
                contract.copy(
                    isDeleted = false,
                    status = restoredStatus,
                    deletedAt = null,
                    updatedAt = now
                )
            )
            dao.getMemberById(contract.memberId)?.let { member ->
                if (member.isDeleted) {
                    dao.upsertMember(
                        member.copy(
                            isDeleted = false,
                            deletedAt = null,
                            updatedAt = now
                        )
                    )
                }
            }
        }
    }

    suspend fun permanentlyDeleteMember(memberId: String) {
        dao.hardDeleteMember(memberId)
    }

    suspend fun permanentlyDeleteContract(contractId: String) {
        dao.hardDeleteContract(contractId)
    }

    // --- PT Management (HLV Hà Đức) ---
    suspend fun createPtContract(
        existingPtClientId: String?,
        fullName: String,
        phoneNumber: String,
        registerDateIso: String,
        paymentDateIso: String,
        totalSessions: Int,
        agreedValueVnd: Long,
        cashPaidVnd: Long,
        transferPaidVnd: Long,
        allExistingContracts: List<PtContractEntity>,
        allExistingSessions: List<PtSessionEntity>
    ): Result<PtContractEntity> {
        if (fullName.isBlank()) return Result.failure(IllegalArgumentException("Vui lòng nhập họ tên khách hàng PT."))
        if (totalSessions <= 0) return Result.failure(IllegalArgumentException("Số buổi PT đăng ký phải lớn hơn 0."))

        val client = if (!existingPtClientId.isNullOrBlank()) {
            dao.getPtClientById(existingPtClientId)?.copy(
                fullName = fullName.trim(),
                phoneNumber = phoneNumber.trim(),
                isDeleted = false,
                updatedAt = System.currentTimeMillis()
            ) ?: PtClientEntity(fullName = fullName.trim(), phoneNumber = phoneNumber.trim())
        } else {
            PtClientEntity(fullName = fullName.trim(), phoneNumber = phoneNumber.trim())
        }

        val clientContracts = allExistingContracts.filter { it.ptClientId == client.id && !it.isDeleted && it.status == "ACTIVE" }
        for (activeContract in clientContracts) {
            val used = allExistingSessions.filter { it.ptContractId == activeContract.id }.sumOf { it.sessionsUsed }
            val remaining = activeContract.totalSessions - used
            if (remaining > 0) {
                return Result.failure(
                    IllegalStateException("Khách hàng ${client.fullName} đang có hợp đồng PT (${activeContract.contractCode}) còn $remaining buổi chưa tập hết.")
                )
            }
        }

        dao.upsertPtClient(client)

        val ptContract = PtContractEntity(
            contractCode = FormatUtils.generateUniqueCode("HDP"),
            ptClientId = client.id,
            trainerName = "Hà Đức",
            registerDateIso = registerDateIso,
            paymentDateIso = paymentDateIso,
            totalSessions = totalSessions,
            agreedValueVnd = agreedValueVnd,
            cashPaidVnd = cashPaidVnd,
            transferPaidVnd = transferPaidVnd,
            status = "ACTIVE"
        )
        dao.upsertPtContract(ptContract)
        dao.insertAuditLog(
            EditAuditLogEntity(
                entityType = "PT_CONTRACT",
                entityId = ptContract.id,
                summary = "Tạo hợp đồng PT ${ptContract.contractCode} cho ${client.fullName}: $totalSessions buổi - ${FormatUtils.formatVnd(agreedValueVnd)}"
            )
        )
        return Result.success(ptContract)
    }

    suspend fun recordPtSession(
        ptContract: PtContractEntity,
        currentUsedSessions: Int,
        sessionDateIso: String,
        sessionsUsed: Int,
        note: String
    ): Result<PtSessionEntity> {
        if (sessionsUsed <= 0) return Result.failure(IllegalArgumentException("Số buổi tập phải lớn hơn 0."))
        val remaining = ptContract.totalSessions - currentUsedSessions
        if (sessionsUsed > remaining) {
            return Result.failure(
                IllegalStateException("Không thể ghi nhận $sessionsUsed buổi vì hợp đồng ${ptContract.contractCode} chỉ còn $remaining buổi.")
            )
        }

        val session = PtSessionEntity(
            ptContractId = ptContract.id,
            ptClientId = ptContract.ptClientId,
            sessionDateIso = sessionDateIso,
            sessionsUsed = sessionsUsed,
            note = note.trim()
        )
        dao.upsertPtSession(session)

        val newUsed = currentUsedSessions + sessionsUsed
        if (newUsed >= ptContract.totalSessions) {
            dao.upsertPtContract(
                ptContract.copy(
                    status = "COMPLETED",
                    updatedAt = System.currentTimeMillis()
                )
            )
        }
        return Result.success(session)
    }

    suspend fun updatePtContract(
        ptContract: PtContractEntity,
        totalSessions: Int,
        agreedValueVnd: Long,
        registerDateIso: String,
        currentUsedSessions: Int
    ): Result<Unit> {
        if (totalSessions < currentUsedSessions) {
            return Result.failure(IllegalArgumentException("Tổng số buổi mới ($totalSessions) không thể nhỏ hơn số buổi đã tập ($currentUsedSessions)."))
        }
        val newStatus = if (currentUsedSessions >= totalSessions) "COMPLETED" else "ACTIVE"
        dao.upsertPtContract(
            ptContract.copy(
                totalSessions = totalSessions,
                agreedValueVnd = agreedValueVnd,
                registerDateIso = registerDateIso,
                status = newStatus,
                updatedAt = System.currentTimeMillis()
            )
        )
        return Result.success(Unit)
    }

    suspend fun softDeletePtClient(ptClientId: String) {
        val now = System.currentTimeMillis()
        dao.getPtClientById(ptClientId)?.let { client ->
            dao.upsertPtClient(
                client.copy(
                    isDeleted = true,
                    deletedAt = now,
                    deleteReason = "Xóa hồ sơ PT",
                    updatedAt = now
                )
            )
        }
    }

    suspend fun restorePtClient(ptClientId: String) {
        dao.getPtClientById(ptClientId)?.let { client ->
            dao.upsertPtClient(
                client.copy(
                    isDeleted = false,
                    deletedAt = null,
                    updatedAt = System.currentTimeMillis()
                )
            )
        }
    }

    suspend fun permanentlyDeletePtClient(ptClientId: String) {
        dao.hardDeletePtClient(ptClientId)
    }

    // --- Short-Term Tickets: Daily & Weekly ---
    suspend fun sellShortTermTicket(
        ticketType: String, // "VE_NGAY" or "VE_TUAN"
        saleDateIso: String,
        quantity: Int,
        unitPriceVnd: Long,
        cashAmountVnd: Long,
        transferAmountVnd: Long
    ): Result<ShortTermTicketEntity> {
        if (quantity <= 0) return Result.failure(IllegalArgumentException("Số lượng vé phải lớn hơn 0."))
        if (unitPriceVnd <= 0L) return Result.failure(IllegalArgumentException("Vui lòng nhập hoặc cấu hình đơn giá vé."))

        val total = unitPriceVnd * quantity
        val methodLabel = when {
            cashAmountVnd > 0L && transferAmountVnd > 0L -> "Kết hợp"
            transferAmountVnd > 0L -> "Chuyển khoản"
            else -> "Tiền mặt"
        }
        val ticket = ShortTermTicketEntity(
            ticketCode = FormatUtils.generateUniqueCode(if (ticketType == "VE_NGAY") "VNG" else "VTN"),
            ticketType = ticketType,
            saleDateIso = saleDateIso,
            quantity = quantity,
            unitPriceVnd = unitPriceVnd,
            totalAmountVnd = total,
            cashAmountVnd = cashAmountVnd,
            transferAmountVnd = transferAmountVnd,
            paymentMethodLabel = methodLabel
        )
        dao.upsertShortTermTicket(ticket)
        return Result.success(ticket)
    }

    suspend fun softDeleteTicket(ticket: ShortTermTicketEntity) {
        dao.upsertShortTermTicket(ticket.copy(isDeleted = true, deletedAt = System.currentTimeMillis()))
    }

    suspend fun restoreTicket(ticket: ShortTermTicketEntity) {
        dao.upsertShortTermTicket(ticket.copy(isDeleted = false, deletedAt = null))
    }

    suspend fun permanentlyDeleteTicket(ticketId: String) {
        dao.hardDeleteShortTermTicket(ticketId)
    }
}
