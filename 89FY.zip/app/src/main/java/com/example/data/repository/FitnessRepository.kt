package com.example.data.repository

import com.example.data.local.*
import com.example.domain.DateCalculator
import com.example.domain.FormatUtils
import kotlinx.coroutines.flow.Flow

/**
 * Central Repository enforcing all 26 mandatory business rules in the PRD:
 * - Strict separation between GYM and YOGA
 * - Automatic classification of NEW vs RENEWAL (including PT -> Gym transition = RENEWAL)
 * - Early vs On-time vs Late renewal start date calculation
 * - Contract editing recalculates endDate, revenue allocation, and debt without altering payment history
 * - Contract freezing (tạm dừng) adds days to endDate
 * - PT session tracking prevents exceeding remaining sessions and prevents buying a new PT contract while one is active
 * - Contract cancellation & refund moves member & contract to Trash while preserving financial history
 * - Soft delete & safe restore in Trash
 */
class FitnessRepository(private val dao: AppDao) {

    val pricePlansFlow: Flow<List<PricePlanEntity>> = dao.observeAllPricePlans()
    val membersFlow: Flow<List<MemberEntity>> = dao.observeAllMembers()
    val contractsFlow: Flow<List<ContractEntity>> = dao.observeAllContracts()
    val contractFreezesFlow: Flow<List<ContractFreezeEntity>> = dao.observeAllContractFreezes()
    val paymentsFlow: Flow<List<PaymentTransactionEntity>> = dao.observeAllPayments()
    val refundsFlow: Flow<List<RefundTransactionEntity>> = dao.observeAllRefunds()
    val ptClientsFlow: Flow<List<PtClientEntity>> = dao.observeAllPtClients()
    val ptContractsFlow: Flow<List<PtContractEntity>> = dao.observeAllPtContracts()
    val ptSessionsFlow: Flow<List<PtSessionEntity>> = dao.observeAllPtSessions()
    val shortTermTicketsFlow: Flow<List<ShortTermTicketEntity>> = dao.observeAllShortTermTickets()
    val auditLogsFlow: Flow<List<EditAuditLogEntity>> = dao.observeAuditLogs()

    // --- Price Plan Management (Sections 17, 18, 19) ---
    suspend fun savePricePlan(plan: PricePlanEntity) {
        dao.upsertPricePlan(plan.copy(updatedAt = System.currentTimeMillis()))
        dao.insertAuditLog(
            EditAuditLogEntity(
                entityType = "PRICE_PLAN",
                entityId = plan.id,
                summary = "Cập nhật gói giá [${plan.domain}] ${plan.planName}: ${FormatUtils.formatVnd(plan.priceVnd)}"
            )
        )
    }

    suspend fun togglePricePlanActive(plan: PricePlanEntity) {
        val updated = plan.copy(isActive = !plan.isActive, updatedAt = System.currentTimeMillis())
        dao.upsertPricePlan(updated)
    }

    // --- Member & Contract Creation (Sections 4, 5) ---
    /**
     * Creates a new or renewal contract for Gym or Yoga.
     * Enforces:
     * - Rule 2: Anyone who ever had a profile or contract in the domain is classified as RENEWAL.
     * - Rule 3: A PT client transitioning to a monthly Gym membership is classified as RENEWAL.
     * - Rule 4 & 5: Early renewal starts on previous endDate; on-time/late starts on actual renewal date.
     */
    suspend fun createMemberContract(
        domain: String, // "GYM" or "YOGA"
        existingMemberId: String?,
        linkedPtClientId: String?,
        fullName: String,
        phoneNumber: String,
        customerGroup: String,
        avatarPath: String?,
        pricePlanId: String?,
        planNameSnapshot: String,
        durationMonths: Int,
        agreedValueVnd: Long,
        paymentDateIso: String,
        createdDateIso: String,
        requestedStartDateIso: String,
        cashPaidVnd: Long,
        transferPaidVnd: Long
    ): Result<ContractEntity> {
        if (fullName.isBlank()) return Result.failure(IllegalArgumentException("Vui lòng nhập họ và tên hội viên."))
        if (durationMonths <= 0) return Result.failure(IllegalArgumentException("Số tháng đăng ký phải lớn hơn 0."))
        if (agreedValueVnd < 0L) return Result.failure(IllegalArgumentException("Giá trị hợp đồng không hợp lệ."))

        val existingMember = existingMemberId?.let { dao.getMemberById(it) }
        val priorContracts = if (existingMember != null) {
            dao.getContractsForMember(existingMember.id)
        } else {
            emptyList()
        }

        val hasPriorHistoryInDomain = existingMember != null || priorContracts.isNotEmpty()
        val isFromPtTransition = domain == "GYM" && (!linkedPtClientId.isNullOrBlank() || !existingMember?.linkedPtClientId.isNullOrBlank())

        // Mandatory classification rule (Section 5.2 & 6.6)
        val contractType = if (hasPriorHistoryInDomain || isFromPtTransition) "RENEWAL" else "NEW"

        val memberToSave = if (existingMember != null) {
            existingMember.copy(
                fullName = fullName.trim(),
                phoneNumber = phoneNumber.trim(),
                customerGroup = customerGroup,
                avatarPath = avatarPath ?: existingMember.avatarPath,
                linkedPtClientId = linkedPtClientId ?: existingMember.linkedPtClientId,
                isDeleted = false,
                deleteType = "NONE",
                deletedAt = null,
                updatedAt = System.currentTimeMillis()
            )
        } else {
            MemberEntity(
                domain = domain,
                fullName = fullName.trim(),
                phoneNumber = phoneNumber.trim(),
                customerGroup = customerGroup,
                avatarPath = avatarPath,
                linkedPtClientId = linkedPtClientId
            )
        }
        dao.upsertMember(memberToSave)

        // If linked from PT client, also update PT client's linkedGymMemberId (Section 6.6)
        val effectivePtId = linkedPtClientId ?: memberToSave.linkedPtClientId
        if (domain == "GYM" && !effectivePtId.isNullOrBlank()) {
            dao.getPtClientById(effectivePtId)?.let { ptClient ->
                dao.upsertPtClient(
                    ptClient.copy(
                        linkedGymMemberId = memberToSave.id,
                        phoneNumber = phoneNumber.trim().ifBlank { ptClient.phoneNumber },
                        updatedAt = System.currentTimeMillis()
                    )
                )
            }
        }

        // Calculate endDate from requestedStartDateIso + durationMonths
        val endDateIso = DateCalculator.calculateEndDate(
            startIsoDate = requestedStartDateIso,
            months = durationMonths,
            extraFrozenDays = 0
        )

        val contractCode = FormatUtils.generateUniqueCode(if (domain == "GYM") "HDG" else "HDY")
        val contract = ContractEntity(
            contractCode = contractCode,
            memberId = memberToSave.id,
            domain = domain,
            contractType = contractType,
            pricePlanId = pricePlanId,
            planNameSnapshot = planNameSnapshot,
            durationMonths = durationMonths,
            agreedValueVnd = agreedValueVnd,
            paymentDateIso = paymentDateIso,
            createdDateIso = createdDateIso,
            startDateIso = requestedStartDateIso,
            endDateIso = endDateIso
        )
        dao.upsertContract(contract)

        // Record initial payment transaction if amount > 0
        val totalPaid = cashPaidVnd + transferPaidVnd
        if (totalPaid > 0L) {
            val methodLabel = when {
                cashPaidVnd > 0L && transferPaidVnd > 0L -> "Kết hợp"
                transferPaidVnd > 0L -> "Chuyển khoản"
                else -> "Tiền mặt"
            }
            val payment = PaymentTransactionEntity(
                transactionCode = FormatUtils.generateUniqueCode("PTU"),
                contractId = contract.id,
                memberId = memberToSave.id,
                domain = domain,
                paymentDateIso = paymentDateIso,
                cashAmountVnd = cashPaidVnd,
                transferAmountVnd = transferPaidVnd,
                totalAmountVnd = totalPaid,
                paymentMethodLabel = methodLabel,
                note = "Thanh toán khi tạo hợp đồng ${contract.contractCode}"
            )
            dao.upsertPayment(payment)
        }

        dao.insertAuditLog(
            EditAuditLogEntity(
                entityType = "CONTRACT",
                entityId = contract.id,
                summary = "Tạo hợp đồng ${contract.contractCode} (${if (contractType == "NEW") "Đăng ký mới" else "Gia hạn"}) cho ${memberToSave.fullName} - Giá trị: ${FormatUtils.formatVnd(agreedValueVnd)}"
            )
        )
        return Result.success(contract)
    }

    /**
     * Edits member profile information (Section 2.2 & 4.5).
     * Also synchronizes phone number with linked PT profile if present (Section 27.7).
     */
    suspend fun updateMemberProfile(
        memberId: String,
        fullName: String,
        phoneNumber: String,
        customerGroup: String,
        avatarPath: String?
    ): Result<Unit> {
        val existing = dao.getMemberById(memberId)
            ?: return Result.failure(IllegalArgumentException("Không tìm thấy hồ sơ hội viên."))
        val updated = existing.copy(
            fullName = fullName.trim(),
            phoneNumber = phoneNumber.trim(),
            customerGroup = customerGroup,
            avatarPath = avatarPath ?: existing.avatarPath,
            updatedAt = System.currentTimeMillis()
        )
        dao.upsertMember(updated)

        if (!updated.linkedPtClientId.isNullOrBlank()) {
            dao.getPtClientById(updated.linkedPtClientId)?.let { ptClient ->
                dao.upsertPtClient(
                    ptClient.copy(
                        fullName = fullName.trim(),
                        phoneNumber = phoneNumber.trim(),
                        updatedAt = System.currentTimeMillis()
                    )
                )
            }
        }

        dao.insertAuditLog(
            EditAuditLogEntity(
                entityType = "MEMBER",
                entityId = updated.id,
                summary = "Chỉnh sửa hồ sơ hội viên ${updated.fullName} (${updated.phoneNumber})"
            )
        )
        return Result.success(Unit)
    }

    /**
     * Edits an existing contract without modifying or creating payment transactions (Sections 5.5, 9.5, 12.4).
     */
    suspend fun updateContractDetails(
        contractId: String,
        planNameSnapshot: String,
        durationMonths: Int,
        agreedValueVnd: Long,
        paymentDateIso: String,
        createdDateIso: String,
        startDateIso: String,
        customEndDateIso: String? = null
    ): Result<ContractEntity> {
        val existing = dao.getContractById(contractId)
            ?: return Result.failure(IllegalArgumentException("Không tìm thấy hợp đồng cần chỉnh sửa."))

        val recalculatedEndIso = customEndDateIso?.takeIf { DateCalculator.isValidIsoDate(it) }
            ?: DateCalculator.calculateEndDate(
                startIsoDate = startDateIso,
                months = durationMonths,
                extraFrozenDays = existing.frozenDays
            )

        val updated = existing.copy(
            planNameSnapshot = planNameSnapshot.trim(),
            durationMonths = durationMonths,
            agreedValueVnd = agreedValueVnd,
            paymentDateIso = paymentDateIso,
            createdDateIso = createdDateIso,
            startDateIso = startDateIso,
            endDateIso = recalculatedEndIso,
            updatedAt = System.currentTimeMillis()
        )
        dao.upsertContract(updated)
        dao.insertAuditLog(
            EditAuditLogEntity(
                entityType = "CONTRACT",
                entityId = updated.id,
                summary = "Sửa hợp đồng ${updated.contractCode}: Giá trị ${FormatUtils.formatVnd(existing.agreedValueVnd)} -> ${FormatUtils.formatVnd(agreedValueVnd)}, Hết hạn ${DateCalculator.formatDisplay(existing.endDateIso)} -> ${DateCalculator.formatDisplay(recalculatedEndIso)}"
            )
        )
        return Result.success(updated)
    }

    /**
     * Freezes (pauses) a contract and extends its end date by [daysFrozen] (Confirmed Decision 3).
     */
    suspend fun freezeContract(
        contractId: String,
        freezeStartIso: String,
        daysFrozen: Int,
        reason: String
    ): Result<Unit> {
        if (daysFrozen <= 0) return Result.failure(IllegalArgumentException("Số ngày đóng băng phải lớn hơn 0."))
        val contract = dao.getContractById(contractId)
            ?: return Result.failure(IllegalArgumentException("Không tìm thấy hợp đồng."))

        val freezeEndIso = DateCalculator.addDays(freezeStartIso, daysFrozen)
        val newTotalFrozen = contract.frozenDays + daysFrozen
        val newEndDateIso = DateCalculator.calculateEndDate(
            startIsoDate = contract.startDateIso,
            months = contract.durationMonths,
            extraFrozenDays = newTotalFrozen
        )

        val freezeRecord = ContractFreezeEntity(
            contractId = contract.id,
            freezeStartIso = freezeStartIso,
            freezeEndIso = freezeEndIso,
            daysFrozen = daysFrozen,
            reason = reason.ifBlank { "Hội viên xin tạm dừng tập" }
        )
        dao.upsertContractFreeze(freezeRecord)
        dao.upsertContract(
            contract.copy(
                frozenDays = newTotalFrozen,
                endDateIso = newEndDateIso,
                updatedAt = System.currentTimeMillis()
            )
        )
        dao.insertAuditLog(
            EditAuditLogEntity(
                entityType = "CONTRACT_FREEZE",
                entityId = contract.id,
                summary = "Đóng băng hợp đồng ${contract.contractCode} thêm $daysFrozen ngày (Hết hạn mới: ${DateCalculator.formatDisplay(newEndDateIso)})"
            )
        )
        return Result.success(Unit)
    }

    // --- Debt Collection / Payment Recording (Section 12) ---
    /**
     * Records a debt payment without generating duplicate allocated revenue (Section 12.3).
     */
    suspend fun recordContractPayment(
        contractId: String,
        paymentDateIso: String,
        cashAmountVnd: Long,
        transferAmountVnd: Long,
        note: String
    ): Result<PaymentTransactionEntity> {
        val total = cashAmountVnd + transferAmountVnd
        if (total <= 0L) return Result.failure(IllegalArgumentException("Số tiền thu phải lớn hơn 0."))
        val contract = dao.getContractById(contractId)
            ?: return Result.failure(IllegalArgumentException("Không tìm thấy hợp đồng."))

        val methodLabel = when {
            cashAmountVnd > 0L && transferAmountVnd > 0L -> "Kết hợp"
            transferAmountVnd > 0L -> "Chuyển khoản"
            else -> "Tiền mặt"
        }

        val payment = PaymentTransactionEntity(
            transactionCode = FormatUtils.generateUniqueCode("PTU"),
            contractId = contract.id,
            memberId = contract.memberId,
            domain = contract.domain,
            paymentDateIso = paymentDateIso,
            cashAmountVnd = cashAmountVnd,
            transferAmountVnd = transferAmountVnd,
            totalAmountVnd = total,
            paymentMethodLabel = methodLabel,
            note = note.ifBlank { "Thu công nợ hợp đồng ${contract.contractCode}" }
        )
        dao.upsertPayment(payment)
        dao.insertAuditLog(
            EditAuditLogEntity(
                entityType = "PAYMENT",
                entityId = payment.id,
                summary = "Thu tiền ${FormatUtils.formatVnd(total)} ($methodLabel) cho hợp đồng ${contract.contractCode}"
            )
        )
        return Result.success(payment)
    }

    // --- Contract Cancellation & Refund (Section 14) ---
    /**
     * Cancels a contract, records manual refund amount (no automatic day deduction),
     * moves the contract and member profile into Trash while preserving all payment & refund history.
     */
    suspend fun cancelContractAndRefund(
        contractId: String,
        cancelDateIso: String,
        refundDateIso: String,
        reason: String,
        refundCashVnd: Long,
        refundTransferVnd: Long,
        note: String
    ): Result<Unit> {
        if (reason.isBlank()) return Result.failure(IllegalArgumentException("Vui lòng nhập lý do hủy hợp đồng."))
        val contract = dao.getContractById(contractId)
            ?: return Result.failure(IllegalArgumentException("Không tìm thấy hợp đồng."))

        val totalRefund = refundCashVnd + refundTransferVnd
        val now = System.currentTimeMillis()

        val updatedContract = contract.copy(
            status = "CANCELLED",
            cancelledDateIso = cancelDateIso,
            cancelReason = reason.trim(),
            refundedAmountVnd = totalRefund,
            refundDateIso = refundDateIso,
            refundCashVnd = refundCashVnd,
            refundTransferVnd = refundTransferVnd,
            cancelNote = note.trim(),
            isDeleted = true,
            deleteType = "CONTRACT_CANCELLED",
            deletedAt = now,
            updatedAt = now
        )
        dao.upsertContract(updatedContract)

        if (totalRefund > 0L) {
            val refundTx = RefundTransactionEntity(
                refundCode = FormatUtils.generateUniqueCode("HTN"),
                contractId = contract.id,
                memberId = contract.memberId,
                domain = contract.domain,
                refundDateIso = refundDateIso,
                cashAmountVnd = refundCashVnd,
                transferAmountVnd = refundTransferVnd,
                totalRefundVnd = totalRefund,
                reason = reason.trim(),
                note = note.trim()
            )
            dao.upsertRefund(refundTx)
        }

        // Move member profile to Trash as required by Section 14.2
        dao.getMemberById(contract.memberId)?.let { member ->
            dao.upsertMember(
                member.copy(
                    isDeleted = true,
                    deleteType = "CONTRACT_CANCELLED",
                    deletedAt = now,
                    deleteReason = "Hủy hợp đồng ${contract.contractCode}: $reason",
                    updatedAt = now
                )
            )
        }

        dao.insertAuditLog(
            EditAuditLogEntity(
                entityType = "CONTRACT_CANCEL",
                entityId = contract.id,
                summary = "Hủy hợp đồng ${contract.contractCode}, hoàn tiền: ${FormatUtils.formatVnd(totalRefund)} (Lý do: $reason)"
            )
        )
        return Result.success(Unit)
    }

    // --- Soft Delete & Trash Recovery (Section 15) ---
    suspend fun softDeleteMember(memberId: String, reason: String = "Xóa nhầm / Xóa thủ công") {
        val now = System.currentTimeMillis()
        dao.getMemberById(memberId)?.let { member ->
            dao.upsertMember(
                member.copy(
                    isDeleted = true,
                    deleteType = "ACCIDENTAL",
                    deletedAt = now,
                    deleteReason = reason,
                    updatedAt = now
                )
            )
        }
    }

    /**
     * Restores a soft-deleted member from Trash (Section 15.3).
     * Crucial rule: Never turn a cancelled & refunded contract back into an ACTIVE contract upon restore!
     */
    suspend fun restoreMemberFromTrash(memberId: String) {
        val now = System.currentTimeMillis()
        dao.getMemberById(memberId)?.let { member ->
            dao.upsertMember(
                member.copy(
                    isDeleted = false,
                    deleteType = "NONE",
                    deletedAt = null,
                    updatedAt = now
                )
            )
            // Restore accidentally deleted contracts, but keep CANCELLED contracts in CANCELLED status
            val memberContracts = dao.getContractsForMember(memberId)
            for (c in memberContracts) {
                if (c.isDeleted && c.status != "CANCELLED") {
                    dao.upsertContract(
                        c.copy(
                            isDeleted = false,
                            deleteType = "NONE",
                            deletedAt = null,
                            updatedAt = now
                        )
                    )
                }
            }
        }
    }

    suspend fun restoreContractFromTrash(contractId: String) {
        val now = System.currentTimeMillis()
        dao.getContractById(contractId)?.let { contract ->
            // Section 15.3: Do not turn a cancelled and refunded contract into an active contract!
            val restoredStatus = if (contract.deleteType == "CONTRACT_CANCELLED") "CANCELLED" else contract.status
            dao.upsertContract(
                contract.copy(
                    isDeleted = false,
                    status = restoredStatus,
                    deletedAt = null,
                    updatedAt = now
                )
            )
            dao.getMemberById(contract.memberId)?.let { member ->
                if (member.isDeleted) {
                    dao.upsertMember(
                        member.copy(
                            isDeleted = false,
                            deletedAt = null,
                            updatedAt = now
                        )
                    )
                }
            }
        }
    }

    suspend fun permanentlyDeleteMember(memberId: String) {
        dao.hardDeleteMember(memberId)
    }

    suspend fun permanentlyDeleteContract(contractId: String) {
        dao.hardDeleteContract(contractId)
    }

    // --- PT Management (Section 6 — HLV Hà Đức) ---
    /**
     * Creates a PT contract.
     * Enforces Section 6.3: Each PT client can only have ONE active PT contract at a time.
     * Must finish all sessions of the current contract before purchasing a new PT contract.
     */
    suspend fun createPtContract(
        existingPtClientId: String?,
        fullName: String,
        phoneNumber: String,
        registerDateIso: String,
        paymentDateIso: String,
        totalSessions: Int,
        agreedValueVnd: Long,
        cashPaidVnd: Long,
        transferPaidVnd: Long,
        allExistingContracts: List<PtContractEntity>,
        allExistingSessions: List<PtSessionEntity>
    ): Result<PtContractEntity> {
        if (fullName.isBlank()) return Result.failure(IllegalArgumentException("Vui lòng nhập họ tên khách hàng PT."))
        if (totalSessions <= 0) return Result.failure(IllegalArgumentException("Số buổi PT đăng ký phải lớn hơn 0."))

        val client = if (!existingPtClientId.isNullOrBlank()) {
            dao.getPtClientById(existingPtClientId)?.copy(
                fullName = fullName.trim(),
                phoneNumber = phoneNumber.trim(),
                isDeleted = false,
                updatedAt = System.currentTimeMillis()
            ) ?: PtClientEntity(fullName = fullName.trim(), phoneNumber = phoneNumber.trim())
        } else {
            PtClientEntity(fullName = fullName.trim(), phoneNumber = phoneNumber.trim())
        }

        // Check if client already has an active PT contract with remaining sessions > 0 (Section 6.3)
        val clientContracts = allExistingContracts.filter { it.ptClientId == client.id && !it.isDeleted && it.status == "ACTIVE" }
        for (activeContract in clientContracts) {
            val used = allExistingSessions.filter { it.ptContractId == activeContract.id }.sumOf { it.sessionsUsed }
            val remaining = activeContract.totalSessions - used
            if (remaining > 0) {
                return Result.failure(
                    IllegalStateException("Khách hàng ${client.fullName} đang có hợp đồng PT (${activeContract.contractCode}) còn $remaining buổi chưa tập hết. Phải sử dụng hết số buổi hiện tại trước khi mua hợp đồng PT mới.")
                )
            }
        }

        dao.upsertPtClient(client)

        val ptContract = PtContractEntity(
            contractCode = FormatUtils.generateUniqueCode("HDP"),
            ptClientId = client.id,
            trainerName = "Hà Đức",
            registerDateIso = registerDateIso,
            paymentDateIso = paymentDateIso,
            totalSessions = totalSessions,
            agreedValueVnd = agreedValueVnd,
            cashPaidVnd = cashPaidVnd,
            transferPaidVnd = transferPaidVnd,
            status = "ACTIVE"
        )
        dao.upsertPtContract(ptContract)
        dao.insertAuditLog(
            EditAuditLogEntity(
                entityType = "PT_CONTRACT",
                entityId = ptContract.id,
                summary = "Tạo hợp đồng PT ${ptContract.contractCode} cho ${client.fullName}: $totalSessions buổi - ${FormatUtils.formatVnd(agreedValueVnd)} (HLV Hà Đức)"
            )
        )
        return Result.success(ptContract)
    }

    /**
     * Records an individual PT training session (Section 6.4).
     * Prevents recording a session if remaining sessions would drop below 0.
     */
    suspend fun recordPtSession(
        ptContract: PtContractEntity,
        currentUsedSessions: Int,
        sessionDateIso: String,
        sessionsUsed: Int,
        note: String
    ): Result<PtSessionEntity> {
        if (sessionsUsed <= 0) return Result.failure(IllegalArgumentException("Số buổi tập phải lớn hơn 0."))
        val remaining = ptContract.totalSessions - currentUsedSessions
        if (sessionsUsed > remaining) {
            return Result.failure(
                IllegalStateException("Không thể ghi nhận $sessionsUsed buổi vì hợp đồng ${ptContract.contractCode} chỉ còn $remaining buổi.")
            )
        }

        val session = PtSessionEntity(
            ptContractId = ptContract.id,
            ptClientId = ptContract.ptClientId,
            sessionDateIso = sessionDateIso,
            sessionsUsed = sessionsUsed,
            note = note.trim()
        )
        dao.upsertPtSession(session)

        val newUsed = currentUsedSessions + sessionsUsed
        if (newUsed >= ptContract.totalSessions) {
            dao.upsertPtContract(
                ptContract.copy(
                    status = "COMPLETED",
                    updatedAt = System.currentTimeMillis()
                )
            )
        }
        return Result.success(session)
    }

    suspend fun updatePtContract(
        ptContract: PtContractEntity,
        totalSessions: Int,
        agreedValueVnd: Long,
        registerDateIso: String,
        currentUsedSessions: Int
    ): Result<Unit> {
        if (totalSessions < currentUsedSessions) {
            return Result.failure(IllegalArgumentException("Tổng số buổi mới ($totalSessions) không thể nhỏ hơn số buổi đã tập ($currentUsedSessions)."))
        }
        val newStatus = if (currentUsedSessions >= totalSessions) "COMPLETED" else "ACTIVE"
        dao.upsertPtContract(
            ptContract.copy(
                totalSessions = totalSessions,
                agreedValueVnd = agreedValueVnd,
                registerDateIso = registerDateIso,
                status = newStatus,
                updatedAt = System.currentTimeMillis()
            )
        )
        return Result.success(Unit)
    }

    suspend fun softDeletePtClient(ptClientId: String) {
        val now = System.currentTimeMillis()
        dao.getPtClientById(ptClientId)?.let { client ->
            dao.upsertPtClient(
                client.copy(
                    isDeleted = true,
                    deletedAt = now,
                    deleteReason = "Xóa hồ sơ PT",
                    updatedAt = now
                )
            )
        }
    }

    suspend fun restorePtClient(ptClientId: String) {
        dao.getPtClientById(ptClientId)?.let { client ->
            dao.upsertPtClient(
                client.copy(
                    isDeleted = false,
                    deletedAt = null,
                    updatedAt = System.currentTimeMillis()
                )
            )
        }
    }

    suspend fun permanentlyDeletePtClient(ptClientId: String) {
        dao.hardDeletePtClient(ptClientId)
    }

    // --- Short-Term Tickets: Daily & Weekly (Section 7) ---
    suspend fun sellShortTermTicket(
        ticketType: String, // "VE_NGAY" or "VE_TUAN"
        saleDateIso: String,
        quantity: Int,
        unitPriceVnd: Long,
        cashAmountVnd: Long,
        transferAmountVnd: Long
    ): Result<ShortTermTicketEntity> {
        if (quantity <= 0) return Result.failure(IllegalArgumentException("Số lượng vé phải lớn hơn 0."))
        if (unitPriceVnd <= 0L) return Result.failure(IllegalArgumentException("Chưa cấu hình đơn giá vé trong Cài đặt."))

        val total = unitPriceVnd * quantity
        val methodLabel = when {
            cashAmountVnd > 0L && transferAmountVnd > 0L -> "Kết hợp"
            transferAmountVnd > 0L -> "Chuyển khoản"
            else -> "Tiền mặt"
        }
        val ticket = ShortTermTicketEntity(
            ticketCode = FormatUtils.generateUniqueCode(if (ticketType == "VE_NGAY") "VNG" else "VTN"),
            ticketType = ticketType,
            saleDateIso = saleDateIso,
            quantity = quantity,
            unitPriceVnd = unitPriceVnd,
            totalAmountVnd = total,
            cashAmountVnd = cashAmountVnd,
            transferAmountVnd = transferAmountVnd,
            paymentMethodLabel = methodLabel
        )
        dao.upsertShortTermTicket(ticket)
        return Result.success(ticket)
    }

    suspend fun softDeleteTicket(ticket: ShortTermTicketEntity) {
        dao.upsertShortTermTicket(ticket.copy(isDeleted = true, deletedAt = System.currentTimeMillis()))
    }

    suspend fun restoreTicket(ticket: ShortTermTicketEntity) {
        dao.upsertShortTermTicket(ticket.copy(isDeleted = false, deletedAt = null))
    }

    suspend fun permanentlyDeleteTicket(ticketId: String) {
        dao.hardDeleteShortTermTicket(ticketId)
    }
}
