package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.BackupBundle
import com.example.data.model.ContractRecord
import com.example.data.model.MemberProfile
import com.example.data.model.PtSessionRecord
import com.example.data.model.SingleTicketRecord
import com.example.data.model.StudioConfig
import com.example.domain.FitnessCalculator
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

class FitnessRepository(private val db: FirebaseFirestore) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private val auth = Firebase.auth

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    private fun membersCollection(uid: String) =
        db.collection("users").document(uid).collection("members")

    private fun contractsCollection(uid: String) =
        db.collection("users").document(uid).collection("contracts")

    private fun ptSessionsCollection(uid: String) =
        db.collection("users").document(uid).collection("pt_sessions")

    private fun singleTicketsCollection(uid: String) =
        db.collection("users").document(uid).collection("single_tickets")

    private fun settingsCollection(uid: String) =
        db.collection("users").document(uid).collection("settings")

    fun observeMembers(): Flow<List<MemberProfile>> = flow {
        val uid = requireUserId()
        val path = "users/$uid/members"
        emitAll(
            membersCollection(uid)
                .whereEqualTo("userId", uid)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        MemberProfile::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    logIfActiveUser(error, OperationType.LIST, path, uid)
                    throw error
                }
        )
    }

    fun observeContracts(): Flow<List<ContractRecord>> = flow {
        val uid = requireUserId()
        val path = "users/$uid/contracts"
        emitAll(
            contractsCollection(uid)
                .whereEqualTo("userId", uid)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        ContractRecord::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    logIfActiveUser(error, OperationType.LIST, path, uid)
                    throw error
                }
        )
    }

    fun observePtSessions(): Flow<List<PtSessionRecord>> = flow {
        val uid = requireUserId()
        val path = "users/$uid/pt_sessions"
        emitAll(
            ptSessionsCollection(uid)
                .whereEqualTo("userId", uid)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        PtSessionRecord::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    logIfActiveUser(error, OperationType.LIST, path, uid)
                    throw error
                }
        )
    }

    fun observeSingleTickets(): Flow<List<SingleTicketRecord>> = flow {
        val uid = requireUserId()
        val path = "users/$uid/single_tickets"
        emitAll(
            singleTicketsCollection(uid)
                .whereEqualTo("userId", uid)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        SingleTicketRecord::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    logIfActiveUser(error, OperationType.LIST, path, uid)
                    throw error
                }
        )
    }

    fun observeStudioConfig(): Flow<StudioConfig> = flow {
        val uid = requireUserId()
        val path = "users/$uid/settings"
        emitAll(
            settingsCollection(uid)
                .whereEqualTo("userId", uid)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        StudioConfig::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).firstOrNull() ?: StudioConfig(userId = uid)
                }
                .catch { error ->
                    logIfActiveUser(error, OperationType.LIST, path, uid)
                    throw error
                }
        )
    }

    private fun logIfActiveUser(error: Throwable, op: OperationType, path: String, uid: String) {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val exceptionToLog = firestoreError ?: (error as? Exception)
        if (exceptionToLog != null && auth.currentUser?.uid == uid) {
            handleFirestoreError(exceptionToLog, op, path)
        }
    }

    suspend fun getOrCreateConfig(): StudioConfig {
        val uid = requireUserId()
        val docRef = settingsCollection(uid).document("main_config")
        return try {
            val snap = docRef.get().await()
            if (snap.exists()) {
                snap.toObject(
                    StudioConfig::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ) ?: StudioConfig(userId = uid)
            } else {
                val initial = StudioConfig(
                    id = "main_config",
                    userId = uid,
                    createdAt = null,
                    updatedAt = null
                )
                docRef.set(initial).await()
                val createdSnap = docRef.get().await()
                createdSnap.toObject(
                    StudioConfig::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ) ?: initial.copy(createdAt = Timestamp.now(), updatedAt = Timestamp.now())
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, docRef.path)
            throw e
        }
    }

    suspend fun saveStudioConfig(updated: StudioConfig) {
        val uid = requireUserId()
        val existing = getOrCreateConfig()
        val docRef = settingsCollection(uid).document("main_config")
        val payload = updated.copy(
            id = "main_config",
            userId = uid,
            createdAt = existing.createdAt ?: Timestamp.now(),
            updatedAt = null
        )
        try {
            docRef.set(payload).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun getMemberById(memberId: String): Result<MemberProfile> = runCatching {
        val uid = requireUserId()
        val docRef = membersCollection(uid).document(memberId)
        try {
            val snap = docRef.get().await()
            snap.toObject(
                MemberProfile::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: throw NoSuchElementException("Member not found: $memberId")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, docRef.path)
            throw e
        }
    }

    suspend fun createMemberWithInitialContract(
        serviceType: String,
        fullName: String,
        phone: String,
        memberGroup: String,
        durationMonths: Long,
        startDate: String,
        endDate: String,
        totalSessions: Long,
        packageValue: Long,
        paidAmount: Long,
        paymentMethod: String,
        cashAmount: Long,
        transferAmount: Long,
        paymentDate: String
    ): Result<Pair<MemberProfile, ContractRecord>> = runCatching {
        val uid = requireUserId()
        val config = getOrCreateConfig()
        val newStt = when (serviceType) {
            "GYM" -> config.lastGymStt + 1L
            "YOGA" -> config.lastYogaStt + 1L
            "PT" -> config.lastPtStt + 1L
            else -> config.lastGymStt + 1L
        }

        val updatedConfig = when (serviceType) {
            "GYM" -> config.copy(lastGymStt = newStt)
            "YOGA" -> config.copy(lastYogaStt = newStt)
            "PT" -> config.copy(lastPtStt = newStt)
            else -> config.copy(lastGymStt = newStt)
        }
        saveStudioConfig(updatedConfig)

        val memberId = "mem_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val contractId = "con_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val contractCode = FitnessCalculator.buildContractCode(serviceType, newStt, 1L)

        val member = MemberProfile(
            id = memberId,
            userId = uid,
            type = serviceType,
            stt = newStt,
            fullName = fullName.trim(),
            phone = phone.trim(),
            memberGroup = if (serviceType == "GYM") memberGroup else "NONE",
            nextContractSeq = 2L,
            isDeleted = false,
            deletedAtEpoch = 0L,
            deletedBatchId = "",
            createdAt = null,
            updatedAt = null
        )

        val contract = ContractRecord(
            id = contractId,
            userId = uid,
            contractCode = contractCode,
            memberId = memberId,
            memberSttSnapshot = newStt,
            memberNameSnapshot = fullName.trim(),
            memberPhoneSnapshot = phone.trim(),
            serviceType = serviceType,
            isRenewal = false,
            memberGroup = if (serviceType == "GYM") memberGroup else "NONE",
            durationMonths = if (serviceType == "PT") 0L else durationMonths,
            startDate = startDate,
            endDate = if (serviceType == "PT") "" else endDate,
            totalSessions = if (serviceType == "PT") totalSessions else 0L,
            usedSessions = 0L,
            ptStatus = if (serviceType == "PT") "ACTIVE" else "NONE",
            packageValue = packageValue,
            paidAmount = paidAmount,
            paymentMethod = paymentMethod,
            cashAmount = cashAmount,
            transferAmount = transferAmount,
            paymentDate = paymentDate,
            isDeleted = false,
            deletedAtEpoch = 0L,
            deletedBatchId = "",
            createdAt = null,
            updatedAt = null
        )

        val memRef = membersCollection(uid).document(memberId)
        val conRef = contractsCollection(uid).document(contractId)
        try {
            memRef.set(member).await()
            conRef.set(contract).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, memRef.path)
            throw e
        }
        member to contract
    }

    suspend fun createRenewalContract(
        member: MemberProfile,
        memberGroup: String,
        durationMonths: Long,
        startDate: String,
        endDate: String,
        totalSessions: Long,
        packageValue: Long,
        paidAmount: Long,
        paymentMethod: String,
        cashAmount: Long,
        transferAmount: Long,
        paymentDate: String
    ): Result<ContractRecord> = runCatching {
        val uid = requireUserId()
        val seq = member.nextContractSeq.coerceAtLeast(1L)
        val contractCode = FitnessCalculator.buildContractCode(member.type, member.stt, seq)
        val contractId = "con_${UUID.randomUUID().toString().replace("-", "").take(16)}"

        val contract = ContractRecord(
            id = contractId,
            userId = uid,
            contractCode = contractCode,
            memberId = member.id,
            memberSttSnapshot = member.stt,
            memberNameSnapshot = member.fullName,
            memberPhoneSnapshot = member.phone,
            serviceType = member.type,
            isRenewal = seq > 1L,
            memberGroup = if (member.type == "GYM") memberGroup else "NONE",
            durationMonths = if (member.type == "PT") 0L else durationMonths,
            startDate = startDate,
            endDate = if (member.type == "PT") "" else endDate,
            totalSessions = if (member.type == "PT") totalSessions else 0L,
            usedSessions = 0L,
            ptStatus = if (member.type == "PT") "ACTIVE" else "NONE",
            packageValue = packageValue,
            paidAmount = paidAmount,
            paymentMethod = paymentMethod,
            cashAmount = cashAmount,
            transferAmount = transferAmount,
            paymentDate = paymentDate,
            isDeleted = false,
            deletedAtEpoch = 0L,
            deletedBatchId = "",
            createdAt = null,
            updatedAt = null
        )

        val memRef = membersCollection(uid).document(member.id)
        val conRef = contractsCollection(uid).document(contractId)
        try {
            val freshSnap = memRef.get().await()
            val freshMember = freshSnap.toObject(
                MemberProfile::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: member
            memRef.set(
                freshMember.copy(
                    memberGroup = if (member.type == "GYM") memberGroup else freshMember.memberGroup,
                    nextContractSeq = seq + 1L,
                    createdAt = freshMember.createdAt ?: Timestamp.now(),
                    updatedAt = null
                )
            ).await()
            conRef.set(contract).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, conRef.path)
            throw e
        }
        contract
    }

    suspend fun updateMemberProfile(
        member: MemberProfile,
        newFullName: String,
        newPhone: String,
        newGroup: String
    ): Result<Unit> = runCatching {
        val uid = requireUserId()
        val memRef = membersCollection(uid).document(member.id)
        try {
            val snap = memRef.get().await()
            val current = snap.toObject(
                MemberProfile::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: member
            memRef.set(
                current.copy(
                    fullName = newFullName.trim(),
                    phone = newPhone.trim(),
                    memberGroup = if (current.type == "GYM") newGroup else "NONE",
                    createdAt = current.createdAt ?: Timestamp.now(),
                    updatedAt = null
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, memRef.path)
            throw e
        }
    }

    suspend fun updateContractRecord(updated: ContractRecord): Result<Unit> = runCatching {
        val uid = requireUserId()
        val conRef = contractsCollection(uid).document(updated.id)
        try {
            val snap = conRef.get().await()
            val current = snap.toObject(
                ContractRecord::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: updated
            val recalculatedPtStatus = if (current.serviceType == "PT") {
                if (updated.usedSessions >= updated.totalSessions && updated.totalSessions > 0L) {
                    "COMPLETED"
                } else {
                    "ACTIVE"
                }
            } else {
                "NONE"
            }
            conRef.set(
                updated.copy(
                    userId = uid,
                    contractCode = current.contractCode,
                    memberId = current.memberId,
                    serviceType = current.serviceType,
                    ptStatus = recalculatedPtStatus,
                    createdAt = current.createdAt ?: Timestamp.now(),
                    updatedAt = null
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, conRef.path)
            throw e
        }
    }

    suspend fun recordPtSession(
        member: MemberProfile,
        contract: ContractRecord,
        sessionDate: String,
        note: String
    ): Result<PtSessionRecord> = runCatching {
        val uid = requireUserId()
        val sessionId = "pts_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val session = PtSessionRecord(
            id = sessionId,
            userId = uid,
            contractId = contract.id,
            memberId = member.id,
            memberSttSnapshot = member.stt,
            memberNameSnapshot = member.fullName,
            contractCodeSnapshot = contract.contractCode,
            sessionDate = sessionDate,
            note = note.trim(),
            isDeleted = false,
            deletedAtEpoch = 0L,
            deletedBatchId = "",
            createdAt = null,
            updatedAt = null
        )

        val sesRef = ptSessionsCollection(uid).document(sessionId)
        val conRef = contractsCollection(uid).document(contract.id)
        try {
            sesRef.set(session).await()
            val snap = conRef.get().await()
            val freshContract = snap.toObject(
                ContractRecord::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: contract
            val newUsed = freshContract.usedSessions + 1L
            val newStatus = if (newUsed >= freshContract.totalSessions) "COMPLETED" else "ACTIVE"
            conRef.set(
                freshContract.copy(
                    usedSessions = newUsed,
                    ptStatus = newStatus,
                    createdAt = freshContract.createdAt ?: Timestamp.now(),
                    updatedAt = null
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, sesRef.path)
            throw e
        }
        session
    }

    suspend fun updatePtSession(
        session: PtSessionRecord,
        newDate: String,
        newNote: String
    ): Result<Unit> = runCatching {
        val uid = requireUserId()
        val sesRef = ptSessionsCollection(uid).document(session.id)
        try {
            val snap = sesRef.get().await()
            val current = snap.toObject(
                PtSessionRecord::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: session
            sesRef.set(
                current.copy(
                    sessionDate = newDate,
                    note = newNote.trim(),
                    createdAt = current.createdAt ?: Timestamp.now(),
                    updatedAt = null
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, sesRef.path)
            throw e
        }
    }

    suspend fun createSingleTicket(
        ticketType: String,
        saleDate: String,
        quantity: Long,
        unitPrice: Long,
        paymentMethod: String,
        cashAmount: Long,
        transferAmount: Long
    ): Result<SingleTicketRecord> = runCatching {
        val uid = requireUserId()
        val ticketId = "tkt_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val total = quantity * unitPrice
        val record = SingleTicketRecord(
            id = ticketId,
            userId = uid,
            ticketType = ticketType,
            saleDate = saleDate,
            quantity = quantity,
            unitPrice = unitPrice,
            totalAmount = total,
            paymentMethod = paymentMethod,
            cashAmount = cashAmount,
            transferAmount = transferAmount,
            isDeleted = false,
            deletedAtEpoch = 0L,
            deletedBatchId = "",
            createdAt = null,
            updatedAt = null
        )
        val ref = singleTicketsCollection(uid).document(ticketId)
        try {
            ref.set(record).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, ref.path)
            throw e
        }
        record
    }

    /**
     * Xóa mềm đồng bộ hồ sơ và các hợp đồng + buổi tập liên quan vào Thùng rác.
     */
    suspend fun softDeleteMemberCascade(
        member: MemberProfile,
        relatedContracts: List<ContractRecord>,
        relatedSessions: List<PtSessionRecord>
    ): Result<Unit> = runCatching {
        val uid = requireUserId()
        val nowEpoch = System.currentTimeMillis()
        val batchId = "del_${UUID.randomUUID().toString().replace("-", "").take(12)}"

        val memRef = membersCollection(uid).document(member.id)
        try {
            val snap = memRef.get().await()
            val freshMem = snap.toObject(
                MemberProfile::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: member
            memRef.set(
                freshMem.copy(
                    isDeleted = true,
                    deletedAtEpoch = nowEpoch,
                    deletedBatchId = batchId,
                    createdAt = freshMem.createdAt ?: Timestamp.now(),
                    updatedAt = null
                )
            ).await()

            for (c in relatedContracts.filter { !it.isDeleted }) {
                val cRef = contractsCollection(uid).document(c.id)
                val cSnap = cRef.get().await()
                val freshC = cSnap.toObject(
                    ContractRecord::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ) ?: c
                cRef.set(
                    freshC.copy(
                        isDeleted = true,
                        deletedAtEpoch = nowEpoch,
                        deletedBatchId = batchId,
                        createdAt = freshC.createdAt ?: Timestamp.now(),
                        updatedAt = null
                    )
                ).await()
            }

            for (s in relatedSessions.filter { !it.isDeleted }) {
                val sRef = ptSessionsCollection(uid).document(s.id)
                val sSnap = sRef.get().await()
                val freshS = sSnap.toObject(
                    PtSessionRecord::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ) ?: s
                sRef.set(
                    freshS.copy(
                        isDeleted = true,
                        deletedAtEpoch = nowEpoch,
                        deletedBatchId = batchId,
                        createdAt = freshS.createdAt ?: Timestamp.now(),
                        updatedAt = null
                    )
                ).await()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, memRef.path)
            throw e
        }
    }

    suspend fun softDeleteContract(
        contract: ContractRecord,
        relatedSessions: List<PtSessionRecord>
    ): Result<Unit> = runCatching {
        val uid = requireUserId()
        val nowEpoch = System.currentTimeMillis()
        val batchId = "delc_${UUID.randomUUID().toString().replace("-", "").take(12)}"
        val cRef = contractsCollection(uid).document(contract.id)
        try {
            val cSnap = cRef.get().await()
            val freshC = cSnap.toObject(
                ContractRecord::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: contract
            cRef.set(
                freshC.copy(
                    isDeleted = true,
                    deletedAtEpoch = nowEpoch,
                    deletedBatchId = batchId,
                    createdAt = freshC.createdAt ?: Timestamp.now(),
                    updatedAt = null
                )
            ).await()

            for (s in relatedSessions.filter { !it.isDeleted && it.contractId == contract.id }) {
                val sRef = ptSessionsCollection(uid).document(s.id)
                val sSnap = sRef.get().await()
                val freshS = sSnap.toObject(
                    PtSessionRecord::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ) ?: s
                sRef.set(
                    freshS.copy(
                        isDeleted = true,
                        deletedAtEpoch = nowEpoch,
                        deletedBatchId = batchId,
                        createdAt = freshS.createdAt ?: Timestamp.now(),
                        updatedAt = null
                    )
                ).await()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, cRef.path)
            throw e
        }
    }

    suspend fun softDeletePtSession(
        session: PtSessionRecord,
        parentContract: ContractRecord?
    ): Result<Unit> = runCatching {
        val uid = requireUserId()
        val nowEpoch = System.currentTimeMillis()
        val sRef = ptSessionsCollection(uid).document(session.id)
        try {
            val sSnap = sRef.get().await()
            val freshS = sSnap.toObject(
                PtSessionRecord::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: session
            sRef.set(
                freshS.copy(
                    isDeleted = true,
                    deletedAtEpoch = nowEpoch,
                    deletedBatchId = "dels_${session.id}",
                    createdAt = freshS.createdAt ?: Timestamp.now(),
                    updatedAt = null
                )
            ).await()

            if (parentContract != null) {
                val cRef = contractsCollection(uid).document(parentContract.id)
                val cSnap = cRef.get().await()
                val freshC = cSnap.toObject(
                    ContractRecord::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ) ?: parentContract
                val newUsed = (freshC.usedSessions - 1L).coerceAtLeast(0L)
                val newStatus = if (newUsed >= freshC.totalSessions && freshC.totalSessions > 0L) {
                    "COMPLETED"
                } else {
                    "ACTIVE"
                }
                cRef.set(
                    freshC.copy(
                        usedSessions = newUsed,
                        ptStatus = newStatus,
                        createdAt = freshC.createdAt ?: Timestamp.now(),
                        updatedAt = null
                    )
                ).await()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, sRef.path)
            throw e
        }
    }

    suspend fun softDeleteSingleTicket(ticket: SingleTicketRecord): Result<Unit> = runCatching {
        val uid = requireUserId()
        val nowEpoch = System.currentTimeMillis()
        val tRef = singleTicketsCollection(uid).document(ticket.id)
        try {
            val snap = tRef.get().await()
            val fresh = snap.toObject(
                SingleTicketRecord::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: ticket
            tRef.set(
                fresh.copy(
                    isDeleted = true,
                    deletedAtEpoch = nowEpoch,
                    deletedBatchId = "delt_${ticket.id}",
                    createdAt = fresh.createdAt ?: Timestamp.now(),
                    updatedAt = null
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, tRef.path)
            throw e
        }
    }

    /**
     * Khôi phục hồ sơ từ Thùng rác (khôi phục đồng bộ các hợp đồng và buổi tập cùng deletedBatchId).
     */
    suspend fun restoreMemberCascade(
        member: MemberProfile,
        allContracts: List<ContractRecord>,
        allSessions: List<PtSessionRecord>
    ): Result<Unit> = runCatching {
        val uid = requireUserId()
        val batchId = member.deletedBatchId
        val memRef = membersCollection(uid).document(member.id)
        try {
            val snap = memRef.get().await()
            val freshMem = snap.toObject(
                MemberProfile::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: member
            memRef.set(
                freshMem.copy(
                    isDeleted = false,
                    deletedAtEpoch = 0L,
                    deletedBatchId = "",
                    createdAt = freshMem.createdAt ?: Timestamp.now(),
                    updatedAt = null
                )
            ).await()

            if (batchId.isNotBlank()) {
                for (c in allContracts.filter { it.isDeleted && it.deletedBatchId == batchId }) {
                    val cRef = contractsCollection(uid).document(c.id)
                    val cSnap = cRef.get().await()
                    val freshC = cSnap.toObject(
                        ContractRecord::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ) ?: c
                    cRef.set(
                        freshC.copy(
                            isDeleted = false,
                            deletedAtEpoch = 0L,
                            deletedBatchId = "",
                            createdAt = freshC.createdAt ?: Timestamp.now(),
                            updatedAt = null
                        )
                    ).await()
                }
                for (s in allSessions.filter { it.isDeleted && it.deletedBatchId == batchId }) {
                    val sRef = ptSessionsCollection(uid).document(s.id)
                    val sSnap = sRef.get().await()
                    val freshS = sSnap.toObject(
                        PtSessionRecord::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ) ?: s
                    sRef.set(
                        freshS.copy(
                            isDeleted = false,
                            deletedAtEpoch = 0L,
                            deletedBatchId = "",
                            createdAt = freshS.createdAt ?: Timestamp.now(),
                            updatedAt = null
                        )
                    ).await()
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, memRef.path)
            throw e
        }
    }

    /**
     * Khôi phục hợp đồng từ Thùng rác (tự động khôi phục hồ sơ gốc nếu hồ sơ đang nằm trong Thùng rác).
     */
    suspend fun restoreContractWithParentCheck(
        contract: ContractRecord,
        parentMember: MemberProfile?,
        allSessions: List<PtSessionRecord>
    ): Result<Unit> = runCatching {
        val uid = requireUserId()
        val cRef = contractsCollection(uid).document(contract.id)
        try {
            if (parentMember != null && parentMember.isDeleted) {
                val memRef = membersCollection(uid).document(parentMember.id)
                val mSnap = memRef.get().await()
                val freshM = mSnap.toObject(
                    MemberProfile::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ) ?: parentMember
                memRef.set(
                    freshM.copy(
                        isDeleted = false,
                        deletedAtEpoch = 0L,
                        deletedBatchId = "",
                        createdAt = freshM.createdAt ?: Timestamp.now(),
                        updatedAt = null
                    )
                ).await()
            }

            val cSnap = cRef.get().await()
            val freshC = cSnap.toObject(
                ContractRecord::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: contract
            cRef.set(
                freshC.copy(
                    isDeleted = false,
                    deletedAtEpoch = 0L,
                    deletedBatchId = "",
                    createdAt = freshC.createdAt ?: Timestamp.now(),
                    updatedAt = null
                )
            ).await()

            val batchId = contract.deletedBatchId
            if (batchId.isNotBlank()) {
                for (s in allSessions.filter { it.isDeleted && it.contractId == contract.id && it.deletedBatchId == batchId }) {
                    val sRef = ptSessionsCollection(uid).document(s.id)
                    val sSnap = sRef.get().await()
                    val freshS = sSnap.toObject(
                        PtSessionRecord::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ) ?: s
                    sRef.set(
                        freshS.copy(
                            isDeleted = false,
                            deletedAtEpoch = 0L,
                            deletedBatchId = "",
                            createdAt = freshS.createdAt ?: Timestamp.now(),
                            updatedAt = null
                        )
                    ).await()
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, cRef.path)
            throw e
        }
    }

    suspend fun restorePtSession(
        session: PtSessionRecord,
        parentContract: ContractRecord?
    ): Result<Unit> = runCatching {
        val uid = requireUserId()
        val sRef = ptSessionsCollection(uid).document(session.id)
        try {
            val sSnap = sRef.get().await()
            val freshS = sSnap.toObject(
                PtSessionRecord::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: session
            sRef.set(
                freshS.copy(
                    isDeleted = false,
                    deletedAtEpoch = 0L,
                    deletedBatchId = "",
                    createdAt = freshS.createdAt ?: Timestamp.now(),
                    updatedAt = null
                )
            ).await()

            if (parentContract != null) {
                val cRef = contractsCollection(uid).document(parentContract.id)
                val cSnap = cRef.get().await()
                val freshC = cSnap.toObject(
                    ContractRecord::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ) ?: parentContract
                val newUsed = freshC.usedSessions + 1L
                val newStatus = if (newUsed >= freshC.totalSessions && freshC.totalSessions > 0L) {
                    "COMPLETED"
                } else {
                    "ACTIVE"
                }
                cRef.set(
                    freshC.copy(
                        usedSessions = newUsed,
                        ptStatus = newStatus,
                        createdAt = freshC.createdAt ?: Timestamp.now(),
                        updatedAt = null
                    )
                ).await()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, sRef.path)
            throw e
        }
    }

    suspend fun restoreSingleTicket(ticket: SingleTicketRecord): Result<Unit> = runCatching {
        val uid = requireUserId()
        val tRef = singleTicketsCollection(uid).document(ticket.id)
        try {
            val snap = tRef.get().await()
            val fresh = snap.toObject(
                SingleTicketRecord::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: ticket
            tRef.set(
                fresh.copy(
                    isDeleted = false,
                    deletedAtEpoch = 0L,
                    deletedBatchId = "",
                    createdAt = fresh.createdAt ?: Timestamp.now(),
                    updatedAt = null
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, tRef.path)
            throw e
        }
    }

    suspend fun permanentDeleteMember(
        memberId: String,
        relatedContracts: List<ContractRecord>,
        relatedSessions: List<PtSessionRecord>
    ): Result<Unit> = runCatching {
        val uid = requireUserId()
        val memRef = membersCollection(uid).document(memberId)
        try {
            for (s in relatedSessions.filter { it.memberId == memberId }) {
                ptSessionsCollection(uid).document(s.id).delete().await()
            }
            for (c in relatedContracts.filter { it.memberId == memberId }) {
                contractsCollection(uid).document(c.id).delete().await()
            }
            memRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, memRef.path)
            throw e
        }
    }

    suspend fun permanentDeleteContract(
        contractId: String,
        relatedSessions: List<PtSessionRecord>
    ): Result<Unit> = runCatching {
        val uid = requireUserId()
        val cRef = contractsCollection(uid).document(contractId)
        try {
            for (s in relatedSessions.filter { it.contractId == contractId }) {
                ptSessionsCollection(uid).document(s.id).delete().await()
            }
            cRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, cRef.path)
            throw e
        }
    }

    suspend fun permanentDeletePtSession(sessionId: String): Result<Unit> = runCatching {
        val uid = requireUserId()
        val sRef = ptSessionsCollection(uid).document(sessionId)
        try {
            sRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, sRef.path)
            throw e
        }
    }

    suspend fun permanentDeleteSingleTicket(ticketId: String): Result<Unit> = runCatching {
        val uid = requireUserId()
        val tRef = singleTicketsCollection(uid).document(ticketId)
        try {
            tRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, tRef.path)
            throw e
        }
    }

    /**
     * Khôi phục từ gói dữ liệu sao lưu (Offline hoặc Google Drive) với quy tắc ưu tiên bản mới nhất (Last-Write-Wins).
     */
    suspend fun restoreFromBackupBundle(bundle: BackupBundle): Result<Unit> = runCatching {
        val uid = requireUserId()
        val currentConfig = getOrCreateConfig()
        val mergedConfig = bundle.config.copy(
            id = "main_config",
            userId = uid,
            lastGymStt = maxOf(currentConfig.lastGymStt, bundle.config.lastGymStt),
            lastYogaStt = maxOf(currentConfig.lastYogaStt, bundle.config.lastYogaStt),
            lastPtStt = maxOf(currentConfig.lastPtStt, bundle.config.lastPtStt),
            lastSyncEpoch = System.currentTimeMillis()
        )
        saveStudioConfig(mergedConfig)

        for (member in bundle.members) {
            val docId = member.id.ifBlank { "mem_${UUID.randomUUID().toString().replace("-", "").take(16)}" }
            val ref = membersCollection(uid).document(docId)
            val snap = ref.get().await()
            if (snap.exists()) {
                val existing = snap.toObject(
                    MemberProfile::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
                ref.set(
                    member.copy(
                        id = docId,
                        userId = uid,
                        type = existing?.type ?: member.type,
                        stt = existing?.stt ?: member.stt,
                        createdAt = existing?.createdAt ?: Timestamp.now(),
                        updatedAt = null
                    )
                ).await()
            } else {
                ref.set(
                    member.copy(
                        id = docId,
                        userId = uid,
                        createdAt = null,
                        updatedAt = null
                    )
                ).await()
            }
        }

        for (contract in bundle.contracts) {
            val docId = contract.id.ifBlank { "con_${UUID.randomUUID().toString().replace("-", "").take(16)}" }
            val ref = contractsCollection(uid).document(docId)
            val snap = ref.get().await()
            if (snap.exists()) {
                val existing = snap.toObject(
                    ContractRecord::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
                ref.set(
                    contract.copy(
                        id = docId,
                        userId = uid,
                        contractCode = existing?.contractCode ?: contract.contractCode,
                        memberId = existing?.memberId ?: contract.memberId,
                        serviceType = existing?.serviceType ?: contract.serviceType,
                        createdAt = existing?.createdAt ?: Timestamp.now(),
                        updatedAt = null
                    )
                ).await()
            } else {
                ref.set(
                    contract.copy(
                        id = docId,
                        userId = uid,
                        createdAt = null,
                        updatedAt = null
                    )
                ).await()
            }
        }

        for (session in bundle.ptSessions) {
            val docId = session.id.ifBlank { "pts_${UUID.randomUUID().toString().replace("-", "").take(16)}" }
            val ref = ptSessionsCollection(uid).document(docId)
            val snap = ref.get().await()
            if (snap.exists()) {
                val existing = snap.toObject(
                    PtSessionRecord::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
                ref.set(
                    session.copy(
                        id = docId,
                        userId = uid,
                        contractId = existing?.contractId ?: session.contractId,
                        memberId = existing?.memberId ?: session.memberId,
                        createdAt = existing?.createdAt ?: Timestamp.now(),
                        updatedAt = null
                    )
                ).await()
            } else {
                ref.set(
                    session.copy(
                        id = docId,
                        userId = uid,
                        createdAt = null,
                        updatedAt = null
                    )
                ).await()
            }
        }

        for (ticket in bundle.singleTickets) {
            val docId = ticket.id.ifBlank { "tkt_${UUID.randomUUID().toString().replace("-", "").take(16)}" }
            val ref = singleTicketsCollection(uid).document(docId)
            val snap = ref.get().await()
            if (snap.exists()) {
                val existing = snap.toObject(
                    SingleTicketRecord::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
                ref.set(
                    ticket.copy(
                        id = docId,
                        userId = uid,
                        createdAt = existing?.createdAt ?: Timestamp.now(),
                        updatedAt = null
                    )
                ).await()
            } else {
                ref.set(
                    ticket.copy(
                        id = docId,
                        userId = uid,
                        createdAt = null,
                        updatedAt = null
                    )
                ).await()
            }
        }
    }
}
