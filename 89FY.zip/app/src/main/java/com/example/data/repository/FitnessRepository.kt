package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.local.FitnessLocalDao
import com.example.data.local.FitnessLocalDatabase
import com.example.data.local.LocalContractEntity
import com.example.data.local.LocalMemberEntity
import com.example.data.local.LocalPtSessionEntity
import com.example.data.local.LocalSingleTicketEntity
import com.example.data.local.LocalStudioConfigEntity
import com.example.data.model.BackupBundle
import com.example.data.model.ContractRecord
import com.example.data.model.MemberProfile
import com.example.data.model.PtSessionRecord
import com.example.data.model.SingleTicketRecord
import com.example.data.model.StudioConfig
import com.example.domain.FitnessCalculator
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

/**
 * Kiến trúc Offline-first:
 * - Khi `localDao != null` (chế độ vận hành chính của ứng dụng): Cơ sở dữ liệu Room SQLite trên thiết bị
 *   là nguồn dữ liệu duy nhất (Single Source of Truth). Toàn bộ chức năng quản lý hoạt động 100% offline
 *   mà không cần Internet hoặc đăng nhập Google.
 * - `remoteDb` (Firebase Firestore) chỉ được dùng khi người dùng chủ động bấm Sao lưu / Khôi phục Cloud
 *   tại mục Cài đặt sau khi đã đăng nhập Google.
 */
class FitnessRepository(
    private val localDao: FitnessLocalDao? = null,
    private val remoteDb: FirebaseFirestore? = null
) {

    // Constructor dùng cho kiểm thử quy tắc bảo mật Firestore (FitnessRepositoryRuleTest)
    constructor(db: FirebaseFirestore) : this(localDao = null, remoteDb = db)

    // Constructor chuẩn dùng trong ứng dụng Android Offline-first
    constructor(context: Context) : this(
        localDao = FitnessLocalDatabase.getDatabase(context.applicationContext).fitnessDao(),
        remoteDb = kotlin.runCatching {
            FirebaseFirestore.getInstance(
                context.applicationContext.getString(R.string.firestore_database_id)
            )
        }.getOrNull()
    )

    private val auth
        get() = runCatching { Firebase.auth }.getOrNull()

    private fun requireRemoteUserId(): String {
        return auth?.currentUser?.uid
            ?: throw IllegalStateException("Vui lòng đăng nhập Google trong Cài đặt để sử dụng tính năng đồng bộ Cloud.")
    }

    private fun requireRemoteDb(): FirebaseFirestore {
        return remoteDb ?: throw IllegalStateException("Dịch vụ Cloud chưa sẵn sàng trên thiết bị này.")
    }

    private fun membersCollection(uid: String) =
        requireRemoteDb().collection("users").document(uid).collection("members")

    private fun contractsCollection(uid: String) =
        requireRemoteDb().collection("users").document(uid).collection("contracts")

    private fun ptSessionsCollection(uid: String) =
        requireRemoteDb().collection("users").document(uid).collection("pt_sessions")

    private fun singleTicketsCollection(uid: String) =
        requireRemoteDb().collection("users").document(uid).collection("single_tickets")

    private fun settingsCollection(uid: String) =
        requireRemoteDb().collection("users").document(uid).collection("settings")

    // =========================================================================================
    // REACTIVE STREAMS (Single Source of Truth = Local Room Database)
    // =========================================================================================

    fun observeMembers(): Flow<List<MemberProfile>> {
        if (localDao != null) {
            return localDao.observeAllMembers().map { list -> list.map { it.toDomain() } }
        }
        return flow {
            val uid = requireRemoteUserId()
            val path = "users/$uid/members"
            emitAll(
                membersCollection(uid)
                    .whereEqualTo("userId", uid)
                    .snapshots()
                    .map { snapshot ->
                        snapshot.toObjects(
                            MemberProfile::class.java,
                            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                        )
                    }
                    .catch { error ->
                        logIfActiveUser(error, OperationType.LIST, path, uid)
                        throw error
                    }
            )
        }
    }

    fun observeContracts(): Flow<List<ContractRecord>> {
        if (localDao != null) {
            return localDao.observeAllContracts().map { list -> list.map { it.toDomain() } }
        }
        return flow {
            val uid = requireRemoteUserId()
            val path = "users/$uid/contracts"
            emitAll(
                contractsCollection(uid)
                    .whereEqualTo("userId", uid)
                    .snapshots()
                    .map { snapshot ->
                        snapshot.toObjects(
                            ContractRecord::class.java,
                            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                        )
                    }
                    .catch { error ->
                        logIfActiveUser(error, OperationType.LIST, path, uid)
                        throw error
                    }
            )
        }
    }

    fun observePtSessions(): Flow<List<PtSessionRecord>> {
        if (localDao != null) {
            return localDao.observeAllPtSessions().map { list -> list.map { it.toDomain() } }
        }
        return flow {
            val uid = requireRemoteUserId()
            val path = "users/$uid/pt_sessions"
            emitAll(
                ptSessionsCollection(uid)
                    .whereEqualTo("userId", uid)
                    .snapshots()
                    .map { snapshot ->
                        snapshot.toObjects(
                            PtSessionRecord::class.java,
                            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                        )
                    }
                    .catch { error ->
                        logIfActiveUser(error, OperationType.LIST, path, uid)
                        throw error
                    }
            )
        }
    }

    fun observeSingleTickets(): Flow<List<SingleTicketRecord>> {
        if (localDao != null) {
            return localDao.observeAllSingleTickets().map { list -> list.map { it.toDomain() } }
        }
        return flow {
            val uid = requireRemoteUserId()
            val path = "users/$uid/single_tickets"
            emitAll(
                singleTicketsCollection(uid)
                    .whereEqualTo("userId", uid)
                    .snapshots()
                    .map { snapshot ->
                        snapshot.toObjects(
                            SingleTicketRecord::class.java,
                            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                        )
                    }
                    .catch { error ->
                        logIfActiveUser(error, OperationType.LIST, path, uid)
                        throw error
                    }
            )
        }
    }

    fun observeStudioConfig(): Flow<StudioConfig> {
        if (localDao != null) {
            return localDao.observeConfig().map { entity ->
                entity?.toDomain() ?: StudioConfig(userId = "local_user")
            }
        }
        return flow {
            val uid = requireRemoteUserId()
            val path = "users/$uid/settings"
            emitAll(
                settingsCollection(uid)
                    .whereEqualTo("userId", uid)
                    .snapshots()
                    .map { snapshot ->
                        snapshot.toObjects(
                            StudioConfig::class.java,
                            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                        ).firstOrNull() ?: StudioConfig(userId = uid)
                    }
                    .catch { error ->
                        logIfActiveUser(error, OperationType.LIST, path, uid)
                        throw error
                    }
            )
        }
    }

    private fun logIfActiveUser(error: Throwable, op: OperationType, path: String, uid: String) {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val exceptionToLog = firestoreError ?: (error as? Exception)
        if (exceptionToLog != null && auth?.currentUser?.uid == uid) {
            handleFirestoreError(exceptionToLog, op, path)
        }
    }

    // =========================================================================================
    // CRUD OPERATIONS (Local Room Database First)
    // =========================================================================================

    suspend fun getOrCreateConfig(): StudioConfig {
        if (localDao != null) {
            val existing = localDao.getConfigOnce()
            if (existing != null) return existing.toDomain()
            val initial = LocalStudioConfigEntity(id = "main_config", userId = "local_user")
            localDao.upsertConfig(initial)
            return initial.toDomain()
        }

        val uid = requireRemoteUserId()
        val docRef = settingsCollection(uid).document("main_config")
        return try {
            val snap = docRef.get().await()
            if (snap.exists()) {
                snap.toObject(
                    StudioConfig::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ) ?: StudioConfig(userId = uid)
            } else {
                val initial = StudioConfig(
                    id = "main_config",
                    userId = uid,
                    createdAt = null,
                    updatedAt = null
                )
                docRef.set(initial).await()
                val createdSnap = docRef.get().await()
                createdSnap.toObject(
                    StudioConfig::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ) ?: initial.copy(createdAt = Timestamp.now(), updatedAt = Timestamp.now())
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, docRef.path)
            throw e
        }
    }

    suspend fun saveStudioConfig(updated: StudioConfig) {
        if (localDao != null) {
            val now = System.currentTimeMillis()
            val existing = localDao.getConfigOnce()
            val entity = LocalStudioConfigEntity.fromDomain(updated, now).copy(
                id = "main_config",
                createdAtEpoch = existing?.createdAtEpoch ?: now,
                updatedAtEpoch = now
            )
            localDao.upsertConfig(entity)
            return
        }

        val uid = requireRemoteUserId()
        val existing = getOrCreateConfig()
        val docRef = settingsCollection(uid).document("main_config")
        val payload = updated.copy(
            id = "main_config",
            userId = uid,
            createdAt = existing.createdAt ?: Timestamp.now(),
            updatedAt = null
        )
        try {
            docRef.set(payload).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun getMemberById(memberId: String): Result<MemberProfile> = runCatching {
        if (localDao != null) {
            return@runCatching localDao.getMemberById(memberId)?.toDomain()
                ?: throw NoSuchElementException("Member not found: $memberId")
        }
        val uid = requireRemoteUserId()
        val docRef = membersCollection(uid).document(memberId)
        try {
            val snap = docRef.get().await()
            snap.toObject(
                MemberProfile::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: throw NoSuchElementException("Member not found: $memberId")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, docRef.path)
            throw e
        }
    }

    suspend fun createMemberWithInitialContract(
        serviceType: String,
        fullName: String,
        phone: String,
        memberGroup: String,
        durationMonths: Long,
        startDate: String,
        endDate: String,
        totalSessions: Long,
        packageValue: Long,
        paidAmount: Long,
        paymentMethod: String,
        cashAmount: Long,
        transferAmount: Long,
        paymentDate: String
    ): Result<Pair<MemberProfile, ContractRecord>> = runCatching {
        if (localDao != null) {
            val now = System.currentTimeMillis()
            val config = getOrCreateConfig()
            val newStt = when (serviceType) {
                "GYM" -> config.lastGymStt + 1L
                "YOGA" -> config.lastYogaStt + 1L
                "PT" -> config.lastPtStt + 1L
                else -> config.lastGymStt + 1L
            }
            val updatedConfig = when (serviceType) {
                "GYM" -> config.copy(lastGymStt = newStt)
                "YOGA" -> config.copy(lastYogaStt = newStt)
                "PT" -> config.copy(lastPtStt = newStt)
                else -> config.copy(lastGymStt = newStt)
            }
            val memberId = "mem_${UUID.randomUUID().toString().replace("-", "").take(16)}"
            val contractId = "con_${UUID.randomUUID().toString().replace("-", "").take(16)}"
            val contractCode = FitnessCalculator.buildContractCode(serviceType, newStt, 1L)

            val memberEntity = LocalMemberEntity(
                id = memberId,
                userId = "local_user",
                type = serviceType,
                stt = newStt,
                fullName = fullName.trim(),
                phone = phone.trim(),
                memberGroup = if (serviceType == "GYM") memberGroup else "NONE",
                nextContractSeq = 2L,
                isDeleted = false,
                deletedAtEpoch = 0L,
                deletedBatchId = "",
                createdAtEpoch = now,
                updatedAtEpoch = now
            )

            val contractEntity = LocalContractEntity(
                id = contractId,
                userId = "local_user",
                contractCode = contractCode,
                memberId = memberId,
                memberSttSnapshot = newStt,
                memberNameSnapshot = fullName.trim(),
                memberPhoneSnapshot = phone.trim(),
                serviceType = serviceType,
                isRenewal = false,
                memberGroup = if (serviceType == "GYM") memberGroup else "NONE",
                durationMonths = if (serviceType == "PT") 0L else durationMonths,
                startDate = startDate,
                endDate = if (serviceType == "PT") "" else endDate,
                totalSessions = if (serviceType == "PT") totalSessions else 0L,
                usedSessions = 0L,
                ptStatus = if (serviceType == "PT") "ACTIVE" else "NONE",
                packageValue = packageValue,
                paidAmount = paidAmount,
                paymentMethod = paymentMethod,
                cashAmount = cashAmount,
                transferAmount = transferAmount,
                paymentDate = paymentDate,
                isDeleted = false,
                deletedAtEpoch = 0L,
                deletedBatchId = "",
                createdAtEpoch = now,
                updatedAtEpoch = now
            )

            localDao.createMemberAndContractTransaction(
                updatedConfig = LocalStudioConfigEntity.fromDomain(updatedConfig, now),
                member = memberEntity,
                contract = contractEntity
            )
            return@runCatching memberEntity.toDomain() to contractEntity.toDomain()
        }

        val uid = requireRemoteUserId()
        val config = getOrCreateConfig()
        val newStt = when (serviceType) {
            "GYM" -> config.lastGymStt + 1L
            "YOGA" -> config.lastYogaStt + 1L
            "PT" -> config.lastPtStt + 1L
            else -> config.lastGymStt + 1L
        }

        val updatedConfig = when (serviceType) {
            "GYM" -> config.copy(lastGymStt = newStt)
            "YOGA" -> config.copy(lastYogaStt = newStt)
            "PT" -> config.copy(lastPtStt = newStt)
            else -> config.copy(lastGymStt = newStt)
        }
        saveStudioConfig(updatedConfig)

        val memberId = "mem_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val contractId = "con_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val contractCode = FitnessCalculator.buildContractCode(serviceType, newStt, 1L)

        val member = MemberProfile(
            id = memberId,
            userId = uid,
            type = serviceType,
            stt = newStt,
            fullName = fullName.trim(),
            phone = phone.trim(),
            memberGroup = if (serviceType == "GYM") memberGroup else "NONE",
            nextContractSeq = 2L,
            isDeleted = false,
            deletedAtEpoch = 0L,
            deletedBatchId = "",
            createdAt = null,
            updatedAt = null
        )

        val contract = ContractRecord(
            id = contractId,
            userId = uid,
            contractCode = contractCode,
            memberId = memberId,
            memberSttSnapshot = newStt,
            memberNameSnapshot = fullName.trim(),
            memberPhoneSnapshot = phone.trim(),
            serviceType = serviceType,
            isRenewal = false,
            memberGroup = if (serviceType == "GYM") memberGroup else "NONE",
            durationMonths = if (serviceType == "PT") 0L else durationMonths,
            startDate = startDate,
            endDate = if (serviceType == "PT") "" else endDate,
            totalSessions = if (serviceType == "PT") totalSessions else 0L,
            usedSessions = 0L,
            ptStatus = if (serviceType == "PT") "ACTIVE" else "NONE",
            packageValue = packageValue,
            paidAmount = paidAmount,
            paymentMethod = paymentMethod,
            cashAmount = cashAmount,
            transferAmount = transferAmount,
            paymentDate = paymentDate,
            isDeleted = false,
            deletedAtEpoch = 0L,
            deletedBatchId = "",
            createdAt = null,
            updatedAt = null
        )

        val memRef = membersCollection(uid).document(memberId)
        val conRef = contractsCollection(uid).document(contractId)
        try {
            memRef.set(member).await()
            conRef.set(contract).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, memRef.path)
            throw e
        }
        member to contract
    }

    suspend fun createRenewalContract(
        member: MemberProfile,
        memberGroup: String,
        durationMonths: Long,
        startDate: String,
        endDate: String,
        totalSessions: Long,
        packageValue: Long,
        paidAmount: Long,
        paymentMethod: String,
        cashAmount: Long,
        transferAmount: Long,
        paymentDate: String
    ): Result<ContractRecord> = runCatching {
        if (localDao != null) {
            val now = System.currentTimeMillis()
            val freshMemberEntity = localDao.getMemberById(member.id)
                ?: LocalMemberEntity.fromDomain(member, now)
            val seq = freshMemberEntity.nextContractSeq.coerceAtLeast(1L)
            val contractCode = FitnessCalculator.buildContractCode(freshMemberEntity.type, freshMemberEntity.stt, seq)
            val contractId = "con_${UUID.randomUUID().toString().replace("-", "").take(16)}"

            val updatedMemberEntity = freshMemberEntity.copy(
                memberGroup = if (freshMemberEntity.type == "GYM") memberGroup else freshMemberEntity.memberGroup,
                nextContractSeq = seq + 1L,
                updatedAtEpoch = now
            )

            val contractEntity = LocalContractEntity(
                id = contractId,
                userId = "local_user",
                contractCode = contractCode,
                memberId = freshMemberEntity.id,
                memberSttSnapshot = freshMemberEntity.stt,
                memberNameSnapshot = freshMemberEntity.fullName,
                memberPhoneSnapshot = freshMemberEntity.phone,
                serviceType = freshMemberEntity.type,
                isRenewal = seq > 1L,
                memberGroup = if (freshMemberEntity.type == "GYM") memberGroup else "NONE",
                durationMonths = if (freshMemberEntity.type == "PT") 0L else durationMonths,
                startDate = startDate,
                endDate = if (freshMemberEntity.type == "PT") "" else endDate,
                totalSessions = if (freshMemberEntity.type == "PT") totalSessions else 0L,
                usedSessions = 0L,
                ptStatus = if (freshMemberEntity.type == "PT") "ACTIVE" else "NONE",
                packageValue = packageValue,
                paidAmount = paidAmount,
                paymentMethod = paymentMethod,
                cashAmount = cashAmount,
                transferAmount = transferAmount,
                paymentDate = paymentDate,
                isDeleted = false,
                deletedAtEpoch = 0L,
                deletedBatchId = "",
                createdAtEpoch = now,
                updatedAtEpoch = now
            )

            localDao.createRenewalContractTransaction(updatedMemberEntity, contractEntity)
            return@runCatching contractEntity.toDomain()
        }

        val uid = requireRemoteUserId()
        val seq = member.nextContractSeq.coerceAtLeast(1L)
        val contractCode = FitnessCalculator.buildContractCode(member.type, member.stt, seq)
        val contractId = "con_${UUID.randomUUID().toString().replace("-", "").take(16)}"

        val contract = ContractRecord(
            id = contractId,
            userId = uid,
            contractCode = contractCode,
            memberId = member.id,
            memberSttSnapshot = member.stt,
            memberNameSnapshot = member.fullName,
            memberPhoneSnapshot = member.phone,
            serviceType = member.type,
            isRenewal = seq > 1L,
            memberGroup = if (member.type == "GYM") memberGroup else "NONE",
            durationMonths = if (member.type == "PT") 0L else durationMonths,
            startDate = startDate,
            endDate = if (member.type == "PT") "" else endDate,
            totalSessions = if (member.type == "PT") totalSessions else 0L,
            usedSessions = 0L,
            ptStatus = if (member.type == "PT") "ACTIVE" else "NONE",
            packageValue = packageValue,
            paidAmount = paidAmount,
            paymentMethod = paymentMethod,
            cashAmount = cashAmount,
            transferAmount = transferAmount,
            paymentDate = paymentDate,
            isDeleted = false,
            deletedAtEpoch = 0L,
            deletedBatchId = "",
            createdAt = null,
            updatedAt = null
        )

        val memRef = membersCollection(uid).document(member.id)
        val conRef = contractsCollection(uid).document(contractId)
        try {
            val freshSnap = memRef.get().await()
            val freshMember = freshSnap.toObject(
                MemberProfile::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: member
            memRef.set(
                freshMember.copy(
                    memberGroup = if (member.type == "GYM") memberGroup else freshMember.memberGroup,
                    nextContractSeq = seq + 1L,
                    createdAt = freshMember.createdAt ?: Timestamp.now(),
                    updatedAt = null
                )
            ).await()
            conRef.set(contract).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, conRef.path)
            throw e
        }
        contract
    }

    suspend fun updateMemberProfile(
        member: MemberProfile,
        newFullName: String,
        newPhone: String,
        newGroup: String
    ): Result<Unit> = runCatching {
        if (localDao != null) {
            val now = System.currentTimeMillis()
            val existing = localDao.getMemberById(member.id) ?: LocalMemberEntity.fromDomain(member, now)
            localDao.upsertMember(
                existing.copy(
                    fullName = newFullName.trim(),
                    phone = newPhone.trim(),
                    memberGroup = if (existing.type == "GYM") newGroup else "NONE",
                    updatedAtEpoch = now
                )
            )
            return@runCatching
        }

        val uid = requireRemoteUserId()
        val memRef = membersCollection(uid).document(member.id)
        try {
            val snap = memRef.get().await()
            val current = snap.toObject(
                MemberProfile::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: member
            memRef.set(
                current.copy(
                    fullName = newFullName.trim(),
                    phone = newPhone.trim(),
                    memberGroup = if (current.type == "GYM") newGroup else "NONE",
                    createdAt = current.createdAt ?: Timestamp.now(),
                    updatedAt = null
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, memRef.path)
            throw e
        }
    }

    suspend fun updateContractRecord(updated: ContractRecord): Result<Unit> = runCatching {
        if (localDao != null) {
            val now = System.currentTimeMillis()
            val current = localDao.getContractById(updated.id) ?: LocalContractEntity.fromDomain(updated, now)
            val recalculatedPtStatus = if (current.serviceType == "PT") {
                if (updated.usedSessions >= updated.totalSessions && updated.totalSessions > 0L) {
                    "COMPLETED"
                } else {
                    "ACTIVE"
                }
            } else {
                "NONE"
            }
            val entity = LocalContractEntity.fromDomain(updated, now).copy(
                id = current.id,
                contractCode = current.contractCode,
                memberId = current.memberId,
                serviceType = current.serviceType,
                ptStatus = recalculatedPtStatus,
                createdAtEpoch = current.createdAtEpoch,
                updatedAtEpoch = now
            )
            localDao.upsertContract(entity)
            return@runCatching
        }

        val uid = requireRemoteUserId()
        val conRef = contractsCollection(uid).document(updated.id)
        try {
            val snap = conRef.get().await()
            val current = snap.toObject(
                ContractRecord::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: updated
            val recalculatedPtStatus = if (current.serviceType == "PT") {
                if (updated.usedSessions >= updated.totalSessions && updated.totalSessions > 0L) {
                    "COMPLETED"
                } else {
                    "ACTIVE"
                }
            } else {
                "NONE"
            }
            conRef.set(
                updated.copy(
                    userId = uid,
                    contractCode = current.contractCode,
                    memberId = current.memberId,
                    serviceType = current.serviceType,
                    ptStatus = recalculatedPtStatus,
                    createdAt = current.createdAt ?: Timestamp.now(),
                    updatedAt = null
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, conRef.path)
            throw e
        }
    }

    suspend fun recordPtSession(
        member: MemberProfile,
        contract: ContractRecord,
        sessionDate: String,
        note: String
    ): Result<PtSessionRecord> = runCatching {
        if (localDao != null) {
            val now = System.currentTimeMillis()
            val sessionId = "pts_${UUID.randomUUID().toString().replace("-", "").take(16)}"
            val sessionEntity = LocalPtSessionEntity(
                id = sessionId,
                userId = "local_user",
                contractId = contract.id,
                memberId = member.id,
                memberSttSnapshot = member.stt,
                memberNameSnapshot = member.fullName,
                contractCodeSnapshot = contract.contractCode,
                sessionDate = sessionDate,
                note = note.trim(),
                isDeleted = false,
                deletedAtEpoch = 0L,
                deletedBatchId = "",
                createdAtEpoch = now,
                updatedAtEpoch = now
            )
            val freshContract = localDao.getContractById(contract.id) ?: LocalContractEntity.fromDomain(contract, now)
            val newUsed = freshContract.usedSessions + 1L
            val newStatus = if (newUsed >= freshContract.totalSessions) "COMPLETED" else "ACTIVE"
            val updatedContract = freshContract.copy(
                usedSessions = newUsed,
                ptStatus = newStatus,
                updatedAtEpoch = now
            )
            localDao.recordPtSessionTransaction(sessionEntity, updatedContract)
            return@runCatching sessionEntity.toDomain()
        }

        val uid = requireRemoteUserId()
        val sessionId = "pts_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val session = PtSessionRecord(
            id = sessionId,
            userId = uid,
            contractId = contract.id,
            memberId = member.id,
            memberSttSnapshot = member.stt,
            memberNameSnapshot = member.fullName,
            contractCodeSnapshot = contract.contractCode,
            sessionDate = sessionDate,
            note = note.trim(),
            isDeleted = false,
            deletedAtEpoch = 0L,
            deletedBatchId = "",
            createdAt = null,
            updatedAt = null
        )

        val sesRef = ptSessionsCollection(uid).document(sessionId)
        val conRef = contractsCollection(uid).document(contract.id)
        try {
            sesRef.set(session).await()
            val snap = conRef.get().await()
            val freshContract = snap.toObject(
                ContractRecord::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: contract
            val newUsed = freshContract.usedSessions + 1L
            val newStatus = if (newUsed >= freshContract.totalSessions) "COMPLETED" else "ACTIVE"
            conRef.set(
                freshContract.copy(
                    usedSessions = newUsed,
                    ptStatus = newStatus,
                    createdAt = freshContract.createdAt ?: Timestamp.now(),
                    updatedAt = null
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, sesRef.path)
            throw e
        }
        session
    }

    suspend fun updatePtSession(
        session: PtSessionRecord,
        newDate: String,
        newNote: String
    ): Result<Unit> = runCatching {
        if (localDao != null) {
            val now = System.currentTimeMillis()
            val current = localDao.getPtSessionById(session.id) ?: LocalPtSessionEntity.fromDomain(session, now)
            localDao.upsertPtSession(
                current.copy(
                    sessionDate = newDate,
                    note = newNote.trim(),
                    updatedAtEpoch = now
                )
            )
            return@runCatching
        }

        val uid = requireRemoteUserId()
        val sesRef = ptSessionsCollection(uid).document(session.id)
        try {
            val snap = sesRef.get().await()
            val current = snap.toObject(
                PtSessionRecord::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: session
            sesRef.set(
                current.copy(
                    sessionDate = newDate,
                    note = newNote.trim(),
                    createdAt = current.createdAt ?: Timestamp.now(),
                    updatedAt = null
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, sesRef.path)
            throw e
        }
    }

    suspend fun createSingleTicket(
        ticketType: String,
        saleDate: String,
        quantity: Long,
        unitPrice: Long,
        paymentMethod: String,
        cashAmount: Long,
        transferAmount: Long
    ): Result<SingleTicketRecord> = runCatching {
        if (localDao != null) {
            val now = System.currentTimeMillis()
            val ticketId = "tkt_${UUID.randomUUID().toString().replace("-", "").take(16)}"
            val total = quantity * unitPrice
            val entity = LocalSingleTicketEntity(
                id = ticketId,
                userId = "local_user",
                ticketType = ticketType,
                saleDate = saleDate,
                quantity = quantity,
                unitPrice = unitPrice,
                totalAmount = total,
                paymentMethod = paymentMethod,
                cashAmount = cashAmount,
                transferAmount = transferAmount,
                isDeleted = false,
                deletedAtEpoch = 0L,
                deletedBatchId = "",
                createdAtEpoch = now,
                updatedAtEpoch = now
            )
            localDao.upsertSingleTicket(entity)
            return@runCatching entity.toDomain()
        }

        val uid = requireRemoteUserId()
        val ticketId = "tkt_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val total = quantity * unitPrice
        val record = SingleTicketRecord(
            id = ticketId,
            userId = uid,
            ticketType = ticketType,
            saleDate = saleDate,
            quantity = quantity,
            unitPrice = unitPrice,
            totalAmount = total,
            paymentMethod = paymentMethod,
            cashAmount = cashAmount,
            transferAmount = transferAmount,
            isDeleted = false,
            deletedAtEpoch = 0L,
            deletedBatchId = "",
            createdAt = null,
            updatedAt = null
        )
        val ref = singleTicketsCollection(uid).document(ticketId)
        try {
            ref.set(record).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, ref.path)
            throw e
        }
        record
    }

    suspend fun softDeleteMemberCascade(
        member: MemberProfile,
        relatedContracts: List<ContractRecord>,
        relatedSessions: List<PtSessionRecord>
    ): Result<Unit> = runCatching {
        val nowEpoch = System.currentTimeMillis()
        val batchId = "del_${UUID.randomUUID().toString().replace("-", "").take(12)}"

        if (localDao != null) {
            val existingMember = localDao.getMemberById(member.id) ?: LocalMemberEntity.fromDomain(member, nowEpoch)
            val updatedMember = existingMember.copy(
                isDeleted = true,
                deletedAtEpoch = nowEpoch,
                deletedBatchId = batchId,
                updatedAtEpoch = nowEpoch
            )
            val updatedContracts = relatedContracts.filter { !it.isDeleted }.map { c ->
                val existingC = localDao.getContractById(c.id) ?: LocalContractEntity.fromDomain(c, nowEpoch)
                existingC.copy(
                    isDeleted = true,
                    deletedAtEpoch = nowEpoch,
                    deletedBatchId = batchId,
                    updatedAtEpoch = nowEpoch
                )
            }
            val updatedSessions = relatedSessions.filter { !it.isDeleted }.map { s ->
                val existingS = localDao.getPtSessionById(s.id) ?: LocalPtSessionEntity.fromDomain(s, nowEpoch)
                existingS.copy(
                    isDeleted = true,
                    deletedAtEpoch = nowEpoch,
                    deletedBatchId = batchId,
                    updatedAtEpoch = nowEpoch
                )
            }
            localDao.softDeleteMemberCascadeTransaction(updatedMember, updatedContracts, updatedSessions)
            return@runCatching
        }

        val uid = requireRemoteUserId()
        val memRef = membersCollection(uid).document(member.id)
        try {
            val snap = memRef.get().await()
            val freshMem = snap.toObject(
                MemberProfile::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: member
            memRef.set(
                freshMem.copy(
                    isDeleted = true,
                    deletedAtEpoch = nowEpoch,
                    deletedBatchId = batchId,
                    createdAt = freshMem.createdAt ?: Timestamp.now(),
                    updatedAt = null
                )
            ).await()

            for (c in relatedContracts.filter { !it.isDeleted }) {
                val cRef = contractsCollection(uid).document(c.id)
                val cSnap = cRef.get().await()
                val freshC = cSnap.toObject(
                    ContractRecord::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ) ?: c
                cRef.set(
                    freshC.copy(
                        isDeleted = true,
                        deletedAtEpoch = nowEpoch,
                        deletedBatchId = batchId,
                        createdAt = freshC.createdAt ?: Timestamp.now(),
                        updatedAt = null
                    )
                ).await()
            }

            for (s in relatedSessions.filter { !it.isDeleted }) {
                val sRef = ptSessionsCollection(uid).document(s.id)
                val sSnap = sRef.get().await()
                val freshS = sSnap.toObject(
                    PtSessionRecord::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ) ?: s
                sRef.set(
                    freshS.copy(
                        isDeleted = true,
                        deletedAtEpoch = nowEpoch,
                        deletedBatchId = batchId,
                        createdAt = freshS.createdAt ?: Timestamp.now(),
                        updatedAt = null
                    )
                ).await()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, memRef.path)
            throw e
        }
    }

    suspend fun softDeleteContract(
        contract: ContractRecord,
        relatedSessions: List<PtSessionRecord>
    ): Result<Unit> = runCatching {
        val nowEpoch = System.currentTimeMillis()
        val batchId = "delc_${UUID.randomUUID().toString().replace("-", "").take(12)}"

        if (localDao != null) {
            val existingC = localDao.getContractById(contract.id) ?: LocalContractEntity.fromDomain(contract, nowEpoch)
            localDao.upsertContract(
                existingC.copy(
                    isDeleted = true,
                    deletedAtEpoch = nowEpoch,
                    deletedBatchId = batchId,
                    updatedAtEpoch = nowEpoch
                )
            )
            val sessionsToUpdate = relatedSessions.filter { !it.isDeleted && it.contractId == contract.id }.map { s ->
                val existingS = localDao.getPtSessionById(s.id) ?: LocalPtSessionEntity.fromDomain(s, nowEpoch)
                existingS.copy(
                    isDeleted = true,
                    deletedAtEpoch = nowEpoch,
                    deletedBatchId = batchId,
                    updatedAtEpoch = nowEpoch
                )
            }
            if (sessionsToUpdate.isNotEmpty()) {
                localDao.upsertPtSessions(sessionsToUpdate)
            }
            return@runCatching
        }

        val uid = requireRemoteUserId()
        val cRef = contractsCollection(uid).document(contract.id)
        try {
            val cSnap = cRef.get().await()
            val freshC = cSnap.toObject(
                ContractRecord::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: contract
            cRef.set(
                freshC.copy(
                    isDeleted = true,
                    deletedAtEpoch = nowEpoch,
                    deletedBatchId = batchId,
                    createdAt = freshC.createdAt ?: Timestamp.now(),
                    updatedAt = null
                )
            ).await()

            for (s in relatedSessions.filter { !it.isDeleted && it.contractId == contract.id }) {
                val sRef = ptSessionsCollection(uid).document(s.id)
                val sSnap = sRef.get().await()
                val freshS = sSnap.toObject(
                    PtSessionRecord::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ) ?: s
                sRef.set(
                    freshS.copy(
                        isDeleted = true,
                        deletedAtEpoch = nowEpoch,
                        deletedBatchId = batchId,
                        createdAt = freshS.createdAt ?: Timestamp.now(),
                        updatedAt = null
                    )
                ).await()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, cRef.path)
            throw e
        }
    }

    suspend fun softDeletePtSession(
        session: PtSessionRecord,
        parentContract: ContractRecord?
    ): Result<Unit> = runCatching {
        val nowEpoch = System.currentTimeMillis()
        if (localDao != null) {
            val existingS = localDao.getPtSessionById(session.id) ?: LocalPtSessionEntity.fromDomain(session, nowEpoch)
            localDao.upsertPtSession(
                existingS.copy(
                    isDeleted = true,
                    deletedAtEpoch = nowEpoch,
                    deletedBatchId = "dels_${session.id}",
                    updatedAtEpoch = nowEpoch
                )
            )
            if (parentContract != null) {
                val existingC = localDao.getContractById(parentContract.id)
                    ?: LocalContractEntity.fromDomain(parentContract, nowEpoch)
                val newUsed = (existingC.usedSessions - 1L).coerceAtLeast(0L)
                val newStatus = if (newUsed >= existingC.totalSessions && existingC.totalSessions > 0L) {
                    "COMPLETED"
                } else {
                    "ACTIVE"
                }
                localDao.upsertContract(
                    existingC.copy(
                        usedSessions = newUsed,
                        ptStatus = newStatus,
                        updatedAtEpoch = nowEpoch
                    )
                )
            }
            return@runCatching
        }

        val uid = requireRemoteUserId()
        val sRef = ptSessionsCollection(uid).document(session.id)
        try {
            val sSnap = sRef.get().await()
            val freshS = sSnap.toObject(
                PtSessionRecord::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: session
            sRef.set(
                freshS.copy(
                    isDeleted = true,
                    deletedAtEpoch = nowEpoch,
                    deletedBatchId = "dels_${session.id}",
                    createdAt = freshS.createdAt ?: Timestamp.now(),
                    updatedAt = null
                )
            ).await()

            if (parentContract != null) {
                val cRef = contractsCollection(uid).document(parentContract.id)
                val cSnap = cRef.get().await()
                val freshC = cSnap.toObject(
                    ContractRecord::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ) ?: parentContract
                val newUsed = (freshC.usedSessions - 1L).coerceAtLeast(0L)
                val newStatus = if (newUsed >= freshC.totalSessions && freshC.totalSessions > 0L) {
                    "COMPLETED"
                } else {
                    "ACTIVE"
                }
                cRef.set(
                    freshC.copy(
                        usedSessions = newUsed,
                        ptStatus = newStatus,
                        createdAt = freshC.createdAt ?: Timestamp.now(),
                        updatedAt = null
                    )
                ).await()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, sRef.path)
            throw e
        }
    }

    suspend fun softDeleteSingleTicket(ticket: SingleTicketRecord): Result<Unit> = runCatching {
        val nowEpoch = System.currentTimeMillis()
        if (localDao != null) {
            val existing = localDao.getSingleTicketById(ticket.id) ?: LocalSingleTicketEntity.fromDomain(ticket, nowEpoch)
            localDao.upsertSingleTicket(
                existing.copy(
                    isDeleted = true,
                    deletedAtEpoch = nowEpoch,
                    deletedBatchId = "delt_${ticket.id}",
                    updatedAtEpoch = nowEpoch
                )
            )
            return@runCatching
        }

        val uid = requireRemoteUserId()
        val tRef = singleTicketsCollection(uid).document(ticket.id)
        try {
            val snap = tRef.get().await()
            val fresh = snap.toObject(
                SingleTicketRecord::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: ticket
            tRef.set(
                fresh.copy(
                    isDeleted = true,
                    deletedAtEpoch = nowEpoch,
                    deletedBatchId = "delt_${ticket.id}",
                    createdAt = fresh.createdAt ?: Timestamp.now(),
                    updatedAt = null
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, tRef.path)
            throw e
        }
    }

    suspend fun restoreMemberCascade(
        member: MemberProfile,
        allContracts: List<ContractRecord>,
        allSessions: List<PtSessionRecord>
    ): Result<Unit> = runCatching {
        val now = System.currentTimeMillis()
        val batchId = member.deletedBatchId
        if (localDao != null) {
            val existingM = localDao.getMemberById(member.id) ?: LocalMemberEntity.fromDomain(member, now)
            localDao.upsertMember(
                existingM.copy(
                    isDeleted = false,
                    deletedAtEpoch = 0L,
                    deletedBatchId = "",
                    updatedAtEpoch = now
                )
            )
            if (batchId.isNotBlank()) {
                val restoredContracts = allContracts.filter { it.isDeleted && it.deletedBatchId == batchId }.map { c ->
                    val existingC = localDao.getContractById(c.id) ?: LocalContractEntity.fromDomain(c, now)
                    existingC.copy(
                        isDeleted = false,
                        deletedAtEpoch = 0L,
                        deletedBatchId = "",
                        updatedAtEpoch = now
                    )
                }
                if (restoredContracts.isNotEmpty()) localDao.upsertContracts(restoredContracts)

                val restoredSessions = allSessions.filter { it.isDeleted && it.deletedBatchId == batchId }.map { s ->
                    val existingS = localDao.getPtSessionById(s.id) ?: LocalPtSessionEntity.fromDomain(s, now)
                    existingS.copy(
                        isDeleted = false,
                        deletedAtEpoch = 0L,
                        deletedBatchId = "",
                        updatedAtEpoch = now
                    )
                }
                if (restoredSessions.isNotEmpty()) localDao.upsertPtSessions(restoredSessions)
            }
            return@runCatching
        }

        val uid = requireRemoteUserId()
        val memRef = membersCollection(uid).document(member.id)
        try {
            val snap = memRef.get().await()
            val freshMem = snap.toObject(
                MemberProfile::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: member
            memRef.set(
                freshMem.copy(
                    isDeleted = false,
                    deletedAtEpoch = 0L,
                    deletedBatchId = "",
                    createdAt = freshMem.createdAt ?: Timestamp.now(),
                    updatedAt = null
                )
            ).await()

            if (batchId.isNotBlank()) {
                for (c in allContracts.filter { it.isDeleted && it.deletedBatchId == batchId }) {
                    val cRef = contractsCollection(uid).document(c.id)
                    val cSnap = cRef.get().await()
                    val freshC = cSnap.toObject(
                        ContractRecord::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ) ?: c
                    cRef.set(
                        freshC.copy(
                            isDeleted = false,
                            deletedAtEpoch = 0L,
                            deletedBatchId = "",
                            createdAt = freshC.createdAt ?: Timestamp.now(),
                            updatedAt = null
                        )
                    ).await()
                }
                for (s in allSessions.filter { it.isDeleted && it.deletedBatchId == batchId }) {
                    val sRef = ptSessionsCollection(uid).document(s.id)
                    val sSnap = sRef.get().await()
                    val freshS = sSnap.toObject(
                        PtSessionRecord::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ) ?: s
                    sRef.set(
                        freshS.copy(
                            isDeleted = false,
                            deletedAtEpoch = 0L,
                            deletedBatchId = "",
                            createdAt = freshS.createdAt ?: Timestamp.now(),
                            updatedAt = null
                        )
                    ).await()
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, memRef.path)
            throw e
        }
    }

    suspend fun restoreContractWithParentCheck(
        contract: ContractRecord,
        parentMember: MemberProfile?,
        allSessions: List<PtSessionRecord>
    ): Result<Unit> = runCatching {
        val now = System.currentTimeMillis()
        if (localDao != null) {
            if (parentMember != null && parentMember.isDeleted) {
                val existingM = localDao.getMemberById(parentMember.id)
                    ?: LocalMemberEntity.fromDomain(parentMember, now)
                localDao.upsertMember(
                    existingM.copy(
                        isDeleted = false,
                        deletedAtEpoch = 0L,
                        deletedBatchId = "",
                        updatedAtEpoch = now
                    )
                )
            }
            val existingC = localDao.getContractById(contract.id) ?: LocalContractEntity.fromDomain(contract, now)
            localDao.upsertContract(
                existingC.copy(
                    isDeleted = false,
                    deletedAtEpoch = 0L,
                    deletedBatchId = "",
                    updatedAtEpoch = now
                )
            )
            val batchId = contract.deletedBatchId
            if (batchId.isNotBlank()) {
                val restoredSessions = allSessions.filter {
                    it.isDeleted && it.contractId == contract.id && it.deletedBatchId == batchId
                }.map { s ->
                    val existingS = localDao.getPtSessionById(s.id) ?: LocalPtSessionEntity.fromDomain(s, now)
                    existingS.copy(
                        isDeleted = false,
                        deletedAtEpoch = 0L,
                        deletedBatchId = "",
                        updatedAtEpoch = now
                    )
                }
                if (restoredSessions.isNotEmpty()) localDao.upsertPtSessions(restoredSessions)
            }
            return@runCatching
        }

        val uid = requireRemoteUserId()
        val cRef = contractsCollection(uid).document(contract.id)
        try {
            if (parentMember != null && parentMember.isDeleted) {
                val memRef = membersCollection(uid).document(parentMember.id)
                val mSnap = memRef.get().await()
                val freshM = mSnap.toObject(
                    MemberProfile::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ) ?: parentMember
                memRef.set(
                    freshM.copy(
                        isDeleted = false,
                        deletedAtEpoch = 0L,
                        deletedBatchId = "",
                        createdAt = freshM.createdAt ?: Timestamp.now(),
                        updatedAt = null
                    )
                ).await()
            }

            val cSnap = cRef.get().await()
            val freshC = cSnap.toObject(
                ContractRecord::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: contract
            cRef.set(
                freshC.copy(
                    isDeleted = false,
                    deletedAtEpoch = 0L,
                    deletedBatchId = "",
                    createdAt = freshC.createdAt ?: Timestamp.now(),
                    updatedAt = null
                )
            ).await()

            val batchId = contract.deletedBatchId
            if (batchId.isNotBlank()) {
                for (s in allSessions.filter { it.isDeleted && it.contractId == contract.id && it.deletedBatchId == batchId }) {
                    val sRef = ptSessionsCollection(uid).document(s.id)
                    val sSnap = sRef.get().await()
                    val freshS = sSnap.toObject(
                        PtSessionRecord::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ) ?: s
                    sRef.set(
                        freshS.copy(
                            isDeleted = false,
                            deletedAtEpoch = 0L,
                            deletedBatchId = "",
                            createdAt = freshS.createdAt ?: Timestamp.now(),
                            updatedAt = null
                        )
                    ).await()
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, cRef.path)
            throw e
        }
    }

    suspend fun restorePtSession(
        session: PtSessionRecord,
        parentContract: ContractRecord?
    ): Result<Unit> = runCatching {
        val now = System.currentTimeMillis()
        if (localDao != null) {
            val existingS = localDao.getPtSessionById(session.id) ?: LocalPtSessionEntity.fromDomain(session, now)
            localDao.upsertPtSession(
                existingS.copy(
                    isDeleted = false,
                    deletedAtEpoch = 0L,
                    deletedBatchId = "",
                    updatedAtEpoch = now
                )
            )
            if (parentContract != null) {
                val existingC = localDao.getContractById(parentContract.id)
                    ?: LocalContractEntity.fromDomain(parentContract, now)
                val newUsed = existingC.usedSessions + 1L
                val newStatus = if (newUsed >= existingC.totalSessions && existingC.totalSessions > 0L) {
                    "COMPLETED"
                } else {
                    "ACTIVE"
                }
                localDao.upsertContract(
                    existingC.copy(
                        usedSessions = newUsed,
                        ptStatus = newStatus,
                        updatedAtEpoch = now
                    )
                )
            }
            return@runCatching
        }

        val uid = requireRemoteUserId()
        val sRef = ptSessionsCollection(uid).document(session.id)
        try {
            val sSnap = sRef.get().await()
            val freshS = sSnap.toObject(
                PtSessionRecord::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: session
            sRef.set(
                freshS.copy(
                    isDeleted = false,
                    deletedAtEpoch = 0L,
                    deletedBatchId = "",
                    createdAt = freshS.createdAt ?: Timestamp.now(),
                    updatedAt = null
                )
            ).await()

            if (parentContract != null) {
                val cRef = contractsCollection(uid).document(parentContract.id)
                val cSnap = cRef.get().await()
                val freshC = cSnap.toObject(
                    ContractRecord::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ) ?: parentContract
                val newUsed = freshC.usedSessions + 1L
                val newStatus = if (newUsed >= freshC.totalSessions && freshC.totalSessions > 0L) {
                    "COMPLETED"
                } else {
                    "ACTIVE"
                }
                cRef.set(
                    freshC.copy(
                        usedSessions = newUsed,
                        ptStatus = newStatus,
                        createdAt = freshC.createdAt ?: Timestamp.now(),
                        updatedAt = null
                    )
                ).await()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, sRef.path)
            throw e
        }
    }

    suspend fun restoreSingleTicket(ticket: SingleTicketRecord): Result<Unit> = runCatching {
        val now = System.currentTimeMillis()
        if (localDao != null) {
            val existing = localDao.getSingleTicketById(ticket.id) ?: LocalSingleTicketEntity.fromDomain(ticket, now)
            localDao.upsertSingleTicket(
                existing.copy(
                    isDeleted = false,
                    deletedAtEpoch = 0L,
                    deletedBatchId = "",
                    updatedAtEpoch = now
                )
            )
            return@runCatching
        }

        val uid = requireRemoteUserId()
        val tRef = singleTicketsCollection(uid).document(ticket.id)
        try {
            val snap = tRef.get().await()
            val fresh = snap.toObject(
                SingleTicketRecord::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: ticket
            tRef.set(
                fresh.copy(
                    isDeleted = false,
                    deletedAtEpoch = 0L,
                    deletedBatchId = "",
                    createdAt = fresh.createdAt ?: Timestamp.now(),
                    updatedAt = null
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, tRef.path)
            throw e
        }
    }

    suspend fun permanentDeleteMember(
        memberId: String,
        relatedContracts: List<ContractRecord>,
        relatedSessions: List<PtSessionRecord>
    ): Result<Unit> = runCatching {
        if (localDao != null) {
            localDao.permanentDeleteMemberCascadeTransaction(
                memberId = memberId,
                contractIds = relatedContracts.filter { it.memberId == memberId }.map { it.id },
                sessionIds = relatedSessions.filter { it.memberId == memberId }.map { it.id }
            )
            return@runCatching
        }

        val uid = requireRemoteUserId()
        val memRef = membersCollection(uid).document(memberId)
        try {
            for (s in relatedSessions.filter { it.memberId == memberId }) {
                ptSessionsCollection(uid).document(s.id).delete().await()
            }
            for (c in relatedContracts.filter { it.memberId == memberId }) {
                contractsCollection(uid).document(c.id).delete().await()
            }
            memRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, memRef.path)
            throw e
        }
    }

    suspend fun permanentDeleteContract(
        contractId: String,
        relatedSessions: List<PtSessionRecord>
    ): Result<Unit> = runCatching {
        if (localDao != null) {
            relatedSessions.filter { it.contractId == contractId }.forEach {
                localDao.deletePtSessionById(it.id)
            }
            localDao.deleteContractById(contractId)
            return@runCatching
        }

        val uid = requireRemoteUserId()
        val cRef = contractsCollection(uid).document(contractId)
        try {
            for (s in relatedSessions.filter { it.contractId == contractId }) {
                ptSessionsCollection(uid).document(s.id).delete().await()
            }
            cRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, cRef.path)
            throw e
        }
    }

    suspend fun permanentDeletePtSession(sessionId: String): Result<Unit> = runCatching {
        if (localDao != null) {
            localDao.deletePtSessionById(sessionId)
            return@runCatching
        }

        val uid = requireRemoteUserId()
        val sRef = ptSessionsCollection(uid).document(sessionId)
        try {
            sRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, sRef.path)
            throw e
        }
    }

    suspend fun permanentDeleteSingleTicket(ticketId: String): Result<Unit> = runCatching {
        if (localDao != null) {
            localDao.deleteSingleTicketById(ticketId)
            return@runCatching
        }

        val uid = requireRemoteUserId()
        val tRef = singleTicketsCollection(uid).document(ticketId)
        try {
            tRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, tRef.path)
            throw e
        }
    }

    // =========================================================================================
    // BACKUP & RESTORE (Local Single Source of Truth + Integrity Verification + Optional Cloud)
    // =========================================================================================

    /**
     * Tạo gói sao lưu từ cơ sở dữ liệu Local (Single Source of Truth) và kiểm tra tính toàn vẹn.
     */
    suspend fun buildLocalBackupBundle(): Result<BackupBundle> = runCatching {
        if (localDao != null) {
            val config = getOrCreateConfig()
            val members = localDao.getAllMembersOnce().map { it.toDomain() }
            val contracts = localDao.getAllContractsOnce().map { it.toDomain() }
            val sessions = localDao.getAllPtSessionsOnce().map { it.toDomain() }
            val tickets = localDao.getAllSingleTicketsOnce().map { it.toDomain() }
            val bundle = BackupBundle(
                exportedAtEpoch = System.currentTimeMillis(),
                config = config,
                members = members,
                contracts = contracts,
                ptSessions = sessions,
                singleTickets = tickets
            )
            bundle.validateIntegrity().getOrThrow()
            return@runCatching bundle
        } else {
            throw IllegalStateException("Local database is required for buildLocalBackupBundle")
        }
    }

    /**
     * Khôi phục dữ liệu từ gói sao lưu (file .json hoặc Cloud) về cơ sở dữ liệu Local
     * sau khi kiểm tra tính toàn vẹn.
     */
    suspend fun restoreFromBackupBundle(bundle: BackupBundle): Result<Unit> = runCatching {
        bundle.validateIntegrity().getOrThrow()
        val now = System.currentTimeMillis()

        if (localDao != null) {
            val currentConfig = getOrCreateConfig()
            val maxGymSttInBundle = bundle.members.filter { it.type == "GYM" }.maxOfOrNull { it.stt } ?: 0L
            val maxYogaSttInBundle = bundle.members.filter { it.type == "YOGA" }.maxOfOrNull { it.stt } ?: 0L
            val maxPtSttInBundle = bundle.members.filter { it.type == "PT" }.maxOfOrNull { it.stt } ?: 0L

            val mergedConfig = bundle.config.copy(
                id = "main_config",
                userId = "local_user",
                lastGymStt = maxOf(currentConfig.lastGymStt, bundle.config.lastGymStt, maxGymSttInBundle),
                lastYogaStt = maxOf(currentConfig.lastYogaStt, bundle.config.lastYogaStt, maxYogaSttInBundle),
                lastPtStt = maxOf(currentConfig.lastPtStt, bundle.config.lastPtStt, maxPtSttInBundle),
                lastSyncEpoch = now
            )
            localDao.upsertConfig(LocalStudioConfigEntity.fromDomain(mergedConfig, now))

            val memberEntities = bundle.members.map { m ->
                val docId = m.id.ifBlank { "mem_${UUID.randomUUID().toString().replace("-", "").take(16)}" }
                val existing = localDao.getMemberById(docId)
                LocalMemberEntity.fromDomain(
                    m.copy(
                        id = docId,
                        userId = "local_user",
                        type = existing?.type ?: m.type,
                        stt = existing?.stt ?: m.stt
                    ),
                    now
                )
            }
            if (memberEntities.isNotEmpty()) localDao.upsertMembers(memberEntities)

            val contractEntities = bundle.contracts.map { c ->
                val docId = c.id.ifBlank { "con_${UUID.randomUUID().toString().replace("-", "").take(16)}" }
                LocalContractEntity.fromDomain(c.copy(id = docId, userId = "local_user"), now)
            }
            if (contractEntities.isNotEmpty()) localDao.upsertContracts(contractEntities)

            val sessionEntities = bundle.ptSessions.map { s ->
                val docId = s.id.ifBlank { "pts_${UUID.randomUUID().toString().replace("-", "").take(16)}" }
                LocalPtSessionEntity.fromDomain(s.copy(id = docId, userId = "local_user"), now)
            }
            if (sessionEntities.isNotEmpty()) localDao.upsertPtSessions(sessionEntities)

            val ticketEntities = bundle.singleTickets.map { t ->
                val docId = t.id.ifBlank { "tkt_${UUID.randomUUID().toString().replace("-", "").take(16)}" }
                LocalSingleTicketEntity.fromDomain(t.copy(id = docId, userId = "local_user"), now)
            }
            if (ticketEntities.isNotEmpty()) localDao.upsertSingleTickets(ticketEntities)
            return@runCatching
        }

        // Chế độ remote-only (dùng trong test emulator)
        val uid = requireRemoteUserId()
        val currentConfig = getOrCreateConfig()
        val mergedConfig = bundle.config.copy(
            id = "main_config",
            userId = uid,
            lastGymStt = maxOf(currentConfig.lastGymStt, bundle.config.lastGymStt),
            lastYogaStt = maxOf(currentConfig.lastYogaStt, bundle.config.lastYogaStt),
            lastPtStt = maxOf(currentConfig.lastPtStt, bundle.config.lastPtStt),
            lastSyncEpoch = now
        )
        saveStudioConfig(mergedConfig)
        uploadBundleToFirestore(uid, bundle.copy(config = mergedConfig))
    }

    /**
     * Sao lưu chủ động dữ liệu từ Local Room Database lên tài khoản Google Cloud (Firestore).
     * Chỉ thực thi khi người dùng bấm nút Sao lưu Cloud trong Cài đặt.
     */
    suspend fun backupLocalToCloud(): Result<BackupBundle> = runCatching {
        val uid = requireRemoteUserId()
        val localBundle = buildLocalBackupBundle().getOrThrow()
        val syncEpoch = System.currentTimeMillis()
        val syncedConfig = localBundle.config.copy(
            id = "main_config",
            userId = uid,
            lastSyncEpoch = syncEpoch
        )
        val bundleToUpload = localBundle.copy(config = syncedConfig)
        uploadBundleToFirestore(uid, bundleToUpload)
        saveStudioConfig(syncedConfig.copy(userId = "local_user"))
        bundleToUpload
    }

    /**
     * Tải bản sao lưu từ tài khoản Google Cloud (Firestore) và kiểm tra tính toàn vẹn
     * trước khi hiển thị hộp thoại xác nhận khôi phục về Local Database.
     */
    suspend fun fetchCloudBackupBundle(): Result<BackupBundle> = runCatching {
        val uid = requireRemoteUserId()
        val configSnap = settingsCollection(uid).document("main_config").get().await()
        val cloudConfig = if (configSnap.exists()) {
            configSnap.toObject(
                StudioConfig::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: StudioConfig(userId = uid)
        } else {
            StudioConfig(userId = uid)
        }

        val members = membersCollection(uid)
            .whereEqualTo("userId", uid)
            .get().await()
            .toObjects(MemberProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)

        val contracts = contractsCollection(uid)
            .whereEqualTo("userId", uid)
            .get().await()
            .toObjects(ContractRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)

        val ptSessions = ptSessionsCollection(uid)
            .whereEqualTo("userId", uid)
            .get().await()
            .toObjects(PtSessionRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)

        val singleTickets = singleTicketsCollection(uid)
            .whereEqualTo("userId", uid)
            .get().await()
            .toObjects(SingleTicketRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)

        val bundle = BackupBundle(
            exportedAtEpoch = System.currentTimeMillis(),
            config = cloudConfig,
            members = members,
            contracts = contracts,
            ptSessions = ptSessions,
            singleTickets = singleTickets
        )
        bundle.validateIntegrity().getOrThrow()
        bundle
    }

    private suspend fun uploadBundleToFirestore(uid: String, bundle: BackupBundle) {
        val cfgRef = settingsCollection(uid).document("main_config")
        val cfgSnap = cfgRef.get().await()
        if (cfgSnap.exists()) {
            val existingCfg = cfgSnap.toObject(
                StudioConfig::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            )
            cfgRef.set(
                bundle.config.copy(
                    id = "main_config",
                    userId = uid,
                    createdAt = existingCfg?.createdAt ?: Timestamp.now(),
                    updatedAt = null
                )
            ).await()
        } else {
            cfgRef.set(
                bundle.config.copy(
                    id = "main_config",
                    userId = uid,
                    createdAt = null,
                    updatedAt = null
                )
            ).await()
        }

        for (member in bundle.members) {
            val docId = member.id.ifBlank { "mem_${UUID.randomUUID().toString().replace("-", "").take(16)}" }
            val ref = membersCollection(uid).document(docId)
            val snap = ref.get().await()
            if (snap.exists()) {
                val existing = snap.toObject(
                    MemberProfile::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
                ref.set(
                    member.copy(
                        id = docId,
                        userId = uid,
                        type = existing?.type ?: member.type,
                        stt = existing?.stt ?: member.stt,
                        createdAt = existing?.createdAt ?: Timestamp.now(),
                        updatedAt = null
                    )
                ).await()
            } else {
                ref.set(
                    member.copy(
                        id = docId,
                        userId = uid,
                        createdAt = null,
                        updatedAt = null
                    )
                ).await()
            }
        }

        for (contract in bundle.contracts) {
            val docId = contract.id.ifBlank { "con_${UUID.randomUUID().toString().replace("-", "").take(16)}" }
            val ref = contractsCollection(uid).document(docId)
            val snap = ref.get().await()
            if (snap.exists()) {
                val existing = snap.toObject(
                    ContractRecord::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
                ref.set(
                    contract.copy(
                        id = docId,
                        userId = uid,
                        contractCode = existing?.contractCode ?: contract.contractCode,
                        memberId = existing?.memberId ?: contract.memberId,
                        serviceType = existing?.serviceType ?: contract.serviceType,
                        createdAt = existing?.createdAt ?: Timestamp.now(),
                        updatedAt = null
                    )
                ).await()
            } else {
                ref.set(
                    contract.copy(
                        id = docId,
                        userId = uid,
                        createdAt = null,
                        updatedAt = null
                    )
                ).await()
            }
        }

        for (session in bundle.ptSessions) {
            val docId = session.id.ifBlank { "pts_${UUID.randomUUID().toString().replace("-", "").take(16)}" }
            val ref = ptSessionsCollection(uid).document(docId)
            val snap = ref.get().await()
            if (snap.exists()) {
                val existing = snap.toObject(
                    PtSessionRecord::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
                ref.set(
                    session.copy(
                        id = docId,
                        userId = uid,
                        contractId = existing?.contractId ?: session.contractId,
                        memberId = existing?.memberId ?: session.memberId,
                        createdAt = existing?.createdAt ?: Timestamp.now(),
                        updatedAt = null
                    )
                ).await()
            } else {
                ref.set(
                    session.copy(
                        id = docId,
                        userId = uid,
                        createdAt = null,
                        updatedAt = null
                    )
                ).await()
            }
        }

        for (ticket in bundle.singleTickets) {
            val docId = ticket.id.ifBlank { "tkt_${UUID.randomUUID().toString().replace("-", "").take(16)}" }
            val ref = singleTicketsCollection(uid).document(docId)
            val snap = ref.get().await()
            if (snap.exists()) {
                val existing = snap.toObject(
                    SingleTicketRecord::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
                ref.set(
                    ticket.copy(
                        id = docId,
                        userId = uid,
                        createdAt = existing?.createdAt ?: Timestamp.now(),
                        updatedAt = null
                    )
                ).await()
            } else {
                ref.set(
                    ticket.copy(
                        id = docId,
                        userId = uid,
                        createdAt = null,
                        updatedAt = null
                    )
                ).await()
            }
        }
    }
}
