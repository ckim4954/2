package com.example.domain

import java.util.Calendar
import java.util.GregorianCalendar
import java.util.Locale
import java.util.TimeZone

/**
 * Deterministic Date Calculator for 89 FITNESS & YOGA.
 * Uses ISO format "yyyy-MM-dd" internally for storage and sorting,
 * and "dd/MM/yyyy" for Vietnamese display.
 *
 * Rules enforced:
 * 1. End date is the milestone when the membership expires (exclusive end of usage).
 *    Example: Start 15/01 + 1 month -> valid through 14/02, End Date = 15/02.
 * 2. Registration on 29, 30, 31 clamps to the last day of the target month (including leap years).
 * 3. Frozen days are added directly to the calculated end date.
 * 4. Early renewal (< oldEndDate) starts on oldEndDate.
 *    On-time or late renewal (>= oldEndDate) starts on actual renewal date.
 */
object DateCalculator {

    private val utcZone: TimeZone = TimeZone.getTimeZone("UTC")

    fun todayIso(): String {
        val cal = Calendar.getInstance()
        return String.format(
            Locale.US,
            "%04d-%02d-%02d",
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH) + 1,
            cal.get(Calendar.DAY_OF_MONTH)
        )
    }

    fun formatDisplay(isoDate: String): String {
        val parts = parseIso(isoDate) ?: return isoDate
        return String.format(Locale.US, "%02d/%02d/%04d", parts[2], parts[1], parts[0])
    }

    fun parseDisplayToIso(displayDate: String): String? {
        val trimmed = displayDate.trim()
        if (trimmed.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))) {
            return if (isValidIsoDate(trimmed)) trimmed else null
        }
        val slashParts = trimmed.split("/", "-")
        if (slashParts.size != 3) return null
        val day = slashParts[0].toIntOrNull() ?: return null
        val month = slashParts[1].toIntOrNull() ?: return null
        val year = slashParts[2].toIntOrNull() ?: return null
        val iso = String.format(Locale.US, "%04d-%02d-%02d", year, month, day)
        return if (isValidIsoDate(iso)) iso else null
    }

    fun isValidIsoDate(isoDate: String): Boolean {
        val parts = parseIso(isoDate) ?: return false
        val y = parts[0]
        val m = parts[1]
        val d = parts[2]
        if (y !in 1970..2100 || m !in 1..12) return false
        val maxDay = maxDaysInMonth(y, m)
        return d in 1..maxDay
    }

    fun maxDaysInMonth(year: Int, month: Int): Int {
        val cal = GregorianCalendar(utcZone, Locale.US)
        cal.isLenient = false
        cal.clear()
        cal.set(year, month - 1, 1)
        return cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    }

    /**
     * Adds [months] to [startIsoDate] clamping 29/30/31 to the end of the target month,
     * then adds [extraFrozenDays] if any.
     */
    fun calculateEndDate(
        startIsoDate: String,
        months: Int,
        extraFrozenDays: Int = 0
    ): String {
        val parts = parseIso(startIsoDate) ?: return startIsoDate
        val startYear = parts[0]
        val startMonth = parts[1] // 1..12
        val startDay = parts[2]

        val totalMonths = (startYear * 12 + (startMonth - 1)) + months
        val targetYear = totalMonths / 12
        val targetMonth = (totalMonths % 12) + 1
        val clampedDay = minOf(startDay, maxDaysInMonth(targetYear, targetMonth))

        val baseEndIso = String.format(Locale.US, "%04d-%02d-%02d", targetYear, targetMonth, clampedDay)
        return if (extraFrozenDays != 0) {
            addDays(baseEndIso, extraFrozenDays)
        } else {
            baseEndIso
        }
    }

    fun addDays(isoDate: String, daysToAdd: Int): String {
        val cal = toUtcCalendar(isoDate) ?: return isoDate
        cal.add(Calendar.DAY_OF_MONTH, daysToAdd)
        return fromUtcCalendar(cal)
    }

    /**
     * Renewal start date rule (Section 5.4):
     * - Early renewal (renewalDate < previousEndDate): new contract starts on previousEndDate.
     * - On-time (renewalDate == previousEndDate) or late (renewalDate > previousEndDate):
     *   new contract starts on renewalDate.
     */
    fun calculateRenewalStartDate(previousEndDateIso: String, renewalDateIso: String): String {
        return if (renewalDateIso < previousEndDateIso) {
            previousEndDateIso
        } else {
            renewalDateIso
        }
    }

    /**
     * Exact number of days from [startIso] (inclusive) to [endIso] (exclusive).
     * Returns 0 if endIso <= startIso.
     */
    fun daysBetween(startIso: String, endIso: String): Int {
        val startCal = toUtcCalendar(startIso) ?: return 0
        val endCal = toUtcCalendar(endIso) ?: return 0
        val diffMillis = endCal.timeInMillis - startCal.timeInMillis
        if (diffMillis <= 0L) return 0
        return (diffMillis / (24L * 60L * 60L * 1000L)).toInt()
    }

    /**
     * Signed difference in days: (targetEndIso - currentIso).
     * > 0 means remaining days (Còn X ngày).
     * == 0 means expires today (Hết hạn hôm nay).
     * < 0 means expired by |days| (Hết hạn X ngày).
     */
    fun signedDaysUntilExpiry(currentIso: String, endIso: String): Int {
        val curCal = toUtcCalendar(currentIso) ?: return 0
        val endCal = toUtcCalendar(endIso) ?: return 0
        val diffMillis = endCal.timeInMillis - curCal.timeInMillis
        return (diffMillis / (24L * 60L * 60L * 1000L)).toInt()
    }

    /**
     * Calculates how many effective days of [contractStartIso, contractEndIso)
     * fall within the calendar month [year]-[month] (1..12).
     */
    fun effectiveDaysInMonth(
        contractStartIso: String,
        contractEndIso: String,
        year: Int,
        month: Int
    ): Int {
        if (contractEndIso <= contractStartIso) return 0
        val monthStartIso = String.format(Locale.US, "%04d-%02d-01", year, month)
        val nextMonthYear = if (month == 12) year + 1 else year
        val nextMonth = if (month == 12) 1 else month + 1
        val monthEndExclusiveIso = String.format(Locale.US, "%04d-%02d-01", nextMonthYear, nextMonth)

        val overlapStart = maxOf(contractStartIso, monthStartIso)
        val overlapEnd = minOf(contractEndIso, monthEndExclusiveIso)
        if (overlapEnd <= overlapStart) return 0
        return daysBetween(overlapStart, overlapEnd)
    }

    fun getYearMonth(isoDate: String): Pair<Int, Int>? {
        val parts = parseIso(isoDate) ?: return null
        return parts[0] to parts[1]
    }

    private fun parseIso(isoDate: String): IntArray? {
        val segments = isoDate.trim().split("-")
        if (segments.size != 3) return null
        val y = segments[0].toIntOrNull() ?: return null
        val m = segments[1].toIntOrNull() ?: return null
        val d = segments[2].toIntOrNull() ?: return null
        return intArrayOf(y, m, d)
    }

    private fun toUtcCalendar(isoDate: String): GregorianCalendar? {
        val parts = parseIso(isoDate) ?: return null
        val cal = GregorianCalendar(utcZone, Locale.US)
        cal.clear()
        cal.set(parts[0], parts[1] - 1, parts[2], 0, 0, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal
    }

    private fun fromUtcCalendar(cal: Calendar): String {
        return String.format(
            Locale.US,
            "%04d-%02d-%02d",
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH) + 1,
            cal.get(Calendar.DAY_OF_MONTH)
        )
    }
}
