package com.example.domain

import com.example.data.model.ContractRecord
import com.example.data.model.MemberProfile
import com.example.data.model.PtSessionRecord
import com.example.data.model.SingleTicketRecord
import java.text.NumberFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToLong

enum class MemberExpiryState {
    ACTIVE,
    EXPIRING_SOON_7_DAYS,
    EXPIRED_TODAY,
    EXPIRED
}

data class MemberCardSummary(
    val member: MemberProfile,
    val latestContract: ContractRecord?,
    val allContracts: List<ContractRecord>,
    val daysRemainingOrOverdue: Int, // >0: còn n ngày, 0: hết hạn hôm nay, <0: quá hạn |n| ngày
    val expiryState: MemberExpiryState
) {
    val isActive: Boolean
        get() = expiryState == MemberExpiryState.ACTIVE || expiryState == MemberExpiryState.EXPIRING_SOON_7_DAYS
}

enum class AllocatedReportType(
    val index: Int,
    val serviceCategory: String, // GYM or YOGA
    val title: String,
    val shortTitle: String
) {
    GYM_NEW_AND_ACTIVE(1, "GYM", "Doanh thu phân bổ GYM — Còn hạn và đăng ký mới", "GYM: Còn hạn & ĐK mới"),
    GYM_RENEWAL(2, "GYM", "Doanh thu phân bổ GYM — Gia hạn", "GYM: Gia hạn"),
    GYM_PT(3, "GYM", "Doanh thu phân bổ GYM — PT (50% phòng tập)", "GYM: PT (50% phòng tập)"),
    GYM_SINGLE_TICKET(4, "GYM", "Doanh thu phân bổ GYM — Vé lẻ", "GYM: Vé lẻ"),
    GYM_TOTAL(5, "GYM", "Tổng doanh thu phân bổ GYM", "Tổng doanh thu phân bổ GYM"),
    YOGA_NEW_AND_ACTIVE(6, "YOGA", "Doanh thu phân bổ YOGA — Còn hạn và đăng ký mới", "YOGA: Còn hạn & ĐK mới"),
    YOGA_RENEWAL(7, "YOGA", "Doanh thu phân bổ YOGA — Gia hạn", "YOGA: Gia hạn"),
    YOGA_TOTAL(8, "YOGA", "Tổng doanh thu phân bổ YOGA", "Tổng doanh thu phân bổ YOGA")
}

data class AllocatedLineItem(
    val id: String,
    val codeOrLabel: String,
    val memberSttText: String,
    val memberName: String,
    val periodText: String,
    val packageValue: Long,
    val totalUnitText: String,
    val monthUnitText: String,
    val allocatedAmount: Long,
    val categoryLabel: String
)

data class AllocatedMonthlySummary(
    val year: Int,
    val month: Int,
    val gymNewAndActiveItems: List<AllocatedLineItem>,
    val gymRenewalItems: List<AllocatedLineItem>,
    val gymPtItems: List<AllocatedLineItem>,
    val gymSingleTicketItems: List<AllocatedLineItem>,
    val yogaNewAndActiveItems: List<AllocatedLineItem>,
    val yogaRenewalItems: List<AllocatedLineItem>
) {
    val gymNewAndActiveTotal: Long = gymNewAndActiveItems.sumOf { it.allocatedAmount }
    val gymRenewalTotal: Long = gymRenewalItems.sumOf { it.allocatedAmount }
    val gymPtTotal: Long = gymPtItems.sumOf { it.allocatedAmount }
    val gymSingleTicketTotal: Long = gymSingleTicketItems.sumOf { it.allocatedAmount }
    val gymGrandTotal: Long = gymNewAndActiveTotal + gymRenewalTotal + gymPtTotal + gymSingleTicketTotal

    val yogaNewAndActiveTotal: Long = yogaNewAndActiveItems.sumOf { it.allocatedAmount }
    val yogaRenewalTotal: Long = yogaRenewalItems.sumOf { it.allocatedAmount }
    val yogaGrandTotal: Long = yogaNewAndActiveTotal + yogaRenewalTotal

    fun itemsForReport(type: AllocatedReportType): List<AllocatedLineItem> = when (type) {
        AllocatedReportType.GYM_NEW_AND_ACTIVE -> gymNewAndActiveItems
        AllocatedReportType.GYM_RENEWAL -> gymRenewalItems
        AllocatedReportType.GYM_PT -> gymPtItems
        AllocatedReportType.GYM_SINGLE_TICKET -> gymSingleTicketItems
        AllocatedReportType.GYM_TOTAL ->
            gymNewAndActiveItems + gymRenewalItems + gymPtItems + gymSingleTicketItems
        AllocatedReportType.YOGA_NEW_AND_ACTIVE -> yogaNewAndActiveItems
        AllocatedReportType.YOGA_RENEWAL -> yogaRenewalItems
        AllocatedReportType.YOGA_TOTAL -> yogaNewAndActiveItems + yogaRenewalItems
    }

    fun totalForReport(type: AllocatedReportType): Long = when (type) {
        AllocatedReportType.GYM_NEW_AND_ACTIVE -> gymNewAndActiveTotal
        AllocatedReportType.GYM_RENEWAL -> gymRenewalTotal
        AllocatedReportType.GYM_PT -> gymPtTotal
        AllocatedReportType.GYM_SINGLE_TICKET -> gymSingleTicketTotal
        AllocatedReportType.GYM_TOTAL -> gymGrandTotal
        AllocatedReportType.YOGA_NEW_AND_ACTIVE -> yogaNewAndActiveTotal
        AllocatedReportType.YOGA_RENEWAL -> yogaRenewalTotal
        AllocatedReportType.YOGA_TOTAL -> yogaGrandTotal
    }
}

data class CashflowTransactionItem(
    val id: String,
    val date: String,
    val serviceCategory: String, // GYM, YOGA, PT, VE_LE
    val title: String,
    val subtitle: String,
    val paidAmount: Long,
    val paymentMethod: String, // TRANSFER, CASH, COMBINED
    val cashAmount: Long,
    val transferAmount: Long
)

data class MonthlyCashflowSummary(
    val year: Int,
    val month: Int,
    val transactions: List<CashflowTransactionItem>
) {
    val totalCashflow: Long = transactions.sumOf { it.paidAmount }
    val gymTotal: Long = transactions.filter { it.serviceCategory == "GYM" }.sumOf { it.paidAmount }
    val yogaTotal: Long = transactions.filter { it.serviceCategory == "YOGA" }.sumOf { it.paidAmount }
    val ptTotal: Long = transactions.filter { it.serviceCategory == "PT" }.sumOf { it.paidAmount }
    val singleTicketTotal: Long = transactions.filter { it.serviceCategory == "VE_LE" }.sumOf { it.paidAmount }

    val pureCashMethodTotal: Long = transactions.filter { it.paymentMethod == "CASH" }.sumOf { it.paidAmount }
    val pureTransferMethodTotal: Long = transactions.filter { it.paymentMethod == "TRANSFER" }.sumOf { it.paidAmount }
    val combinedMethodTotal: Long = transactions.filter { it.paymentMethod == "COMBINED" }.sumOf { it.paidAmount }

    val actualCashReceived: Long = transactions.sumOf {
        when (it.paymentMethod) {
            "CASH" -> it.paidAmount
            "COMBINED" -> it.cashAmount
            else -> 0L
        }
    }
    val actualTransferReceived: Long = transactions.sumOf {
        when (it.paymentMethod) {
            "TRANSFER" -> it.paidAmount
            "COMBINED" -> it.transferAmount
            else -> 0L
        }
    }
}

object FitnessCalculator {

    private val utcZone: TimeZone = TimeZone.getTimeZone("UTC")

    fun todayIso(): String {
        val cal = Calendar.getInstance()
        return formatIso(
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH) + 1,
            cal.get(Calendar.DAY_OF_MONTH)
        )
    }

    fun currentYearMonth(): Pair<Int, Int> {
        val cal = Calendar.getInstance()
        return cal.get(Calendar.YEAR) to (cal.get(Calendar.MONTH) + 1)
    }

    fun formatIso(year: Int, month: Int, day: Int): String =
        String.format(Locale.US, "%04d-%02d-%02d", year, month, day)

    fun parseIso(dateStr: String): Triple<Int, Int, Int>? {
        val parts = dateStr.trim().split("-")
        if (parts.size != 3) return null
        val y = parts[0].toIntOrNull() ?: return null
        val m = parts[1].toIntOrNull() ?: return null
        val d = parts[2].toIntOrNull() ?: return null
        if (m !in 1..12 || d !in 1..31) return null
        return Triple(y, m, d)
    }

    fun formatDisplayDate(isoDate: String): String {
        val parsed = parseIso(isoDate) ?: return isoDate
        return String.format(Locale.US, "%02d/%02d/%04d", parsed.third, parsed.second, parsed.first)
    }

    fun daysInMonth(year: Int, month: Int): Int {
        val cal = Calendar.getInstance(utcZone)
        cal.clear()
        cal.set(Calendar.YEAR, year)
        cal.set(Calendar.MONTH, month - 1)
        cal.set(Calendar.DAY_OF_MONTH, 1)
        return cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    }

    fun toEpochDay(isoDate: String): Long? {
        val (y, m, d) = parseIso(isoDate) ?: return null
        val cal = Calendar.getInstance(utcZone)
        cal.clear()
        cal.set(y, m - 1, d, 0, 0, 0)
        return cal.timeInMillis / 86_400_000L
    }

    fun fromEpochDay(epochDay: Long): String {
        val cal = Calendar.getInstance(utcZone)
        cal.clear()
        cal.timeInMillis = epochDay * 86_400_000L
        return formatIso(
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH) + 1,
            cal.get(Calendar.DAY_OF_MONTH)
        )
    }

    /**
     * Quy tắc thời hạn GYM/YOGA (03_Quy_tac_va_cong_thuc.md):
     * - Ngày bắt đầu và ngày hết hạn đều tính vào thời hạn.
     * - Nếu ngày đăng ký là 29/30/31 và tháng đích không có ngày tương ứng, dùng ngày cuối tháng đích; không cộng bù ngày.
     * - Với các ngày thông thường (ví dụ 15/10 gói 1 tháng -> 14/11; 20/11 gói 1 tháng -> 19/12),
     *   ngày hết hạn là ngày cùng số ở tháng đích trừ 1 ngày.
     */
    fun calculateEndDate(startDateIso: String, durationMonths: Int): String {
        val (startY, startM, startD) = parseIso(startDateIso) ?: return startDateIso
        if (durationMonths <= 0) return startDateIso

        val totalMonths = (startY * 12 + (startM - 1)) + durationMonths
        val targetY = totalMonths / 12
        val targetM = (totalMonths % 12) + 1
        val maxDayInTarget = daysInMonth(targetY, targetM)

        return if (startD >= 29 && startD > maxDayInTarget) {
            // Tháng đích không có ngày tương ứng (29/30/31) -> lấy đúng ngày cuối tháng đích, không cộng bù
            formatIso(targetY, targetM, maxDayInTarget)
        } else {
            // Ngày tương ứng ở tháng đích trừ đi 1 ngày (để tính cả ngày đầu & ngày cuối)
            val targetIso = formatIso(targetY, targetM, min(startD, maxDayInTarget))
            val targetEpoch = toEpochDay(targetIso) ?: return targetIso
            fromEpochDay(targetEpoch - 1L)
        }
    }

    /**
     * Tổng số ngày hiệu lực của hợp đồng (tính cả ngày bắt đầu và ngày hết hạn).
     */
    fun totalValidDaysInclusive(startDateIso: String, endDateIso: String): Long {
        val startEpoch = toEpochDay(startDateIso) ?: return 0L
        val endEpoch = toEpochDay(endDateIso) ?: return 0L
        if (endEpoch < startEpoch) return 0L
        return (endEpoch - startEpoch) + 1L
    }

    /**
     * Số ngày hiệu lực của hợp đồng giao với tháng báo cáo (tính cả 2 đầu mút).
     */
    fun overlapDaysInMonth(startDateIso: String, endDateIso: String, year: Int, month: Int): Long {
        val contractStart = toEpochDay(startDateIso) ?: return 0L
        val contractEnd = toEpochDay(endDateIso) ?: return 0L
        if (contractEnd < contractStart) return 0L

        val monthStartIso = formatIso(year, month, 1)
        val monthEndIso = formatIso(year, month, daysInMonth(year, month))
        val monthStart = toEpochDay(monthStartIso) ?: return 0L
        val monthEnd = toEpochDay(monthEndIso) ?: return 0L

        val overlapStart = max(contractStart, monthStart)
        val overlapEnd = min(contractEnd, monthEnd)
        return if (overlapEnd >= overlapStart) (overlapEnd - overlapStart) + 1L else 0L
    }

    /**
     * Công thức doanh thu phân bổ tháng cho 1 hợp đồng GYM/YOGA:
     * Doanh thu phân bổ tháng = Giá trị hợp đồng / Tổng số ngày hiệu lực × Số ngày hiệu lực giao với tháng báo cáo
     * Chính sách làm tròn đã xác nhận: Làm tròn đến hàng đồng cho từng hợp đồng trước khi cộng.
     */
    fun calculateContractAllocatedRevenue(
        packageValue: Long,
        startDateIso: String,
        endDateIso: String,
        year: Int,
        month: Int
    ): Triple<Long, Long, Long> {
        val totalDays = totalValidDaysInclusive(startDateIso, endDateIso)
        val overlapDays = overlapDaysInMonth(startDateIso, endDateIso, year, month)
        if (totalDays <= 0L || overlapDays <= 0L || packageValue <= 0L) {
            return Triple(0L, totalDays, 0L)
        }
        val exact = (packageValue.toDouble() / totalDays.toDouble()) * overlapDays.toDouble()
        return Triple(exact.roundToLong(), totalDays, overlapDays)
    }

    /**
     * Công thức doanh thu phân bổ PT trong tháng:
     * PT gộp phân bổ = Giá trị gói / Tổng số buổi gói × Số buổi thực tế trong tháng
     * Phần phòng tập = PT gộp phân bổ × 50% (làm tròn đến hàng đồng cho từng hợp đồng trước khi cộng).
     */
    fun calculatePtGymShareRevenue(
        packageValue: Long,
        totalSessions: Long,
        sessionsInMonth: Int
    ): Long {
        if (totalSessions <= 0L || sessionsInMonth <= 0 || packageValue <= 0L) return 0L
        val gross = (packageValue.toDouble() / totalSessions.toDouble()) * sessionsInMonth.toDouble()
        val gymShare = gross * 0.5
        return gymShare.roundToLong()
    }

    fun buildContractCode(serviceType: String, memberStt: Long, contractSeq: Long): String {
        return String.format(Locale.US, "%s-STT%d-%03d", serviceType.uppercase(Locale.US), memberStt, contractSeq)
    }

    fun evaluateMemberCardSummary(
        member: MemberProfile,
        memberContracts: List<ContractRecord>,
        todayIso: String = todayIso()
    ): MemberCardSummary {
        val activeSorted = memberContracts
            .filter { !it.isDeleted }
            .sortedWith(compareByDescending<ContractRecord> { it.endDate }.thenByDescending { it.startDate })
        val latest = activeSorted.firstOrNull()
        val todayEpoch = toEpochDay(todayIso) ?: 0L
        val endEpoch = latest?.endDate?.let { toEpochDay(it) }

        if (endEpoch == null) {
            return MemberCardSummary(
                member = member,
                latestContract = latest,
                allContracts = activeSorted,
                daysRemainingOrOverdue = -1,
                expiryState = MemberExpiryState.EXPIRED
            )
        }

        val diffDays = (endEpoch - todayEpoch).toInt()
        val state = when {
            diffDays < 0 -> MemberExpiryState.EXPIRED
            diffDays == 0 -> MemberExpiryState.EXPIRED_TODAY
            diffDays in 1..7 -> MemberExpiryState.EXPIRING_SOON_7_DAYS
            else -> MemberExpiryState.ACTIVE
        }
        return MemberCardSummary(
            member = member,
            latestContract = latest,
            allContracts = activeSorted,
            daysRemainingOrOverdue = diffDays,
            expiryState = state
        )
    }

    fun computeAllocatedMonthlySummary(
        year: Int,
        month: Int,
        contracts: List<ContractRecord>,
        ptSessions: List<PtSessionRecord>,
        singleTickets: List<SingleTicketRecord>
    ): AllocatedMonthlySummary {
        val validContracts = contracts.filter { !it.isDeleted }
        val validSessions = ptSessions.filter { !it.isDeleted }
        val validTickets = singleTickets.filter { !it.isDeleted }
        val monthPrefix = String.format(Locale.US, "%04d-%02d-", year, month)

        val gymNewAndActive = mutableListOf<AllocatedLineItem>()
        val gymRenewal = mutableListOf<AllocatedLineItem>()
        val gymPt = mutableListOf<AllocatedLineItem>()
        val yogaNewAndActive = mutableListOf<AllocatedLineItem>()
        val yogaRenewal = mutableListOf<AllocatedLineItem>()

        for (contract in validContracts) {
            when (contract.serviceType) {
                "GYM" -> {
                    val (allocated, totalDays, overlapDays) = calculateContractAllocatedRevenue(
                        packageValue = contract.packageValue,
                        startDateIso = contract.startDate,
                        endDateIso = contract.endDate,
                        year = year,
                        month = month
                    )
                    if (overlapDays > 0L) {
                        val item = AllocatedLineItem(
                            id = contract.id,
                            codeOrLabel = contract.contractCode,
                            memberSttText = "STT${contract.memberSttSnapshot}",
                            memberName = contract.memberNameSnapshot,
                            periodText = "${formatDisplayDate(contract.startDate)} – ${formatDisplayDate(contract.endDate)}",
                            packageValue = contract.packageValue,
                            totalUnitText = "$totalDays ngày",
                            monthUnitText = "$overlapDays ngày",
                            allocatedAmount = allocated,
                            categoryLabel = if (contract.isRenewal) "GYM Gia hạn" else "GYM Đăng ký mới / Còn hạn"
                        )
                        if (contract.isRenewal) gymRenewal.add(item) else gymNewAndActive.add(item)
                    }
                }
                "YOGA" -> {
                    val (allocated, totalDays, overlapDays) = calculateContractAllocatedRevenue(
                        packageValue = contract.packageValue,
                        startDateIso = contract.startDate,
                        endDateIso = contract.endDate,
                        year = year,
                        month = month
                    )
                    if (overlapDays > 0L) {
                        val item = AllocatedLineItem(
                            id = contract.id,
                            codeOrLabel = contract.contractCode,
                            memberSttText = "STT${contract.memberSttSnapshot}",
                            memberName = contract.memberNameSnapshot,
                            periodText = "${formatDisplayDate(contract.startDate)} – ${formatDisplayDate(contract.endDate)}",
                            packageValue = contract.packageValue,
                            totalUnitText = "$totalDays ngày",
                            monthUnitText = "$overlapDays ngày",
                            allocatedAmount = allocated,
                            categoryLabel = if (contract.isRenewal) "YOGA Gia hạn" else "YOGA Đăng ký mới / Còn hạn"
                        )
                        if (contract.isRenewal) yogaRenewal.add(item) else yogaNewAndActive.add(item)
                    }
                }
                "PT" -> {
                    val sessionsForContractInMonth = validSessions.count {
                        it.contractId == contract.id && it.sessionDate.startsWith(monthPrefix)
                    }
                    if (sessionsForContractInMonth > 0 && contract.totalSessions > 0L) {
                        val gymShare = calculatePtGymShareRevenue(
                            packageValue = contract.packageValue,
                            totalSessions = contract.totalSessions,
                            sessionsInMonth = sessionsForContractInMonth
                        )
                        gymPt.add(
                            AllocatedLineItem(
                                id = contract.id,
                                codeOrLabel = contract.contractCode,
                                memberSttText = "STT${contract.memberSttSnapshot}",
                                memberName = contract.memberNameSnapshot,
                                periodText = "ĐK: ${formatDisplayDate(contract.startDate)}",
                                packageValue = contract.packageValue,
                                totalUnitText = "${contract.totalSessions} buổi",
                                monthUnitText = "$sessionsForContractInMonth buổi (x50%)",
                                allocatedAmount = gymShare,
                                categoryLabel = "PT (50% phòng tập)"
                            )
                        )
                    }
                }
            }
        }

        val gymTickets = validTickets
            .filter { it.saleDate.startsWith(monthPrefix) }
            .sortedByDescending { it.saleDate }
            .map { ticket ->
                val typeLabel = if (ticket.ticketType == "WEEKLY") "Vé tuần" else "Vé ngày"
                AllocatedLineItem(
                    id = ticket.id,
                    codeOrLabel = typeLabel,
                    memberSttText = "Vé lẻ",
                    memberName = "$typeLabel (${formatDisplayDate(ticket.saleDate)})",
                    periodText = formatDisplayDate(ticket.saleDate),
                    packageValue = ticket.unitPrice,
                    totalUnitText = "Đơn giá",
                    monthUnitText = "SL: ${ticket.quantity}",
                    allocatedAmount = ticket.totalAmount,
                    categoryLabel = "Vé lẻ GYM"
                )
            }

        return AllocatedMonthlySummary(
            year = year,
            month = month,
            gymNewAndActiveItems = gymNewAndActive,
            gymRenewalItems = gymRenewal,
            gymPtItems = gymPt,
            gymSingleTicketItems = gymTickets,
            yogaNewAndActiveItems = yogaNewAndActive,
            yogaRenewalItems = yogaRenewal
        )
    }

    fun computeMonthlyCashflow(
        year: Int,
        month: Int,
        contracts: List<ContractRecord>,
        singleTickets: List<SingleTicketRecord>
    ): MonthlyCashflowSummary {
        val monthPrefix = String.format(Locale.US, "%04d-%02d-", year, month)
        val list = mutableListOf<CashflowTransactionItem>()

        contracts.filter { !it.isDeleted && it.paymentDate.startsWith(monthPrefix) }.forEach { c ->
            list.add(
                CashflowTransactionItem(
                    id = "c_${c.id}",
                    date = c.paymentDate,
                    serviceCategory = c.serviceType,
                    title = "${c.contractCode} — ${c.memberNameSnapshot}",
                    subtitle = if (c.serviceType == "PT") {
                        "Gói PT ${c.totalSessions} buổi"
                    } else {
                        "Gói ${c.durationMonths} tháng (${if (c.isRenewal) "Gia hạn" else "Đăng ký mới"})"
                    },
                    paidAmount = c.paidAmount,
                    paymentMethod = c.paymentMethod,
                    cashAmount = c.cashAmount,
                    transferAmount = c.transferAmount
                )
            )
        }

        singleTickets.filter { !it.isDeleted && it.saleDate.startsWith(monthPrefix) }.forEach { t ->
            val typeLabel = if (t.ticketType == "WEEKLY") "Vé tuần" else "Vé ngày"
            list.add(
                CashflowTransactionItem(
                    id = "t_${t.id}",
                    date = t.saleDate,
                    serviceCategory = "VE_LE",
                    title = "$typeLabel × ${t.quantity}",
                    subtitle = "Đơn giá: ${formatCurrency(t.unitPrice)}",
                    paidAmount = t.totalAmount,
                    paymentMethod = t.paymentMethod,
                    cashAmount = t.cashAmount,
                    transferAmount = t.transferAmount
                )
            )
        }

        val sorted = list.sortedByDescending { it.date }
        return MonthlyCashflowSummary(year = year, month = month, transactions = sorted)
    }

    fun findActivePtContract(contracts: List<ContractRecord>): ContractRecord? {
        return contracts
            .filter { !it.isDeleted && it.serviceType == "PT" && it.ptStatus == "ACTIVE" && it.usedSessions < it.totalSessions }
            .maxByOrNull { it.startDate }
    }

    fun formatCurrency(amount: Long): String {
        val formatter = NumberFormat.getInstance(Locale.forLanguageTag("vi-VN"))
        return "${formatter.format(amount)} đ"
    }
}
