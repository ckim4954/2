package com.example.domain

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

object FormatUtils {
    private val vndSymbols = DecimalFormatSymbols(Locale.US).apply {
        groupingSeparator = '.'
        decimalSeparator = ','
    }
    private val vndFormatter = DecimalFormat("#,###", vndSymbols)

    fun formatVnd(amount: Long): String {
        return "${vndFormatter.format(amount)} đ"
    }

    fun formatNumberInput(amount: Long): String {
        return if (amount == 0L) "" else vndFormatter.format(amount)
    }

    fun parseVndInput(raw: String): Long {
        val digitsOnly = raw.filter { it.isDigit() }
        return digitsOnly.toLongOrNull() ?: 0L
    }

    fun formatStt(index: Int): String {
        return String.format(Locale.US, "%02d", index)
    }

    /**
     * Generates a human-readable, globally unique code that will never collide across devices.
     */
    fun generateUniqueCode(prefix: String): String {
        val timestampPart = (System.currentTimeMillis() % 100000000L).toString().padStart(8, '0')
        val randomPart = (100..999).random()
        return "$prefix-$timestampPart-$randomPart"
    }
}
