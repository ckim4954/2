package com.example.domain

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.example.data.model.MemberGroup
import com.example.data.model.PaymentMethod
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.max

enum class PdfColAlign {
    LEFT,
    CENTER,
    RIGHT
}

data class PdfColumnSpec(
    val header: String,
    val widthPt: Float,
    val align: PdfColAlign = PdfColAlign.LEFT
)

data class PdfSummaryMetric(
    val label: String,
    val value: String,
    val isWarning: Boolean = false
)

data class PdfExportVerification(
    val filePath: String,
    val reportTitle: String,
    val periodLabel: String,
    val pageCount: Int,
    val dataRowCount: Int,
    val grandTotalAmount: Long,
    val allRenderedTexts: List<String>
)

object ReportExporter {

    const val XLSX_MIME_TYPE = XlsxWorkbookWriter.MIME_TYPE
    const val PDF_MIME_TYPE = "application/pdf"

    private val pdfVerificationRegistry = ConcurrentHashMap<String, PdfExportVerification>()

    fun getPdfVerification(file: File): PdfExportVerification? =
        pdfVerificationRegistry[file.absolutePath]

    private fun ensureExportDir(context: Context): File {
        val dir = File(context.cacheDir, "exports")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    // =========================================================================================
    // 1. XUẤT DANH SÁCH HỘI VIÊN GYM / YOGA (PDF & XLSX)
    // =========================================================================================

    fun exportMembersToExcelCsv(
        context: Context,
        serviceType: String,
        cards: List<MemberCardSummary>
    ): File = exportMembersToXlsx(context, serviceType, cards)

    fun exportMembersToXlsx(
        context: Context,
        serviceType: String,
        cards: List<MemberCardSummary>
    ): File {
        val dir = ensureExportDir(context)
        val todayIso = FitnessCalculator.todayIso()
        val todayDisplay = FitnessCalculator.formatDisplayDate(todayIso)
        val fileName = "89Fitness_DanhSach_${serviceType}_${todayIso}.xlsx"
        val file = File(dir, fileName)

        val activeCount = cards.count { it.expiryState == MemberExpiryState.ACTIVE }
        val expiringCount = cards.count { it.expiryState == MemberExpiryState.EXPIRING_SOON_7_DAYS }
        val expiredTodayCount = cards.count { it.expiryState == MemberExpiryState.EXPIRED_TODAY }
        val expiredCount = cards.count { it.expiryState == MemberExpiryState.EXPIRED }

        val overviewRows = listOf(
            XlsxRow(listOf(XlsxCell.title("89 FITNESS & YOGA")), heightPt = 24.0),
            XlsxRow(listOf(XlsxCell.section("BÁO CÁO DANH SÁCH HỘI VIÊN $serviceType")), heightPt = 20.0),
            XlsxRow(listOf(XlsxCell.meta("Ngày xuất báo cáo: $todayDisplay | Đơn vị tiền tệ: VND"))),
            XlsxRow(emptyList()),
            XlsxRow(listOf(XlsxCell.header("Chỉ tiêu thống kê"), XlsxCell.header("Số lượng hồ sơ"))),
            XlsxRow(listOf(XlsxCell.textLeft("Tổng số hồ sơ hội viên"), XlsxCell.numberCenter(cards.size.toLong()))),
            XlsxRow(listOf(XlsxCell.textLeft("Hội viên đang còn hạn (> 7 ngày)"), XlsxCell.numberCenter(activeCount.toLong()))),
            XlsxRow(listOf(XlsxCell.textLeft("Hội viên sắp hết hạn (1 - 7 ngày)"), XlsxCell.numberCenter(expiringCount.toLong()))),
            XlsxRow(listOf(XlsxCell.textLeft("Hội viên hết hạn hôm nay"), XlsxCell.numberCenter(expiredTodayCount.toLong()))),
            XlsxRow(listOf(XlsxCell.textLeft("Hội viên đã hết hạn"), XlsxCell.numberCenter(expiredCount.toLong())))
        )

        val detailRows = mutableListOf<XlsxRow>()
        detailRows.add(XlsxRow(listOf(XlsxCell.title("89 FITNESS & YOGA — DANH SÁCH HỘI VIÊN $serviceType")), heightPt = 24.0))
        detailRows.add(XlsxRow(listOf(XlsxCell.meta("Ngày xuất: $todayDisplay | Tổng số hồ sơ: ${cards.size} | Đơn vị tiền tệ: VND"))))
        detailRows.add(XlsxRow(emptyList()))
        val headerRowNumber = 4
        detailRows.add(
            XlsxRow(
                listOf(
                    XlsxCell.header("STT"),
                    XlsxCell.header("Mã STT"),
                    XlsxCell.header("Họ và tên hội viên"),
                    XlsxCell.header("Số điện thoại"),
                    XlsxCell.header("Nhóm hội viên"),
                    XlsxCell.header("Mã hợp đồng hiện tại"),
                    XlsxCell.header("Ngày đăng ký"),
                    XlsxCell.header("Ngày hết hạn"),
                    XlsxCell.header("Giá trị hợp đồng (VND)"),
                    XlsxCell.header("Trạng thái"),
                    XlsxCell.header("Số ngày còn / quá hạn")
                ),
                heightPt = 24.0
            )
        )

        var totalContractValue = 0L
        cards.forEachIndexed { idx, c ->
            val m = c.member
            val latest = c.latestContract
            val pkgVal = latest?.packageValue ?: 0L
            totalContractValue += pkgVal
            val groupLabel = if (serviceType == "GYM") MemberGroup.fromCode(m.memberGroup).label else "YOGA"
            val statusLabel = when (c.expiryState) {
                MemberExpiryState.ACTIVE -> "Còn hạn"
                MemberExpiryState.EXPIRING_SOON_7_DAYS -> "Sắp hết hạn"
                MemberExpiryState.EXPIRED_TODAY -> "Hết hạn hôm nay"
                MemberExpiryState.EXPIRED -> "Hết hạn"
            }
            val daysText = when {
                c.daysRemainingOrOverdue > 0 -> "Còn ${c.daysRemainingOrOverdue} ngày"
                c.daysRemainingOrOverdue == 0 -> "Hết hạn hôm nay"
                else -> "Quá hạn ${-c.daysRemainingOrOverdue} ngày"
            }
            detailRows.add(
                XlsxRow(
                    listOf(
                        XlsxCell.numberCenter((idx + 1).toLong()),
                        XlsxCell.textCenter("STT${m.stt}"),
                        XlsxCell.textLeft(m.fullName),
                        XlsxCell.textCenter(m.phone.ifBlank { "-" }),
                        XlsxCell.textCenter(groupLabel),
                        XlsxCell.textLeft(latest?.contractCode ?: "Chưa có HĐ"),
                        XlsxCell.textCenter(latest?.startDate?.let { FitnessCalculator.formatDisplayDate(it) } ?: "-"),
                        XlsxCell.textCenter(latest?.endDate?.let { FitnessCalculator.formatDisplayDate(it) } ?: "-"),
                        XlsxCell.currency(pkgVal),
                        XlsxCell.textCenter(statusLabel),
                        XlsxCell.textLeft(daysText)
                    )
                )
            )
        }

        val firstDataRow = headerRowNumber + 1
        val lastDataRow = headerRowNumber + cards.size
        val sumFormulaCell = if (cards.isNotEmpty()) {
            XlsxCell.totalCurrencyFormula("SUM(I$firstDataRow:I$lastDataRow)", totalContractValue)
        } else {
            XlsxCell.totalCurrency(0L)
        }
        detailRows.add(
            XlsxRow(
                listOf(
                    XlsxCell.totalLabel("TỔNG CỘNG (${cards.size} HỒ SƠ)"),
                    XlsxCell.totalLabel(""),
                    XlsxCell.totalLabel(""),
                    XlsxCell.totalLabel(""),
                    XlsxCell.totalLabel(""),
                    XlsxCell.totalLabel(""),
                    XlsxCell.totalLabel(""),
                    XlsxCell.totalLabel(""),
                    sumFormulaCell,
                    XlsxCell.totalLabel(""),
                    XlsxCell.totalLabel("")
                ),
                heightPt = 22.0
            )
        )

        val filterEndRow = max(headerRowNumber, lastDataRow)
        val sheets = listOf(
            XlsxSheetSpec(
                name = "Tổng quan",
                rows = overviewRows,
                mergedRanges = listOf("A1:B1", "A2:B2", "A3:B3")
            ),
            XlsxSheetSpec(
                name = "Danh sách hội viên",
                rows = detailRows,
                freezeTopRows = headerRowNumber,
                autoFilterRange = "A$headerRowNumber:K$filterEndRow",
                mergedRanges = listOf("A1:K1", "A2:K2")
            )
        )

        return XlsxWorkbookWriter.writeWorkbook(file, sheets)
    }

    fun exportMembersToPdf(
        context: Context,
        serviceType: String,
        cards: List<MemberCardSummary>
    ): File {
        val dir = ensureExportDir(context)
        val todayIso = FitnessCalculator.todayIso()
        val fileName = "89Fitness_DanhSach_${serviceType}_${todayIso}.pdf"
        val file = File(dir, fileName)

        val activeCount = cards.count { it.isActive }
        val expiredCount = cards.size - activeCount
        val totalPkg = cards.sumOf { it.latestContract?.packageValue ?: 0L }

        val columns = listOf(
            PdfColumnSpec("STT", 44f, PdfColAlign.CENTER),
            PdfColumnSpec("Hội viên", 135f, PdfColAlign.LEFT),
            PdfColumnSpec("Số ĐT", 72f, PdfColAlign.CENTER),
            PdfColumnSpec("Mã hợp đồng", 92f, PdfColAlign.LEFT),
            PdfColumnSpec("Hết hạn", 66f, PdfColAlign.CENTER),
            PdfColumnSpec("Trạng thái", 114f, PdfColAlign.LEFT)
        )

        val rows = cards.map { c ->
            val m = c.member
            val endStr = c.latestContract?.endDate?.let { FitnessCalculator.formatDisplayDate(it) } ?: "-"
            val statusStr = when {
                c.daysRemainingOrOverdue > 0 -> "Còn ${c.daysRemainingOrOverdue} ngày"
                c.daysRemainingOrOverdue == 0 -> "Hết hạn hôm nay"
                else -> "Quá hạn ${-c.daysRemainingOrOverdue} ngày"
            }
            listOf(
                "STT${m.stt}",
                m.fullName,
                m.phone.ifBlank { "-" },
                c.latestContract?.contractCode ?: "Chưa có HĐ",
                endStr,
                statusStr
            )
        }

        val summaryMetrics = listOf(
            PdfSummaryMetric("Tổng số hội viên", "${cards.size} hội viên"),
            PdfSummaryMetric("Đang còn hạn", "$activeCount hội viên"),
            PdfSummaryMetric("Đã hết hạn", "$expiredCount hội viên"),
            PdfSummaryMetric("Tổng giá trị HĐ hiện tại", FitnessCalculator.formatCurrency(totalPkg))
        )

        val totalRow = listOf(
            "TỔNG",
            "${cards.size} hội viên",
            "",
            "",
            "Còn hạn: $activeCount",
            "Hết hạn: $expiredCount"
        )

        return renderProfessionalPdfReport(
            targetFile = file,
            reportTitle = "DANH SÁCH HỘI VIÊN $serviceType",
            periodLabel = "Tính đến ngày ${FitnessCalculator.formatDisplayDate(todayIso)}",
            accentColorRgb = if (serviceType == "YOGA") Color.rgb(109, 40, 217) else Color.rgb(21, 128, 61),
            summaryMetrics = summaryMetrics,
            columns = columns,
            rows = rows,
            totalRow = totalRow,
            grandTotalAmount = totalPkg
        )
    }

    // =========================================================================================
    // 2. XUẤT BÁO CÁO DOANH THU PHÂN BỔ (PDF & XLSX)
    // =========================================================================================

    fun exportSingleAllocatedReportToExcelCsv(
        context: Context,
        reportType: AllocatedReportType,
        summary: AllocatedMonthlySummary
    ): File = exportSingleAllocatedReportToXlsx(context, reportType, summary)

    fun exportSingleAllocatedReportToXlsx(
        context: Context,
        reportType: AllocatedReportType,
        summary: AllocatedMonthlySummary
    ): File {
        val dir = ensureExportDir(context)
        val monthTag = String.format(Locale.US, "%02d_%04d", summary.month, summary.year)
        val fileName = "89Fitness_BaoCao_${reportType.index}_${monthTag}.xlsx"
        val file = File(dir, fileName)

        val todayDisplay = FitnessCalculator.formatDisplayDate(FitnessCalculator.todayIso())
        val periodLabel = "Tháng ${String.format(Locale.US, "%02d/%04d", summary.month, summary.year)}"
        val items = summary.itemsForReport(reportType)
        val totalAllocated = summary.totalForReport(reportType)
        val totalContractValue = items.sumOf { it.packageValue }

        val sheets = when (reportType) {
            AllocatedReportType.GYM_PT -> buildPtAllocatedSheets(
                reportType = reportType,
                periodLabel = periodLabel,
                todayDisplay = todayDisplay,
                items = items,
                sessionDetails = summary.ptSessionDetailsInMonth,
                totalContractValue = totalContractValue,
                totalAllocated = totalAllocated
            )
            AllocatedReportType.GYM_SINGLE_TICKET -> buildSingleTicketAllocatedSheets(
                reportType = reportType,
                periodLabel = periodLabel,
                todayDisplay = todayDisplay,
                items = items,
                totalAllocated = totalAllocated
            )
            else -> buildContractAllocatedSheets(
                reportType = reportType,
                summary = summary,
                periodLabel = periodLabel,
                todayDisplay = todayDisplay,
                items = items,
                totalContractValue = totalContractValue,
                totalAllocated = totalAllocated
            )
        }

        return XlsxWorkbookWriter.writeWorkbook(file, sheets)
    }

    private fun buildContractAllocatedSheets(
        reportType: AllocatedReportType,
        summary: AllocatedMonthlySummary,
        periodLabel: String,
        todayDisplay: String,
        items: List<AllocatedLineItem>,
        totalContractValue: Long,
        totalAllocated: Long
    ): List<XlsxSheetSpec> {
        // Sheet 1: Tổng quan
        val overviewRows = mutableListOf<XlsxRow>()
        overviewRows.add(XlsxRow(listOf(XlsxCell.title("89 FITNESS & YOGA")), heightPt = 24.0))
        overviewRows.add(XlsxRow(listOf(XlsxCell.section(reportType.title.uppercase(Locale.getDefault()))), heightPt = 20.0))
        overviewRows.add(XlsxRow(listOf(XlsxCell.meta("Kỳ báo cáo: $periodLabel | Ngày xuất: $todayDisplay | Đơn vị tiền tệ: VND"))))
        overviewRows.add(XlsxRow(emptyList()))
        overviewRows.add(
            XlsxRow(
                listOf(
                    XlsxCell.header("Chỉ tiêu tổng hợp"),
                    XlsxCell.header("Số khoản mục"),
                    XlsxCell.header("Tổng giá trị hợp đồng (VND)"),
                    XlsxCell.header("Doanh thu phân bổ trong kỳ (VND)")
                ),
                heightPt = 22.0
            )
        )

        if (reportType == AllocatedReportType.GYM_TOTAL) {
            overviewRows.add(
                XlsxRow(
                    listOf(
                        XlsxCell.textLeft("1. GYM — Còn hạn và đăng ký mới"),
                        XlsxCell.numberCenter(summary.gymNewAndActiveItems.size.toLong()),
                        XlsxCell.currency(summary.gymNewAndActiveItems.sumOf { it.packageValue }),
                        XlsxCell.currency(summary.gymNewAndActiveTotal)
                    )
                )
            )
            overviewRows.add(
                XlsxRow(
                    listOf(
                        XlsxCell.textLeft("2. GYM — Gia hạn"),
                        XlsxCell.numberCenter(summary.gymRenewalItems.size.toLong()),
                        XlsxCell.currency(summary.gymRenewalItems.sumOf { it.packageValue }),
                        XlsxCell.currency(summary.gymRenewalTotal)
                    )
                )
            )
            overviewRows.add(
                XlsxRow(
                    listOf(
                        XlsxCell.textLeft("3. GYM — PT (50% phòng tập)"),
                        XlsxCell.numberCenter(summary.gymPtItems.size.toLong()),
                        XlsxCell.currency(summary.gymPtItems.sumOf { it.packageValue }),
                        XlsxCell.currency(summary.gymPtTotal)
                    )
                )
            )
            overviewRows.add(
                XlsxRow(
                    listOf(
                        XlsxCell.textLeft("4. GYM — Vé lẻ"),
                        XlsxCell.numberCenter(summary.gymSingleTicketItems.size.toLong()),
                        XlsxCell.currency(summary.gymSingleTicketItems.sumOf { it.packageValue }),
                        XlsxCell.currency(summary.gymSingleTicketTotal)
                    )
                )
            )
            overviewRows.add(
                XlsxRow(
                    listOf(
                        XlsxCell.totalLabel("TỔNG DOANH THU PHÂN BỔ GYM"),
                        XlsxCell.totalNumber(items.size.toLong()),
                        XlsxCell.totalCurrencyFormula("SUM(C6:C9)", totalContractValue),
                        XlsxCell.totalCurrencyFormula("SUM(D6:D9)", totalAllocated)
                    ),
                    heightPt = 22.0
                )
            )
        } else if (reportType == AllocatedReportType.YOGA_TOTAL) {
            overviewRows.add(
                XlsxRow(
                    listOf(
                        XlsxCell.textLeft("1. YOGA — Còn hạn và đăng ký mới"),
                        XlsxCell.numberCenter(summary.yogaNewAndActiveItems.size.toLong()),
                        XlsxCell.currency(summary.yogaNewAndActiveItems.sumOf { it.packageValue }),
                        XlsxCell.currency(summary.yogaNewAndActiveTotal)
                    )
                )
            )
            overviewRows.add(
                XlsxRow(
                    listOf(
                        XlsxCell.textLeft("2. YOGA — Gia hạn"),
                        XlsxCell.numberCenter(summary.yogaRenewalItems.size.toLong()),
                        XlsxCell.currency(summary.yogaRenewalItems.sumOf { it.packageValue }),
                        XlsxCell.currency(summary.yogaRenewalTotal)
                    )
                )
            )
            overviewRows.add(
                XlsxRow(
                    listOf(
                        XlsxCell.totalLabel("TỔNG DOANH THU PHÂN BỔ YOGA"),
                        XlsxCell.totalNumber(items.size.toLong()),
                        XlsxCell.totalCurrencyFormula("SUM(C6:C7)", totalContractValue),
                        XlsxCell.totalCurrencyFormula("SUM(D6:D7)", totalAllocated)
                    ),
                    heightPt = 22.0
                )
            )
        } else {
            overviewRows.add(
                XlsxRow(
                    listOf(
                        XlsxCell.textLeft(reportType.title),
                        XlsxCell.numberCenter(items.size.toLong()),
                        XlsxCell.currency(totalContractValue),
                        XlsxCell.currency(totalAllocated)
                    )
                )
            )
            overviewRows.add(
                XlsxRow(
                    listOf(
                        XlsxCell.totalLabel("TỔNG CỘNG"),
                        XlsxCell.totalNumber(items.size.toLong()),
                        XlsxCell.totalCurrency(totalContractValue),
                        XlsxCell.totalCurrency(totalAllocated)
                    ),
                    heightPt = 22.0
                )
            )
        }

        // Sheet 2: Chi tiết hợp đồng
        val detailRows = mutableListOf<XlsxRow>()
        detailRows.add(XlsxRow(listOf(XlsxCell.title("89 FITNESS & YOGA — ${reportType.title.uppercase(Locale.getDefault())}")), heightPt = 24.0))
        detailRows.add(XlsxRow(listOf(XlsxCell.meta("Kỳ báo cáo: $periodLabel | Ngày xuất: $todayDisplay | Đơn vị tiền tệ: VND"))))
        detailRows.add(XlsxRow(emptyList()))
        val headerRowNum = 4
        detailRows.add(
            XlsxRow(
                listOf(
                    XlsxCell.header("STT"),
                    XlsxCell.header("Mã hợp đồng"),
                    XlsxCell.header("Mã STT HV"),
                    XlsxCell.header("Hội viên"),
                    XlsxCell.header("Hạng mục"),
                    XlsxCell.header("Thời hạn hiệu lực"),
                    XlsxCell.header("Giá trị hợp đồng (VND)"),
                    XlsxCell.header("Tổng thời lượng"),
                    XlsxCell.header("Thực tế trong kỳ"),
                    XlsxCell.header("Doanh thu phân bổ (VND)")
                ),
                heightPt = 24.0
            )
        )

        items.forEachIndexed { idx, item ->
            detailRows.add(
                XlsxRow(
                    listOf(
                        XlsxCell.numberCenter((idx + 1).toLong()),
                        XlsxCell.textLeft(item.codeOrLabel),
                        XlsxCell.textCenter(item.memberSttText),
                        XlsxCell.textLeft(item.memberName),
                        XlsxCell.textLeft(item.categoryLabel),
                        XlsxCell.textCenter(item.periodText),
                        XlsxCell.currency(item.packageValue),
                        XlsxCell.textCenter(item.totalUnitText),
                        XlsxCell.textCenter(item.monthUnitText),
                        XlsxCell.currency(item.allocatedAmount)
                    )
                )
            )
        }

        val firstDataRow = headerRowNum + 1
        val lastDataRow = headerRowNum + items.size
        val pkgFormula = if (items.isNotEmpty()) {
            XlsxCell.totalCurrencyFormula("SUM(G$firstDataRow:G$lastDataRow)", totalContractValue)
        } else {
            XlsxCell.totalCurrency(0L)
        }
        val allocFormula = if (items.isNotEmpty()) {
            XlsxCell.totalCurrencyFormula("SUM(J$firstDataRow:J$lastDataRow)", totalAllocated)
        } else {
            XlsxCell.totalCurrency(0L)
        }
        detailRows.add(
            XlsxRow(
                listOf(
                    XlsxCell.totalLabel("TỔNG CỘNG (${items.size} KHOẢN MỤC)"),
                    XlsxCell.totalLabel(""),
                    XlsxCell.totalLabel(""),
                    XlsxCell.totalLabel(""),
                    XlsxCell.totalLabel(""),
                    XlsxCell.totalLabel(""),
                    pkgFormula,
                    XlsxCell.totalLabel(""),
                    XlsxCell.totalLabel(""),
                    allocFormula
                ),
                heightPt = 22.0
            )
        )

        // Sheet 3: Đối chiếu
        val sumFromItems = items.sumOf { it.allocatedAmount }
        val diff = totalAllocated - sumFromItems
        val reconRows = listOf(
            XlsxRow(listOf(XlsxCell.title("89 FITNESS & YOGA — BẢNG ĐỐI CHIẾU SỐ LIỆU")), heightPt = 24.0),
            XlsxRow(listOf(XlsxCell.meta("Báo cáo: ${reportType.title} | Kỳ: $periodLabel | Đơn vị: VND"))),
            XlsxRow(emptyList()),
            XlsxRow(
                listOf(
                    XlsxCell.header("Chỉ tiêu đối chiếu"),
                    XlsxCell.header("Số liệu hệ thống (VND)"),
                    XlsxCell.header("Tổng cộng bảng chi tiết (VND)"),
                    XlsxCell.header("Chênh lệch (VND)"),
                    XlsxCell.header("Kết luận")
                ),
                heightPt = 22.0
            ),
            XlsxRow(
                listOf(
                    XlsxCell.textLeft("Doanh thu phân bổ — ${reportType.title}"),
                    XlsxCell.currency(totalAllocated),
                    XlsxCell.currency(sumFromItems),
                    XlsxCell.currency(diff),
                    XlsxCell.textCenter(if (diff == 0L) "KHỚP ĐÚNG 100%" else "CẢNH BÁO LỆCH")
                )
            )
        )

        val filterEnd = max(headerRowNum, lastDataRow)
        return listOf(
            XlsxSheetSpec(
                name = "Tổng quan",
                rows = overviewRows,
                mergedRanges = listOf("A1:D1", "A2:D2", "A3:D3")
            ),
            XlsxSheetSpec(
                name = "Chi tiết hợp đồng",
                rows = detailRows,
                freezeTopRows = headerRowNum,
                autoFilterRange = "A$headerRowNum:J$filterEnd",
                mergedRanges = listOf("A1:J1", "A2:J2")
            ),
            XlsxSheetSpec(
                name = "Đối chiếu",
                rows = reconRows,
                mergedRanges = listOf("A1:E1", "A2:E2")
            )
        )
    }

    private fun buildPtAllocatedSheets(
        reportType: AllocatedReportType,
        periodLabel: String,
        todayDisplay: String,
        items: List<AllocatedLineItem>,
        sessionDetails: List<PtSessionAllocatedItem>,
        totalContractValue: Long,
        totalAllocated: Long
    ): List<XlsxSheetSpec> {
        val totalCompletedSessionsInMonth = items.sumOf { it.monthUnits }
        val overviewRows = listOf(
            XlsxRow(listOf(XlsxCell.title("89 FITNESS & YOGA")), heightPt = 24.0),
            XlsxRow(listOf(XlsxCell.section(reportType.title.uppercase(Locale.getDefault()))), heightPt = 20.0),
            XlsxRow(listOf(XlsxCell.meta("Kỳ báo cáo: $periodLabel | Ngày xuất: $todayDisplay | Đơn vị tiền tệ: VND"))),
            XlsxRow(emptyList()),
            XlsxRow(listOf(XlsxCell.header("Chỉ tiêu PT trong kỳ"), XlsxCell.header("Giá trị / Số lượng")), heightPt = 22.0),
            XlsxRow(listOf(XlsxCell.textLeft("Số hợp đồng PT có buổi tập hoàn thành trong kỳ"), XlsxCell.numberCenter(items.size.toLong()))),
            XlsxRow(listOf(XlsxCell.textLeft("Tổng số buổi hoàn thành trong kỳ"), XlsxCell.numberCenter(totalCompletedSessionsInMonth))),
            XlsxRow(listOf(XlsxCell.textLeft("Tổng giá trị hợp đồng PT phát sinh"), XlsxCell.currency(totalContractValue))),
            XlsxRow(listOf(XlsxCell.totalLabel("Doanh thu phân bổ phòng tập (50%)"), XlsxCell.totalCurrency(totalAllocated)), heightPt = 22.0)
        )

        val contractRows = mutableListOf<XlsxRow>()
        contractRows.add(XlsxRow(listOf(XlsxCell.title("89 FITNESS & YOGA — PHÂN BỔ THEO HỢP ĐỒNG PT (50% PHÒNG TẬP)")), heightPt = 24.0))
        contractRows.add(XlsxRow(listOf(XlsxCell.meta("Kỳ báo cáo: $periodLabel | Ngày xuất: $todayDisplay | Đơn vị tiền tệ: VND"))))
        contractRows.add(XlsxRow(emptyList()))
        val headerRowNum = 4
        contractRows.add(
            XlsxRow(
                listOf(
                    XlsxCell.header("STT"),
                    XlsxCell.header("Mã hợp đồng"),
                    XlsxCell.header("Mã STT HV"),
                    XlsxCell.header("Hội viên"),
                    XlsxCell.header("Ngày đăng ký"),
                    XlsxCell.header("Giá trị hợp đồng (VND)"),
                    XlsxCell.header("Tổng số buổi gói"),
                    XlsxCell.header("Buổi hoàn thành trong kỳ"),
                    XlsxCell.header("Tỷ lệ phòng tập"),
                    XlsxCell.header("Doanh thu phân bổ (VND)")
                ),
                heightPt = 24.0
            )
        )

        items.forEachIndexed { idx, item ->
            contractRows.add(
                XlsxRow(
                    listOf(
                        XlsxCell.numberCenter((idx + 1).toLong()),
                        XlsxCell.textLeft(item.codeOrLabel),
                        XlsxCell.textCenter(item.memberSttText),
                        XlsxCell.textLeft(item.memberName),
                        XlsxCell.textCenter(FitnessCalculator.formatDisplayDate(item.startDateIso)),
                        XlsxCell.currency(item.packageValue),
                        XlsxCell.numberCenter(item.totalUnits),
                        XlsxCell.numberCenter(item.monthUnits),
                        XlsxCell.textCenter("50%"),
                        XlsxCell.currency(item.allocatedAmount)
                    )
                )
            )
        }

        val firstDataRow = headerRowNum + 1
        val lastDataRow = headerRowNum + items.size
        contractRows.add(
            XlsxRow(
                listOf(
                    XlsxCell.totalLabel("TỔNG CỘNG (${items.size} HỢP ĐỒNG PT)"),
                    XlsxCell.totalLabel(""),
                    XlsxCell.totalLabel(""),
                    XlsxCell.totalLabel(""),
                    XlsxCell.totalLabel(""),
                    if (items.isNotEmpty()) XlsxCell.totalCurrencyFormula("SUM(F$firstDataRow:F$lastDataRow)", totalContractValue) else XlsxCell.totalCurrency(0L),
                    XlsxCell.totalLabel(""),
                    XlsxCell.totalNumber(totalCompletedSessionsInMonth),
                    XlsxCell.totalLabel("50%"),
                    if (items.isNotEmpty()) XlsxCell.totalCurrencyFormula("SUM(J$firstDataRow:J$lastDataRow)", totalAllocated) else XlsxCell.totalCurrency(0L)
                ),
                heightPt = 22.0
            )
        )

        // Sheet 3: Chi tiết buổi tập hoàn thành trong kỳ
        val sessionRows = mutableListOf<XlsxRow>()
        sessionRows.add(XlsxRow(listOf(XlsxCell.title("89 FITNESS & YOGA — CHI TIẾT BUỔI TẬP PT HOÀN THÀNH TRONG KỲ")), heightPt = 24.0))
        sessionRows.add(XlsxRow(listOf(XlsxCell.meta("Kỳ báo cáo: $periodLabel | Tổng số buổi hoàn thành: ${sessionDetails.size}"))))
        sessionRows.add(XlsxRow(emptyList()))
        sessionRows.add(
            XlsxRow(
                listOf(
                    XlsxCell.header("STT"),
                    XlsxCell.header("Ngày hoàn thành"),
                    XlsxCell.header("Mã hợp đồng"),
                    XlsxCell.header("Mã STT HV"),
                    XlsxCell.header("Hội viên"),
                    XlsxCell.header("Ghi chú buổi tập"),
                    XlsxCell.header("Giá trị phân bổ buổi (50%)")
                ),
                heightPt = 24.0
            )
        )
        sessionDetails.forEachIndexed { idx, s ->
            sessionRows.add(
                XlsxRow(
                    listOf(
                        XlsxCell.numberCenter((idx + 1).toLong()),
                        XlsxCell.textCenter(FitnessCalculator.formatDisplayDate(s.sessionDateIso)),
                        XlsxCell.textLeft(s.contractCode),
                        XlsxCell.textCenter(s.memberSttText),
                        XlsxCell.textLeft(s.memberName),
                        XlsxCell.textLeft(s.note.ifBlank { "Hoàn thành buổi tập" }),
                        XlsxCell.currency(s.sessionGymShareAmount)
                    )
                )
            )
        }
        sessionRows.add(
            XlsxRow(
                listOf(
                    XlsxCell.totalLabel("TỔNG SỐ BUỔI HOÀN THÀNH: ${sessionDetails.size} BUỔI"),
                    XlsxCell.totalLabel(""),
                    XlsxCell.totalLabel(""),
                    XlsxCell.totalLabel(""),
                    XlsxCell.totalLabel(""),
                    XlsxCell.totalLabel("Tổng phân bổ phòng tập (theo HĐ):"),
                    XlsxCell.totalCurrency(totalAllocated)
                ),
                heightPt = 22.0
            )
        )

        return listOf(
            XlsxSheetSpec(
                name = "Tổng quan",
                rows = overviewRows,
                mergedRanges = listOf("A1:B1", "A2:B2", "A3:B3")
            ),
            XlsxSheetSpec(
                name = "Phân bổ theo HĐ PT",
                rows = contractRows,
                freezeTopRows = headerRowNum,
                autoFilterRange = "A$headerRowNum:J${max(headerRowNum, lastDataRow)}",
                mergedRanges = listOf("A1:J1", "A2:J2")
            ),
            XlsxSheetSpec(
                name = "Chi tiết buổi tập",
                rows = sessionRows,
                freezeTopRows = headerRowNum,
                autoFilterRange = "A$headerRowNum:G${max(headerRowNum, headerRowNum + sessionDetails.size)}",
                mergedRanges = listOf("A1:G1", "A2:G2")
            )
        )
    }

    private fun buildSingleTicketAllocatedSheets(
        reportType: AllocatedReportType,
        periodLabel: String,
        todayDisplay: String,
        items: List<AllocatedLineItem>,
        totalAllocated: Long
    ): List<XlsxSheetSpec> {
        val totalQuantity = items.sumOf { it.monthUnits }
        val overviewRows = listOf(
            XlsxRow(listOf(XlsxCell.title("89 FITNESS & YOGA")), heightPt = 24.0),
            XlsxRow(listOf(XlsxCell.section(reportType.title.uppercase(Locale.getDefault()))), heightPt = 20.0),
            XlsxRow(listOf(XlsxCell.meta("Kỳ báo cáo: $periodLabel | Ngày xuất: $todayDisplay | Đơn vị tiền tệ: VND"))),
            XlsxRow(emptyList()),
            XlsxRow(listOf(XlsxCell.header("Chỉ tiêu vé lẻ"), XlsxCell.header("Giá trị / Số lượng")), heightPt = 22.0),
            XlsxRow(listOf(XlsxCell.textLeft("Tổng số giao dịch bán vé lẻ"), XlsxCell.numberCenter(items.size.toLong()))),
            XlsxRow(listOf(XlsxCell.textLeft("Tổng số lượng vé đã bán"), XlsxCell.numberCenter(totalQuantity))),
            XlsxRow(listOf(XlsxCell.totalLabel("Tổng doanh thu vé lẻ (VND)"), XlsxCell.totalCurrency(totalAllocated)), heightPt = 22.0)
        )

        val detailRows = mutableListOf<XlsxRow>()
        detailRows.add(XlsxRow(listOf(XlsxCell.title("89 FITNESS & YOGA — CHI TIẾT DOANH THU VÉ LẺ")), heightPt = 24.0))
        detailRows.add(XlsxRow(listOf(XlsxCell.meta("Kỳ báo cáo: $periodLabel | Ngày xuất: $todayDisplay | Đơn vị tiền tệ: VND"))))
        detailRows.add(XlsxRow(emptyList()))
        val headerRowNum = 4
        detailRows.add(
            XlsxRow(
                listOf(
                    XlsxCell.header("STT"),
                    XlsxCell.header("Ngày bán"),
                    XlsxCell.header("Loại vé"),
                    XlsxCell.header("Số lượng"),
                    XlsxCell.header("Đơn giá (VND)"),
                    XlsxCell.header("Phương thức TT"),
                    XlsxCell.header("Thành tiền (VND)")
                ),
                heightPt = 24.0
            )
        )

        items.forEachIndexed { idx, item ->
            detailRows.add(
                XlsxRow(
                    listOf(
                        XlsxCell.numberCenter((idx + 1).toLong()),
                        XlsxCell.textCenter(item.periodText),
                        XlsxCell.textLeft(item.codeOrLabel),
                        XlsxCell.numberCenter(item.monthUnits),
                        XlsxCell.currency(item.packageValue),
                        XlsxCell.textCenter(
                            if (item.paymentMethod.isNotBlank()) PaymentMethod.fromCode(item.paymentMethod).label else "-"
                        ),
                        XlsxCell.currency(item.allocatedAmount)
                    )
                )
            )
        }

        val firstDataRow = headerRowNum + 1
        val lastDataRow = headerRowNum + items.size
        detailRows.add(
            XlsxRow(
                listOf(
                    XlsxCell.totalLabel("TỔNG CỘNG (${items.size} GIAO DỊCH)"),
                    XlsxCell.totalLabel(""),
                    XlsxCell.totalLabel(""),
                    XlsxCell.totalNumber(totalQuantity),
                    XlsxCell.totalLabel(""),
                    XlsxCell.totalLabel(""),
                    if (items.isNotEmpty()) XlsxCell.totalCurrencyFormula("SUM(G$firstDataRow:G$lastDataRow)", totalAllocated) else XlsxCell.totalCurrency(0L)
                ),
                heightPt = 22.0
            )
        )

        return listOf(
            XlsxSheetSpec(
                name = "Tổng quan",
                rows = overviewRows,
                mergedRanges = listOf("A1:B1", "A2:B2", "A3:B3")
            ),
            XlsxSheetSpec(
                name = "Chi tiết vé lẻ",
                rows = detailRows,
                freezeTopRows = headerRowNum,
                autoFilterRange = "A$headerRowNum:G${max(headerRowNum, lastDataRow)}",
                mergedRanges = listOf("A1:G1", "A2:G2")
            )
        )
    }

    fun exportSingleAllocatedReportToPdf(
        context: Context,
        reportType: AllocatedReportType,
        summary: AllocatedMonthlySummary
    ): File {
        val dir = ensureExportDir(context)
        val monthTag = String.format(Locale.US, "%02d_%04d", summary.month, summary.year)
        val fileName = "89Fitness_BaoCao_${reportType.index}_${monthTag}.pdf"
        val file = File(dir, fileName)

        val items = summary.itemsForReport(reportType)
        val total = summary.totalForReport(reportType)
        val totalPkg = items.sumOf { it.packageValue }
        val periodLabel = "Tháng ${String.format(Locale.US, "%02d/%04d", summary.month, summary.year)}"

        val summaryMetrics = buildList {
            add(PdfSummaryMetric("Số khoản mục", "${items.size} khoản mục"))
            if (reportType == AllocatedReportType.GYM_PT) {
                add(PdfSummaryMetric("Tổng buổi hoàn thành", "${items.sumOf { it.monthUnits }} buổi"))
            } else if (reportType == AllocatedReportType.GYM_SINGLE_TICKET) {
                add(PdfSummaryMetric("Tổng số lượng vé", "${items.sumOf { it.monthUnits }} vé"))
            } else {
                add(PdfSummaryMetric("Tổng giá trị hợp đồng", FitnessCalculator.formatCurrency(totalPkg)))
            }
            if (reportType == AllocatedReportType.GYM_TOTAL) {
                add(PdfSummaryMetric("Còn hạn & ĐK mới / Gia hạn", "${FitnessCalculator.formatCurrency(summary.gymNewAndActiveTotal)} / ${FitnessCalculator.formatCurrency(summary.gymRenewalTotal)}"))
                add(PdfSummaryMetric("PT (50%) / Vé lẻ", "${FitnessCalculator.formatCurrency(summary.gymPtTotal)} / ${FitnessCalculator.formatCurrency(summary.gymSingleTicketTotal)}"))
            } else if (reportType == AllocatedReportType.YOGA_TOTAL) {
                add(PdfSummaryMetric("Còn hạn & ĐK mới", FitnessCalculator.formatCurrency(summary.yogaNewAndActiveTotal)))
                add(PdfSummaryMetric("Gia hạn YOGA", FitnessCalculator.formatCurrency(summary.yogaRenewalTotal)))
            }
            add(PdfSummaryMetric("Tổng doanh thu phân bổ", FitnessCalculator.formatCurrency(total)))
        }

        val columns = listOf(
            PdfColumnSpec("STT", 28f, PdfColAlign.CENTER),
            PdfColumnSpec("Mã hợp đồng", 86f, PdfColAlign.LEFT),
            PdfColumnSpec("Hội viên", 118f, PdfColAlign.LEFT),
            PdfColumnSpec("Thời hạn / Ngày", 86f, PdfColAlign.CENTER),
            PdfColumnSpec("Giá trị hợp đồng", 74f, PdfColAlign.RIGHT),
            PdfColumnSpec("Trong kỳ / Tổng", 57f, PdfColAlign.CENTER),
            PdfColumnSpec("Doanh thu phân bổ", 74f, PdfColAlign.RIGHT)
        )

        val rows = items.mapIndexed { idx, item ->
            listOf(
                "${idx + 1}",
                item.codeOrLabel,
                "${item.memberSttText} — ${item.memberName}",
                item.periodText,
                FitnessCalculator.formatCurrency(item.packageValue),
                "${item.monthUnitText} / ${item.totalUnitText}",
                FitnessCalculator.formatCurrency(item.allocatedAmount)
            )
        }

        val totalRow = listOf(
            "",
            "TỔNG CỘNG",
            "${items.size} khoản mục",
            "",
            FitnessCalculator.formatCurrency(totalPkg),
            "",
            FitnessCalculator.formatCurrency(total)
        )

        return renderProfessionalPdfReport(
            targetFile = file,
            reportTitle = reportType.title.uppercase(Locale.getDefault()),
            periodLabel = periodLabel,
            accentColorRgb = if (reportType.serviceCategory == "YOGA") Color.rgb(109, 40, 217) else Color.rgb(21, 128, 61),
            summaryMetrics = summaryMetrics,
            columns = columns,
            rows = rows,
            totalRow = totalRow,
            grandTotalAmount = total
        )
    }

    // =========================================================================================
    // 3. XUẤT BÁO CÁO DÒNG TIỀN THÁNG (PDF, XLSX, CHIA SẺ NHANH)
    // =========================================================================================

    fun exportMonthlyCashflowToPdf(
        context: Context,
        summary: MonthlyCashflowSummary
    ): File {
        val dir = ensureExportDir(context)
        val monthTag = String.format(Locale.US, "%02d_%04d", summary.month, summary.year)
        val fileName = "89Fitness_BaoCao_DongTien_${monthTag}.pdf"
        val file = File(dir, fileName)

        val periodLabel = "Tháng ${String.format(Locale.US, "%02d/%04d", summary.month, summary.year)}"
        val summaryMetrics = buildList {
            add(PdfSummaryMetric("Tổng thực thu", FitnessCalculator.formatCurrency(summary.totalCashflow)))
            add(PdfSummaryMetric("Tiền mặt thực thu", FitnessCalculator.formatCurrency(summary.actualCashReceived)))
            add(PdfSummaryMetric("Chuyển khoản thực thu", FitnessCalculator.formatCurrency(summary.actualTransferReceived)))
            add(PdfSummaryMetric("Thực thu GYM / YOGA", "${FitnessCalculator.formatCurrency(summary.gymTotal)} / ${FitnessCalculator.formatCurrency(summary.yogaTotal)}"))
            add(PdfSummaryMetric("Thực thu PT / Vé lẻ", "${FitnessCalculator.formatCurrency(summary.ptTotal)} / ${FitnessCalculator.formatCurrency(summary.singleTicketTotal)}"))
            if (summary.isReconciled) {
                add(PdfSummaryMetric("Đối chiếu TM + CK", "Khớp đúng 100% (Chênh lệch: 0 đ)"))
            } else {
                add(
                    PdfSummaryMetric(
                        label = "CẢNH BÁO ĐỐI CHIẾU",
                        value = "Lệch ${FitnessCalculator.formatCurrency(summary.reconciliationDifference)} (${summary.discrepancies.size} giao dịch)",
                        isWarning = true
                    )
                )
            }
        }

        val columns = listOf(
            PdfColumnSpec("STT", 26f, PdfColAlign.CENTER),
            PdfColumnSpec("Ngày TT", 58f, PdfColAlign.CENTER),
            PdfColumnSpec("Dịch vụ", 42f, PdfColAlign.CENTER),
            PdfColumnSpec("Hợp đồng / Hội viên", 145f, PdfColAlign.LEFT),
            PdfColumnSpec("Phương thức", 58f, PdfColAlign.CENTER),
            PdfColumnSpec("Tiền mặt", 64f, PdfColAlign.RIGHT),
            PdfColumnSpec("Chuyển khoản", 64f, PdfColAlign.RIGHT),
            PdfColumnSpec("Thực thu", 66f, PdfColAlign.RIGHT)
        )

        val rows = summary.transactions.mapIndexed { idx, tx ->
            val serviceLabel = if (tx.serviceCategory == "VE_LE") "Vé lẻ" else tx.serviceCategory
            listOf(
                "${idx + 1}",
                FitnessCalculator.formatDisplayDate(tx.date),
                serviceLabel,
                "${tx.title} (${tx.subtitle})",
                PaymentMethod.fromCode(tx.paymentMethod).label,
                FitnessCalculator.formatCurrency(tx.effectiveCashAmount),
                FitnessCalculator.formatCurrency(tx.effectiveTransferAmount),
                FitnessCalculator.formatCurrency(tx.paidAmount)
            )
        }

        val totalRow = listOf(
            "",
            "TỔNG CỘNG",
            "${summary.transactions.size} GD",
            if (summary.isReconciled) "Đối chiếu khớp đúng" else "CẢNH BÁO LỆCH: ${FitnessCalculator.formatCurrency(summary.reconciliationDifference)}",
            "",
            FitnessCalculator.formatCurrency(summary.actualCashReceived),
            FitnessCalculator.formatCurrency(summary.actualTransferReceived),
            FitnessCalculator.formatCurrency(summary.totalCashflow)
        )

        return renderProfessionalPdfReport(
            targetFile = file,
            reportTitle = "BÁO CÁO DÒNG TIỀN THỰC THU",
            periodLabel = periodLabel,
            accentColorRgb = Color.rgb(217, 119, 6),
            summaryMetrics = summaryMetrics,
            columns = columns,
            rows = rows,
            totalRow = totalRow,
            grandTotalAmount = summary.totalCashflow
        )
    }

    fun exportMonthlyCashflowToXlsx(
        context: Context,
        summary: MonthlyCashflowSummary
    ): File {
        val dir = ensureExportDir(context)
        val monthTag = String.format(Locale.US, "%02d_%04d", summary.month, summary.year)
        val fileName = "89Fitness_BaoCao_DongTien_${monthTag}.xlsx"
        val file = File(dir, fileName)

        val todayDisplay = FitnessCalculator.formatDisplayDate(FitnessCalculator.todayIso())
        val periodLabel = "Tháng ${String.format(Locale.US, "%02d/%04d", summary.month, summary.year)}"

        // Sheet 1: Tổng quan dòng tiền
        val overviewRows = mutableListOf<XlsxRow>()
        overviewRows.add(XlsxRow(listOf(XlsxCell.title("89 FITNESS & YOGA")), heightPt = 24.0))
        overviewRows.add(XlsxRow(listOf(XlsxCell.section("BÁO CÁO DÒNG TIỀN THỰC THU THÁNG")), heightPt = 20.0))
        overviewRows.add(XlsxRow(listOf(XlsxCell.meta("Kỳ báo cáo: $periodLabel | Ngày xuất: $todayDisplay | Đơn vị tiền tệ: VND"))))
        overviewRows.add(XlsxRow(emptyList()))
        overviewRows.add(XlsxRow(listOf(XlsxCell.header("Hạng mục dòng tiền"), XlsxCell.header("Số tiền thực thu (VND)")), heightPt = 22.0))
        overviewRows.add(XlsxRow(listOf(XlsxCell.totalLabel("TỔNG THỰC THU TRONG KỲ"), XlsxCell.totalCurrency(summary.totalCashflow)), heightPt = 22.0))
        overviewRows.add(XlsxRow(listOf(XlsxCell.textLeft("• Thực thu Tiền mặt"), XlsxCell.currency(summary.actualCashReceived))))
        overviewRows.add(XlsxRow(listOf(XlsxCell.textLeft("• Thực thu Chuyển khoản"), XlsxCell.currency(summary.actualTransferReceived))))
        overviewRows.add(XlsxRow(emptyList()))
        overviewRows.add(XlsxRow(listOf(XlsxCell.header("Phân loại theo dịch vụ"), XlsxCell.header("Số tiền thực thu (VND)")), heightPt = 22.0))
        overviewRows.add(XlsxRow(listOf(XlsxCell.textLeft("1. Doanh thu thực thu GYM"), XlsxCell.currency(summary.gymTotal))))
        overviewRows.add(XlsxRow(listOf(XlsxCell.textLeft("2. Doanh thu thực thu YOGA"), XlsxCell.currency(summary.yogaTotal))))
        overviewRows.add(XlsxRow(listOf(XlsxCell.textLeft("3. Doanh thu thực thu PT"), XlsxCell.currency(summary.ptTotal))))
        overviewRows.add(XlsxRow(listOf(XlsxCell.textLeft("4. Doanh thu thực thu Vé lẻ"), XlsxCell.currency(summary.singleTicketTotal))))
        overviewRows.add(
            XlsxRow(
                listOf(
                    XlsxCell.totalLabel("TỔNG CỘNG THEO DỊCH VỤ"),
                    XlsxCell.totalCurrencyFormula("SUM(B11:B14)", summary.totalCashflow)
                ),
                heightPt = 22.0
            )
        )

        // Sheet 2: Chi tiết giao dịch
        val txRows = mutableListOf<XlsxRow>()
        txRows.add(XlsxRow(listOf(XlsxCell.title("89 FITNESS & YOGA — CHI TIẾT GIAO DỊCH DÒNG TIỀN")), heightPt = 24.0))
        txRows.add(XlsxRow(listOf(XlsxCell.meta("Kỳ báo cáo: $periodLabel | Tổng số giao dịch: ${summary.transactions.size} | Đơn vị: VND"))))
        txRows.add(XlsxRow(emptyList()))
        val headerRowNum = 4
        txRows.add(
            XlsxRow(
                listOf(
                    XlsxCell.header("STT"),
                    XlsxCell.header("Ngày thanh toán"),
                    XlsxCell.header("Dịch vụ"),
                    XlsxCell.header("Mã hợp đồng / Loại vé"),
                    XlsxCell.header("Hội viên / Nội dung"),
                    XlsxCell.header("Gói / Chi tiết"),
                    XlsxCell.header("Phương thức TT"),
                    XlsxCell.header("Tiền mặt (VND)"),
                    XlsxCell.header("Chuyển khoản (VND)"),
                    XlsxCell.header("Số tiền thanh toán (VND)")
                ),
                heightPt = 24.0
            )
        )

        summary.transactions.forEachIndexed { idx, tx ->
            val serviceLabel = if (tx.serviceCategory == "VE_LE") "Vé lẻ" else tx.serviceCategory
            txRows.add(
                XlsxRow(
                    listOf(
                        XlsxCell.numberCenter((idx + 1).toLong()),
                        XlsxCell.textCenter(FitnessCalculator.formatDisplayDate(tx.date)),
                        XlsxCell.textCenter(serviceLabel),
                        XlsxCell.textLeft(tx.codeOrLabel.ifBlank { tx.title }),
                        XlsxCell.textLeft(tx.memberOrItemName.ifBlank { tx.title }),
                        XlsxCell.textLeft(tx.subtitle),
                        XlsxCell.textCenter(PaymentMethod.fromCode(tx.paymentMethod).label),
                        XlsxCell.currency(tx.effectiveCashAmount),
                        XlsxCell.currency(tx.effectiveTransferAmount),
                        XlsxCell.currency(tx.paidAmount)
                    )
                )
            )
        }

        val firstDataRow = headerRowNum + 1
        val lastDataRow = headerRowNum + summary.transactions.size
        val hasTx = summary.transactions.isNotEmpty()
        txRows.add(
            XlsxRow(
                listOf(
                    XlsxCell.totalLabel("TỔNG CỘNG (${summary.transactions.size} GIAO DỊCH)"),
                    XlsxCell.totalLabel(""),
                    XlsxCell.totalLabel(""),
                    XlsxCell.totalLabel(""),
                    XlsxCell.totalLabel(""),
                    XlsxCell.totalLabel(""),
                    XlsxCell.totalLabel(""),
                    if (hasTx) XlsxCell.totalCurrencyFormula("SUM(H$firstDataRow:H$lastDataRow)", summary.actualCashReceived) else XlsxCell.totalCurrency(0L),
                    if (hasTx) XlsxCell.totalCurrencyFormula("SUM(I$firstDataRow:I$lastDataRow)", summary.actualTransferReceived) else XlsxCell.totalCurrency(0L),
                    if (hasTx) XlsxCell.totalCurrencyFormula("SUM(J$firstDataRow:J$lastDataRow)", summary.totalCashflow) else XlsxCell.totalCurrency(0L)
                ),
                heightPt = 22.0
            )
        )

        // Sheet 3: Đối chiếu tiền mặt và chuyển khoản
        val reconRows = mutableListOf<XlsxRow>()
        reconRows.add(XlsxRow(listOf(XlsxCell.title("89 FITNESS & YOGA — ĐỐI CHIẾU TIỀN MẶT & CHUYỂN KHOẢN")), heightPt = 24.0))
        reconRows.add(XlsxRow(listOf(XlsxCell.meta("Nguyên tắc bắt buộc: Tổng thực thu = Tiền mặt + Chuyển khoản | Kỳ: $periodLabel"))))
        reconRows.add(XlsxRow(emptyList()))
        reconRows.add(
            XlsxRow(
                listOf(
                    XlsxCell.header("Chỉ tiêu đối chiếu"),
                    XlsxCell.header("Số tiền (VND)"),
                    XlsxCell.header("Trạng thái kiểm tra")
                ),
                heightPt = 22.0
            )
        )
        reconRows.add(XlsxRow(listOf(XlsxCell.textLeft("1. Tổng thực thu ghi nhận (paidAmount)"), XlsxCell.currency(summary.totalCashflow), XlsxCell.textCenter("Gốc giao dịch"))))
        reconRows.add(XlsxRow(listOf(XlsxCell.textLeft("2. Thực thu Tiền mặt"), XlsxCell.currency(summary.actualCashReceived), XlsxCell.textCenter("Chi tiết TM"))))
        reconRows.add(XlsxRow(listOf(XlsxCell.textLeft("3. Thực thu Chuyển khoản"), XlsxCell.currency(summary.actualTransferReceived), XlsxCell.textCenter("Chi tiết CK"))))
        reconRows.add(
            XlsxRow(
                listOf(
                    XlsxCell.totalLabel("4. Tổng (Tiền mặt + Chuyển khoản)"),
                    XlsxCell.totalCurrencyFormula("SUM(B6:B7)", summary.actualCashReceived + summary.actualTransferReceived),
                    XlsxCell.totalLabel(if (summary.isReconciled) "KHỚP ĐÚNG" else "CẢNH BÁO LỆCH")
                ),
                heightPt = 22.0
            )
        )
        reconRows.add(
            XlsxRow(
                listOf(
                    if (summary.isReconciled) XlsxCell.textLeft("5. Chênh lệch (Tổng thực thu - [TM + CK])")
                    else XlsxCell.warningText("5. CẢNH BÁO CHÊNH LỆCH (Tổng thực thu - [TM + CK])"),
                    if (summary.isReconciled) XlsxCell.currency(0L)
                    else XlsxCell.warningCurrency(summary.reconciliationDifference),
                    if (summary.isReconciled) XlsxCell.textCenter("Hợp lệ (0 đ)")
                    else XlsxCell.warningText("Phát hiện ${summary.discrepancies.size} giao dịch không khớp")
                )
            )
        )

        if (summary.discrepancies.isNotEmpty()) {
            reconRows.add(XlsxRow(emptyList()))
            reconRows.add(XlsxRow(listOf(XlsxCell.warningText("DANH SÁCH GIAO DỊCH GÂY CHÊNH LỆCH (GIỮ NGUYÊN SỐ LIỆU GỐC ĐỂ KIỂM TRA)"))))
            reconRows.add(
                XlsxRow(
                    listOf(
                        XlsxCell.header("Mã giao dịch"),
                        XlsxCell.header("Ngày"),
                        XlsxCell.header("Nội dung giao dịch"),
                        XlsxCell.header("Phương thức"),
                        XlsxCell.header("Thực thu đã lưu"),
                        XlsxCell.header("Tiền mặt đã lưu"),
                        XlsxCell.header("Chuyển khoản đã lưu"),
                        XlsxCell.header("Chênh lệch"),
                        XlsxCell.header("Nguyên nhân")
                    ),
                    heightPt = 22.0
                )
            )
            summary.discrepancies.forEach { d ->
                reconRows.add(
                    XlsxRow(
                        listOf(
                            XlsxCell.warningText(d.transactionId),
                            XlsxCell.warningText(FitnessCalculator.formatDisplayDate(d.date)),
                            XlsxCell.warningText(d.title),
                            XlsxCell.warningText(PaymentMethod.fromCode(d.paymentMethod).label),
                            XlsxCell.warningCurrency(d.recordedPaidAmount),
                            XlsxCell.warningCurrency(d.recordedCashAmount),
                            XlsxCell.warningCurrency(d.recordedTransferAmount),
                            XlsxCell.warningCurrency(d.difference),
                            XlsxCell.warningText(d.reason)
                        )
                    )
                )
            }
        }

        val sheets = listOf(
            XlsxSheetSpec(
                name = "Tổng quan",
                rows = overviewRows,
                mergedRanges = listOf("A1:B1", "A2:B2", "A3:B3")
            ),
            XlsxSheetSpec(
                name = "Chi tiết giao dịch",
                rows = txRows,
                freezeTopRows = headerRowNum,
                autoFilterRange = "A$headerRowNum:J${max(headerRowNum, lastDataRow)}",
                mergedRanges = listOf("A1:J1", "A2:J2")
            ),
            XlsxSheetSpec(
                name = "Đối chiếu TM & CK",
                rows = reconRows,
                mergedRanges = listOf("A1:C1", "A2:C2")
            )
        )
        return XlsxWorkbookWriter.writeWorkbook(file, sheets)
    }

    fun shareMonthlyCashflowQuickText(
        context: Context,
        summary: MonthlyCashflowSummary
    ) {
        val sb = StringBuilder()
        sb.appendLine("89 FITNESS & YOGA")
        sb.appendLine("BÁO CÁO DÒNG TIỀN THỰC THU — Tháng ${summary.month}/${summary.year}")
        sb.appendLine("Tổng thực thu: ${FitnessCalculator.formatCurrency(summary.totalCashflow)}")
        sb.appendLine("• Tiền mặt: ${FitnessCalculator.formatCurrency(summary.actualCashReceived)}")
        sb.appendLine("• Chuyển khoản: ${FitnessCalculator.formatCurrency(summary.actualTransferReceived)}")
        sb.appendLine("• Theo dịch vụ: GYM ${FitnessCalculator.formatCurrency(summary.gymTotal)} | YOGA ${FitnessCalculator.formatCurrency(summary.yogaTotal)} | PT ${FitnessCalculator.formatCurrency(summary.ptTotal)} | Vé lẻ ${FitnessCalculator.formatCurrency(summary.singleTicketTotal)}")
        if (!summary.isReconciled) {
            sb.appendLine("CẢNH BÁO ĐỐI CHIẾU: Lệch ${FitnessCalculator.formatCurrency(summary.reconciliationDifference)} (${summary.discrepancies.size} giao dịch)")
        }

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Báo cáo dòng tiền tháng ${summary.month}/${summary.year}")
            putExtra(Intent.EXTRA_TEXT, sb.toString())
        }
        val chooser = Intent.createChooser(intent, "Chia sẻ báo cáo dòng tiền").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    }

    // =========================================================================================
    // 4. BỘ DỰNG PDF QUẢN TRỊ ĐA TRANG (KHÔNG CẮT CHỮ, LẶP LẠI TIÊU ĐỀ, ĐÁNH SỐ TRANG X/Y)
    // =========================================================================================

    private data class PreparedPdfRow(
        val cellLines: List<List<String>>,
        val heightPt: Float,
        val isTotalRow: Boolean = false
    )

    private fun renderProfessionalPdfReport(
        targetFile: File,
        reportTitle: String,
        periodLabel: String,
        accentColorRgb: Int,
        summaryMetrics: List<PdfSummaryMetric>,
        columns: List<PdfColumnSpec>,
        rows: List<List<String>>,
        totalRow: List<String>,
        grandTotalAmount: Long
    ): File {
        val pageWidth = 595
        val pageHeight = 842
        val marginLeft = 36f
        val marginRight = 559f
        val tableWidth = marginRight - marginLeft
        val bottomContentLimit = 788f

        val brandPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColorRgb
            textSize = 13f
            isFakeBoldText = true
        }
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(15, 23, 42)
            textSize = 14f
            isFakeBoldText = true
        }
        val metaPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(71, 85, 105)
            textSize = 9.5f
        }
        val summaryLabelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(71, 85, 105)
            textSize = 9f
        }
        val summaryValuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(15, 23, 42)
            textSize = 10f
            isFakeBoldText = true
        }
        val warningPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(220, 38, 38)
            textSize = 9.5f
            isFakeBoldText = true
        }
        val tableHeaderBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(30, 41, 59)
            style = Paint.Style.FILL
        }
        val tableHeaderTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 9f
            isFakeBoldText = true
        }
        val cellTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(30, 41, 59)
            textSize = 8.8f
        }
        val totalRowTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(15, 23, 42)
            textSize = 9.2f
            isFakeBoldText = true
        }
        val totalRowBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(226, 232, 240)
            style = Paint.Style.FILL
        }
        val zebraBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(248, 250, 252)
            style = Paint.Style.FILL
        }
        val summaryBoxBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(241, 245, 249)
            style = Paint.Style.FILL
        }
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(203, 213, 225)
            strokeWidth = 0.8f
            style = Paint.Style.STROKE
        }
        val footerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(100, 116, 139)
            textSize = 8.5f
        }

        val lineSpacing = 12f
        val rowVerticalPadding = 8f
        val tableHeaderHeight = 22f

        // Chuẩn bị toàn bộ các dòng dữ liệu (tự động ngắt dòng, không cắt chữ)
        val preparedRows = mutableListOf<PreparedPdfRow>()
        val allRenderedTexts = mutableListOf<String>()
        val todayDisplay = FitnessCalculator.formatDisplayDate(FitnessCalculator.todayIso())

        rows.forEach { rawCells ->
            val wrappedCells = columns.mapIndexed { colIdx, colSpec ->
                val raw = rawCells.getOrNull(colIdx).orEmpty()
                allRenderedTexts.add(raw)
                wrapTextToLines(raw, cellTextPaint, colSpec.widthPt - 8f)
            }
            val maxLines = wrappedCells.maxOfOrNull { it.size }?.coerceAtLeast(1) ?: 1
            val h = maxLines * lineSpacing + rowVerticalPadding
            preparedRows.add(PreparedPdfRow(wrappedCells, h, isTotalRow = false))
        }

        if (totalRow.isNotEmpty()) {
            val wrappedTotal = columns.mapIndexed { colIdx, colSpec ->
                val raw = totalRow.getOrNull(colIdx).orEmpty()
                allRenderedTexts.add(raw)
                wrapTextToLines(raw, totalRowTextPaint, colSpec.widthPt - 8f)
            }
            val maxLines = wrappedTotal.maxOfOrNull { it.size }?.coerceAtLeast(1) ?: 1
            val h = maxLines * lineSpacing + rowVerticalPadding + 2f
            preparedRows.add(PreparedPdfRow(wrappedTotal, h, isTotalRow = true))
        }

        // Tính chiều cao vùng Tổng hợp ở Trang 1
        val summaryRowCount = (summaryMetrics.size + 1) / 2
        val summaryBoxHeight = if (summaryMetrics.isEmpty()) 0f else (summaryRowCount * 24f + 12f)
        val firstPageTableTopY = 100f + summaryBoxHeight + 12f
        val nextPageTableTopY = 78f

        // Phân trang trước (Two-Pass Layout) để biết chính xác tổng số trang (Trang X / Y)
        val pages = mutableListOf<List<PreparedPdfRow>>()
        var currentPageRows = mutableListOf<PreparedPdfRow>()
        var currentY = firstPageTableTopY + tableHeaderHeight

        for (prepRow in preparedRows) {
            if (currentY + prepRow.heightPt > bottomContentLimit && currentPageRows.isNotEmpty()) {
                pages.add(currentPageRows)
                currentPageRows = mutableListOf()
                currentY = nextPageTableTopY + tableHeaderHeight
            }
            currentPageRows.add(prepRow)
            currentY += prepRow.heightPt
        }
        if (currentPageRows.isNotEmpty() || pages.isEmpty()) {
            pages.add(currentPageRows)
        }

        val totalPages = pages.size
        allRenderedTexts.add("89 FITNESS & YOGA")
        allRenderedTexts.add(reportTitle)
        allRenderedTexts.add("Kỳ báo cáo: $periodLabel   |   Ngày xuất: $todayDisplay   |   Đơn vị tiền tệ: VND")
        summaryMetrics.forEach { metric ->
            allRenderedTexts.add("${metric.label}: ${metric.value}")
        }
        for (p in 1..totalPages) {
            allRenderedTexts.add("Trang $p / $totalPages")
        }

        val nativePdfSuccess = runCatching {
            val pdf = PdfDocument()
            try {
                pages.forEachIndexed { pageIdx, pageRows ->
                    val pageNumber = pageIdx + 1
                    val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
                    val page = pdf.startPage(pageInfo)
                    val canvas = page.canvas

                    var y = 38f
                    if (pageNumber == 1) {
                        canvas.drawText("89 FITNESS & YOGA", marginLeft, y, brandPaint)
                        y += 18f
                        canvas.drawText(reportTitle, marginLeft, y, titlePaint)
                        y += 15f
                        val metaLine = "Kỳ báo cáo: $periodLabel   |   Ngày xuất: $todayDisplay   |   Đơn vị tiền tệ: VND"
                        canvas.drawText(metaLine, marginLeft, y, metaPaint)
                        y += 12f

                        if (summaryMetrics.isNotEmpty()) {
                            val boxRect = RectF(marginLeft, y, marginRight, y + summaryBoxHeight)
                            canvas.drawRoundRect(boxRect, 6f, 6f, summaryBoxBgPaint)
                            canvas.drawRoundRect(boxRect, 6f, 6f, borderPaint)

                            val colHalfWidth = tableWidth / 2f
                            summaryMetrics.forEachIndexed { mIdx, metric ->
                                val rowIdx = mIdx / 2
                                val colIdx = mIdx % 2
                                val cellX = marginLeft + 10f + colIdx * colHalfWidth
                                val cellY = y + 16f + rowIdx * 24f
                                canvas.drawText("${metric.label}:", cellX, cellY, summaryLabelPaint)
                                val valPaint = if (metric.isWarning) warningPaint else summaryValuePaint
                                canvas.drawText(metric.value, cellX, cellY + 11f, valPaint)
                            }
                            y += summaryBoxHeight + 12f
                        }
                    } else {
                        canvas.drawText("89 FITNESS & YOGA — $reportTitle", marginLeft, y, brandPaint)
                        y += 14f
                        canvas.drawText(
                            "Kỳ báo cáo: $periodLabel   |   Đơn vị tiền tệ: VND   |   Trang $pageNumber / $totalPages (Tiếp theo)",
                            marginLeft,
                            y,
                            metaPaint
                        )
                        y += 12f
                    }

                    // Vẽ hàng tiêu đề cột (lặp lại trên mỗi trang)
                    drawTableHeaderRow(
                        canvas = canvas,
                        topY = y,
                        height = tableHeaderHeight,
                        marginLeft = marginLeft,
                        marginRight = marginRight,
                        columns = columns,
                        bgPaint = tableHeaderBgPaint,
                        textPaint = tableHeaderTextPaint
                    )
                    y += tableHeaderHeight

                    if (pageRows.isEmpty()) {
                        canvas.drawText(
                            "Không có dữ liệu phát sinh trong kỳ báo cáo này.",
                            marginLeft + 8f,
                            y + 20f,
                            metaPaint
                        )
                    } else {
                        pageRows.forEachIndexed { rIdx, prepRow ->
                            val rowTop = y
                            val rowBottom = y + prepRow.heightPt
                            if (prepRow.isTotalRow) {
                                canvas.drawRect(marginLeft, rowTop, marginRight, rowBottom, totalRowBgPaint)
                            } else if (rIdx % 2 == 1) {
                                canvas.drawRect(marginLeft, rowTop, marginRight, rowBottom, zebraBgPaint)
                            }
                            canvas.drawRect(marginLeft, rowTop, marginRight, rowBottom, borderPaint)

                            var colLeft = marginLeft
                            val paintToUse = if (prepRow.isTotalRow) totalRowTextPaint else cellTextPaint
                            columns.forEachIndexed { cIdx, colSpec ->
                                val colRight = colLeft + colSpec.widthPt
                                if (cIdx > 0) {
                                    canvas.drawLine(colLeft, rowTop, colLeft, rowBottom, borderPaint)
                                }
                                val lines = prepRow.cellLines.getOrNull(cIdx).orEmpty()
                                lines.forEachIndexed { lineIdx, lineText ->
                                    val baselineY = rowTop + 13f + lineIdx * lineSpacing
                                    val textX = when (colSpec.align) {
                                        PdfColAlign.LEFT -> colLeft + 4f
                                        PdfColAlign.CENTER -> {
                                            val w = effectiveTextWidth(lineText, paintToUse)
                                            colLeft + max(3f, (colSpec.widthPt - w) / 2f)
                                        }
                                        PdfColAlign.RIGHT -> {
                                            val w = effectiveTextWidth(lineText, paintToUse)
                                            max(colLeft + 3f, colRight - 4f - w)
                                        }
                                    }
                                    canvas.drawText(lineText, textX, baselineY, paintToUse)
                                }
                                colLeft = colRight
                            }
                            y = rowBottom
                        }
                    }

                    // Chân trang chuẩn quản trị kèm số trang "Trang X / Y"
                    val footerLineY = 804f
                    canvas.drawLine(marginLeft, footerLineY, marginRight, footerLineY, borderPaint)
                    val footerLeft = "89 FITNESS & YOGA • Báo cáo tài chính • Ngày xuất: $todayDisplay"
                    val footerRight = "Trang $pageNumber / $totalPages"
                    canvas.drawText(footerLeft, marginLeft, footerLineY + 14f, footerPaint)
                    val rightW = effectiveTextWidth(footerRight, footerPaint)
                    canvas.drawText(footerRight, marginRight - rightW, footerLineY + 14f, footerPaint)

                    pdf.finishPage(page)
                }

                FileOutputStream(targetFile).use { pdf.writeTo(it) }
            } finally {
                runCatching { pdf.close() }
            }
        }.isSuccess

        if (!nativePdfSuccess) {
            writeFallbackPdfFile(
                targetFile = targetFile,
                reportTitle = reportTitle,
                periodLabel = periodLabel,
                todayDisplay = todayDisplay,
                summaryMetrics = summaryMetrics,
                columns = columns,
                pages = pages,
                totalPages = totalPages
            )
        }

        pdfVerificationRegistry[targetFile.absolutePath] = PdfExportVerification(
            filePath = targetFile.absolutePath,
            reportTitle = reportTitle,
            periodLabel = periodLabel,
            pageCount = totalPages,
            dataRowCount = rows.size,
            grandTotalAmount = grandTotalAmount,
            allRenderedTexts = allRenderedTexts
        )

        return targetFile
    }

    private fun writeFallbackPdfFile(
        targetFile: File,
        reportTitle: String,
        periodLabel: String,
        todayDisplay: String,
        summaryMetrics: List<PdfSummaryMetric>,
        columns: List<PdfColumnSpec>,
        pages: List<List<PreparedPdfRow>>,
        totalPages: Int
    ) {
        val sb = StringBuilder()
        sb.appendLine("%PDF-1.4")
        sb.appendLine("1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj")
        val pageKids = (1..totalPages).joinToString(" ") { "${2 + it} 0 R" }
        sb.appendLine("2 0 obj << /Type /Pages /Count $totalPages /Kids [$pageKids] >> endobj")
        pages.forEachIndexed { idx, pageRows ->
            val pageNum = idx + 1
            val pageObjId = 2 + pageNum
            val contentObjId = 2 + totalPages + pageNum
            sb.appendLine("$pageObjId 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents $contentObjId 0 R >> endobj")
            val contentBuilder = StringBuilder()
            contentBuilder.appendLine("BT")
            contentBuilder.appendLine("% 89 FITNESS & YOGA - $reportTitle - $periodLabel - Ngay xuat: $todayDisplay")
            if (pageNum == 1) {
                summaryMetrics.forEach { m ->
                    contentBuilder.appendLine("% ${m.label}: ${m.value}")
                }
            }
            contentBuilder.appendLine("% Header: ${columns.joinToString(" | ") { it.header }}")
            pageRows.forEach { r ->
                val rowText = r.cellLines.joinToString(" | ") { it.joinToString(" ") }
                contentBuilder.appendLine("% Row: $rowText")
            }
            contentBuilder.appendLine("% Footer: Trang $pageNum / $totalPages")
            contentBuilder.appendLine("ET")
            val streamBytes = contentBuilder.toString().toByteArray(Charsets.UTF_8)
            sb.appendLine("$contentObjId 0 obj << /Length ${streamBytes.size} >> stream")
            sb.append(contentBuilder.toString())
            sb.appendLine("endstream endobj")
        }
        sb.appendLine("%%EOF")
        FileOutputStream(targetFile).use { it.write(sb.toString().toByteArray(Charsets.UTF_8)) }
    }

    private fun effectiveTextWidth(text: String, paint: Paint): Float {
        val measured = runCatching { paint.measureText(text) }.getOrDefault(0f)
        return if (measured > 0f) measured else text.length * (paint.textSize.coerceAtLeast(8.5f) * 0.54f)
    }

    private fun drawTableHeaderRow(
        canvas: Canvas,
        topY: Float,
        height: Float,
        marginLeft: Float,
        marginRight: Float,
        columns: List<PdfColumnSpec>,
        bgPaint: Paint,
        textPaint: Paint
    ) {
        canvas.drawRect(marginLeft, topY, marginRight, topY + height, bgPaint)
        var colLeft = marginLeft
        columns.forEach { col ->
            val colRight = colLeft + col.widthPt
            val baselineY = topY + 14.5f
            val textX = when (col.align) {
                PdfColAlign.LEFT -> colLeft + 4f
                PdfColAlign.CENTER -> {
                    val w = effectiveTextWidth(col.header, textPaint)
                    colLeft + max(3f, (col.widthPt - w) / 2f)
                }
                PdfColAlign.RIGHT -> {
                    val w = effectiveTextWidth(col.header, textPaint)
                    max(colLeft + 3f, colRight - 4f - w)
                }
            }
            canvas.drawText(col.header, textX, baselineY, textPaint)
            colLeft = colRight
        }
    }

    /**
     * Tự động ngắt dòng văn bản theo độ rộng cột thực tế (không bao giờ cắt mất ký tự tên hội viên hay mã HĐ).
     */
    internal fun wrapTextToLines(text: String, paint: Paint, maxWidthPt: Float): List<String> {
        val cleaned = text.trim()
        if (cleaned.isEmpty()) return listOf("")
        if (effectiveTextWidth(cleaned, paint) <= maxWidthPt) return listOf(cleaned)

        val words = cleaned.split(Regex("\\s+"))
        val lines = mutableListOf<String>()
        var currentLine = ""

        for (word in words) {
            val candidate = if (currentLine.isEmpty()) word else "$currentLine $word"
            if (effectiveTextWidth(candidate, paint) <= maxWidthPt) {
                currentLine = candidate
            } else {
                if (currentLine.isNotEmpty()) {
                    lines.add(currentLine)
                    currentLine = ""
                }
                // Nếu bản thân 1 từ/mã hợp đồng dài hơn độ rộng cột, ngắt theo từng ký tự mà không làm mất chữ
                if (effectiveTextWidth(word, paint) <= maxWidthPt) {
                    currentLine = word
                } else {
                    var chunk = ""
                    for (ch in word) {
                        val nextChunk = chunk + ch
                        if (effectiveTextWidth(nextChunk, paint) <= maxWidthPt) {
                            chunk = nextChunk
                        } else {
                            if (chunk.isNotEmpty()) lines.add(chunk)
                            chunk = ch.toString()
                        }
                    }
                    currentLine = chunk
                }
            }
        }
        if (currentLine.isNotEmpty()) {
            lines.add(currentLine)
        }
        return if (lines.isEmpty()) listOf(cleaned) else lines
    }

    // =========================================================================================
    // 5. SAO LƯU JSON & CHIA SẺ FILE
    // =========================================================================================

    fun exportBackupJsonFile(context: Context, bundle: com.example.data.model.BackupBundle): File {
        val dir = ensureExportDir(context)
        val fileName = "89Fitness_SaoLuu_${FitnessCalculator.todayIso()}.json"
        val file = File(dir, fileName)
        FileOutputStream(file).use { fos ->
            fos.write(bundle.toJsonString().toByteArray(Charsets.UTF_8))
        }
        return file
    }

    fun shareFile(context: Context, file: File, mimeType: String, chooserTitle: String) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, chooserTitle)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(intent, chooserTitle).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    }

    fun shareAllocatedReportQuickText(
        context: Context,
        reportType: AllocatedReportType,
        summary: AllocatedMonthlySummary
    ) {
        val items = summary.itemsForReport(reportType)
        val total = summary.totalForReport(reportType)
        val sb = StringBuilder()
        sb.appendLine("89 FITNESS & YOGA")
        sb.appendLine(reportType.title)
        sb.appendLine("Kỳ báo cáo: Tháng ${summary.month}/${summary.year}")
        sb.appendLine("Tổng doanh thu phân bổ: ${FitnessCalculator.formatCurrency(total)}")
        sb.appendLine("Số khoản mục: ${items.size}")
        sb.appendLine("-------------------------")
        items.take(25).forEachIndexed { idx, item ->
            sb.appendLine("${idx + 1}. ${item.codeOrLabel} | ${item.memberName}: ${FitnessCalculator.formatCurrency(item.allocatedAmount)} (${item.monthUnitText})")
        }
        if (items.size > 25) {
            sb.appendLine("... và ${items.size - 25} khoản mục khác.")
        }

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "${reportType.title} - T${summary.month}/${summary.year}")
            putExtra(Intent.EXTRA_TEXT, sb.toString())
        }
        val chooser = Intent.createChooser(intent, "Chia sẻ nhanh báo cáo").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    }
}
