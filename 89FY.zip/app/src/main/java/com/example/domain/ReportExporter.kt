package com.example.domain

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.example.data.model.MemberGroup
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

object ReportExporter {

    private fun ensureExportDir(context: Context): File {
        val dir = File(context.cacheDir, "exports")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun exportMembersToExcelCsv(
        context: Context,
        serviceType: String,
        cards: List<MemberCardSummary>
    ): File {
        val dir = ensureExportDir(context)
        val fileName = "89Fitness_DanhSach_${serviceType}_${FitnessCalculator.todayIso()}.csv"
        val file = File(dir, fileName)
        FileOutputStream(file).use { fos ->
            // UTF-8 BOM so Microsoft Excel opens Vietnamese characters properly
            fos.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
            val sb = StringBuilder()
            sb.appendLine("89 FITNESS & YOGA - DANH SÁCH HỒ SƠ $serviceType")
            sb.appendLine("Tổng số hồ sơ,${cards.size}")
            sb.appendLine("STT,Họ và tên,Số điện thoại,Nhóm,Mã HĐ hiện tại,Ngày đăng ký,Ngày hết hạn,Trạng thái,Số ngày còn/quá hạn")
            for (c in cards) {
                val m = c.member
                val latest = c.latestContract
                val groupLabel = if (serviceType == "GYM") MemberGroup.fromCode(m.memberGroup).label else "YOGA"
                val statusLabel = when (c.expiryState) {
                    MemberExpiryState.ACTIVE -> "Còn hạn"
                    MemberExpiryState.EXPIRING_SOON_7_DAYS -> "Sắp hết hạn"
                    MemberExpiryState.EXPIRED_TODAY -> "Hết hạn hôm nay"
                    MemberExpiryState.EXPIRED -> "Hết hạn"
                }
                val daysText = when {
                    c.daysRemainingOrOverdue > 0 -> "Còn ${c.daysRemainingOrOverdue} ngày"
                    c.daysRemainingOrOverdue == 0 -> "Hết hạn hôm nay"
                    else -> "Quá hạn ${-c.daysRemainingOrOverdue} ngày"
                }
                sb.appendLine(
                    listOf(
                        "STT${m.stt}",
                        escapeCsv(m.fullName),
                        escapeCsv(m.phone),
                        escapeCsv(groupLabel),
                        escapeCsv(latest?.contractCode ?: "Chưa có HĐ"),
                        escapeCsv(latest?.startDate?.let { FitnessCalculator.formatDisplayDate(it) } ?: ""),
                        escapeCsv(latest?.endDate?.let { FitnessCalculator.formatDisplayDate(it) } ?: ""),
                        escapeCsv(statusLabel),
                        escapeCsv(daysText)
                    ).joinToString(",")
                )
            }
            fos.write(sb.toString().toByteArray(Charsets.UTF_8))
        }
        return file
    }

    fun exportMembersToPdf(
        context: Context,
        serviceType: String,
        cards: List<MemberCardSummary>
    ): File {
        val dir = ensureExportDir(context)
        val fileName = "89Fitness_DanhSach_${serviceType}_${FitnessCalculator.todayIso()}.pdf"
        val file = File(dir, fileName)

        val pdf = PdfDocument()
        val pageWidth = 595
        val pageHeight = 842
        var pageNumber = 1
        var pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
        var page = pdf.startPage(pageInfo)
        var canvas: Canvas = page.canvas

        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (serviceType == "YOGA") Color.rgb(109, 40, 217) else Color.rgb(21, 128, 61)
            textSize = 16f
            isFakeBoldText = true
        }
        val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(15, 23, 42)
            textSize = 11f
            isFakeBoldText = true
        }
        val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(30, 41, 59)
            textSize = 10f
        }
        val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(203, 213, 225)
            strokeWidth = 1f
        }

        var y = 45f
        canvas.drawText("89 FITNESS & YOGA — DANH SÁCH HỒ SƠ $serviceType", 36f, y, titlePaint)
        y += 20f
        canvas.drawText("Tổng số hồ sơ: ${cards.size} | Ngày xuất: ${FitnessCalculator.formatDisplayDate(FitnessCalculator.todayIso())}", 36f, y, headerPaint)
        y += 16f
        canvas.drawLine(36f, y, 559f, y, linePaint)
        y += 18f

        canvas.drawText("STT", 36f, y, headerPaint)
        canvas.drawText("Họ và tên", 85f, y, headerPaint)
        canvas.drawText("SĐT", 245f, y, headerPaint)
        canvas.drawText("Hết hạn", 340f, y, headerPaint)
        canvas.drawText("Trạng thái", 430f, y, headerPaint)
        y += 10f
        canvas.drawLine(36f, y, 559f, y, linePaint)
        y += 16f

        for (c in cards) {
            if (y > 790f) {
                pdf.finishPage(page)
                pageNumber++
                pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
                page = pdf.startPage(pageInfo)
                canvas = page.canvas
                y = 45f
            }
            val m = c.member
            val endStr = c.latestContract?.endDate?.let { FitnessCalculator.formatDisplayDate(it) } ?: "-"
            val statusStr = when {
                c.daysRemainingOrOverdue > 0 -> "Còn ${c.daysRemainingOrOverdue} ngày"
                c.daysRemainingOrOverdue == 0 -> "Hết hạn hôm nay"
                else -> "Quá hạn ${-c.daysRemainingOrOverdue} ngày"
            }
            canvas.drawText("STT${m.stt}", 36f, y, bodyPaint)
            canvas.drawText(m.fullName.take(28), 85f, y, bodyPaint)
            canvas.drawText(m.phone, 245f, y, bodyPaint)
            canvas.drawText(endStr, 340f, y, bodyPaint)
            canvas.drawText(statusStr, 430f, y, bodyPaint)
            y += 18f
        }

        pdf.finishPage(page)
        FileOutputStream(file).use { pdf.writeTo(it) }
        pdf.close()
        return file
    }

    fun exportSingleAllocatedReportToExcelCsv(
        context: Context,
        reportType: AllocatedReportType,
        summary: AllocatedMonthlySummary
    ): File {
        val dir = ensureExportDir(context)
        val monthTag = String.format(Locale.US, "%02d_%04d", summary.month, summary.year)
        val fileName = "89Fitness_BaoCao_${reportType.index}_${monthTag}.csv"
        val file = File(dir, fileName)
        val items = summary.itemsForReport(reportType)
        val total = summary.totalForReport(reportType)

        FileOutputStream(file).use { fos ->
            fos.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
            val sb = StringBuilder()
            sb.appendLine("89 FITNESS & YOGA - ${reportType.title.uppercase(Locale.getDefault())}")
            sb.appendLine("Kỳ báo cáo,Tháng ${summary.month}/${summary.year}")
            sb.appendLine("Tổng doanh thu phân bổ (VND),$total")
            sb.appendLine("Mã HĐ / Loại,STT,Họ tên / Nội dung,Thời hạn / Ngày,Giá trị gói (VND),Tổng thời lượng,Thực tế trong tháng,Doanh thu phân bổ tháng (VND)")
            for (item in items) {
                sb.appendLine(
                    listOf(
                        escapeCsv(item.codeOrLabel),
                        escapeCsv(item.memberSttText),
                        escapeCsv(item.memberName),
                        escapeCsv(item.periodText),
                        item.packageValue.toString(),
                        escapeCsv(item.totalUnitText),
                        escapeCsv(item.monthUnitText),
                        item.allocatedAmount.toString()
                    ).joinToString(",")
                )
            }
            fos.write(sb.toString().toByteArray(Charsets.UTF_8))
        }
        return file
    }

    fun exportSingleAllocatedReportToPdf(
        context: Context,
        reportType: AllocatedReportType,
        summary: AllocatedMonthlySummary
    ): File {
        val dir = ensureExportDir(context)
        val monthTag = String.format(Locale.US, "%02d_%04d", summary.month, summary.year)
        val fileName = "89Fitness_BaoCao_${reportType.index}_${monthTag}.pdf"
        val file = File(dir, fileName)
        val items = summary.itemsForReport(reportType)
        val total = summary.totalForReport(reportType)

        val pdf = PdfDocument()
        val pageWidth = 595
        val pageHeight = 842
        var pageNumber = 1
        var pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
        var page = pdf.startPage(pageInfo)
        var canvas = page.canvas

        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (reportType.serviceCategory == "YOGA") Color.rgb(109, 40, 217) else Color.rgb(21, 128, 61)
            textSize = 14f
            isFakeBoldText = true
        }
        val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(15, 23, 42)
            textSize = 11f
            isFakeBoldText = true
        }
        val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(30, 41, 59)
            textSize = 9.5f
        }
        val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(203, 213, 225)
            strokeWidth = 1f
        }

        var y = 45f
        canvas.drawText("89 FITNESS & YOGA", 36f, y, titlePaint)
        y += 20f
        canvas.drawText(reportType.title, 36f, y, titlePaint)
        y += 20f
        canvas.drawText(
            "Kỳ báo cáo: Tháng ${summary.month}/${summary.year}   |   Tổng cộng: ${FitnessCalculator.formatCurrency(total)}",
            36f,
            y,
            headerPaint
        )
        y += 14f
        canvas.drawLine(36f, y, 559f, y, linePaint)
        y += 16f

        canvas.drawText("Mã / Loại", 36f, y, headerPaint)
        canvas.drawText("Hội viên", 145f, y, headerPaint)
        canvas.drawText("Trong tháng", 330f, y, headerPaint)
        canvas.drawText("Phân bổ (VND)", 450f, y, headerPaint)
        y += 10f
        canvas.drawLine(36f, y, 559f, y, linePaint)
        y += 16f

        for (item in items) {
            if (y > 790f) {
                pdf.finishPage(page)
                pageNumber++
                pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
                page = pdf.startPage(pageInfo)
                canvas = page.canvas
                y = 45f
            }
            canvas.drawText(item.codeOrLabel.take(18), 36f, y, bodyPaint)
            canvas.drawText("${item.memberSttText} - ${item.memberName}".take(28), 145f, y, bodyPaint)
            canvas.drawText("${item.monthUnitText}/${item.totalUnitText}".take(20), 330f, y, bodyPaint)
            canvas.drawText(FitnessCalculator.formatCurrency(item.allocatedAmount), 450f, y, bodyPaint)
            y += 18f
        }

        pdf.finishPage(page)
        FileOutputStream(file).use { pdf.writeTo(it) }
        pdf.close()
        return file
    }

    fun exportBackupJsonFile(context: Context, bundle: com.example.data.model.BackupBundle): File {
        val dir = ensureExportDir(context)
        val fileName = "89Fitness_SaoLuu_${FitnessCalculator.todayIso()}.json"
        val file = File(dir, fileName)
        FileOutputStream(file).use { fos ->
            fos.write(bundle.toJsonString().toByteArray(Charsets.UTF_8))
        }
        return file
    }

    fun shareFile(context: Context, file: File, mimeType: String, chooserTitle: String) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, chooserTitle)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(intent, chooserTitle).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    }

    fun shareAllocatedReportQuickText(
        context: Context,
        reportType: AllocatedReportType,
        summary: AllocatedMonthlySummary
    ) {
        val items = summary.itemsForReport(reportType)
        val total = summary.totalForReport(reportType)
        val sb = StringBuilder()
        sb.appendLine("📊 89 FITNESS & YOGA")
        sb.appendLine("📌 ${reportType.title}")
        sb.appendLine("🗓 Kỳ báo cáo: Tháng ${summary.month}/${summary.year}")
        sb.appendLine("💰 Tổng doanh thu phân bổ: ${FitnessCalculator.formatCurrency(total)}")
        sb.appendLine("Số khoản mục: ${items.size}")
        sb.appendLine("-------------------------")
        items.take(25).forEachIndexed { idx, item ->
            sb.appendLine("${idx + 1}. ${item.codeOrLabel} | ${item.memberName}: ${FitnessCalculator.formatCurrency(item.allocatedAmount)} (${item.monthUnitText})")
        }
        if (items.size > 25) {
            sb.appendLine("... và ${items.size - 25} khoản mục khác.")
        }

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "${reportType.title} - T${summary.month}/${summary.year}")
            putExtra(Intent.EXTRA_TEXT, sb.toString())
        }
        val chooser = Intent.createChooser(intent, "Chia sẻ nhanh báo cáo").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    }

    private fun escapeCsv(value: String): String {
        val escaped = value.replace("\"", "\"\"")
        return if (escaped.contains(",") || escaped.contains("\"") || escaped.contains("\n")) {
            "\"$escaped\""
        } else {
            escaped
        }
    }
}
