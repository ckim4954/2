package com.example.domain

import java.math.BigDecimal
import java.math.RoundingMode

/**
 * Core Financial & Revenue Allocation Engine for 89 FITNESS & YOGA.
 *
 * Strictly enforces:
 * 1. Daily proration formula:
 *    Allocated Revenue = ROUND(Contract Value / Total Effective Days * Effective Days in Month)
 * 2. Rounding to nearest 1 VND (HALF_UP) per contract BEFORE summing.
 * 3. Independent of amount paid/collected (debt does not reduce allocated revenue).
 * 4. Cancelled contracts only recognize retained amount (Contract Value - Refunded Amount)
 *    up to the cancellation date/month, and 0 VND for subsequent months.
 * 5. PT contracts split 50% Gym / 50% Trainer Hà Đức, allocated by actual sessions completed in the month.
 * 6. Short-term tickets (Daily / Weekly) recognize 100% on the sale date.
 */
object RevenueAllocationEngine {

    data class ContractAllocationInput(
        val contractId: String,
        val contractCode: String,
        val memberId: String,
        val memberName: String,
        val durationMonths: Int,
        val startDateIso: String,
        val endDateIso: String,
        val agreedValueVnd: Long,
        val isRenewal: Boolean,
        val isCancelled: Boolean = false,
        val cancelledDateIso: String? = null,
        val refundedAmountVnd: Long = 0L
    )

    data class ContractAllocationRow(
        val contractId: String,
        val contractCode: String,
        val memberId: String,
        val memberName: String,
        val durationMonths: Int,
        val startDateIso: String,
        val endDateIso: String,
        val agreedValueVnd: Long,
        val effectiveValueVnd: Long,
        val totalEffectiveDays: Int,
        val effectiveDaysInMonth: Int,
        val allocatedRevenueVnd: Long,
        val isRenewal: Boolean
    )

    data class PtAllocationInput(
        val ptContractId: String,
        val contractCode: String,
        val clientName: String,
        val registerDateIso: String,
        val totalSessions: Int,
        val agreedValueVnd: Long,
        val sessionsInTargetMonth: Int
    )

    data class PtAllocationRow(
        val ptContractId: String,
        val contractCode: String,
        val clientName: String,
        val registerDateIso: String,
        val totalSessions: Int,
        val agreedValueVnd: Long,
        val sessionsInMonth: Int,
        val gymAllocatedRevenueVnd: Long,
        val trainerShareVnd: Long
    )

    /**
     * Rounds a decimal value to the nearest VND unit using standard HALF_UP rounding.
     */
    fun roundToVnd(value: Double): Long {
        if (value.isNaN() || value.isInfinite() || value <= 0.0) return 0L
        return BigDecimal.valueOf(value).setScale(0, RoundingMode.HALF_UP).toLong()
    }

    /**
     * Calculates allocated revenue for a single Gym/Yoga contract in [year]-[month].
     */
    fun allocateContractForMonth(
        input: ContractAllocationInput,
        year: Int,
        month: Int
    ): ContractAllocationRow? {
        if (input.isCancelled) {
            val retained = (input.agreedValueVnd - input.refundedAmountVnd).coerceAtLeast(0L)
            if (retained == 0L) return null

            val cancelDate = input.cancelledDateIso ?: input.startDateIso
            val cancelYm = DateCalculator.getYearMonth(cancelDate)
            if (cancelYm != null) {
                val (cancelYear, cancelMonth) = cancelYm
                // Stop generating revenue in months strictly after the cancellation month
                if (year > cancelYear || (year == cancelYear && month > cancelMonth)) {
                    return null
                }
                // In the cancellation month, if cancelled before the contract was active, recognize retained in cancellation month
                val effectiveEnd = minOf(input.endDateIso, maxOf(cancelDate, DateCalculator.addDays(input.startDateIso, 1)))
                val totalDays = DateCalculator.daysBetween(input.startDateIso, effectiveEnd).coerceAtLeast(1)
                val daysInMonth = DateCalculator.effectiveDaysInMonth(input.startDateIso, effectiveEnd, year, month)
                if (daysInMonth <= 0) return null
                val raw = retained.toDouble() / totalDays.toDouble() * daysInMonth.toDouble()
                val allocated = roundToVnd(raw)
                return ContractAllocationRow(
                    contractId = input.contractId,
                    contractCode = input.contractCode,
                    memberId = input.memberId,
                    memberName = input.memberName,
                    durationMonths = input.durationMonths,
                    startDateIso = input.startDateIso,
                    endDateIso = input.endDateIso,
                    agreedValueVnd = input.agreedValueVnd,
                    effectiveValueVnd = retained,
                    totalEffectiveDays = totalDays,
                    effectiveDaysInMonth = daysInMonth,
                    allocatedRevenueVnd = allocated,
                    isRenewal = input.isRenewal
                )
            }
        }

        val totalEffectiveDays = DateCalculator.daysBetween(input.startDateIso, input.endDateIso)
        if (totalEffectiveDays <= 0) return null

        val daysInMonth = DateCalculator.effectiveDaysInMonth(
            contractStartIso = input.startDateIso,
            contractEndIso = input.endDateIso,
            year = year,
            month = month
        )
        if (daysInMonth <= 0) return null

        // Exact formula: Contract Value / Total Effective Days * Effective Days in Month
        val rawRevenue = input.agreedValueVnd.toDouble() / totalEffectiveDays.toDouble() * daysInMonth.toDouble()
        val roundedRevenue = roundToVnd(rawRevenue)

        return ContractAllocationRow(
            contractId = input.contractId,
            contractCode = input.contractCode,
            memberId = input.memberId,
            memberName = input.memberName,
            durationMonths = input.durationMonths,
            startDateIso = input.startDateIso,
            endDateIso = input.endDateIso,
            agreedValueVnd = input.agreedValueVnd,
            effectiveValueVnd = input.agreedValueVnd,
            totalEffectiveDays = totalEffectiveDays,
            effectiveDaysInMonth = daysInMonth,
            allocatedRevenueVnd = roundedRevenue,
            isRenewal = input.isRenewal
        )
    }

    /**
     * Calculates allocated revenue for a list of contracts in [year]-[month],
     * rounding each contract individually before summing.
     */
    fun calculateMonthlyContractReport(
        contracts: List<ContractAllocationInput>,
        year: Int,
        month: Int
    ): Pair<List<ContractAllocationRow>, Long> {
        val rows = contracts.mapNotNull { allocateContractForMonth(it, year, month) }
        val totalVnd = rows.sumOf { it.allocatedRevenueVnd }
        return rows to totalVnd
    }

    /**
     * Calculates PT monthly revenue allocation where 50% belongs to Gym and 50% to Trainer Hà Đức.
     */
    fun allocatePtForMonth(input: PtAllocationInput): PtAllocationRow? {
        if (input.totalSessions <= 0 || input.sessionsInTargetMonth <= 0) return null
        val gymTotalShare = input.agreedValueVnd.toDouble() * 0.5
        val rawGymMonthly = (gymTotalShare / input.totalSessions.toDouble()) * input.sessionsInTargetMonth.toDouble()
        val gymRounded = roundToVnd(rawGymMonthly)
        return PtAllocationRow(
            ptContractId = input.ptContractId,
            contractCode = input.contractCode,
            clientName = input.clientName,
            registerDateIso = input.registerDateIso,
            totalSessions = input.totalSessions,
            agreedValueVnd = input.agreedValueVnd,
            sessionsInMonth = input.sessionsInTargetMonth,
            gymAllocatedRevenueVnd = gymRounded,
            trainerShareVnd = gymRounded
        )
    }
}
