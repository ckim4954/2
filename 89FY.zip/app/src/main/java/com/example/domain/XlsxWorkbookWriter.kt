package com.example.domain

import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream
import kotlin.math.max
import kotlin.math.min

/**
 * Các kiểu định dạng ô chuẩn trong file Excel (.xlsx) quản trị tài chính.
 */
enum class XlsxCellStyle(val styleIndex: Int) {
    DEFAULT(0),
    REPORT_TITLE(1),       // 14pt Bold, màu xanh thương hiệu
    SUBTITLE_META(2),      // 10pt nghiêng/thường, màu xám đậm
    SECTION_HEADER(3),     // 11pt Bold, nền xám nhạt, viền mảnh
    TABLE_HEADER(4),       // 10pt Bold chữ trắng, nền xanh đậm #1E293B, căn giữa, viền mảnh
    DATA_TEXT_LEFT(5),     // 10pt thường, căn trái, tự xuống dòng, viền mảnh
    DATA_TEXT_CENTER(6),   // 10pt thường, căn giữa, viền mảnh
    DATA_NUMBER_CENTER(7), // 10pt số nguyên #,##0, căn giữa, viền mảnh
    DATA_CURRENCY(8),      // 10pt tiền tệ #,##0 "đ", căn phải, viền mảnh
    TOTAL_LABEL(9),        // 10pt Bold, nền nhấn #F1F5F9, viền đậm trên/dưới
    TOTAL_CURRENCY(10),    // 10pt Bold tiền tệ #,##0 "đ", nền nhấn #F1F5F9, căn phải
    WARNING_CELL(11)       // 10pt Bold chữ đỏ #DC2626, nền hồng nhạt #FEF2F2, viền mảnh
}

sealed class XlsxCellValue {
    data class Text(val text: String) : XlsxCellValue()
    data class Number(val value: Long) : XlsxCellValue()
    data class Formula(val formula: String, val cachedValue: Long) : XlsxCellValue()
    data object Blank : XlsxCellValue()
}

data class XlsxCell(
    val value: XlsxCellValue,
    val style: XlsxCellStyle = XlsxCellStyle.DEFAULT
) {
    companion object {
        fun textLeft(value: String) = XlsxCell(XlsxCellValue.Text(value), XlsxCellStyle.DATA_TEXT_LEFT)
        fun textCenter(value: String) = XlsxCell(XlsxCellValue.Text(value), XlsxCellStyle.DATA_TEXT_CENTER)
        fun header(value: String) = XlsxCell(XlsxCellValue.Text(value), XlsxCellStyle.TABLE_HEADER)
        fun title(value: String) = XlsxCell(XlsxCellValue.Text(value), XlsxCellStyle.REPORT_TITLE)
        fun meta(value: String) = XlsxCell(XlsxCellValue.Text(value), XlsxCellStyle.SUBTITLE_META)
        fun section(value: String) = XlsxCell(XlsxCellValue.Text(value), XlsxCellStyle.SECTION_HEADER)
        fun numberCenter(value: Long) = XlsxCell(XlsxCellValue.Number(value), XlsxCellStyle.DATA_NUMBER_CENTER)
        fun currency(value: Long) = XlsxCell(XlsxCellValue.Number(value), XlsxCellStyle.DATA_CURRENCY)
        fun totalLabel(value: String) = XlsxCell(XlsxCellValue.Text(value), XlsxCellStyle.TOTAL_LABEL)
        fun totalNumber(value: Long) = XlsxCell(XlsxCellValue.Number(value), XlsxCellStyle.TOTAL_LABEL)
        fun totalCurrency(value: Long) = XlsxCell(XlsxCellValue.Number(value), XlsxCellStyle.TOTAL_CURRENCY)
        fun totalCurrencyFormula(formula: String, cachedValue: Long) =
            XlsxCell(XlsxCellValue.Formula(formula, cachedValue), XlsxCellStyle.TOTAL_CURRENCY)
        fun warningText(value: String) = XlsxCell(XlsxCellValue.Text(value), XlsxCellStyle.WARNING_CELL)
        fun warningCurrency(value: Long) = XlsxCell(XlsxCellValue.Number(value), XlsxCellStyle.WARNING_CELL)
        fun blank(style: XlsxCellStyle = XlsxCellStyle.DEFAULT) = XlsxCell(XlsxCellValue.Blank, style)
    }
}

data class XlsxRow(
    val cells: List<XlsxCell>,
    val heightPt: Double? = null
)

data class XlsxSheetSpec(
    val name: String,
    val rows: List<XlsxRow>,
    val freezeTopRows: Int = 0,
    val autoFilterRange: String? = null, // Ví dụ: "A6:K25"
    val mergedRanges: List<String> = emptyList(), // Ví dụ: listOf("A1:H1", "A2:H2")
    val minColWidths: Map<Int, Double> = emptyMap() // 0-indexed column -> min width
)

data class XlsxInspectedSheet(
    val name: String,
    val xmlContent: String,
    val numericValues: List<Long>,
    val formulas: List<String>,
    val textValues: List<String>
)

data class XlsxInspectedWorkbook(
    val entryNames: Set<String>,
    val sheetNames: List<String>,
    val sheets: List<XlsxInspectedSheet>
)

/**
 * Bộ tạo file Excel OpenXML (.xlsx) chuẩn ECMA-376 hoạt động 100% Offline trên Android.
 * Tương thích hoàn toàn với Microsoft Excel, Google Sheets và LibreOffice Calc.
 */
object XlsxWorkbookWriter {

    const val MIME_TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

    fun writeWorkbook(targetFile: File, sheets: List<XlsxSheetSpec>): File {
        require(sheets.isNotEmpty()) { "Workbook phải có ít nhất 1 Sheet." }
        FileOutputStream(targetFile).use { fos ->
            ZipOutputStream(fos).use { zos ->
                // 1. [Content_Types].xml
                putXmlEntry(zos, "[Content_Types].xml", buildContentTypesXml(sheets.size))
                // 2. _rels/.rels
                putXmlEntry(zos, "_rels/.rels", buildRootRelsXml())
                // 3. xl/workbook.xml
                putXmlEntry(zos, "xl/workbook.xml", buildWorkbookXml(sheets))
                // 4. xl/_rels/workbook.xml.rels
                putXmlEntry(zos, "xl/_rels/workbook.xml.rels", buildWorkbookRelsXml(sheets.size))
                // 5. xl/styles.xml
                putXmlEntry(zos, "xl/styles.xml", buildStylesXml())
                // 6. xl/worksheets/sheet1..N.xml
                sheets.forEachIndexed { index, spec ->
                    val sheetNumber = index + 1
                    putXmlEntry(zos, "xl/worksheets/sheet$sheetNumber.xml", buildWorksheetXml(spec))
                }
            }
        }
        return targetFile
    }

    fun columnLetter(colIndexZeroBased: Int): String {
        var n = colIndexZeroBased
        val sb = StringBuilder()
        while (n >= 0) {
            val rem = n % 26
            sb.insert(0, ('A'.code + rem).toChar())
            n = (n / 26) - 1
        }
        return sb.toString()
    }

    fun cellRef(colIndexZeroBased: Int, rowNumberOneBased: Int): String =
        "${columnLetter(colIndexZeroBased)}$rowNumberOneBased"

    private fun putXmlEntry(zos: ZipOutputStream, path: String, xml: String) {
        val entry = ZipEntry(path)
        zos.putNextEntry(entry)
        zos.write(xml.toByteArray(Charsets.UTF_8))
        zos.closeEntry()
    }

    private fun sanitizeSheetName(raw: String, fallbackIndex: Int): String {
        val cleaned = raw
            .replace(Regex("[\\\\/?*\\[\\]:]"), "-")
            .trim()
            .take(31)
        return cleaned.ifBlank { "Sheet$fallbackIndex" }
    }

    private fun buildContentTypesXml(sheetCount: Int): String {
        val sb = StringBuilder()
        sb.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        sb.append("""<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">""")
        sb.append("""<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>""")
        sb.append("""<Default Extension="xml" ContentType="application/xml"/>""")
        sb.append("""<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>""")
        sb.append("""<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>""")
        for (i in 1..sheetCount) {
            sb.append("""<Override PartName="/xl/worksheets/sheet$i.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>""")
        }
        sb.append("""</Types>""")
        return sb.toString()
    }

    private fun buildRootRelsXml(): String =
        """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""" +
            """<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">""" +
            """<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>""" +
            """</Relationships>"""

    private fun buildWorkbookXml(sheets: List<XlsxSheetSpec>): String {
        val sb = StringBuilder()
        sb.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        sb.append("""<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">""")
        sb.append("""<sheets>""")
        val usedNames = mutableSetOf<String>()
        sheets.forEachIndexed { idx, spec ->
            val sheetId = idx + 1
            var safeName = sanitizeSheetName(spec.name, sheetId)
            if (!usedNames.add(safeName.lowercase(Locale.ROOT))) {
                safeName = "${safeName.take(28)}_$sheetId"
                usedNames.add(safeName.lowercase(Locale.ROOT))
            }
            sb.append("""<sheet name="${escapeXml(safeName)}" sheetId="$sheetId" r:id="rId$sheetId"/>""")
        }
        sb.append("""</sheets>""")
        sb.append("""</workbook>""")
        return sb.toString()
    }

    private fun buildWorkbookRelsXml(sheetCount: Int): String {
        val sb = StringBuilder()
        sb.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        sb.append("""<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">""")
        for (i in 1..sheetCount) {
            sb.append("""<Relationship Id="rId$i" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet$i.xml"/>""")
        }
        val stylesId = sheetCount + 1
        sb.append("""<Relationship Id="rId$stylesId" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>""")
        sb.append("""</Relationships>""")
        return sb.toString()
    }

    private fun buildStylesXml(): String {
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <numFmts count="2">
    <numFmt numFmtId="164" formatCode="#,##0 &quot;đ&quot;"/>
    <numFmt numFmtId="165" formatCode="#,##0"/>
  </numFmts>
  <fonts count="7">
    <font><sz val="10"/><color rgb="FF1E293B"/><name val="Arial"/></font>
    <font><b/><sz val="14"/><color rgb="FF15803D"/><name val="Arial"/></font>
    <font><sz val="10"/><color rgb="FF475569"/><name val="Arial"/></font>
    <font><b/><sz val="11"/><color rgb="FF0F172A"/><name val="Arial"/></font>
    <font><b/><sz val="10"/><color rgb="FFFFFFFF"/><name val="Arial"/></font>
    <font><b/><sz val="10"/><color rgb="FF0F172A"/><name val="Arial"/></font>
    <font><b/><sz val="10"/><color rgb="FFDC2626"/><name val="Arial"/></font>
  </fonts>
  <fills count="6">
    <fill><patternFill patternType="none"/></fill>
    <fill><patternFill patternType="gray125"/></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FF1E293B"/><bgColor indexed="64"/></patternFill></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FFF1F5F9"/><bgColor indexed="64"/></patternFill></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FFE2E8F0"/><bgColor indexed="64"/></patternFill></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FFFEF2F2"/><bgColor indexed="64"/></patternFill></fill>
  </fills>
  <borders count="3">
    <border><left/><right/><top/><bottom/><diagonal/></border>
    <border>
      <left style="thin"><color rgb="FFCBD5E1"/></left>
      <right style="thin"><color rgb="FFCBD5E1"/></right>
      <top style="thin"><color rgb="FFCBD5E1"/></top>
      <bottom style="thin"><color rgb="FFCBD5E1"/></bottom>
      <diagonal/>
    </border>
    <border>
      <left style="thin"><color rgb="FF94A3B8"/></left>
      <right style="thin"><color rgb="FF94A3B8"/></right>
      <top style="medium"><color rgb="FF0F172A"/></top>
      <bottom style="double"><color rgb="FF0F172A"/></bottom>
      <diagonal/>
    </border>
  </borders>
  <cellStyleXfs count="1">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0"/>
  </cellStyleXfs>
  <cellXfs count="12">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
    <xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1">
      <alignment horizontal="left" vertical="center"/>
    </xf>
    <xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1">
      <alignment horizontal="left" vertical="center"/>
    </xf>
    <xf numFmtId="0" fontId="3" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">
      <alignment horizontal="left" vertical="center"/>
    </xf>
    <xf numFmtId="0" fontId="4" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">
      <alignment horizontal="center" vertical="center" wrapText="1"/>
    </xf>
    <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1">
      <alignment horizontal="left" vertical="center" wrapText="1"/>
    </xf>
    <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1">
      <alignment horizontal="center" vertical="center"/>
    </xf>
    <xf numFmtId="165" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyBorder="1" applyAlignment="1">
      <alignment horizontal="center" vertical="center"/>
    </xf>
    <xf numFmtId="164" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyBorder="1" applyAlignment="1">
      <alignment horizontal="right" vertical="center"/>
    </xf>
    <xf numFmtId="0" fontId="5" fillId="4" borderId="2" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">
      <alignment horizontal="left" vertical="center"/>
    </xf>
    <xf numFmtId="164" fontId="5" fillId="4" borderId="2" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">
      <alignment horizontal="right" vertical="center"/>
    </xf>
    <xf numFmtId="164" fontId="6" fillId="5" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">
      <alignment horizontal="left" vertical="center" wrapText="1"/>
    </xf>
  </cellXfs>
</styleSheet>"""
    }

    private fun buildWorksheetXml(spec: XlsxSheetSpec): String {
        val sb = StringBuilder()
        sb.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        sb.append("""<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">""")

        // 1. sheetViews (Freeze Panes)
        if (spec.freezeTopRows > 0) {
            val topLeft = "A${spec.freezeTopRows + 1}"
            sb.append("""<sheetViews><sheetView workbookViewId="0">""")
            sb.append("""<pane ySplit="${spec.freezeTopRows}" topLeftCell="$topLeft" activePane="bottomLeft" state="frozen"/>""")
            sb.append("""</sheetView></sheetViews>""")
        } else {
            sb.append("""<sheetViews><sheetView workbookViewId="0"/></sheetViews>""")
        }

        // 2. Tính độ rộng cột tự động (<cols>)
        val maxColumns = spec.rows.maxOfOrNull { it.cells.size } ?: 1
        val colWidths = DoubleArray(maxColumns) { colIdx ->
            spec.minColWidths[colIdx] ?: 12.0
        }
        val mergedRowIndices = mutableSetOf<Int>()
        spec.mergedRanges.forEach { range ->
            val startPart = range.substringBefore(":")
            val rowDigits = startPart.filter { it.isDigit() }.toIntOrNull()
            if (rowDigits != null) mergedRowIndices.add(rowDigits - 1)
        }

        spec.rows.forEachIndexed { rowIdx, row ->
            if (rowIdx !in mergedRowIndices) {
                row.cells.forEachIndexed { colIdx, cell ->
                    val displayLen = when (val v = cell.value) {
                        is XlsxCellValue.Text -> v.text.length + 4
                        is XlsxCellValue.Number -> FitnessCalculator.formatCurrency(v.value).length + 4
                        is XlsxCellValue.Formula -> FitnessCalculator.formatCurrency(v.cachedValue).length + 5
                        is XlsxCellValue.Blank -> 4
                    }
                    colWidths[colIdx] = min(46.0, max(colWidths[colIdx], displayLen * 1.15))
                }
            }
        }

        if (maxColumns > 0) {
            sb.append("""<cols>""")
            for (c in 0 until maxColumns) {
                val colNum = c + 1
                val w = String.format(Locale.US, "%.2f", colWidths[c])
                sb.append("""<col min="$colNum" max="$colNum" width="$w" customWidth="1"/>""")
            }
            sb.append("""</cols>""")
        }

        // 3. <sheetData>
        sb.append("""<sheetData>""")
        spec.rows.forEachIndexed { rIndex, row ->
            val rowNum = rIndex + 1
            val htAttr = row.heightPt?.let {
                String.format(Locale.US, """ ht="%.1f" customHeight="1"""", it)
            } ?: ""
            sb.append("""<row r="$rowNum"$htAttr>""")
            row.cells.forEachIndexed { cIndex, cell ->
                val ref = cellRef(cIndex, rowNum)
                val s = cell.style.styleIndex
                when (val v = cell.value) {
                    is XlsxCellValue.Text -> {
                        sb.append("""<c r="$ref" s="$s" t="inlineStr"><is><t xml:space="preserve">${escapeXml(v.text)}</t></is></c>""")
                    }
                    is XlsxCellValue.Number -> {
                        sb.append("""<c r="$ref" s="$s" t="n"><v>${v.value}</v></c>""")
                    }
                    is XlsxCellValue.Formula -> {
                        sb.append("""<c r="$ref" s="$s" t="n"><f>${escapeXml(v.formula)}</f><v>${v.cachedValue}</v></c>""")
                    }
                    is XlsxCellValue.Blank -> {
                        if (s != 0) {
                            sb.append("""<c r="$ref" s="$s"/>""")
                        }
                    }
                }
            }
            sb.append("""</row>""")
        }
        sb.append("""</sheetData>""")

        // 4. <autoFilter> (phải đặt trước <mergeCells> theo schema OpenXML)
        if (!spec.autoFilterRange.isNullOrBlank()) {
            sb.append("""<autoFilter ref="${escapeXml(spec.autoFilterRange)}"/>""")
        }

        // 5. <mergeCells>
        if (spec.mergedRanges.isNotEmpty()) {
            sb.append("""<mergeCells count="${spec.mergedRanges.size}">""")
            spec.mergedRanges.forEach { range ->
                sb.append("""<mergeCell ref="${escapeXml(range)}"/>""")
            }
            sb.append("""</mergeCells>""")
        }

        sb.append("""</worksheet>""")
        return sb.toString()
    }

    private fun escapeXml(input: String): String {
        val sb = StringBuilder(input.length + 16)
        for (ch in input) {
            when (ch) {
                '&' -> sb.append("&amp;")
                '<' -> sb.append("&lt;")
                '>' -> sb.append("&gt;")
                '"' -> sb.append("&quot;")
                '\'' -> sb.append("&apos;")
                else -> if (ch.code >= 0x20 || ch == '\n' || ch == '\r' || ch == '\t') {
                    sb.append(ch)
                }
            }
        }
        return sb.toString()
    }

    /**
     * Đọc và kiểm tra cấu trúc thực tế của file .xlsx đã xuất (phục vụ đối chiếu & kiểm thử tự động).
     */
    fun inspectWorkbook(file: File): XlsxInspectedWorkbook {
        ZipFile(file).use { zip ->
            val entryNames = mutableSetOf<String>()
            val entries = zip.entries()
            while (entries.hasMoreElements()) {
                entryNames.add(entries.nextElement().name)
            }

            val workbookXml = zip.getEntry("xl/workbook.xml")?.let {
                zip.getInputStream(it).bufferedReader(Charsets.UTF_8).readText()
            }.orEmpty()

            val sheetNameRegex = Regex("""<sheet\s+name="([^"]+)"""")
            val sheetNames = sheetNameRegex.findAll(workbookXml).map { unescapeXml(it.groupValues[1]) }.toList()

            val numRegex = Regex("""<v>(-?\d+)</v>""")
            val formulaRegex = Regex("""<f>([^<]+)</f>""")
            val textRegex = Regex("""<t[^>]*>([^<]*)</t>""")

            val inspectedSheets = sheetNames.mapIndexed { idx, name ->
                val sheetPath = "xl/worksheets/sheet${idx + 1}.xml"
                val sheetXml = zip.getEntry(sheetPath)?.let {
                    zip.getInputStream(it).bufferedReader(Charsets.UTF_8).readText()
                }.orEmpty()
                val nums = numRegex.findAll(sheetXml).mapNotNull { it.groupValues[1].toLongOrNull() }.toList()
                val formulas = formulaRegex.findAll(sheetXml).map { unescapeXml(it.groupValues[1]) }.toList()
                val texts = textRegex.findAll(sheetXml).map { unescapeXml(it.groupValues[1]) }.toList()
                XlsxInspectedSheet(
                    name = name,
                    xmlContent = sheetXml,
                    numericValues = nums,
                    formulas = formulas,
                    textValues = texts
                )
            }

            return XlsxInspectedWorkbook(
                entryNames = entryNames,
                sheetNames = sheetNames,
                sheets = inspectedSheets
            )
        }
    }

    private fun unescapeXml(input: String): String =
        input
            .replace("&quot;", "\"")
            .replace("&apos;", "'")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&amp;", "&")
}
