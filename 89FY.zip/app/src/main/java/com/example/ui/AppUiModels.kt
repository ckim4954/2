package com.example.ui

import com.example.data.local.*
import com.example.domain.DateCalculator

enum class MemberExpiryFilter(val label: String) {
    ALL("Tất cả"),
    VALID("Còn hạn"),
    EXPIRING_SOON("Sắp hết hạn"),
    EXPIRED("Đã hết hạn")
}

enum class ExpirySortOrder(val label: String) {
    ASCENDING("Hết hạn tăng dần"),
    DESCENDING("Hết hạn giảm dần")
}

sealed interface AppScreen {
    data object HomeDashboard : AppScreen
    data class MemberList(
        val domain: String, // "GYM" or "YOGA"
        val initialFilter: MemberExpiryFilter = MemberExpiryFilter.ALL
    ) : AppScreen
    data class MemberDetail(val memberId: String) : AppScreen
    data class CreateContract(
        val preselectedDomain: String? = null, // "GYM" or "YOGA"
        val preselectedService: String? = null, // "NEW", "RENEWAL", "PT", "VE_NGAY", "VE_TUAN"
        val renewalMemberId: String? = null,
        val fromPtClientId: String? = null
    ) : AppScreen
    data object PtManagement : AppScreen
    data class Revenue(val initialDomain: String = "GYM") : AppScreen
    data class Tracking(
        val initialDomain: String = "GYM",
        val initialSubTab: Int = 0 // 0 = Theo dõi hội viên, 1 = Công nợ
    ) : AppScreen
    data object Settings : AppScreen
    data object Trash : AppScreen
}

/**
 * Enriched summary for a Member in Gym or Yoga list (Section 4.1 - 4.5).
 */
data class MemberSummaryUi(
    val member: MemberEntity,
    val currentContract: ContractEntity?,
    val allContracts: List<ContractEntity>,
    val payments: List<PaymentTransactionEntity>,
    val refunds: List<RefundTransactionEntity>,
    val freezes: List<ContractFreezeEntity>,
    val signedDaysRemaining: Int, // > 0 remaining, == 0 expires today, < 0 expired
    val isValid: Boolean, // signedDaysRemaining > 0
    val isExpiringSoon: Boolean, // signedDaysRemaining in 1..7 (still belongs to valid group!)
    val isExpired: Boolean, // signedDaysRemaining <= 0
    val statusText: String, // e.g., "Còn 91 ngày", "Hết hạn hôm nay", "Hết hạn 15 ngày"
    val totalAgreedVnd: Long,
    val totalPaidVnd: Long,
    val totalDebtVnd: Long,
    val hasOverpaymentWarning: Boolean
) {
    val startDateIso: String get() = currentContract?.startDateIso ?: ""
    val endDateIso: String get() = currentContract?.endDateIso ?: ""
    val planName: String get() = currentContract?.planNameSnapshot ?: "Chưa có hợp đồng"
    val durationMonths: Int get() = currentContract?.durationMonths ?: 0
}

/**
 * Enriched summary for a Contract with Debt / Payment breakdown (Section 12).
 */
data class ContractDebtUi(
    val contract: ContractEntity,
    val memberName: String,
    val memberPhone: String,
    val payments: List<PaymentTransactionEntity>,
    val totalPaidVnd: Long,
    val debtVnd: Long,
    val overpaidVnd: Long // > 0 when contract value was edited lower than totalPaidVnd (Section 12.4)
)

/**
 * Enriched summary for a PT Client and their contracts/sessions (Section 6).
 */
data class PtClientSummaryUi(
    val client: PtClientEntity,
    val activeContract: PtContractEntity?,
    val allContracts: List<PtContractEntity>,
    val allSessions: List<PtSessionEntity>,
    val usedSessionsOnActive: Int,
    val remainingSessionsOnActive: Int
)

enum class GymReportType(val title: String) {
    NEW_MEMBERS("1. Doanh thu phân bổ hội viên đăng ký mới"),
    RENEWAL_MEMBERS("2. Doanh thu phân bổ hội viên gia hạn"),
    PT_REVENUE("3. Doanh thu phân bổ PT (50% Gym)"),
    TICKETS_REVENUE("4. Doanh thu vé ngày và vé tuần"),
    TOTAL_GYM("5. Tổng doanh thu Gym")
}

enum class YogaReportType(val title: String) {
    NEW_MEMBERS("1. Doanh thu phân bổ hội viên đăng ký mới"),
    RENEWAL_MEMBERS("2. Doanh thu phân bổ hội viên gia hạn"),
    TOTAL_YOGA("3. Tổng doanh thu Yoga")
}

fun buildMemberStatusText(signedDays: Int, hasContract: Boolean): String {
    if (!hasContract) return "Chưa có hợp đồng"
    return when {
        signedDays > 0 -> "Còn $signedDays ngày"
        signedDays == 0 -> "Hết hạn hôm nay"
        else -> "Hết hạn ${-signedDays} ngày"
    }
}
