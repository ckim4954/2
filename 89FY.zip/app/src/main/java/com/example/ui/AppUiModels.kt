package com.example.ui

import com.example.data.export.ReportTableData
import com.example.data.local.*

/**
 * Tracking expiry filter groups required by Section 8 of the Upgrade PRD:
 * - Tất cả
 * - Còn hạn
 * - Hôm nay hết hạn
 * - Sắp hết hạn 1–7 ngày
 * - Sắp hết hạn 8–15 ngày
 * - Đã hết hạn
 */
enum class MemberExpiryFilter(val label: String) {
    ALL("Tất cả"),
    VALID("Còn hạn"),
    TODAY_EXPIRING("Hôm nay hết hạn"),
    EXPIRING_SOON("Sắp hết hạn 1–7 ngày"),
    EXPIRING_8_15("Sắp hết hạn 8–15 ngày"),
    EXPIRED("Đã hết hạn")
}

enum class ExpirySortOrder(val label: String) {
    ASCENDING("Hết hạn tăng dần"),
    DESCENDING("Hết hạn giảm dần")
}

sealed interface AppScreen {
    data object HomeDashboard : AppScreen
    data class MemberList(
        val domain: String, // "GYM" or "YOGA"
        val initialFilter: MemberExpiryFilter = MemberExpiryFilter.ALL
    ) : AppScreen
    data class MemberDetail(val memberId: String) : AppScreen
    data class CreateContract(
        val preselectedDomain: String? = null, // "GYM" or "YOGA"
        val preselectedService: String? = null, // "NEW", "RENEWAL", "PT", "VE_NGAY", "VE_TUAN"
        val renewalMemberId: String? = null,
        val fromPtClientId: String? = null
    ) : AppScreen
    data object PtManagement : AppScreen
    data class Revenue(val initialSubScreen: Int = 0) : AppScreen // 0 = 3-Tile Hub, 1 = Gym, 2 = Yoga, 3 = Export
    data class Tracking(
        val initialDomain: String = "GYM",
        val initialSubTab: Int = 0 // 0 = Theo dõi hội viên, 1 = Công nợ
    ) : AppScreen
    data object Settings : AppScreen
    data object Trash : AppScreen
}

data class PendingFileExportRequest(
    val table: ReportTableData,
    val asExcel: Boolean,
    val suggestedFileName: String
)

enum class TrashItemType(val label: String) {
    MEMBER("Hội viên"),
    CONTRACT("Hợp đồng"),
    PRICE_PLAN("Gói tập"),
    PT_CLIENT("Hồ sơ PT"),
    TICKET("Vé ngày/tuần")
}

data class TrashSelectableItem(
    val type: TrashItemType,
    val id: String,
    val title: String,
    val subtitle: String,
    val badgeText: String,
    val isCancelledRefund: Boolean = false
)

/**
 * Enriched summary for a Member in Gym or Yoga list.
 */
data class MemberSummaryUi(
    val member: MemberEntity,
    val currentContract: ContractEntity?,
    val allContracts: List<ContractEntity>,
    val payments: List<PaymentTransactionEntity>,
    val refunds: List<RefundTransactionEntity>,
    val freezes: List<ContractFreezeEntity>,
    val signedDaysRemaining: Int, // > 0 remaining, == 0 expires today, < 0 expired
    val isValid: Boolean, // signedDaysRemaining > 0
    val isTodayExpiring: Boolean, // signedDaysRemaining == 0
    val isExpiringSoon: Boolean, // signedDaysRemaining in 1..7
    val isExpiring8To15: Boolean, // signedDaysRemaining in 8..15
    val isExpired: Boolean, // signedDaysRemaining <= 0
    val statusText: String, // "Còn X ngày", "Hết hạn hôm nay", "Hết hạn X ngày"
    val totalAgreedVnd: Long,
    val totalPaidVnd: Long,
    val totalDebtVnd: Long,
    val hasOverpaymentWarning: Boolean
) {
    val startDateIso: String get() = currentContract?.startDateIso ?: ""
    val endDateIso: String get() = currentContract?.endDateIso ?: ""
    val planName: String get() = currentContract?.planNameSnapshot ?: "Chưa có hợp đồng"
    val durationMonths: Int get() = currentContract?.durationMonths ?: 0
}

data class ContractDebtUi(
    val contract: ContractEntity,
    val memberName: String,
    val memberPhone: String,
    val payments: List<PaymentTransactionEntity>,
    val totalPaidVnd: Long,
    val debtVnd: Long,
    val overpaidVnd: Long
)

data class PtClientSummaryUi(
    val client: PtClientEntity,
    val activeContract: PtContractEntity?,
    val allContracts: List<PtContractEntity>,
    val allSessions: List<PtSessionEntity>,
    val usedSessionsOnActive: Int,
    val remainingSessionsOnActive: Int
)

enum class GymReportType(val title: String) {
    NEW_MEMBERS("1. Doanh thu hội viên mới"),
    RENEWAL_MEMBERS("2. Doanh thu gia hạn"),
    PT_REVENUE("3. Doanh thu PT (50% Gym)"),
    TICKETS_REVENUE("4. Doanh thu vé ngày & vé tuần"),
    TOTAL_GYM("5. Báo cáo tổng hợp Gym")
}

enum class YogaReportType(val title: String) {
    NEW_MEMBERS("1. Doanh thu hội viên mới"),
    RENEWAL_MEMBERS("2. Doanh thu gia hạn"),
    TOTAL_YOGA("3. Báo cáo tổng hợp Yoga")
}

fun buildMemberStatusText(signedDays: Int, hasContract: Boolean): String {
    if (!hasContract) return "Chưa có hợp đồng"
    return when {
        signedDays > 0 -> "Còn $signedDays ngày"
        signedDays == 0 -> "Hết hạn hôm nay"
        else -> "Hết hạn ${-signedDays} ngày"
    }
}
