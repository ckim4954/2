package com.example.ui

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.backup.GoogleDriveBackupManager
import com.example.data.export.ReportExportManager
import com.example.data.export.ReportTableData
import com.example.data.export.SavedExportResult
import com.example.data.local.*
import com.example.data.media.AvatarStorageManager
import com.example.data.preferences.AppPreferencesState
import com.example.data.preferences.UserPreferencesRepository
import com.example.data.repository.FitnessRepository
import com.example.domain.DateCalculator
import com.example.domain.FormatUtils
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class AppDataSnapshot(
    val pricePlans: List<PricePlanEntity> = emptyList(),
    val members: List<MemberEntity> = emptyList(),
    val contracts: List<ContractEntity> = emptyList(),
    val freezes: List<ContractFreezeEntity> = emptyList(),
    val payments: List<PaymentTransactionEntity> = emptyList(),
    val refunds: List<RefundTransactionEntity> = emptyList(),
    val ptClients: List<PtClientEntity> = emptyList(),
    val ptContracts: List<PtContractEntity> = emptyList(),
    val ptSessions: List<PtSessionEntity> = emptyList(),
    val shortTermTickets: List<ShortTermTicketEntity> = emptyList(),
    val auditLogs: List<EditAuditLogEntity> = emptyList()
)

class FitnessViewModel(
    private val repository: FitnessRepository,
    private val preferencesRepository: UserPreferencesRepository,
    private val avatarStorageManager: AvatarStorageManager,
    private val reportExportManager: ReportExportManager,
    private val backupManager: GoogleDriveBackupManager
) : ViewModel() {

    init {
        // Confirmed Decision 3: Automatically seed the 14 standard Gym & Yoga price plans if not present
        viewModelScope.launch {
            repository.ensureStandardPricePlansSeeded()
        }
    }

    private val _navStack = MutableStateFlow<List<AppScreen>>(listOf(AppScreen.HomeDashboard))
    val currentScreen: StateFlow<AppScreen> = _navStack
        .map { it.lastOrNull() ?: AppScreen.HomeDashboard }
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppScreen.HomeDashboard)

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    // State for launching Android folder/file save picker (Confirmed Decision 1)
    private val _pendingExportRequest = MutableStateFlow<PendingFileExportRequest?>(null)
    val pendingExportRequest: StateFlow<PendingFileExportRequest?> = _pendingExportRequest.asStateFlow()

    // State for showing the result of a saved Excel/PDF file with Open & Share actions
    private val _lastSavedExportResult = MutableStateFlow<SavedExportResult?>(null)
    val lastSavedExportResult: StateFlow<SavedExportResult?> = _lastSavedExportResult.asStateFlow()

    val preferencesState: StateFlow<AppPreferencesState> = preferencesRepository.preferencesFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppPreferencesState())

    private val group1Flow = combine(
        repository.pricePlansFlow,
        repository.membersFlow,
        repository.contractsFlow,
        repository.contractFreezesFlow,
        repository.paymentsFlow
    ) { plans, members, contracts, freezes, payments ->
        AppDataSnapshot(
            pricePlans = plans,
            members = members,
            contracts = contracts,
            freezes = freezes,
            payments = payments
        )
    }

    private val group2Flow = combine(
        repository.refundsFlow,
        repository.ptClientsFlow,
        repository.ptContractsFlow,
        repository.ptSessionsFlow,
        repository.shortTermTicketsFlow
    ) { refunds, ptClients, ptContracts, ptSessions, tickets ->
        AppDataSnapshot(
            refunds = refunds,
            ptClients = ptClients,
            ptContracts = ptContracts,
            ptSessions = ptSessions,
            shortTermTickets = tickets
        )
    }

    val dataSnapshot: StateFlow<AppDataSnapshot> = combine(
        group1Flow,
        group2Flow,
        repository.auditLogsFlow
    ) { g1, g2, logs ->
        g1.copy(
            refunds = g2.refunds,
            ptClients = g2.ptClients,
            ptContracts = g2.ptContracts,
            ptSessions = g2.ptSessions,
            shortTermTickets = g2.shortTermTickets,
            auditLogs = logs
        )
    }.stateIn(viewModelScope, SharingStarted.Eagerly, AppDataSnapshot())

    val gymMembersFlow: StateFlow<List<MemberSummaryUi>> = dataSnapshot.map { snap ->
        buildMemberSummaries(snap, domain = "GYM")
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val yogaMembersFlow: StateFlow<List<MemberSummaryUi>> = dataSnapshot.map { snap ->
        buildMemberSummaries(snap, domain = "YOGA")
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val ptClientSummariesFlow: StateFlow<List<PtClientSummaryUi>> = dataSnapshot.map { snap ->
        buildPtClientSummaries(snap)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val gymDebtContractsFlow: StateFlow<List<ContractDebtUi>> = dataSnapshot.map { snap ->
        buildContractDebts(snap, domain = "GYM")
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val yogaDebtContractsFlow: StateFlow<List<ContractDebtUi>> = dataSnapshot.map { snap ->
        buildContractDebts(snap, domain = "YOGA")
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // --- Navigation Actions ---
    fun navigateTo(screen: AppScreen) {
        _navStack.update { stack -> stack + screen }
    }

    fun navigateBack(): Boolean {
        val current = _navStack.value
        return if (current.size > 1) {
            _navStack.value = current.dropLast(1)
            true
        } else {
            false
        }
    }

    fun navigateHome() {
        _navStack.value = listOf(AppScreen.HomeDashboard)
    }

    fun showMessage(msg: String) {
        _snackbarMessage.value = msg
    }

    fun clearMessage() {
        _snackbarMessage.value = null
    }

    fun dismissSavedExportBanner() {
        _lastSavedExportResult.value = null
    }

    // --- Theme & Preferences ---
    fun setDarkMode(enabled: Boolean) {
        viewModelScope.launch {
            preferencesRepository.setDarkMode(enabled)
        }
    }

    // --- Price Catalog Actions ---
    fun savePricePlan(
        existingId: String?,
        domain: String,
        category: String,
        planName: String,
        durationMonths: Int,
        sessionCount: Int,
        priceVnd: Long
    ) {
        if (planName.isBlank() || priceVnd <= 0L) {
            showMessage("Vui lòng nhập tên gói và mức giá hợp lệ (> 0 đ).")
            return
        }
        viewModelScope.launch {
            val plan = if (existingId != null) {
                PricePlanEntity(
                    id = existingId,
                    domain = domain,
                    category = category,
                    planName = planName.trim(),
                    durationMonths = durationMonths,
                    sessionCount = sessionCount,
                    priceVnd = priceVnd,
                    isActive = true
                )
            } else {
                PricePlanEntity(
                    domain = domain,
                    category = category,
                    planName = planName.trim(),
                    durationMonths = durationMonths,
                    sessionCount = sessionCount,
                    priceVnd = priceVnd,
                    isActive = true
                )
            }
            repository.savePricePlan(plan)
            showMessage("Đã lưu gói giá: ${plan.planName}")
        }
    }

    fun togglePricePlanActive(plan: PricePlanEntity) {
        viewModelScope.launch {
            repository.togglePricePlanActive(plan)
            showMessage(if (plan.isActive) "Đã ngừng sử dụng gói ${plan.planName}" else "Đã kích hoạt gói ${plan.planName}")
        }
    }

    fun deleteOrDeactivatePricePlan(plan: PricePlanEntity) {
        viewModelScope.launch {
            val msg = repository.deleteOrDeactivatePricePlan(plan)
            showMessage(msg)
        }
    }

    // --- Member & Contract Actions ---
    fun saveAndCompressAvatar(uri: Uri, onSaved: (String) -> Unit) {
        viewModelScope.launch {
            val path = avatarStorageManager.saveCompressedAvatar(uri)
            if (path != null) {
                onSaved(path)
            } else {
                showMessage("Không thể xử lý ảnh đại diện đã chọn.")
            }
        }
    }

    fun createMemberContract(
        domain: String,
        existingMemberId: String?,
        linkedPtClientId: String?,
        fullName: String,
        phoneNumber: String,
        customerGroup: String,
        avatarPath: String?,
        pricePlanId: String?,
        planNameSnapshot: String,
        durationMonths: Int,
        agreedValueVnd: Long,
        paymentDateIso: String,
        createdDateIso: String,
        startDateIso: String,
        customEndDateIso: String?,
        isEndDateManuallyEdited: Boolean,
        cashPaidVnd: Long,
        transferPaidVnd: Long,
        note: String,
        onSuccess: (ContractEntity) -> Unit
    ) {
        viewModelScope.launch {
            val result = repository.createMemberContract(
                domain = domain,
                existingMemberId = existingMemberId,
                linkedPtClientId = linkedPtClientId,
                fullName = fullName,
                phoneNumber = phoneNumber,
                customerGroup = customerGroup,
                avatarPath = avatarPath,
                pricePlanId = pricePlanId,
                planNameSnapshot = planNameSnapshot,
                durationMonths = durationMonths,
                agreedValueVnd = agreedValueVnd,
                paymentDateIso = paymentDateIso,
                createdDateIso = createdDateIso,
                requestedStartDateIso = startDateIso,
                customEndDateIso = customEndDateIso,
                isEndDateManuallyEdited = isEndDateManuallyEdited,
                cashPaidVnd = cashPaidVnd,
                transferPaidVnd = transferPaidVnd,
                note = note
            )
            result.onSuccess { contract ->
                showMessage("Đã lưu hợp đồng ${contract.contractCode} thành công!")
                onSuccess(contract)
            }.onFailure { err ->
                showMessage(err.message ?: "Lỗi khi tạo hợp đồng.")
            }
        }
    }

    fun updateMemberProfile(
        memberId: String,
        fullName: String,
        phoneNumber: String,
        customerGroup: String,
        avatarPath: String?
    ) {
        viewModelScope.launch {
            repository.updateMemberProfile(memberId, fullName, phoneNumber, customerGroup, avatarPath)
                .onSuccess { showMessage("Đã cập nhật hồ sơ hội viên.") }
                .onFailure { showMessage(it.message ?: "Không thể cập nhật hồ sơ.") }
        }
    }

    fun updateContractDetails(
        contractId: String,
        planNameSnapshot: String,
        durationMonths: Int,
        agreedValueVnd: Long,
        paymentDateIso: String,
        createdDateIso: String,
        startDateIso: String,
        customEndDateIso: String?,
        isEndDateManuallyEdited: Boolean,
        note: String
    ) {
        viewModelScope.launch {
            repository.updateContractDetails(
                contractId = contractId,
                planNameSnapshot = planNameSnapshot,
                durationMonths = durationMonths,
                agreedValueVnd = agreedValueVnd,
                paymentDateIso = paymentDateIso,
                createdDateIso = createdDateIso,
                startDateIso = startDateIso,
                customEndDateIso = customEndDateIso,
                isEndDateManuallyEdited = isEndDateManuallyEdited,
                note = note
            ).onSuccess {
                showMessage("Đã cập nhật hợp đồng ${it.contractCode}.")
            }.onFailure {
                showMessage(it.message ?: "Không thể sửa hợp đồng.")
            }
        }
    }

    fun freezeContract(
        contractId: String,
        freezeStartIso: String,
        daysFrozen: Int,
        reason: String
    ) {
        viewModelScope.launch {
            repository.freezeContract(contractId, freezeStartIso, daysFrozen, reason)
                .onSuccess { showMessage("Đã đóng băng hợp đồng và cộng bù $daysFrozen ngày.") }
                .onFailure { showMessage(it.message ?: "Lỗi khi đóng băng hợp đồng.") }
        }
    }

    fun recordContractPayment(
        contractId: String,
        paymentDateIso: String,
        cashAmountVnd: Long,
        transferAmountVnd: Long,
        note: String
    ) {
        viewModelScope.launch {
            repository.recordContractPayment(contractId, paymentDateIso, cashAmountVnd, transferAmountVnd, note)
                .onSuccess { showMessage("Đã ghi nhận thu tiền (${it.transactionCode}): ${FormatUtils.formatVnd(it.totalAmountVnd)}") }
                .onFailure { showMessage(it.message ?: "Lỗi khi ghi nhận thanh toán.") }
        }
    }

    fun cancelContractAndRefund(
        contractId: String,
        cancelDateIso: String,
        refundDateIso: String,
        reason: String,
        refundCashVnd: Long,
        refundTransferVnd: Long,
        note: String,
        onCompleted: () -> Unit = {}
    ) {
        viewModelScope.launch {
            repository.cancelContractAndRefund(
                contractId = contractId,
                cancelDateIso = cancelDateIso,
                refundDateIso = refundDateIso,
                reason = reason,
                refundCashVnd = refundCashVnd,
                refundTransferVnd = refundTransferVnd,
                note = note
            ).onSuccess {
                showMessage("Đã hủy hợp đồng và chuyển vào Thùng rác.")
                onCompleted()
            }.onFailure {
                showMessage(it.message ?: "Lỗi khi hủy hợp đồng.")
            }
        }
    }

    // --- PT Actions ---
    fun createPtContract(
        existingPtClientId: String?,
        fullName: String,
        phoneNumber: String,
        registerDateIso: String,
        paymentDateIso: String,
        totalSessions: Int,
        agreedValueVnd: Long,
        cashPaidVnd: Long,
        transferPaidVnd: Long,
        onSuccess: () -> Unit = {}
    ) {
        viewModelScope.launch {
            val snap = dataSnapshot.value
            repository.createPtContract(
                existingPtClientId = existingPtClientId,
                fullName = fullName,
                phoneNumber = phoneNumber,
                registerDateIso = registerDateIso,
                paymentDateIso = paymentDateIso,
                totalSessions = totalSessions,
                agreedValueVnd = agreedValueVnd,
                cashPaidVnd = cashPaidVnd,
                transferPaidVnd = transferPaidVnd,
                allExistingContracts = snap.ptContracts,
                allExistingSessions = snap.ptSessions
            ).onSuccess {
                showMessage("Đã tạo hợp đồng PT ${it.contractCode} (HLV Hà Đức).")
                onSuccess()
            }.onFailure {
                showMessage(it.message ?: "Lỗi tạo hợp đồng PT.")
            }
        }
    }

    fun recordPtSession(
        ptContract: PtContractEntity,
        currentUsedSessions: Int,
        sessionDateIso: String,
        sessionsUsed: Int,
        note: String
    ) {
        viewModelScope.launch {
            repository.recordPtSession(
                ptContract = ptContract,
                currentUsedSessions = currentUsedSessions,
                sessionDateIso = sessionDateIso,
                sessionsUsed = sessionsUsed,
                note = note
            ).onSuccess {
                showMessage("Đã ghi nhận $sessionsUsed buổi tập PT ngày ${DateCalculator.formatDisplay(sessionDateIso)}.")
            }.onFailure {
                showMessage(it.message ?: "Không thể ghi nhận buổi tập PT.")
            }
        }
    }

    fun updatePtContract(
        ptContract: PtContractEntity,
        totalSessions: Int,
        agreedValueVnd: Long,
        registerDateIso: String,
        currentUsedSessions: Int
    ) {
        viewModelScope.launch {
            repository.updatePtContract(ptContract, totalSessions, agreedValueVnd, registerDateIso, currentUsedSessions)
                .onSuccess { showMessage("Đã cập nhật hợp đồng PT ${ptContract.contractCode}.") }
                .onFailure { showMessage(it.message ?: "Không thể sửa hợp đồng PT.") }
        }
    }

    // --- Short-Term Tickets ---
    fun sellShortTermTicket(
        ticketType: String,
        saleDateIso: String,
        quantity: Int,
        unitPriceVnd: Long,
        cashAmountVnd: Long,
        transferAmountVnd: Long,
        onSuccess: () -> Unit = {}
    ) {
        viewModelScope.launch {
            repository.sellShortTermTicket(
                ticketType = ticketType,
                saleDateIso = saleDateIso,
                quantity = quantity,
                unitPriceVnd = unitPriceVnd,
                cashAmountVnd = cashAmountVnd,
                transferAmountVnd = transferAmountVnd
            ).onSuccess {
                showMessage("Đã ghi nhận bán vé ${it.ticketCode}: ${FormatUtils.formatVnd(it.totalAmountVnd)}")
                onSuccess()
            }.onFailure {
                showMessage(it.message ?: "Không thể lưu giao dịch vé.")
            }
        }
    }

    // --- Soft Delete & Unified Trash Actions (Section 9) ---
    fun softDeleteMember(memberId: String, reason: String = "Xóa vào Thùng rác") {
        viewModelScope.launch {
            repository.softDeleteMember(memberId, reason)
            showMessage("Đã chuyển hồ sơ hội viên vào Thùng rác.")
        }
    }

    fun softDeleteContract(contractId: String) {
        viewModelScope.launch {
            repository.softDeleteContract(contractId)
            showMessage("Đã chuyển hợp đồng vào Thùng rác.")
        }
    }

    fun softDeletePtClient(clientId: String) {
        viewModelScope.launch {
            repository.softDeletePtClient(clientId)
            showMessage("Đã chuyển hồ sơ PT vào Thùng rác.")
        }
    }

    fun softDeleteTicket(ticket: ShortTermTicketEntity) {
        viewModelScope.launch {
            repository.softDeleteTicket(ticket)
            showMessage("Đã chuyển giao dịch vé vào Thùng rác.")
        }
    }

    fun restoreTrashItem(item: TrashSelectableItem) {
        viewModelScope.launch {
            when (item.type) {
                TrashItemType.MEMBER -> repository.restoreMemberFromTrash(item.id)
                TrashItemType.CONTRACT -> repository.restoreContractFromTrash(item.id)
                TrashItemType.PRICE_PLAN -> repository.restorePricePlanFromTrash(item.id)
                TrashItemType.PT_CLIENT -> repository.restorePtClient(item.id)
                TrashItemType.TICKET -> {
                    dataSnapshot.value.shortTermTickets.firstOrNull { it.id == item.id }?.let {
                        repository.restoreTicket(it)
                    }
                }
            }
            showMessage("Đã khôi phục: ${item.title}")
        }
    }

    /**
     * Permanently deletes only the user-selected items after explicit confirmation (Section 9.4).
     */
    fun permanentlyDeleteSelectedTrashItems(items: List<TrashSelectableItem>) {
        if (items.isEmpty()) return
        viewModelScope.launch {
            for (item in items) {
                when (item.type) {
                    TrashItemType.MEMBER -> repository.permanentlyDeleteMember(item.id)
                    TrashItemType.CONTRACT -> repository.permanentlyDeleteContract(item.id)
                    TrashItemType.PRICE_PLAN -> repository.permanentlyDeletePricePlan(item.id)
                    TrashItemType.PT_CLIENT -> repository.permanentlyDeletePtClient(item.id)
                    TrashItemType.TICKET -> repository.permanentlyDeleteTicket(item.id)
                }
            }
            showMessage("Đã xóa vĩnh viễn ${items.size} mục đã chọn khỏi Thùng rác.")
        }
    }

    // --- Export PDF & Excel via Android SAF Folder/File Picker (Confirmed Decision 1) ---
    fun requestExportFileToDevice(table: ReportTableData, asExcel: Boolean) {
        val suggested = reportExportManager.suggestedFileName(table, asExcel)
        _pendingExportRequest.value = PendingFileExportRequest(
            table = table,
            asExcel = asExcel,
            suggestedFileName = suggested
        )
    }

    fun cancelPendingExportRequest() {
        _pendingExportRequest.value = null
    }

    fun completeExportFileToUri(uri: Uri) {
        val req = _pendingExportRequest.value ?: return
        _pendingExportRequest.value = null
        viewModelScope.launch {
            val result = reportExportManager.saveReportToDeviceUri(req.table, req.asExcel, uri)
            result.onSuccess { saved ->
                _lastSavedExportResult.value = saved
                showMessage("Đã lưu tệp '${saved.fileName}' vào thiết bị thành công!")
            }.onFailure { err ->
                showMessage("Lỗi khi lưu tệp: ${err.message}")
            }
        }
    }

    fun openSavedExportFile(result: SavedExportResult) {
        reportExportManager.openSavedFile(result)
    }

    fun shareSavedExportFile(result: SavedExportResult) {
        reportExportManager.shareExportedFile(result.localFile, result.mimeType)
    }

    // --- Google Sign-In & Google Drive Backup / Restore ---
    fun signInWithGoogle(activityContext: Context) {
        viewModelScope.launch {
            val res = backupManager.signInWithGoogleCredentialManager(activityContext)
            res.onSuccess { email ->
                preferencesRepository.setGoogleAccount(email)
                showMessage("Đã đăng nhập Google: $email")
            }.onFailure { err ->
                showMessage(err.message ?: "Không thể mở Google Sign-In.")
            }
        }
    }

    fun connectGoogleEmailManual(email: String, accessToken: String) {
        viewModelScope.launch {
            preferencesRepository.setGoogleAccount(email.trim(), accessToken.trim())
            showMessage("Đã lưu cấu hình tài khoản Google Drive: $email")
        }
    }

    fun signOutGoogle() {
        viewModelScope.launch {
            preferencesRepository.setGoogleAccount("", "")
            showMessage("Đã đăng xuất tài khoản Google.")
        }
    }

    fun backupToGoogleDriveAndShare() {
        viewModelScope.launch {
            preferencesRepository.updateBackupStatus("Đang tạo bản sao lưu...", 0L)
            val token = preferencesState.value.googleAccessToken
            val result = backupManager.createBackupFileAndUploadIfAuthorized(token)
            result.onSuccess { file ->
                val now = System.currentTimeMillis()
                preferencesRepository.updateBackupStatus("Đã sao lưu an toàn", now)
                showMessage("Đã tạo bản sao lưu dữ liệu thành công.")
                reportExportManager.shareExportedFile(file, "application/json")
            }.onFailure { err ->
                preferencesRepository.updateBackupStatus("Sao lưu cảnh báo: ${err.message}")
                showMessage(err.message ?: "Lỗi khi sao lưu dữ liệu.")
            }
        }
    }

    fun restoreFromSelectedUri(uri: Uri) {
        viewModelScope.launch {
            preferencesRepository.updateBackupStatus("Đang khôi phục dữ liệu...", 0L)
            val result = backupManager.restoreFromUri(uri)
            result.onSuccess { count ->
                preferencesRepository.updateBackupStatus("Khôi phục thành công ($count bản ghi)", System.currentTimeMillis())
                showMessage("Đã khôi phục và gộp an toàn $count bản ghi!")
            }.onFailure { err ->
                preferencesRepository.updateBackupStatus("Khôi phục thất bại")
                showMessage(err.message ?: "Tệp sao lưu không hợp lệ.")
            }
        }
    }

    fun restoreFromLocalSnapshot() {
        viewModelScope.launch {
            val result = backupManager.restoreFromLocalBackupIfExists()
            result.onSuccess { count ->
                preferencesRepository.updateBackupStatus("Khôi phục cục bộ thành công ($count bản ghi)", System.currentTimeMillis())
                showMessage("Đã khôi phục $count bản ghi từ bản sao lưu gần nhất trên máy!")
            }.onFailure { err ->
                showMessage(err.message ?: "Không tìm thấy bản sao lưu.")
            }
        }
    }

    // --- Helper builders ---
    private fun buildMemberSummaries(snap: AppDataSnapshot, domain: String): List<MemberSummaryUi> {
        val todayIso = DateCalculator.todayIso()
        val domainMembers = snap.members.filter { it.domain == domain && !it.isDeleted }
        val contractsByMember = snap.contracts.filter { it.domain == domain && !it.isDeleted }
            .groupBy { it.memberId }
        val paymentsByMember = snap.payments.filter { it.domain == domain }
            .groupBy { it.memberId }
        val refundsByMember = snap.refunds.filter { it.domain == domain }
            .groupBy { it.memberId }
        val freezesByContract = snap.freezes.groupBy { it.contractId }

        return domainMembers.map { member ->
            val mContracts = (contractsByMember[member.id] ?: emptyList())
                .sortedByDescending { it.endDateIso }
            val activeContracts = mContracts.filter { it.status == "ACTIVE" }
            val currentContract = activeContracts.firstOrNull() ?: mContracts.firstOrNull()
            val mPayments = paymentsByMember[member.id] ?: emptyList()
            val mRefunds = refundsByMember[member.id] ?: emptyList()
            val mFreezes = mContracts.flatMap { freezesByContract[it.id] ?: emptyList() }

            val signedDays = if (currentContract != null) {
                DateCalculator.signedDaysUntilExpiry(todayIso, currentContract.endDateIso)
            } else {
                -9999
            }

            val isValid = currentContract != null && signedDays > 0
            val isTodayExpiring = currentContract != null && signedDays == 0
            val isExpiringSoon = currentContract != null && signedDays in 1..7
            val isExpiring8To15 = currentContract != null && signedDays in 8..15
            val isExpired = currentContract != null && signedDays <= 0

            val paymentsByContract = mPayments.groupBy { it.contractId }
            var totalAgreed = 0L
            var totalPaid = 0L
            var totalDebt = 0L
            var hasOverpayment = false

            for (c in activeContracts) {
                val paidForC = (paymentsByContract[c.id] ?: emptyList()).sumOf { it.totalAmountVnd }
                totalAgreed += c.agreedValueVnd
                totalPaid += paidForC
                val diff = c.agreedValueVnd - paidForC
                if (diff > 0L) {
                    totalDebt += diff
                } else if (diff < 0L) {
                    hasOverpayment = true
                }
            }

            MemberSummaryUi(
                member = member,
                currentContract = currentContract,
                allContracts = mContracts,
                payments = mPayments,
                refunds = mRefunds,
                freezes = mFreezes,
                signedDaysRemaining = signedDays,
                isValid = isValid,
                isTodayExpiring = isTodayExpiring,
                isExpiringSoon = isExpiringSoon,
                isExpiring8To15 = isExpiring8To15,
                isExpired = isExpired,
                statusText = buildMemberStatusText(signedDays, currentContract != null),
                totalAgreedVnd = totalAgreed,
                totalPaidVnd = totalPaid,
                totalDebtVnd = totalDebt,
                hasOverpaymentWarning = hasOverpayment
            )
        }
    }

    private fun buildContractDebts(snap: AppDataSnapshot, domain: String): List<ContractDebtUi> {
        val membersById = snap.members.associateBy { it.id }
        val paymentsByContract = snap.payments.groupBy { it.contractId }
        return snap.contracts
            .filter { it.domain == domain && !it.isDeleted && it.status == "ACTIVE" }
            .mapNotNull { contract ->
                val member = membersById[contract.memberId]
                val cPayments = paymentsByContract[contract.id] ?: emptyList()
                val paid = cPayments.sumOf { it.totalAmountVnd }
                val debt = (contract.agreedValueVnd - paid).coerceAtLeast(0L)
                val overpaid = (paid - contract.agreedValueVnd).coerceAtLeast(0L)
                if (debt > 0L || overpaid > 0L) {
                    ContractDebtUi(
                        contract = contract,
                        memberName = member?.fullName ?: "Hội viên",
                        memberPhone = member?.phoneNumber ?: "",
                        payments = cPayments,
                        totalPaidVnd = paid,
                        debtVnd = debt,
                        overpaidVnd = overpaid
                    )
                } else {
                    null
                }
            }
    }

    private fun buildPtClientSummaries(snap: AppDataSnapshot): List<PtClientSummaryUi> {
        val contractsByClient = snap.ptContracts.filter { !it.isDeleted }.groupBy { it.ptClientId }
        val sessionsByContract = snap.ptSessions.groupBy { it.ptContractId }

        return snap.ptClients.filter { !it.isDeleted }.map { client ->
            val cContracts = (contractsByClient[client.id] ?: emptyList()).sortedByDescending { it.registerDateIso }
            val active = cContracts.firstOrNull { it.status == "ACTIVE" } ?: cContracts.firstOrNull()
            val allClientSessions = cContracts.flatMap { sessionsByContract[it.id] ?: emptyList() }
                .sortedByDescending { it.sessionDateIso }
            val usedOnActive = if (active != null) {
                (sessionsByContract[active.id] ?: emptyList()).sumOf { it.sessionsUsed }
            } else {
                0
            }
            val remainingOnActive = if (active != null) {
                (active.totalSessions - usedOnActive).coerceAtLeast(0)
            } else {
                0
            }
            PtClientSummaryUi(
                client = client,
                activeContract = active,
                allContracts = cContracts,
                allSessions = allClientSessions,
                usedSessionsOnActive = usedOnActive,
                remainingSessionsOnActive = remainingOnActive
            )
        }
    }

    class Factory(private val context: Context) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            val appContext = context.applicationContext
            val db = AppDatabase.getInstance(appContext)
            val dao = db.appDao()
            val repo = FitnessRepository(dao)
            val prefs = UserPreferencesRepository(appContext)
            val avatarMgr = AvatarStorageManager(appContext)
            val exportMgr = ReportExportManager(appContext)
            val backupMgr = GoogleDriveBackupManager(appContext, dao)
            return FitnessViewModel(repo, prefs, avatarMgr, exportMgr, backupMgr) as T
        }
    }
}
