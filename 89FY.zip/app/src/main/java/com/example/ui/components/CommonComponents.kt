package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.model.PaymentMethod
import com.example.domain.FitnessCalculator

@Composable
fun ScreenHeaderBar(
    title: String,
    subtitle: String? = null,
    accentColor: Color = MaterialTheme.colorScheme.primary,
    onBack: () -> Unit,
    actions: @Composable () -> Unit = {}
) {
    Surface(
        color = accentColor,
        contentColor = Color.White,
        shadowElevation = 2.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.testTag("back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Quay lại",
                    tint = Color.White
                )
            }
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 4.dp)
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    maxLines = 1
                )
                if (!subtitle.isNullOrBlank()) {
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White.copy(alpha = 0.88f),
                        maxLines = 1
                    )
                }
            }
            actions()
        }
    }
}

@Composable
fun DatePickerField(
    label: String,
    isoDate: String,
    onDateSelected: (String) -> Unit,
    modifier: Modifier = Modifier,
    accentColor: Color = MaterialTheme.colorScheme.primary
) {
    var showPicker by remember { mutableStateOf(false) }
    val displayValue = FitnessCalculator.formatDisplayDate(isoDate)

    Box(modifier = modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = displayValue,
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            trailingIcon = {
                IconButton(
                    onClick = { showPicker = true },
                    modifier = Modifier.testTag("datepicker_open_button_$label")
                ) {
                    Icon(
                        imageVector = Icons.Default.CalendarMonth,
                        contentDescription = "Chọn ngày $label",
                        tint = accentColor
                    )
                }
            },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("datepicker_field_$label")
        )
        // Lớp phủ trong suốt giúp nhấn vào bất kỳ vị trí nào trên ô ngày đều mở hộp thoại chọn ngày Tiếng Việt
        Box(
            modifier = Modifier
                .matchParentSize()
                .clickable { showPicker = true }
        )
    }

    if (showPicker) {
        VietnameseDatePickerDialog(
            label = label,
            initialIsoDate = isoDate,
            accentColor = accentColor,
            onDateConfirmed = { newIso ->
                onDateSelected(newIso)
                showPicker = false
            },
            onDismiss = { showPicker = false }
        )
    }
}

@Composable
fun VietnameseDatePickerDialog(
    label: String,
    initialIsoDate: String,
    accentColor: Color = MaterialTheme.colorScheme.primary,
    onDateConfirmed: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val todayIso = remember { FitnessCalculator.todayIso() }
    val initialTriple = remember(initialIsoDate, todayIso) {
        FitnessCalculator.parseIso(initialIsoDate)
            ?: FitnessCalculator.parseIso(todayIso)
            ?: Triple(2026, 1, 1)
    }

    var selectedYear by remember(initialTriple) { mutableIntStateOf(initialTriple.first) }
    var selectedMonth by remember(initialTriple) { mutableIntStateOf(initialTriple.second) }
    var selectedDay by remember(initialTriple) { mutableIntStateOf(initialTriple.third) }

    var viewYear by remember(initialTriple) { mutableIntStateOf(initialTriple.first) }
    var viewMonth by remember(initialTriple) { mutableIntStateOf(initialTriple.second) }
    var showYearSelector by remember { mutableStateOf(false) }

    val selectedIso = FitnessCalculator.formatIso(selectedYear, selectedMonth, selectedDay)
    val selectedFullVietnameseText = FitnessCalculator.formatVietnameseFullDate(selectedIso)
    val selectedShortDisplay = FitnessCalculator.formatDisplayDate(selectedIso)
    val monthYearTitle = FitnessCalculator.formatVietnameseMonthYear(viewYear, viewMonth)

    val daysInCurrentMonth = FitnessCalculator.daysInMonth(viewYear, viewMonth)
    val leadingEmptyCells = FitnessCalculator.dayOfWeekMondayFirst(viewYear, viewMonth, 1)
    val todayTriple = FitnessCalculator.parseIso(todayIso)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("vietnamese_datepicker_dialog"),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Chọn ngày — $label",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    TextButton(
                        onClick = {
                            if (todayTriple != null) {
                                selectedYear = todayTriple.first
                                selectedMonth = todayTriple.second
                                selectedDay = todayTriple.third
                                viewYear = todayTriple.first
                                viewMonth = todayTriple.second
                                showYearSelector = false
                            }
                        },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.testTag("datepicker_today_button")
                    ) {
                        Text("Hôm nay", color = accentColor, style = MaterialTheme.typography.labelMedium)
                    }
                }

                Surface(
                    color = accentColor.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = selectedFullVietnameseText,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = accentColor,
                            modifier = Modifier.testTag("datepicker_selected_full_text")
                        )
                        Text(
                            text = selectedShortDisplay,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.testTag("datepicker_selected_short_text")
                        )
                    }
                }
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Thanh điều hướng Tháng / Năm hoàn toàn bằng Tiếng Việt
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            if (viewMonth == 1) {
                                viewMonth = 12
                                viewYear -= 1
                            } else {
                                viewMonth -= 1
                            }
                        },
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("datepicker_prev_month_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                            contentDescription = "Tháng trước",
                            tint = accentColor
                        )
                    }

                    Surface(
                        onClick = { showYearSelector = !showYearSelector },
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.testTag("datepicker_month_year_header")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = monthYearTitle,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = "Chọn năm",
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    IconButton(
                        onClick = {
                            if (viewMonth == 12) {
                                viewMonth = 1
                                viewYear += 1
                            } else {
                                viewMonth += 1
                            }
                        },
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("datepicker_next_month_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                            contentDescription = "Tháng sau",
                            tint = accentColor
                        )
                    }
                }

                HorizontalDivider()

                if (showYearSelector) {
                    val years = remember { (2020..2035).toList() }
                    Text(
                        text = "Chọn năm:",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(4),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 220.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(years) { yr ->
                            val isSelectedYear = yr == viewYear
                            Surface(
                                onClick = {
                                    viewYear = yr
                                    selectedYear = yr
                                    val maxD = FitnessCalculator.daysInMonth(viewYear, selectedMonth)
                                    if (selectedDay > maxD) selectedDay = maxD
                                    showYearSelector = false
                                },
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelectedYear) accentColor else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                            ) {
                                Text(
                                    text = yr.toString(),
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = if (isSelectedYear) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelectedYear) Color.White else MaterialTheme.colorScheme.onSurface,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(vertical = 8.dp)
                                )
                            }
                        }
                    }
                } else {
                    // Hàng tiêu đề các thứ trong tuần bằng Tiếng Việt: T2..CN
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        FitnessCalculator.vietnameseWeekdayShortLabels.forEach { dayLabel ->
                            Text(
                                text = dayLabel,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (dayLabel == "CN") MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    // Lưới ngày trong tháng (6 hàng × 7 cột tối đa)
                    val totalCells = leadingEmptyCells + daysInCurrentMonth
                    val rows = (totalCells + 6) / 7
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        for (row in 0 until rows) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceEvenly
                            ) {
                                for (col in 0 until 7) {
                                    val cellIndex = row * 7 + col
                                    val dayNumber = cellIndex - leadingEmptyCells + 1
                                    if (dayNumber in 1..daysInCurrentMonth) {
                                        val isSelected = (viewYear == selectedYear && viewMonth == selectedMonth && dayNumber == selectedDay)
                                        val isToday = (todayTriple != null && viewYear == todayTriple.first && viewMonth == todayTriple.second && dayNumber == todayTriple.third)

                                        Box(
                                            contentAlignment = Alignment.Center,
                                            modifier = Modifier
                                                .weight(1f)
                                                .aspectRatio(1f)
                                                .padding(2.dp)
                                                .clip(CircleShape)
                                                .background(
                                                    if (isSelected) accentColor else Color.Transparent
                                                )
                                                .then(
                                                    if (isToday && !isSelected) {
                                                        Modifier.border(1.2.dp, accentColor, CircleShape)
                                                    } else {
                                                        Modifier
                                                    }
                                                )
                                                .clickable {
                                                    selectedYear = viewYear
                                                    selectedMonth = viewMonth
                                                    selectedDay = dayNumber
                                                }
                                                .testTag("datepicker_day_$dayNumber")
                                        ) {
                                            Text(
                                                text = dayNumber.toString(),
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = if (isSelected || isToday) FontWeight.Bold else FontWeight.Normal,
                                                color = when {
                                                    isSelected -> Color.White
                                                    isToday -> accentColor
                                                    else -> MaterialTheme.colorScheme.onSurface
                                                }
                                            )
                                        }
                                    } else {
                                        Spacer(
                                            modifier = Modifier
                                                .weight(1f)
                                                .aspectRatio(1f)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onDateConfirmed(selectedIso) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = accentColor,
                    contentColor = Color.White
                ),
                modifier = Modifier.testTag("datepicker_confirm_button")
            ) {
                Text("Chọn")
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("datepicker_cancel_button")
            ) {
                Text("Hủy")
            }
        }
    )
}

@Composable
fun PaymentMethodSelectorSection(
    paidAmount: Long,
    selectedMethod: String,
    onMethodChange: (String) -> Unit,
    cashAmountText: String,
    onCashAmountChange: (String) -> Unit,
    transferAmountText: String,
    onTransferAmountChange: (String) -> Unit,
    accentColor: Color = MaterialTheme.colorScheme.primary
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "Phương thức thanh toán",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            PaymentMethod.entries.forEach { method ->
                val selected = selectedMethod == method.code
                FilterChip(
                    selected = selected,
                    onClick = { onMethodChange(method.code) },
                    label = { Text(method.label) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = accentColor,
                        selectedLabelColor = Color.White
                    ),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        if (selectedMethod == PaymentMethod.COMBINED.code) {
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = cashAmountText,
                    onValueChange = { onCashAmountChange(it.filter { ch -> ch.isDigit() }) },
                    label = { Text("Tiền mặt") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = transferAmountText,
                    onValueChange = { onTransferAmountChange(it.filter { ch -> ch.isDigit() }) },
                    label = { Text("Chuyển khoản") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
            }
            val cash = cashAmountText.toLongOrNull() ?: 0L
            val transfer = transferAmountText.toLongOrNull() ?: 0L
            val sum = cash + transfer
            val isValidSum = sum == paidAmount
            if (!isValidSum) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Tổng TM + CK (${FitnessCalculator.formatCurrency(sum)}) phải bằng ${FitnessCalculator.formatCurrency(paidAmount)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
fun ReviewAndConfirmDialog(
    title: String,
    summaryItems: List<Pair<String, String>>,
    accentColor: Color = MaterialTheme.colorScheme.primary,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = null,
                tint = accentColor,
                modifier = Modifier.size(28.dp)
            )
        },
        title = {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                summaryItems.forEach { (label, value) ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.weight(0.42f)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = value,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.weight(0.58f)
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(
                    containerColor = accentColor,
                    contentColor = Color.White
                ),
                modifier = Modifier.testTag("confirm_save_button")
            ) {
                Text("Xác nhận lưu")
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("dismiss_review_button")
            ) {
                Text("Sửa lại")
            }
        }
    )
}

@Composable
fun ConfirmDeleteDialog(
    title: String,
    message: String,
    isPermanent: Boolean = false,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                imageVector = if (isPermanent) Icons.Default.DeleteForever else Icons.Default.Warning,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(28.dp)
            )
        },
        title = {
            Text(text = title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        },
        text = {
            Text(text = message, style = MaterialTheme.typography.bodyMedium)
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error,
                    contentColor = Color.White
                ),
                modifier = Modifier.testTag("confirm_delete_button")
            ) {
                Text(if (isPermanent) "Xóa vĩnh viễn" else "Chuyển vào Thùng rác")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Hủy")
            }
        }
    )
}

@Composable
fun MonthYearPickerRow(
    year: Int,
    month: Int,
    onYearMonthChange: (Int, Int) -> Unit,
    accentColor: Color = MaterialTheme.colorScheme.primary
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.35f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            TextButton(
                onClick = {
                    if (month == 1) onYearMonthChange(year - 1, 12)
                    else onYearMonthChange(year, month - 1)
                }
            ) {
                Text("◀ Tháng trước", color = accentColor)
            }

            Text(
                text = String.format("Tháng %02d / %04d", month, year),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = accentColor
            )

            TextButton(
                onClick = {
                    if (month == 12) onYearMonthChange(year + 1, 1)
                    else onYearMonthChange(year, month + 1)
                }
            ) {
                Text("Tháng sau ▶", color = accentColor)
            }
        }
    }
}
