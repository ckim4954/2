package com.example.ui.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.domain.DateCalculator
import com.example.ui.theme.*
import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FitnessTopAppBar(
    title: String,
    subtitle: String? = null,
    domainBadge: String? = null, // "GYM" or "YOGA"
    onBackClick: (() -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {}
) {
    TopAppBar(
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )
                if (!subtitle.isNullOrBlank()) {
                    Text(
                        text = "• $subtitle",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1
                    )
                }
                if (domainBadge != null) {
                    DomainBadge(domain = domainBadge)
                }
            }
        },
        navigationIcon = {
            if (onBackClick != null) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Quay lại"
                    )
                }
            }
        },
        actions = actions,
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.surface,
            titleContentColor = MaterialTheme.colorScheme.onSurface
        )
    )
}

@Composable
fun DomainBadge(domain: String) {
    val isGym = domain == "GYM"
    val bgColor = if (isGym) GymEmeraldLight.copy(alpha = 0.14f) else YogaIndigoLight.copy(alpha = 0.14f)
    val textColor = if (isGym) GymEmeraldLight else YogaIndigoLight
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .padding(horizontal = 8.dp, vertical = 2.dp)
    ) {
        Text(
            text = if (isGym) "GYM" else "YOGA",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = textColor
        )
    }
}

@Composable
fun StatusPill(
    text: String,
    tone: StatusTone
) {
    val (bg, fg) = when (tone) {
        StatusTone.SUCCESS -> StatusActiveGreen.copy(alpha = 0.14f) to StatusActiveGreen
        StatusTone.WARNING -> StatusWarningAmber.copy(alpha = 0.16f) to StatusWarningAmber
        StatusTone.DANGER -> StatusDangerRed.copy(alpha = 0.14f) to StatusDangerRed
        StatusTone.INFO -> YogaIndigoLight.copy(alpha = 0.14f) to YogaIndigoLight
        StatusTone.NEUTRAL -> MaterialTheme.colorScheme.surfaceVariant to MaterialTheme.colorScheme.onSurfaceVariant
    }
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bg)
            .padding(horizontal = 8.dp, vertical = 2.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.SemiBold,
            color = fg
        )
    }
}

enum class StatusTone {
    SUCCESS, WARNING, DANGER, INFO, NEUTRAL
}

/**
 * Native Android Date Picker field (Section 5.2):
 * - Opens Android native DatePickerDialog with day/month/year selection, month navigation, Cancel and OK buttons
 * - Displays date in dd/mm/yyyy format
 * - Supports readOnly mode (no cursor, no dialog when readOnly = true) for saved contracts before clicking "Sửa hợp đồng"
 */
@Composable
fun DateInputField(
    label: String,
    isoDate: String,
    onIsoDateChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    readOnly: Boolean = false,
    testTagName: String = "date_input"
) {
    val context = LocalContext.current
    val displayValue = remember(isoDate) { DateCalculator.formatDisplay(isoDate) }

    fun openNativeDatePicker() {
        if (readOnly) return
        val cal = Calendar.getInstance()
        val parts = isoDate.split("-")
        val initYear = parts.getOrNull(0)?.toIntOrNull() ?: cal.get(Calendar.YEAR)
        val initMonth = (parts.getOrNull(1)?.toIntOrNull() ?: (cal.get(Calendar.MONTH) + 1)) - 1
        val initDay = parts.getOrNull(2)?.toIntOrNull() ?: cal.get(Calendar.DAY_OF_MONTH)

        val dialog = DatePickerDialog(
            context,
            { _, selectedYear, selectedMonthZeroBased, selectedDay ->
                val pickedIso = String.format(
                    java.util.Locale.US,
                    "%04d-%02d-%02d",
                    selectedYear,
                    selectedMonthZeroBased + 1,
                    selectedDay
                )
                onIsoDateChange(pickedIso)
            },
            initYear,
            initMonth,
            initDay
        )
        dialog.setButton(DatePickerDialog.BUTTON_POSITIVE, "OK", dialog)
        dialog.setButton(DatePickerDialog.BUTTON_NEGATIVE, "Hủy", dialog)
        dialog.show()
    }

    if (readOnly) {
        ReadOnlyInfoRow(label = label, value = displayValue, modifier = modifier.testTag(testTagName))
    } else {
        Box(modifier = modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = displayValue,
                onValueChange = { typed ->
                    val parsed = DateCalculator.parseDisplayToIso(typed)
                    if (parsed != null) {
                        onIsoDateChange(parsed)
                    }
                },
                readOnly = true,
                label = { Text(label) },
                trailingIcon = {
                    IconButton(onClick = { openNativeDatePicker() }) {
                        Icon(
                            imageVector = Icons.Default.CalendarMonth,
                            contentDescription = "Chọn ngày $label"
                        )
                    }
                },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag(testTagName)
            )
            // Transparent overlay to open the native Android calendar on field tap
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .clickable { openNativeDatePicker() }
            )
        }
    }
}

@Composable
fun VndAmountField(
    label: String,
    amountVnd: Long,
    onAmountChange: (Long) -> Unit,
    modifier: Modifier = Modifier,
    readOnly: Boolean = false,
    testTagName: String = "vnd_input"
) {
    if (readOnly) {
        ReadOnlyInfoRow(
            label = label,
            value = com.example.domain.FormatUtils.formatVnd(amountVnd),
            modifier = modifier.testTag(testTagName)
        )
    } else {
        var rawText by remember(amountVnd) {
            mutableStateOf(if (amountVnd == 0L) "" else amountVnd.toString())
        }

        OutlinedTextField(
            value = rawText,
            onValueChange = { input ->
                val digits = input.filter { it.isDigit() }
                rawText = digits
                onAmountChange(digits.toLongOrNull() ?: 0L)
            },
            label = { Text(label) },
            suffix = { Text("VNĐ", style = MaterialTheme.typography.labelMedium) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = modifier
                .fillMaxWidth()
                .testTag(testTagName)
        )
    }
}

/**
 * Clean read-only field with no text cursor when viewing saved records before enabling edit mode (Section 5.2).
 */
@Composable
fun ReadOnlyInfoRow(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
        shape = RoundedCornerShape(8.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = value.ifBlank { "—" },
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}
