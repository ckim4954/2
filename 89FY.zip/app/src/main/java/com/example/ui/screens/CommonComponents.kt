package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.domain.DateCalculator
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FitnessTopAppBar(
    title: String,
    subtitle: String? = null,
    domainBadge: String? = null, // "GYM" or "YOGA"
    onBackClick: (() -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {}
) {
    TopAppBar(
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Column(modifier = Modifier.weight(1f, fill = false)) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                    if (!subtitle.isNullOrBlank()) {
                        Text(
                            text = subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1
                        )
                    }
                }
                if (domainBadge != null) {
                    DomainBadge(domain = domainBadge)
                }
            }
        },
        navigationIcon = {
            if (onBackClick != null) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Quay lại"
                    )
                }
            }
        },
        actions = actions,
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.surface,
            titleContentColor = MaterialTheme.colorScheme.onSurface
        )
    )
}

@Composable
fun DomainBadge(domain: String) {
    val isGym = domain == "GYM"
    val bgColor = if (isGym) GymEmeraldLight.copy(alpha = 0.14f) else YogaIndigoLight.copy(alpha = 0.14f)
    val textColor = if (isGym) GymEmeraldLight else YogaIndigoLight
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(bgColor)
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(
            text = if (isGym) "GYM" else "YOGA",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = textColor
        )
    }
}

@Composable
fun StatusPill(
    text: String,
    tone: StatusTone
) {
    val (bg, fg) = when (tone) {
        StatusTone.SUCCESS -> StatusActiveGreen.copy(alpha = 0.14f) to StatusActiveGreen
        StatusTone.WARNING -> StatusWarningAmber.copy(alpha = 0.16f) to StatusWarningAmber
        StatusTone.DANGER -> StatusDangerRed.copy(alpha = 0.14f) to StatusDangerRed
        StatusTone.INFO -> YogaIndigoLight.copy(alpha = 0.14f) to YogaIndigoLight
        StatusTone.NEUTRAL -> MaterialTheme.colorScheme.surfaceVariant to MaterialTheme.colorScheme.onSurfaceVariant
    }
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bg)
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.SemiBold,
            color = fg
        )
    }
}

enum class StatusTone {
    SUCCESS, WARNING, DANGER, INFO, NEUTRAL
}

/**
 * Date input field supporting dd/mm/yyyy display and quick editing.
 */
@Composable
fun DateInputField(
    label: String,
    isoDate: String,
    onIsoDateChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    testTagName: String = "date_input"
) {
    var textValue by remember(isoDate) {
        mutableStateOf(DateCalculator.formatDisplay(isoDate))
    }
    var isError by remember { mutableStateOf(false) }

    OutlinedTextField(
        value = textValue,
        onValueChange = { newText ->
            textValue = newText
            val parsedIso = DateCalculator.parseDisplayToIso(newText)
            if (parsedIso != null) {
                isError = false
                onIsoDateChange(parsedIso)
            } else {
                isError = newText.length >= 8
            }
        },
        label = { Text(label) },
        placeholder = { Text("dd/mm/yyyy") },
        isError = isError,
        supportingText = if (isError) {
            { Text("Nhập đúng định dạng dd/mm/yyyy (VD: 15/10/2026)") }
        } else null,
        singleLine = true,
        modifier = modifier
            .fillMaxWidth()
            .testTag(testTagName)
    )
}

@Composable
fun VndAmountField(
    label: String,
    amountVnd: Long,
    onAmountChange: (Long) -> Unit,
    modifier: Modifier = Modifier,
    testTagName: String = "vnd_input"
) {
    var rawText by remember(amountVnd) {
        mutableStateOf(if (amountVnd == 0L) "" else amountVnd.toString())
    }

    OutlinedTextField(
        value = rawText,
        onValueChange = { input ->
            val digits = input.filter { it.isDigit() }
            rawText = digits
            onAmountChange(digits.toLongOrNull() ?: 0L)
        },
        label = { Text(label) },
        suffix = { Text("VNĐ", style = MaterialTheme.typography.labelMedium) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        singleLine = true,
        modifier = modifier
            .fillMaxWidth()
            .testTag(testTagName)
    )
}
