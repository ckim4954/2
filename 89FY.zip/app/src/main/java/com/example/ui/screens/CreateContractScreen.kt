package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.ContractEntity
import com.example.data.local.PricePlanEntity
import com.example.domain.DateCalculator
import com.example.domain.FormatUtils
import com.example.ui.MemberSummaryUi
import com.example.ui.PtClientSummaryUi
import com.example.ui.theme.*

/**
 * Unified 4-Step Contract Creation Screen (Section 5):
 * Step 1: Select Domain (Gym or Yoga)
 * Step 2: Select Service Type:
 *   - Gym: Đăng ký mới (NEW), Gia hạn (RENEWAL), PT, Vé ngày (VE_NGAY), Vé tuần (VE_TUAN)
 *   - Yoga: Đăng ký mới (NEW), Gia hạn (RENEWAL)
 * Step 3: Fill dynamic form (auto-applying price catalog, renewal rules, duplicate warnings)
 * Step 4: Save contract / transaction
 */
@Composable
fun CreateContractScreen(
    preselectedDomain: String?,
    preselectedService: String?,
    renewalMemberId: String?,
    fromPtClientId: String?,
    pricePlans: List<PricePlanEntity>,
    gymMembers: List<MemberSummaryUi>,
    yogaMembers: List<MemberSummaryUi>,
    ptClients: List<PtClientSummaryUi>,
    onBack: () -> Unit,
    onOpenSettingsToConfigurePrices: () -> Unit,
    onOpenPtManagement: () -> Unit,
    onSaveMemberContract: (
        domain: String,
        existingMemberId: String?,
        linkedPtClientId: String?,
        fullName: String,
        phoneNumber: String,
        customerGroup: String,
        avatarPath: String?,
        pricePlanId: String?,
        planNameSnapshot: String,
        durationMonths: Int,
        agreedValueVnd: Long,
        paymentDateIso: String,
        createdDateIso: String,
        startDateIso: String,
        cashPaidVnd: Long,
        transferPaidVnd: Long,
        onSuccess: (ContractEntity) -> Unit
    ) -> Unit,
    onSavePtContract: (
        existingPtClientId: String?,
        fullName: String,
        phoneNumber: String,
        registerDateIso: String,
        paymentDateIso: String,
        totalSessions: Int,
        agreedValueVnd: Long,
        cashPaidVnd: Long,
        transferPaidVnd: Long,
        onSuccess: () -> Unit
    ) -> Unit,
    onSaveTicket: (
        ticketType: String,
        saleDateIso: String,
        quantity: Int,
        unitPriceVnd: Long,
        cashAmountVnd: Long,
        transferAmountVnd: Long,
        onSuccess: () -> Unit
    ) -> Unit
) {
    val todayIso = remember { DateCalculator.todayIso() }

    // Step 1: Domain ("GYM" or "YOGA")
    var selectedDomain by remember(preselectedDomain) {
        mutableStateOf(preselectedDomain ?: "GYM")
    }

    // Step 2: Service Type ("NEW", "RENEWAL", "PT", "VE_NGAY", "VE_TUAN")
    var selectedService by remember(preselectedService, renewalMemberId, fromPtClientId) {
        mutableStateOf(
            when {
                !preselectedService.isNullOrBlank() -> preselectedService
                !renewalMemberId.isNullOrBlank() || !fromPtClientId.isNullOrBlank() -> "RENEWAL"
                else -> "NEW"
            }
        )
    }

    val domainMembers = if (selectedDomain == "GYM") gymMembers else yogaMembers
    val prefillRenewalMember = remember(renewalMemberId, domainMembers) {
        domainMembers.firstOrNull { it.member.id == renewalMemberId }
    }
    val prefillPtClient = remember(fromPtClientId, ptClients) {
        ptClients.firstOrNull { it.client.id == fromPtClientId }
    }

    // Selected existing member for renewal (or when customer returns)
    var selectedExistingMemberId by remember(prefillRenewalMember) {
        mutableStateOf(prefillRenewalMember?.member?.id)
    }
    var selectedPtClientId by remember(prefillPtClient) {
        mutableStateOf(prefillPtClient?.client?.id)
    }

    var fullName by remember(prefillRenewalMember, prefillPtClient) {
        mutableStateOf(
            prefillRenewalMember?.member?.fullName
                ?: prefillPtClient?.client?.fullName
                ?: ""
        )
    }
    var phoneNumber by remember(prefillRenewalMember, prefillPtClient) {
        mutableStateOf(
            prefillRenewalMember?.member?.phoneNumber
                ?: prefillPtClient?.client?.phoneNumber
                ?: ""
        )
    }
    var customerGroup by remember(selectedDomain, prefillRenewalMember) {
        mutableStateOf(
            if (selectedDomain == "YOGA") "YOGA"
            else (prefillRenewalMember?.member?.customerGroup ?: "NAM")
        )
    }

    // 4 Separate Date Fields (Section 5.3)
    var paymentDateIso by remember { mutableStateOf(todayIso) }
    var createdDateIso by remember { mutableStateOf(todayIso) }
    var startDateIso by remember(prefillRenewalMember, createdDateIso) {
        val oldEnd = prefillRenewalMember?.endDateIso
        val calculatedStart = if (!oldEnd.isNullOrBlank()) {
            DateCalculator.calculateRenewalStartDate(oldEnd, createdDateIso)
        } else {
            todayIso
        }
        mutableStateOf(calculatedStart)
    }

    // Filter active price plans for current domain & service
    val availablePlans = remember(pricePlans, selectedDomain, selectedService, customerGroup) {
        pricePlans.filter { plan ->
            plan.isActive && plan.domain == selectedDomain && when (selectedService) {
                "PT" -> plan.category == "PT"
                "VE_NGAY" -> plan.category == "VE_NGAY"
                "VE_TUAN" -> plan.category == "VE_TUAN"
                else -> {
                    if (selectedDomain == "YOGA") plan.category == "YOGA"
                    else plan.category == customerGroup
                }
            }
        }
    }

    var selectedPlan by remember(availablePlans) {
        mutableStateOf(availablePlans.firstOrNull())
    }
    var customPlanName by remember(selectedPlan) {
        mutableStateOf(selectedPlan?.planName ?: "")
    }
    var durationMonths by remember(selectedPlan) {
        mutableStateOf(selectedPlan?.durationMonths?.takeIf { it > 0 } ?: 1)
    }
    var ptSessionsCount by remember(selectedPlan) {
        mutableStateOf(selectedPlan?.sessionCount?.takeIf { it > 0 } ?: 12)
    }
    var ticketQuantity by remember { mutableStateOf(1) }
    var agreedValueVnd by remember(selectedPlan) {
        mutableStateOf(selectedPlan?.priceVnd ?: 0L)
    }
    var cashPaidVnd by remember(agreedValueVnd) {
        mutableStateOf(agreedValueVnd)
    }
    var transferPaidVnd by remember { mutableStateOf(0L) }

    val calculatedEndDateIso = remember(startDateIso, durationMonths) {
        DateCalculator.calculateEndDate(startDateIso, durationMonths)
    }

    // Duplicate detection warning (Section 5.2 & 23.2)
    val matchingExistingMember = remember(fullName, phoneNumber, domainMembers, selectedExistingMemberId) {
        if (selectedExistingMemberId != null) null
        else {
            val cleanPhone = phoneNumber.trim()
            val cleanName = fullName.trim().lowercase()
            domainMembers.firstOrNull { m ->
                (cleanPhone.isNotEmpty() && m.member.phoneNumber == cleanPhone) ||
                    (cleanName.length >= 4 && m.member.fullName.lowercase() == cleanName)
            }
        }
    }

    Scaffold(
        topBar = {
            FitnessTopAppBar(
                title = "Tạo hợp đồng",
                subtitle = "Quy trình 4 bước chuẩn nghiệp vụ",
                domainBadge = selectedDomain,
                onBackClick = onBack
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // STEP 1: Choose Domain (Gym vs Yoga)
            ElevatedCard(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Bước 1: Chọn lĩnh vực độc lập",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        FilterChip(
                            selected = selectedDomain == "GYM",
                            onClick = {
                                selectedDomain = "GYM"
                                customerGroup = "NAM"
                                selectedExistingMemberId = null
                            },
                            label = { Text("GYM") },
                            leadingIcon = { Icon(Icons.Default.FitnessCenter, contentDescription = null) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("step1_domain_gym")
                        )
                        FilterChip(
                            selected = selectedDomain == "YOGA",
                            onClick = {
                                selectedDomain = "YOGA"
                                customerGroup = "YOGA"
                                selectedExistingMemberId = null
                                if (selectedService !in listOf("NEW", "RENEWAL")) {
                                    selectedService = "NEW"
                                }
                            },
                            label = { Text("YOGA") },
                            leadingIcon = { Icon(Icons.Default.SelfImprovement, contentDescription = null) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("step1_domain_yoga")
                        )
                    }
                }
            }

            // STEP 2: Choose Service Type
            ElevatedCard(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Bước 2: Chọn loại dịch vụ ($selectedDomain)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    val serviceOptions = if (selectedDomain == "GYM") {
                        listOf(
                            "NEW" to "Đăng ký mới",
                            "RENEWAL" to "Gia hạn",
                            "PT" to "Dịch vụ PT (Hà Đức)",
                            "VE_NGAY" to "Vé ngày",
                            "VE_TUAN" to "Vé tuần"
                        )
                    } else {
                        listOf(
                            "NEW" to "Đăng ký mới",
                            "RENEWAL" to "Gia hạn"
                        )
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        serviceOptions.chunked(2).forEach { rowItems ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                rowItems.forEach { (code, label) ->
                                    FilterChip(
                                        selected = selectedService == code,
                                        onClick = { selectedService = code },
                                        label = { Text(label) },
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("step2_service_${code.lowercase()}")
                                    )
                                }
                                if (rowItems.size == 1) {
                                    Spacer(modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            }

            // STEP 3 & 4: Service-Specific Form
            ElevatedCard(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Bước 3 & 4: Biểu mẫu & Lưu hợp đồng",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )

                    // Unconfigured Price Plan Notice (Section 2.4: No fake prices!)
                    if (availablePlans.isEmpty()) {
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = StatusWarningAmber.copy(alpha = 0.14f)
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "Chưa thiết lập bảng giá cho mục này",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = StatusWarningAmber
                                )
                                Text(
                                    text = "Theo quy tắc không tạo dữ liệu giả, vui lòng thiết lập giá thực tế trong phân hệ Cài đặt hoặc nhập giá thỏa thuận trực tiếp bên dưới.",
                                    style = MaterialTheme.typography.bodySmall
                                )
                                OutlinedButton(
                                    onClick = onOpenSettingsToConfigurePrices,
                                    modifier = Modifier.testTag("goto_settings_price_btn")
                                ) {
                                    Icon(Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Mở Cài đặt Bảng giá")
                                }
                            }
                        }
                    }

                    when (selectedService) {
                        "VE_NGAY", "VE_TUAN" -> {
                            // Short-term ticket form (Section 7: No member profile needed)
                            val ticketLabel = if (selectedService == "VE_NGAY") "Vé tập Ngày" else "Vé tập Tuần"
                            Text(
                                text = "Bán $ticketLabel (Chỉ áp dụng cho Gym — Không cần tạo hồ sơ hội viên)",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = GymEmeraldLight
                            )

                            DateInputField(
                                label = "Ngày bán vé",
                                isoDate = paymentDateIso,
                                onIsoDateChange = { paymentDateIso = it },
                                testTagName = "ticket_sale_date_input"
                            )

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text("Số lượng vé:", style = MaterialTheme.typography.bodyMedium)
                                FilledTonalIconButton(
                                    onClick = { if (ticketQuantity > 1) ticketQuantity-- }
                                ) {
                                    Icon(Icons.Default.Remove, contentDescription = "Giảm")
                                }
                                Text(
                                    text = "$ticketQuantity",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                FilledTonalIconButton(
                                    onClick = { ticketQuantity++ }
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = "Tăng")
                                }
                            }

                            VndAmountField(
                                label = "Đơn giá vé (từ Bảng giá Cài đặt)",
                                amountVnd = agreedValueVnd,
                                onAmountChange = {
                                    agreedValueVnd = it
                                    cashPaidVnd = it * ticketQuantity
                                },
                                testTagName = "ticket_unit_price_input"
                            )

                            val totalTicketVnd = agreedValueVnd * ticketQuantity
                            Text(
                                text = "Thành tiền: ${FormatUtils.formatVnd(totalTicketVnd)}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = GymEmeraldLight
                            )

                            VndAmountField(
                                label = "Thu tiền mặt",
                                amountVnd = cashPaidVnd,
                                onAmountChange = { cashPaidVnd = it }
                            )
                            VndAmountField(
                                label = "Thu chuyển khoản",
                                amountVnd = transferPaidVnd,
                                onAmountChange = { transferPaidVnd = it }
                            )

                            Button(
                                onClick = {
                                    onSaveTicket(
                                        selectedService,
                                        paymentDateIso,
                                        ticketQuantity,
                                        agreedValueVnd,
                                        cashPaidVnd,
                                        transferPaidVnd
                                    ) {
                                        onBack()
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("save_ticket_btn")
                            ) {
                                Icon(Icons.Default.ConfirmationNumber, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Lưu giao dịch bán vé")
                            }
                        }

                        "PT" -> {
                            // PT Contract Form (Section 6 — HLV Hà Đức)
                            Text(
                                text = "Hợp đồng PT — Huấn luyện viên: Hà Đức (Chia sẻ 50% Gym / 50% HLV)",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = PtTealLight
                            )

                            // Optional existing PT client selector
                            if (ptClients.isNotEmpty()) {
                                Text(
                                    text = "Chọn khách PT hiện có (hoặc nhập mới bên dưới):",
                                    style = MaterialTheme.typography.labelMedium
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    ptClients.take(4).forEach { ptc ->
                                        FilterChip(
                                            selected = selectedPtClientId == ptc.client.id,
                                            onClick = {
                                                selectedPtClientId = ptc.client.id
                                                fullName = ptc.client.fullName
                                                phoneNumber = ptc.client.phoneNumber
                                            },
                                            label = { Text("${ptc.client.fullName} (Còn ${ptc.remainingSessionsOnActive}b)") }
                                        )
                                    }
                                }
                            }

                            OutlinedTextField(
                                value = fullName,
                                onValueChange = { fullName = it },
                                label = { Text("Họ và tên khách hàng PT *") },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("pt_client_name_input")
                            )

                            OutlinedTextField(
                                value = phoneNumber,
                                onValueChange = { phoneNumber = it },
                                label = { Text("Số điện thoại") },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("pt_client_phone_input")
                            )

                            if (availablePlans.isNotEmpty()) {
                                Text("Chọn gói PT đã cấu hình:", style = MaterialTheme.typography.labelMedium)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    availablePlans.forEach { p ->
                                        FilterChip(
                                            selected = selectedPlan?.id == p.id,
                                            onClick = {
                                                selectedPlan = p
                                                ptSessionsCount = p.sessionCount.coerceAtLeast(1)
                                                agreedValueVnd = p.priceVnd
                                                cashPaidVnd = p.priceVnd
                                            },
                                            label = { Text("${p.planName} (${p.sessionCount} buổi)") }
                                        )
                                    }
                                }
                            }

                            OutlinedTextField(
                                value = ptSessionsCount.toString(),
                                onValueChange = { ptSessionsCount = it.filter { ch -> ch.isDigit() }.toIntOrNull() ?: 0 },
                                label = { Text("Số buổi PT đăng ký *") },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("pt_sessions_count_input")
                            )

                            VndAmountField(
                                label = "Giá trị hợp đồng PT",
                                amountVnd = agreedValueVnd,
                                onAmountChange = {
                                    agreedValueVnd = it
                                    cashPaidVnd = it
                                },
                                testTagName = "pt_agreed_value_input"
                            )

                            DateInputField(
                                label = "Ngày đăng ký PT",
                                isoDate = createdDateIso,
                                onIsoDateChange = { createdDateIso = it }
                            )
                            DateInputField(
                                label = "Ngày thanh toán",
                                isoDate = paymentDateIso,
                                onIsoDateChange = { paymentDateIso = it }
                            )

                            VndAmountField(
                                label = "Thu tiền mặt",
                                amountVnd = cashPaidVnd,
                                onAmountChange = { cashPaidVnd = it }
                            )
                            VndAmountField(
                                label = "Thu chuyển khoản",
                                amountVnd = transferPaidVnd,
                                onAmountChange = { transferPaidVnd = it }
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = onOpenPtManagement,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Mở Quản lý PT")
                                }
                                Button(
                                    onClick = {
                                        onSavePtContract(
                                            selectedPtClientId,
                                            fullName,
                                            phoneNumber,
                                            createdDateIso,
                                            paymentDateIso,
                                            ptSessionsCount,
                                            agreedValueVnd,
                                            cashPaidVnd,
                                            transferPaidVnd
                                        ) {
                                            onOpenPtManagement()
                                        }
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("save_pt_contract_btn")
                                ) {
                                    Text("Lưu Hợp đồng PT")
                                }
                            }
                        }

                        else -> {
                            // Gym or Yoga Membership Form ("NEW" or "RENEWAL")
                            if (selectedService == "RENEWAL" && domainMembers.isNotEmpty()) {
                                Text(
                                    text = "Chọn hội viên $selectedDomain cần gia hạn:",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    domainMembers.take(6).forEach { m ->
                                        val isChosen = selectedExistingMemberId == m.member.id
                                        OutlinedCard(
                                            onClick = {
                                                selectedExistingMemberId = m.member.id
                                                fullName = m.member.fullName
                                                phoneNumber = m.member.phoneNumber
                                                customerGroup = m.member.customerGroup
                                                startDateIso = DateCalculator.calculateRenewalStartDate(
                                                    previousEndDateIso = m.endDateIso.ifBlank { todayIso },
                                                    renewalDateIso = createdDateIso
                                                )
                                            },
                                            colors = CardDefaults.outlinedCardColors(
                                                containerColor = if (isChosen) {
                                                    MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                                                } else {
                                                    MaterialTheme.colorScheme.surface
                                                }
                                            ),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(10.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column {
                                                    Text(m.member.fullName, fontWeight = FontWeight.Bold)
                                                    Text(
                                                        "Hết hạn cũ: ${DateCalculator.formatDisplay(m.endDateIso)} (${m.statusText})",
                                                        style = MaterialTheme.typography.bodySmall
                                                    )
                                                }
                                                if (isChosen) {
                                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = StatusActiveGreen)
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // Duplicate customer detection banner (Section 5.2)
                            if (matchingExistingMember != null) {
                                Card(
                                    colors = CardDefaults.cardColors(
                                        containerColor = StatusWarningAmber.copy(alpha = 0.16f)
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(
                                        modifier = Modifier.padding(12.dp),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = "Phát hiện khách hàng cũ trong $selectedDomain: ${matchingExistingMember.member.fullName}",
                                            style = MaterialTheme.typography.labelLarge,
                                            fontWeight = FontWeight.Bold,
                                            color = StatusWarningAmber
                                        )
                                        Text(
                                            text = "Theo quy tắc nghiệp vụ, không tạo hồ sơ trùng lặp khi khách cũ quay lại và hợp đồng sẽ được phân loại là Gia hạn.",
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                        TextButton(
                                            onClick = {
                                                selectedExistingMemberId = matchingExistingMember.member.id
                                                selectedService = "RENEWAL"
                                                fullName = matchingExistingMember.member.fullName
                                                phoneNumber = matchingExistingMember.member.phoneNumber
                                                startDateIso = DateCalculator.calculateRenewalStartDate(
                                                    previousEndDateIso = matchingExistingMember.endDateIso.ifBlank { todayIso },
                                                    renewalDateIso = createdDateIso
                                                )
                                            }
                                        ) {
                                            Text("Chuyển sang Gia hạn trên hồ sơ hiện có →")
                                        }
                                    }
                                }
                            }

                            if (!fromPtClientId.isNullOrBlank()) {
                                StatusPill(
                                    text = "Khách PT chuyển sang Gym: Tự động phân loại doanh thu là Gia hạn (Mục 6.6)",
                                    tone = StatusTone.INFO
                                )
                            }

                            OutlinedTextField(
                                value = fullName,
                                onValueChange = { fullName = it },
                                label = { Text("Họ và tên hội viên *") },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("contract_member_name_input")
                            )

                            OutlinedTextField(
                                value = phoneNumber,
                                onValueChange = { phoneNumber = it },
                                label = { Text("Số điện thoại liên hệ") },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("contract_member_phone_input")
                            )

                            // Gym Customer Group Selector (Nam / Nữ / Trẻ em)
                            if (selectedDomain == "GYM") {
                                Text("Nhóm bảng giá Gym:", style = MaterialTheme.typography.labelMedium)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("NAM" to "Nam", "NU" to "Nữ", "TRE_EM" to "Trẻ em").forEach { (code, label) ->
                                        FilterChip(
                                            selected = customerGroup == code,
                                            onClick = { customerGroup = code },
                                            label = { Text(label) }
                                        )
                                    }
                                }
                            }

                            // Price Plan Selector
                            if (availablePlans.isNotEmpty()) {
                                Text("Chọn gói từ Bảng giá:", style = MaterialTheme.typography.labelMedium)
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    availablePlans.forEach { plan ->
                                        val isPlanSelected = selectedPlan?.id == plan.id
                                        FilterChip(
                                            selected = isPlanSelected,
                                            onClick = {
                                                selectedPlan = plan
                                                customPlanName = plan.planName
                                                durationMonths = plan.durationMonths.coerceAtLeast(1)
                                                agreedValueVnd = plan.priceVnd
                                                cashPaidVnd = plan.priceVnd
                                            },
                                            label = {
                                                Text("${plan.planName} (${plan.durationMonths} tháng) — ${FormatUtils.formatVnd(plan.priceVnd)}")
                                            },
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                                }
                            }

                            OutlinedTextField(
                                value = customPlanName,
                                onValueChange = { customPlanName = it },
                                label = { Text("Tên gói đăng ký *") },
                                placeholder = { Text("VD: Gym Nam 3 tháng") },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("contract_plan_name_input")
                            )

                            // Duration Months selector (1, 2, 3, 12 or custom)
                            Text("Số tháng đăng ký:", style = MaterialTheme.typography.labelMedium)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf(1, 2, 3, 12).forEach { m ->
                                    FilterChip(
                                        selected = durationMonths == m,
                                        onClick = { durationMonths = m },
                                        label = { Text(if (m == 12) "1 năm (12T)" else "$m tháng") },
                                        modifier = Modifier.testTag("duration_chip_$m")
                                    )
                                }
                            }

                            VndAmountField(
                                label = "Giá trị hợp đồng thực tế thỏa thuận",
                                amountVnd = agreedValueVnd,
                                onAmountChange = {
                                    agreedValueVnd = it
                                    cashPaidVnd = it
                                },
                                testTagName = "contract_agreed_value_input"
                            )

                            HorizontalDivider()
                            Text(
                                text = "4 mốc thời gian độc lập (Mục 5.3 & 5.4)",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )

                            DateInputField(
                                label = "1. Ngày tạo hợp đồng / Ngày gia hạn",
                                isoDate = createdDateIso,
                                onIsoDateChange = { newCreatedIso ->
                                    createdDateIso = newCreatedIso
                                    // If renewing an existing member, automatically apply early/on-time/late rule!
                                    val existing = domainMembers.firstOrNull { it.member.id == selectedExistingMemberId }
                                    if (existing != null && existing.endDateIso.isNotBlank()) {
                                        startDateIso = DateCalculator.calculateRenewalStartDate(
                                            previousEndDateIso = existing.endDateIso,
                                            renewalDateIso = newCreatedIso
                                        )
                                    }
                                },
                                testTagName = "contract_created_date_input"
                            )

                            DateInputField(
                                label = "2. Ngày thanh toán",
                                isoDate = paymentDateIso,
                                onIsoDateChange = { paymentDateIso = it },
                                testTagName = "contract_payment_date_input"
                            )

                            DateInputField(
                                label = "3. Ngày bắt đầu hiệu lực",
                                isoDate = startDateIso,
                                onIsoDateChange = { startDateIso = it },
                                testTagName = "contract_start_date_input"
                            )

                            Surface(
                                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = "4. Ngày hết hạn (Tự động tính)",
                                            style = MaterialTheme.typography.labelMedium
                                        )
                                        Text(
                                            text = "Tổng số ngày hiệu lực: ${DateCalculator.daysBetween(startDateIso, calculatedEndDateIso)} ngày",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Text(
                                        text = DateCalculator.formatDisplay(calculatedEndDateIso),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }

                            HorizontalDivider()
                            Text(
                                text = "Thanh toán ban đầu (Tiền mặt / Chuyển khoản / Kết hợp)",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )

                            VndAmountField(
                                label = "Số tiền thu Tiền mặt",
                                amountVnd = cashPaidVnd,
                                onAmountChange = { cashPaidVnd = it },
                                testTagName = "contract_cash_paid_input"
                            )

                            VndAmountField(
                                label = "Số tiền thu Chuyển khoản",
                                amountVnd = transferPaidVnd,
                                onAmountChange = { transferPaidVnd = it },
                                testTagName = "contract_transfer_paid_input"
                            )

                            val totalInitialPaid = cashPaidVnd + transferPaidVnd
                            val remainingDebt = (agreedValueVnd - totalInitialPaid).coerceAtLeast(0L)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Đã thu: ${FormatUtils.formatVnd(totalInitialPaid)}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = StatusActiveGreen,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "Công nợ còn lại: ${FormatUtils.formatVnd(remainingDebt)}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (remainingDebt > 0L) StatusDangerRed else MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            Button(
                                onClick = {
                                    val finalMemberId = selectedExistingMemberId ?: matchingExistingMember?.member?.id
                                    val finalPlanName = customPlanName.ifBlank {
                                        "$selectedDomain $durationMonths tháng"
                                    }
                                    onSaveMemberContract(
                                        selectedDomain,
                                        finalMemberId,
                                        fromPtClientId,
                                        fullName,
                                        phoneNumber,
                                        customerGroup,
                                        null,
                                        selectedPlan?.id,
                                        finalPlanName,
                                        durationMonths,
                                        agreedValueVnd,
                                        paymentDateIso,
                                        createdDateIso,
                                        startDateIso,
                                        cashPaidVnd,
                                        transferPaidVnd
                                    ) {
                                        onBack()
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp)
                                    .testTag("save_member_contract_btn")
                            ) {
                                Icon(Icons.Default.Save, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Lưu Hợp Đồng $selectedDomain",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
