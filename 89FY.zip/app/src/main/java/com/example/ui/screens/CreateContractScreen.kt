package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PersonSearch
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.SportsGymnastics
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.MemberGroup
import com.example.data.model.MemberProfile
import com.example.data.model.PaymentMethod
import com.example.data.model.SingleTicketType
import com.example.domain.FitnessCalculator
import com.example.ui.components.DatePickerField
import com.example.ui.components.PaymentMethodSelectorSection
import com.example.ui.components.ReviewAndConfirmDialog
import com.example.ui.components.ScreenHeaderBar
import com.example.ui.theme.GymGreenBright
import com.example.ui.theme.PriceNuPink
import com.example.ui.theme.PriceTreEmOrange
import com.example.ui.theme.YogaPurpleBright
import com.example.ui.viewmodel.FitnessAppState
import com.example.ui.viewmodel.FitnessViewModel

enum class ContractCreationBranch(
    val code: String,
    val title: String,
    val color: Color
) {
    GYM("GYM", "GYM", GymGreenBright),
    YOGA("YOGA", "YOGA", YogaPurpleBright),
    PT("PT", "PT", PriceNuPink),
    SINGLE_TICKET("VE_LE", "VÉ LẺ", PriceTreEmOrange)
}

@Composable
fun CreateContractScreen(
    appState: FitnessAppState,
    viewModel: FitnessViewModel,
    initialBranch: ContractCreationBranch? = null,
    preselectedMember: MemberProfile? = null,
    onBack: () -> Unit
) {
    var selectedBranch by remember(initialBranch, preselectedMember) {
        mutableStateOf(
            when (preselectedMember?.type) {
                "GYM" -> ContractCreationBranch.GYM
                "YOGA" -> ContractCreationBranch.YOGA
                "PT" -> ContractCreationBranch.PT
                else -> initialBranch
            }
        )
    }

    BackHandler {
        if (selectedBranch != null && initialBranch == null && preselectedMember == null) {
            selectedBranch = null
        } else {
            onBack()
        }
    }

    Scaffold(
        topBar = {
            ScreenHeaderBar(
                title = selectedBranch?.let { "TẠO HỢP ĐỒNG — ${it.title}" } ?: "TẠO HỢP ĐỒNG",
                accentColor = selectedBranch?.color ?: Color(0xFF0284C7),
                onBack = {
                    if (selectedBranch != null && initialBranch == null && preselectedMember == null) {
                        selectedBranch = null
                    } else {
                        onBack()
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // 4 lựa chọn nhánh
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                ContractCreationBranch.entries.forEach { branch ->
                    val isSelected = selectedBranch == branch
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedBranch = branch },
                        label = { Text(branch.title) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = branch.color,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("branch_chip_${branch.code}")
                    )
                }
            }

            when (val branch = selectedBranch) {
                null -> {
                    ContractCreationBranch.entries.forEach { item ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedBranch = item }
                                .testTag("branch_card_${item.code}"),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.2.dp, item.color.copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = when (item) {
                                        ContractCreationBranch.GYM -> Icons.Default.FitnessCenter
                                        ContractCreationBranch.YOGA -> Icons.Default.SelfImprovement
                                        ContractCreationBranch.PT -> Icons.Default.SportsGymnastics
                                        ContractCreationBranch.SINGLE_TICKET -> Icons.Default.ConfirmationNumber
                                    },
                                    contentDescription = null,
                                    tint = item.color,
                                    modifier = Modifier.size(26.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = item.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = item.color
                                )
                            }
                        }
                    }
                }

                ContractCreationBranch.GYM, ContractCreationBranch.YOGA -> {
                    GymOrYogaContractCreationFlow(
                        serviceType = branch.code,
                        accentColor = branch.color,
                        appState = appState,
                        viewModel = viewModel,
                        preselectedMember = preselectedMember?.takeIf { it.type == branch.code },
                        onFinish = onBack
                    )
                }

                ContractCreationBranch.PT -> {
                    PtContractCreationFlow(
                        accentColor = branch.color,
                        appState = appState,
                        viewModel = viewModel,
                        preselectedMember = preselectedMember?.takeIf { it.type == "PT" },
                        onFinish = onBack
                    )
                }

                ContractCreationBranch.SINGLE_TICKET -> {
                    SingleTicketCreationFlow(
                        accentColor = branch.color,
                        appState = appState,
                        viewModel = viewModel,
                        onFinish = onBack
                    )
                }
            }
        }
    }
}

@Composable
private fun GymOrYogaContractCreationFlow(
    serviceType: String,
    accentColor: Color,
    appState: FitnessAppState,
    viewModel: FitnessViewModel,
    preselectedMember: MemberProfile?,
    onFinish: () -> Unit
) {
    val isYoga = serviceType == "YOGA"
    val existingPool = if (isYoga) appState.activeYogaMembers else appState.activeGymMembers

    var searchQuery by remember(serviceType, preselectedMember) {
        mutableStateOf(preselectedMember?.fullName ?: "")
    }
    var selectedExistingMember by remember(serviceType, preselectedMember) {
        mutableStateOf(preselectedMember)
    }
    // Mặc định mở ngay biểu mẫu Tạo hội viên mới khi không có hội viên chọn sẵn (không ép tìm kiếm trước)
    var isCreatingNewProfile by remember(serviceType, preselectedMember) {
        mutableStateOf(preselectedMember == null)
    }
    var showExistingSearchSection by remember(serviceType, preselectedMember) {
        mutableStateOf(preselectedMember != null)
    }

    val searchResults = remember(searchQuery, existingPool) {
        if (searchQuery.trim().isEmpty()) emptyList()
        else existingPool.filter { m -> FitnessCalculator.matchesMemberSearchQuery(m, searchQuery) }
    }

    // Khu vực chọn trực tiếp: [Tạo hội viên mới] hoặc [Chọn hội viên hiện có] + ô tìm kiếm
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.4f))
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val isNewMode = isCreatingNewProfile && selectedExistingMember == null
                Button(
                    onClick = {
                        selectedExistingMember = null
                        isCreatingNewProfile = true
                        showExistingSearchSection = false
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isNewMode) accentColor else MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = if (isNewMode) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("create_new_profile_button")
                ) {
                    Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Tạo hội viên mới", style = MaterialTheme.typography.labelLarge)
                }

                val isExistingMode = showExistingSearchSection || selectedExistingMember != null
                Button(
                    onClick = {
                        showExistingSearchSection = true
                        isCreatingNewProfile = false
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isExistingMode) accentColor else MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = if (isExistingMode) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("mode_existing_member_button")
                ) {
                    Icon(Icons.Default.PersonSearch, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Chọn hội viên hiện có", style = MaterialTheme.typography.labelLarge)
                }
            }

            // Ô tìm kiếm hội viên hiện có (luôn sẵn sàng cho cả thao tác tìm kiếm trực tiếp và tự động kiểm thử)
            OutlinedTextField(
                value = searchQuery,
                onValueChange = {
                    searchQuery = it
                    showExistingSearchSection = true
                    if (it.trim().isNotEmpty()) {
                        selectedExistingMember = null
                        isCreatingNewProfile = false
                    }
                },
                placeholder = { Text("Tìm hội viên $serviceType hiện có (STT / Họ tên / SĐT)...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Xóa")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("contract_search_member_input")
            )

            val searchModeLabel = FitnessCalculator.memberSearchModeLabel(searchQuery)
            if (searchModeLabel.isNotEmpty()) {
                Text(
                    text = "$searchModeLabel • Khớp: ${searchResults.size}",
                    style = MaterialTheme.typography.labelSmall,
                    color = accentColor
                )
            }

            if (searchQuery.trim().isNotEmpty()) {
                if (searchResults.isNotEmpty()) {
                    searchResults.forEach { member ->
                        val memberContracts = appState.activeContracts
                            .filter { it.memberId == member.id }
                            .sortedByDescending { it.endDate }
                        val isPicked = selectedExistingMember?.id == member.id && !isCreatingNewProfile

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedExistingMember = member
                                    isCreatingNewProfile = false
                                }
                                .testTag("search_result_member_${member.stt}"),
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isPicked) accentColor.copy(alpha = 0.12f)
                                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                            ),
                            border = BorderStroke(if (isPicked) 1.5.dp else 1.dp, accentColor)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "STT${member.stt} — ${member.fullName}",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                    val latestEnd = memberContracts.firstOrNull()?.endDate
                                    Text(
                                        text = "SĐT: ${member.phone.ifBlank { "Chưa có" }}" +
                                            (if (latestEnd != null) " • Hết hạn: ${FitnessCalculator.formatDisplayDate(latestEnd)}" else ""),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text(
                                    text = "Chọn gia hạn",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = accentColor,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Không tìm thấy hội viên phù hợp.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        TextButton(
                            onClick = {
                                selectedExistingMember = null
                                isCreatingNewProfile = true
                            }
                        ) {
                            Text("Tạo hội viên mới")
                        }
                    }
                }
            }
        }
    }

    // Biểu mẫu hợp đồng (hiển thị ngay khi Tạo hội viên mới HOẶC khi đã chọn hội viên hiện có để Gia hạn)
    if (selectedExistingMember != null || isCreatingNewProfile) {
        val existing = selectedExistingMember
        val previewStt = existing?.stt ?: ((if (isYoga) appState.config.lastYogaStt else appState.config.lastGymStt) + 1L)
        val previewSeq = existing?.nextContractSeq ?: 1L
        val previewContractCode = FitnessCalculator.buildContractCode(serviceType, previewStt, previewSeq)

        var fullName by remember(existing) {
            mutableStateOf(
                existing?.fullName ?: searchQuery.trim().takeIf { q -> q.any { it.isLetter() } }.orEmpty()
            )
        }
        var phone by remember(existing) {
            mutableStateOf(
                existing?.phone ?: searchQuery.trim().takeIf { q -> q.length >= 5 && q.all { it.isDigit() } }.orEmpty()
            )
        }
        var memberGroup by remember(existing, isYoga) {
            mutableStateOf(
                if (isYoga) "NONE"
                else existing?.memberGroup?.takeIf { it != "NONE" } ?: "NAM"
            )
        }
        val durationOptions = remember(serviceType) {
            FitnessCalculator.validDurationsForService(serviceType)
        }
        var durationMonths by remember(serviceType) { mutableIntStateOf(1) }

        var startDate by remember(existing) {
            mutableStateOf(FitnessCalculator.todayIso())
        }
        var endDate by remember(startDate, durationMonths) {
            mutableStateOf(FitnessCalculator.calculateEndDate(startDate, durationMonths))
        }

        val defaultPrice = remember(serviceType, memberGroup, durationMonths, appState.config) {
            if (isYoga) {
                appState.config.getYogaPrice(durationMonths)
            } else {
                appState.config.getGymPrice(MemberGroup.fromCode(memberGroup), durationMonths)
            }
        }

        var packageValueText by remember(defaultPrice) { mutableStateOf(defaultPrice.toString()) }
        var paidAmountText by remember(defaultPrice) { mutableStateOf(defaultPrice.toString()) }
        var paymentMethod by remember { mutableStateOf(PaymentMethod.TRANSFER.code) }
        var cashText by remember { mutableStateOf("0") }
        var transferText by remember(defaultPrice) { mutableStateOf(defaultPrice.toString()) }
        var paymentDate by remember { mutableStateOf(FitnessCalculator.todayIso()) }
        var showReviewDialog by remember { mutableStateOf(false) }

        val pkgValue = packageValueText.toLongOrNull() ?: 0L
        val paidValue = paidAmountText.toLongOrNull() ?: 0L
        val cashValue = cashText.toLongOrNull() ?: 0L
        val transferValue = transferText.toLongOrNull() ?: 0L

        val startTriple = FitnessCalculator.parseIso(startDate)
        val previewAllocation = remember(pkgValue, startDate, endDate, startTriple) {
            if (startTriple == null) Triple(0L, 0L, 0L)
            else FitnessCalculator.calculateContractAllocatedRevenue(
                packageValue = pkgValue,
                startDateIso = startDate,
                endDateIso = endDate,
                year = startTriple.first,
                month = startTriple.second
            )
        }

        // Cảnh báo trùng SĐT không chặn thao tác khi tạo hội viên mới
        val duplicatePhoneMember = remember(existing, phone, existingPool) {
            val cleanPhone = phone.filter { it.isDigit() }
            if (existing != null || cleanPhone.length < 8) null
            else existingPool.firstOrNull { it.phone.filter { ch -> ch.isDigit() } == cleanPhone }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.2.dp, accentColor)
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (existing != null) {
                            "GIA HẠN — STT${existing.stt}"
                        } else {
                            "HỘI VIÊN MỚI — STT$previewStt"
                        },
                        style = MaterialTheme.typography.titleSmall,
                        color = accentColor,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Mã HĐ: $previewContractCode",
                        style = MaterialTheme.typography.labelLarge,
                        color = accentColor,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (existing == null) {
                    OutlinedTextField(
                        value = fullName,
                        onValueChange = { fullName = it },
                        label = { Text("Họ và tên đầy đủ *") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("new_member_name_input")
                    )
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("Số điện thoại") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("new_member_phone_input")
                    )
                    if (duplicatePhoneMember != null) {
                        Surface(
                            color = MaterialTheme.colorScheme.secondaryContainer,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "SĐT đã có: STT${duplicatePhoneMember.stt} — ${duplicatePhoneMember.fullName}",
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.weight(1f)
                                )
                                TextButton(
                                    onClick = {
                                        selectedExistingMember = duplicatePhoneMember
                                        isCreatingNewProfile = false
                                    }
                                ) {
                                    Text("Chọn gia hạn")
                                }
                            }
                        }
                    }
                } else {
                    val history = appState.activeContracts
                        .filter { it.memberId == existing.id }
                        .sortedByDescending { it.endDate }
                    Text(
                        text = "STT${existing.stt} — ${existing.fullName} • SĐT: ${existing.phone.ifBlank { "Chưa có" }}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    if (history.isNotEmpty()) {
                        Text(
                            text = "Đã có ${history.size} HĐ • Gần nhất: ${history.first().contractCode} (${FitnessCalculator.formatDisplayDate(history.first().endDate)})",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Nhóm giá (Chỉ cho GYM)
                if (!isYoga) {
                    Text("Nhóm giá GYM:", style = MaterialTheme.typography.labelLarge)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(MemberGroup.NAM, MemberGroup.NU, MemberGroup.TRE_EM).forEach { grp ->
                            FilterChip(
                                selected = memberGroup == grp.code,
                                onClick = { memberGroup = grp.code },
                                label = { Text(grp.label) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = accentColor,
                                    selectedLabelColor = Color.White
                                ),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                // Chọn gói tháng
                Text("Gói thời hạn ($serviceType):", style = MaterialTheme.typography.labelLarge)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    durationOptions.forEach { m ->
                        FilterChip(
                            selected = durationMonths == m,
                            onClick = {
                                durationMonths = m
                                endDate = FitnessCalculator.calculateEndDate(startDate, m)
                            },
                            label = { Text("$m tháng") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = accentColor,
                                selectedLabelColor = Color.White
                            ),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                // Ngày đăng ký & Ngày hết hạn
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    DatePickerField(
                        label = "Ngày đăng ký",
                        isoDate = startDate,
                        onDateSelected = {
                            startDate = it
                            paymentDate = it
                            endDate = FitnessCalculator.calculateEndDate(it, durationMonths)
                        },
                        modifier = Modifier.weight(1f),
                        accentColor = accentColor
                    )
                    DatePickerField(
                        label = "Ngày hết hạn",
                        isoDate = endDate,
                        onDateSelected = { endDate = it },
                        modifier = Modifier.weight(1f),
                        accentColor = accentColor
                    )
                }

                // Giá trị gói & Số tiền thanh toán
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = packageValueText,
                        onValueChange = {
                            val clean = it.filter { ch -> ch.isDigit() }
                            packageValueText = clean
                            paidAmountText = clean
                        },
                        label = { Text("Giá trị gói (VND)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = paidAmountText,
                        onValueChange = { paidAmountText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Số tiền TT (VND)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                // Doanh thu phân bổ tháng tự động (gọn 1 dòng)
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Phân bổ tháng ${startTriple?.second ?: ""}/${startTriple?.first ?: ""} (${previewAllocation.third}/${previewAllocation.second} ngày):",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = FitnessCalculator.formatCurrency(previewAllocation.first),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = accentColor
                        )
                    }
                }

                // Phương thức thanh toán
                PaymentMethodSelectorSection(
                    paidAmount = paidValue,
                    selectedMethod = paymentMethod,
                    onMethodChange = { paymentMethod = it },
                    cashAmountText = cashText,
                    onCashAmountChange = { cashText = it },
                    transferAmountText = transferText,
                    onTransferAmountChange = { transferText = it },
                    accentColor = accentColor
                )

                val isFormValid = fullName.isNotBlank() &&
                    pkgValue > 0L &&
                    (paymentMethod != "COMBINED" || (cashValue + transferValue == paidValue))

                Button(
                    onClick = { showReviewDialog = true },
                    enabled = isFormValid,
                    colors = ButtonDefaults.buttonColors(containerColor = accentColor, contentColor = Color.White),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("review_contract_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Kiểm tra & Xác nhận lưu", style = MaterialTheme.typography.titleSmall)
                }
            }
        }

        if (showReviewDialog) {
            ReviewAndConfirmDialog(
                title = "Xác nhận lưu hợp đồng $previewContractCode",
                summaryItems = buildList {
                    add("Mã hợp đồng" to previewContractCode)
                    add("STT & Họ tên" to "STT$previewStt — ${fullName.trim()}")
                    add("Số điện thoại" to phone.trim().ifBlank { "Không có" })
                    if (!isYoga) add("Nhóm giá" to MemberGroup.fromCode(memberGroup).label)
                    add("Gói đăng ký" to "$durationMonths tháng (${if (existing != null) "Gia hạn" else "Đăng ký mới"})")
                    add("Ngày đăng ký" to FitnessCalculator.formatDisplayDate(startDate))
                    add("Ngày hết hạn" to FitnessCalculator.formatDisplayDate(endDate))
                    add("Giá trị gói" to FitnessCalculator.formatCurrency(pkgValue))
                    add("Số tiền thanh toán" to FitnessCalculator.formatCurrency(paidValue))
                    add("Phân bổ tháng ĐK" to FitnessCalculator.formatCurrency(previewAllocation.first))
                    add("Phương thức TT" to PaymentMethod.fromCode(paymentMethod).label)
                    if (paymentMethod == "COMBINED") {
                        add("• Tiền mặt" to FitnessCalculator.formatCurrency(cashValue))
                        add("• Chuyển khoản" to FitnessCalculator.formatCurrency(transferValue))
                    }
                },
                accentColor = accentColor,
                onConfirm = {
                    showReviewDialog = false
                    val finalCash = when (paymentMethod) {
                        "CASH" -> paidValue
                        "COMBINED" -> cashValue
                        else -> 0L
                    }
                    val finalTransfer = when (paymentMethod) {
                        "TRANSFER" -> paidValue
                        "COMBINED" -> transferValue
                        else -> 0L
                    }
                    if (existing != null) {
                        viewModel.createRenewalContract(
                            member = existing,
                            memberGroup = memberGroup,
                            durationMonths = durationMonths.toLong(),
                            startDate = startDate,
                            endDate = endDate,
                            totalSessions = 0L,
                            packageValue = pkgValue,
                            paidAmount = paidValue,
                            paymentMethod = paymentMethod,
                            cashAmount = finalCash,
                            transferAmount = finalTransfer,
                            paymentDate = paymentDate,
                            onSuccess = { onFinish() }
                        )
                    } else {
                        viewModel.createNewMemberAndContract(
                            serviceType = serviceType,
                            fullName = fullName,
                            phone = phone,
                            memberGroup = memberGroup,
                            durationMonths = durationMonths.toLong(),
                            startDate = startDate,
                            endDate = endDate,
                            totalSessions = 0L,
                            packageValue = pkgValue,
                            paidAmount = paidValue,
                            paymentMethod = paymentMethod,
                            cashAmount = finalCash,
                            transferAmount = finalTransfer,
                            paymentDate = paymentDate,
                            onSuccess = { _, _ -> onFinish() }
                        )
                    }
                },
                onDismiss = { showReviewDialog = false }
            )
        }
    }
}

@Composable
private fun PtContractCreationFlow(
    accentColor: Color,
    appState: FitnessAppState,
    viewModel: FitnessViewModel,
    preselectedMember: MemberProfile?,
    onFinish: () -> Unit
) {
    val existingPool = appState.activePtMembers
    var searchQuery by remember(preselectedMember) { mutableStateOf(preselectedMember?.fullName ?: "") }
    var selectedMember by remember(preselectedMember) { mutableStateOf(preselectedMember) }
    var isCreatingNew by remember(preselectedMember) { mutableStateOf(preselectedMember == null) }
    var showExistingSearch by remember(preselectedMember) { mutableStateOf(preselectedMember != null) }

    val searchResults = remember(searchQuery, existingPool) {
        if (searchQuery.trim().isEmpty()) emptyList()
        else existingPool.filter { m -> FitnessCalculator.matchesMemberSearchQuery(m, searchQuery) }
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.4f))
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val isNewMode = isCreatingNew && selectedMember == null
                Button(
                    onClick = {
                        selectedMember = null
                        isCreatingNew = true
                        showExistingSearch = false
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isNewMode) accentColor else MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = if (isNewMode) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Tạo hội viên mới", style = MaterialTheme.typography.labelLarge)
                }

                val isExistingMode = showExistingSearch || selectedMember != null
                Button(
                    onClick = {
                        showExistingSearch = true
                        isCreatingNew = false
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isExistingMode) accentColor else MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = if (isExistingMode) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.PersonSearch, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Chọn hội viên hiện có", style = MaterialTheme.typography.labelLarge)
                }
            }

            OutlinedTextField(
                value = searchQuery,
                onValueChange = {
                    searchQuery = it
                    showExistingSearch = true
                    if (it.trim().isNotEmpty()) {
                        selectedMember = null
                        isCreatingNew = false
                    }
                },
                placeholder = { Text("Tìm hội viên PT hiện có (STT / Họ tên / SĐT)...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Xóa")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            )

            val searchModeLabel = FitnessCalculator.memberSearchModeLabel(searchQuery)
            if (searchModeLabel.isNotEmpty()) {
                Text(
                    text = "$searchModeLabel • Khớp: ${searchResults.size}",
                    style = MaterialTheme.typography.labelSmall,
                    color = accentColor
                )
            }

            if (searchQuery.trim().isNotEmpty()) {
                if (searchResults.isNotEmpty()) {
                    searchResults.forEach { member ->
                        val isPicked = selectedMember?.id == member.id && !isCreatingNew
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedMember = member
                                    isCreatingNew = false
                                },
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isPicked) accentColor.copy(alpha = 0.12f)
                                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                            ),
                            border = BorderStroke(if (isPicked) 1.5.dp else 1.dp, accentColor)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "STT${member.stt} — ${member.fullName}",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text("SĐT: ${member.phone.ifBlank { "Chưa có" }}", style = MaterialTheme.typography.bodySmall)
                                }
                                Text(
                                    text = "Chọn gia hạn",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = accentColor,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Không tìm thấy hội viên phù hợp.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        TextButton(
                            onClick = {
                                selectedMember = null
                                isCreatingNew = true
                            }
                        ) {
                            Text("Tạo hội viên PT mới")
                        }
                    }
                }
            }
        }
    }

    if (selectedMember != null || isCreatingNew) {
        val existing = selectedMember
        val activePtContract = remember(existing, appState.activeContracts) {
            existing?.let { mem ->
                appState.activeContracts.firstOrNull {
                    it.memberId == mem.id &&
                        it.serviceType == "PT" &&
                        it.ptStatus == "ACTIVE" &&
                        it.usedSessions < it.totalSessions
                }
            }
        }

        if (activePtContract != null) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Đang có hợp đồng PT còn buổi!",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                        Text(
                            text = "STT${existing?.stt} đang còn ${activePtContract.remainingSessions}/${activePtContract.totalSessions} buổi (${activePtContract.contractCode}). Chỉ gia hạn khi đã hết buổi.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
            }
            return
        }

        val previewStt = existing?.stt ?: (appState.config.lastPtStt + 1L)
        val previewSeq = existing?.nextContractSeq ?: 1L
        val previewCode = FitnessCalculator.buildContractCode("PT", previewStt, previewSeq)

        var fullName by remember(existing) {
            mutableStateOf(
                existing?.fullName ?: searchQuery.trim().takeIf { q -> q.any { it.isLetter() } }.orEmpty()
            )
        }
        var phone by remember(existing) {
            mutableStateOf(
                existing?.phone ?: searchQuery.trim().takeIf { q -> q.length >= 5 && q.all { it.isDigit() } }.orEmpty()
            )
        }
        var sessionsText by remember { mutableStateOf("20") }
        var packageValueText by remember { mutableStateOf("3000000") }
        var paidAmountText by remember { mutableStateOf("3000000") }
        var startDate by remember { mutableStateOf(FitnessCalculator.todayIso()) }
        var paymentMethod by remember { mutableStateOf(PaymentMethod.TRANSFER.code) }
        var cashText by remember { mutableStateOf("0") }
        var transferText by remember { mutableStateOf("3000000") }
        var showReview by remember { mutableStateOf(false) }

        val totalSessions = sessionsText.toLongOrNull() ?: 0L
        val pkgVal = packageValueText.toLongOrNull() ?: 0L
        val paidVal = paidAmountText.toLongOrNull() ?: 0L
        val cashVal = cashText.toLongOrNull() ?: 0L
        val transferVal = transferText.toLongOrNull() ?: 0L

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.2.dp, accentColor)
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (existing != null) "GIA HẠN PT — STT$previewStt" else "HỘI VIÊN PT MỚI — STT$previewStt",
                        style = MaterialTheme.typography.titleSmall,
                        color = accentColor,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Mã HĐ: $previewCode",
                        style = MaterialTheme.typography.labelLarge,
                        color = accentColor,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (existing == null) {
                    OutlinedTextField(
                        value = fullName,
                        onValueChange = { fullName = it },
                        label = { Text("Họ và tên hội viên PT *") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("Số điện thoại") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                } else {
                    Text(
                        text = "STT${existing.stt} — ${existing.fullName} • SĐT: ${existing.phone.ifBlank { "Chưa có" }}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = sessionsText,
                        onValueChange = { sessionsText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Số buổi gói PT *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    DatePickerField(
                        label = "Ngày đăng ký",
                        isoDate = startDate,
                        onDateSelected = { startDate = it },
                        modifier = Modifier.weight(1f),
                        accentColor = accentColor
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = packageValueText,
                        onValueChange = {
                            val clean = it.filter { ch -> ch.isDigit() }
                            packageValueText = clean
                            paidAmountText = clean
                        },
                        label = { Text("Giá trị gói PT (VND)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = paidAmountText,
                        onValueChange = { paidAmountText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Số tiền TT (VND)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                if (totalSessions > 0L && pkgVal > 0L) {
                    val perSession = pkgVal / totalSessions
                    val gymSharePerSession = perSession / 2
                    Text(
                        text = "Đơn giá: ${FitnessCalculator.formatCurrency(perSession)}/buổi • Phòng tập (50%): ${FitnessCalculator.formatCurrency(gymSharePerSession)}/buổi",
                        style = MaterialTheme.typography.bodySmall,
                        color = accentColor,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                PaymentMethodSelectorSection(
                    paidAmount = paidVal,
                    selectedMethod = paymentMethod,
                    onMethodChange = { paymentMethod = it },
                    cashAmountText = cashText,
                    onCashAmountChange = { cashText = it },
                    transferAmountText = transferText,
                    onTransferAmountChange = { transferText = it },
                    accentColor = accentColor
                )

                val isValid = fullName.isNotBlank() &&
                    totalSessions > 0L &&
                    pkgVal > 0L &&
                    (paymentMethod != "COMBINED" || (cashVal + transferVal == paidVal))

                Button(
                    onClick = { showReview = true },
                    enabled = isValid,
                    colors = ButtonDefaults.buttonColors(containerColor = accentColor, contentColor = Color.White),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Kiểm tra & Xác nhận lưu")
                }
            }
        }

        if (showReview) {
            ReviewAndConfirmDialog(
                title = "Xác nhận lưu HĐ PT $previewCode",
                summaryItems = buildList {
                    add("Mã hợp đồng" to previewCode)
                    add("Hội viên PT" to "STT$previewStt — ${fullName.trim()}")
                    add("Số điện thoại" to phone.trim().ifBlank { "Không có" })
                    add("Tổng số buổi" to "$totalSessions buổi")
                    add("Ngày đăng ký" to FitnessCalculator.formatDisplayDate(startDate))
                    add("Giá trị gói PT" to FitnessCalculator.formatCurrency(pkgVal))
                    add("Số tiền thanh toán" to FitnessCalculator.formatCurrency(paidVal))
                    add("Phương thức TT" to PaymentMethod.fromCode(paymentMethod).label)
                },
                accentColor = accentColor,
                onConfirm = {
                    showReview = false
                    val finalCash = when (paymentMethod) {
                        "CASH" -> paidVal
                        "COMBINED" -> cashVal
                        else -> 0L
                    }
                    val finalTransfer = when (paymentMethod) {
                        "TRANSFER" -> paidVal
                        "COMBINED" -> transferVal
                        else -> 0L
                    }
                    if (existing != null) {
                        viewModel.createRenewalContract(
                            member = existing,
                            memberGroup = "NONE",
                            durationMonths = 0L,
                            startDate = startDate,
                            endDate = "",
                            totalSessions = totalSessions,
                            packageValue = pkgVal,
                            paidAmount = paidVal,
                            paymentMethod = paymentMethod,
                            cashAmount = finalCash,
                            transferAmount = finalTransfer,
                            paymentDate = startDate,
                            onSuccess = { onFinish() }
                        )
                    } else {
                        viewModel.createNewMemberAndContract(
                            serviceType = "PT",
                            fullName = fullName,
                            phone = phone,
                            memberGroup = "NONE",
                            durationMonths = 0L,
                            startDate = startDate,
                            endDate = "",
                            totalSessions = totalSessions,
                            packageValue = pkgVal,
                            paidAmount = paidVal,
                            paymentMethod = paymentMethod,
                            cashAmount = finalCash,
                            transferAmount = finalTransfer,
                            paymentDate = startDate,
                            onSuccess = { _, _ -> onFinish() }
                        )
                    }
                },
                onDismiss = { showReview = false }
            )
        }
    }
}

@Composable
private fun SingleTicketCreationFlow(
    accentColor: Color,
    appState: FitnessAppState,
    viewModel: FitnessViewModel,
    onFinish: () -> Unit
) {
    var ticketType by remember { mutableStateOf(SingleTicketType.DAILY.code) }
    var saleDate by remember { mutableStateOf(FitnessCalculator.todayIso()) }
    var quantity by remember { mutableLongStateOf(1L) }
    var unitPriceText by remember { mutableStateOf(appState.config.singleDailyPrice.toString()) }
    var paymentMethod by remember { mutableStateOf(PaymentMethod.TRANSFER.code) }
    var cashText by remember { mutableStateOf("0") }
    var transferText by remember { mutableStateOf(appState.config.singleDailyPrice.toString()) }
    var showReview by remember { mutableStateOf(false) }

    LaunchedEffect(ticketType) {
        val suggested = if (ticketType == SingleTicketType.WEEKLY.code) {
            appState.config.singleWeeklyPrice
        } else {
            appState.config.singleDailyPrice
        }
        unitPriceText = suggested.toString()
    }

    val unitPrice = unitPriceText.toLongOrNull() ?: 0L
    val totalAmount = quantity * unitPrice
    val cashVal = cashText.toLongOrNull() ?: 0L
    val transferVal = transferText.toLongOrNull() ?: 0L

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.2.dp, accentColor)
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "BÁN VÉ LẺ",
                style = MaterialTheme.typography.titleSmall,
                color = accentColor,
                fontWeight = FontWeight.Bold
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SingleTicketType.entries.forEach { t ->
                    FilterChip(
                        selected = ticketType == t.code,
                        onClick = { ticketType = t.code },
                        label = { Text(t.label) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = accentColor,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            DatePickerField(
                label = "Ngày bán",
                isoDate = saleDate,
                onDateSelected = { saleDate = it },
                accentColor = accentColor
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Số lượng vé:", style = MaterialTheme.typography.titleSmall)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = { if (quantity > 1L) quantity-- },
                        modifier = Modifier.testTag("ticket_minus_button")
                    ) {
                        Icon(Icons.Default.Remove, contentDescription = "Giảm số lượng")
                    }
                    Text(
                        text = quantity.toString(),
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = accentColor
                    )
                    OutlinedButton(
                        onClick = { quantity++ },
                        modifier = Modifier.testTag("ticket_plus_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Tăng số lượng")
                    }
                }
            }

            OutlinedTextField(
                value = unitPriceText,
                onValueChange = { unitPriceText = it.filter { ch -> ch.isDigit() } },
                label = { Text("Đơn giá (VND)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Surface(
                color = accentColor.copy(alpha = 0.1f),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Thành tiền ($quantity × ${FitnessCalculator.formatCurrency(unitPrice)}):",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        text = FitnessCalculator.formatCurrency(totalAmount),
                        style = MaterialTheme.typography.titleMedium,
                        color = accentColor,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            PaymentMethodSelectorSection(
                paidAmount = totalAmount,
                selectedMethod = paymentMethod,
                onMethodChange = { paymentMethod = it },
                cashAmountText = cashText,
                onCashAmountChange = { cashText = it },
                transferAmountText = transferText,
                onTransferAmountChange = { transferText = it },
                accentColor = accentColor
            )

            val isValid = quantity >= 1L &&
                unitPrice > 0L &&
                (paymentMethod != "COMBINED" || (cashVal + transferVal == totalAmount))

            Button(
                onClick = { showReview = true },
                enabled = isValid,
                colors = ButtonDefaults.buttonColors(containerColor = accentColor, contentColor = Color.White),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("save_single_ticket_button"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.CheckCircle, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Xem lại & Lưu vé lẻ")
            }
        }
    }

    if (showReview) {
        ReviewAndConfirmDialog(
            title = "Xác nhận lưu giao dịch Vé lẻ",
            summaryItems = listOf(
                "Loại vé" to SingleTicketType.fromCode(ticketType).label,
                "Ngày bán" to FitnessCalculator.formatDisplayDate(saleDate),
                "Số lượng" to "$quantity vé",
                "Đơn giá" to FitnessCalculator.formatCurrency(unitPrice),
                "Tổng tiền" to FitnessCalculator.formatCurrency(totalAmount),
                "Phương thức TT" to PaymentMethod.fromCode(paymentMethod).label
            ),
            accentColor = accentColor,
            onConfirm = {
                showReview = false
                val finalCash = when (paymentMethod) {
                    "CASH" -> totalAmount
                    "COMBINED" -> cashVal
                    else -> 0L
                }
                val finalTransfer = when (paymentMethod) {
                    "TRANSFER" -> totalAmount
                    "COMBINED" -> transferVal
                    else -> 0L
                }
                viewModel.createSingleTicket(
                    ticketType = ticketType,
                    saleDate = saleDate,
                    quantity = quantity,
                    unitPrice = unitPrice,
                    paymentMethod = paymentMethod,
                    cashAmount = finalCash,
                    transferAmount = finalTransfer,
                    onSuccess = { onFinish() }
                )
            },
            onDismiss = { showReview = false }
        )
    }
}
