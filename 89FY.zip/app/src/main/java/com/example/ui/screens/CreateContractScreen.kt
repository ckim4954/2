package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.ContractEntity
import com.example.data.local.PricePlanEntity
import com.example.domain.DateCalculator
import com.example.domain.FormatUtils
import com.example.ui.MemberSummaryUi
import com.example.ui.PtClientSummaryUi
import com.example.ui.theme.*

/**
 * Compact Contract Creation Screen (Section 5.2 of Upgrade PRD):
 * - No "Step 1, Step 2, Step 3, Step 4" labels or redundant text banners
 * - Arranged in logical business order:
 *   Phân hệ -> Dịch vụ -> Thông tin hội viên -> Gói tập -> Ngày hợp đồng -> Ngày thanh toán ->
 *   Ngày bắt đầu -> Ngày hết hạn (auto-calculated or manually adjusted via native DatePickerDialog,
 *   preserving manual end date even when start date changes unless "Tính tự động lại" is clicked) ->
 *   Giá trị hợp đồng -> Đã thanh toán (Tiền mặt / Chuyển khoản) -> Công nợ còn lại -> Ghi chú
 */
@Composable
fun CreateContractScreen(
    preselectedDomain: String?,
    preselectedService: String?,
    renewalMemberId: String?,
    fromPtClientId: String?,
    pricePlans: List<PricePlanEntity>,
    gymMembers: List<MemberSummaryUi>,
    yogaMembers: List<MemberSummaryUi>,
    ptClients: List<PtClientSummaryUi>,
    onBack: () -> Unit,
    onOpenSettingsToConfigurePrices: () -> Unit,
    onOpenPtManagement: () -> Unit,
    onSaveMemberContract: (
        domain: String,
        existingMemberId: String?,
        linkedPtClientId: String?,
        fullName: String,
        phoneNumber: String,
        customerGroup: String,
        avatarPath: String?,
        pricePlanId: String?,
        planNameSnapshot: String,
        durationMonths: Int,
        agreedValueVnd: Long,
        paymentDateIso: String,
        createdDateIso: String,
        startDateIso: String,
        customEndDateIso: String?,
        isEndDateManuallyEdited: Boolean,
        cashPaidVnd: Long,
        transferPaidVnd: Long,
        note: String,
        onSuccess: (ContractEntity) -> Unit
    ) -> Unit,
    onSavePtContract: (
        existingPtClientId: String?,
        fullName: String,
        phoneNumber: String,
        registerDateIso: String,
        paymentDateIso: String,
        totalSessions: Int,
        agreedValueVnd: Long,
        cashPaidVnd: Long,
        transferPaidVnd: Long,
        onSuccess: () -> Unit
    ) -> Unit,
    onSaveTicket: (
        ticketType: String,
        saleDateIso: String,
        quantity: Int,
        unitPriceVnd: Long,
        cashAmountVnd: Long,
        transferAmountVnd: Long,
        onSuccess: () -> Unit
    ) -> Unit
) {
    val todayIso = remember { DateCalculator.todayIso() }

    var selectedDomain by remember(preselectedDomain) {
        mutableStateOf(preselectedDomain ?: "GYM")
    }

    var selectedService by remember(preselectedService, renewalMemberId, fromPtClientId) {
        mutableStateOf(
            when {
                !preselectedService.isNullOrBlank() -> preselectedService
                !renewalMemberId.isNullOrBlank() || !fromPtClientId.isNullOrBlank() -> "RENEWAL"
                else -> "NEW"
            }
        )
    }

    val domainMembers = if (selectedDomain == "GYM") gymMembers else yogaMembers
    val prefillRenewalMember = remember(renewalMemberId, domainMembers) {
        domainMembers.firstOrNull { it.member.id == renewalMemberId }
    }
    val prefillPtClient = remember(fromPtClientId, ptClients) {
        ptClients.firstOrNull { it.client.id == fromPtClientId }
    }

    var selectedExistingMemberId by remember(prefillRenewalMember) {
        mutableStateOf(prefillRenewalMember?.member?.id)
    }
    var selectedPtClientId by remember(prefillPtClient) {
        mutableStateOf(prefillPtClient?.client?.id)
    }

    var fullName by remember(prefillRenewalMember, prefillPtClient) {
        mutableStateOf(
            prefillRenewalMember?.member?.fullName
                ?: prefillPtClient?.client?.fullName
                ?: ""
        )
    }
    var phoneNumber by remember(prefillRenewalMember, prefillPtClient) {
        mutableStateOf(
            prefillRenewalMember?.member?.phoneNumber
                ?: prefillPtClient?.client?.phoneNumber
                ?: ""
        )
    }
    var customerGroup by remember(selectedDomain, prefillRenewalMember) {
        mutableStateOf(
            if (selectedDomain == "YOGA") "YOGA"
            else (prefillRenewalMember?.member?.customerGroup ?: "NAM")
        )
    }

    var paymentDateIso by remember { mutableStateOf(todayIso) }
    var createdDateIso by remember { mutableStateOf(todayIso) }
    var startDateIso by remember(prefillRenewalMember, createdDateIso) {
        val oldEnd = prefillRenewalMember?.endDateIso
        val calculatedStart = if (!oldEnd.isNullOrBlank()) {
            DateCalculator.calculateRenewalStartDate(oldEnd, createdDateIso)
        } else {
            todayIso
        }
        mutableStateOf(calculatedStart)
    }

    // Filter active, non-deleted price plans for current domain & service
    val availablePlans = remember(pricePlans, selectedDomain, selectedService, customerGroup) {
        pricePlans.filter { plan ->
            !plan.isDeleted && plan.isActive && plan.domain == selectedDomain && when (selectedService) {
                "PT" -> plan.category == "PT"
                "VE_NGAY" -> plan.category == "VE_NGAY"
                "VE_TUAN" -> plan.category == "VE_TUAN"
                else -> {
                    if (selectedDomain == "YOGA") plan.category == "YOGA"
                    else plan.category == customerGroup
                }
            }
        }
    }

    var selectedPlan by remember(availablePlans) {
        mutableStateOf(availablePlans.firstOrNull())
    }
    var customPlanName by remember(selectedPlan) {
        mutableStateOf(selectedPlan?.planName ?: "")
    }
    var durationMonths by remember(selectedPlan) {
        mutableIntStateOf(selectedPlan?.durationMonths?.takeIf { it > 0 } ?: 1)
    }
    var ptSessionsCount by remember(selectedPlan) {
        mutableIntStateOf(selectedPlan?.sessionCount?.takeIf { it > 0 } ?: 12)
    }
    var ticketQuantity by remember { mutableIntStateOf(1) }
    var agreedValueVnd by remember(selectedPlan) {
        mutableLongStateOf(selectedPlan?.priceVnd ?: 0L)
    }
    var cashPaidVnd by remember(agreedValueVnd) {
        mutableLongStateOf(agreedValueVnd)
    }
    var transferPaidVnd by remember { mutableLongStateOf(0L) }
    var note by remember { mutableStateOf("") }

    // Manual End Date state (Confirmed Decision 2: preserve manual end date even when startDateIso changes)
    var isEndDateManuallyEdited by remember { mutableStateOf(false) }
    var manualEndDateIso by remember {
        mutableStateOf(DateCalculator.calculateEndDate(startDateIso, durationMonths))
    }

    val autoCalculatedEndDateIso = remember(startDateIso, durationMonths) {
        DateCalculator.calculateEndDate(startDateIso, durationMonths)
    }

    // Keep manualEndDateIso synced ONLY when not manually edited
    LaunchedEffect(autoCalculatedEndDateIso, isEndDateManuallyEdited) {
        if (!isEndDateManuallyEdited) {
            manualEndDateIso = autoCalculatedEndDateIso
        }
    }

    val effectiveEndDateIso = if (isEndDateManuallyEdited) manualEndDateIso else autoCalculatedEndDateIso
    val totalEffectiveDays = remember(startDateIso, effectiveEndDateIso) {
        DateCalculator.daysBetween(startDateIso, effectiveEndDateIso)
    }

    // Duplicate detection warning
    val matchingExistingMember = remember(fullName, phoneNumber, domainMembers, selectedExistingMemberId) {
        if (selectedExistingMemberId != null) null
        else {
            val cleanPhone = phoneNumber.trim()
            val cleanName = fullName.trim().lowercase()
            domainMembers.firstOrNull { m ->
                (cleanPhone.isNotEmpty() && m.member.phoneNumber == cleanPhone) ||
                    (cleanName.length >= 4 && m.member.fullName.lowercase() == cleanName)
            }
        }
    }

    Scaffold(
        topBar = {
            FitnessTopAppBar(
                title = "Tạo hợp đồng",
                domainBadge = selectedDomain,
                onBackClick = onBack
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // 1. Phân hệ & Loại dịch vụ (Compact, no Step labels)
            ElevatedCard(shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = selectedDomain == "GYM",
                            onClick = {
                                selectedDomain = "GYM"
                                customerGroup = "NAM"
                                selectedExistingMemberId = null
                            },
                            label = { Text("Phân hệ GYM") },
                            leadingIcon = { Icon(Icons.Default.FitnessCenter, contentDescription = null, modifier = Modifier.size(16.dp)) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("step1_domain_gym")
                        )
                        FilterChip(
                            selected = selectedDomain == "YOGA",
                            onClick = {
                                selectedDomain = "YOGA"
                                customerGroup = "YOGA"
                                selectedExistingMemberId = null
                                if (selectedService !in listOf("NEW", "RENEWAL")) {
                                    selectedService = "NEW"
                                }
                            },
                            label = { Text("Phân hệ YOGA") },
                            leadingIcon = { Icon(Icons.Default.SelfImprovement, contentDescription = null, modifier = Modifier.size(16.dp)) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("step1_domain_yoga")
                        )
                    }

                    val serviceOptions = if (selectedDomain == "GYM") {
                        listOf(
                            "NEW" to "Đăng ký mới",
                            "RENEWAL" to "Gia hạn",
                            "PT" to "Dịch vụ PT",
                            "VE_NGAY" to "Vé ngày",
                            "VE_TUAN" to "Vé tuần"
                        )
                    } else {
                        listOf(
                            "NEW" to "Đăng ký mới",
                            "RENEWAL" to "Gia hạn"
                        )
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        serviceOptions.chunked(3).forEach { rowItems ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                rowItems.forEach { (code, label) ->
                                    FilterChip(
                                        selected = selectedService == code,
                                        onClick = { selectedService = code },
                                        label = { Text(label, style = MaterialTheme.typography.labelMedium) },
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("step2_service_${code.lowercase()}")
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 2. Biểu mẫu hợp đồng / giao dịch
            ElevatedCard(shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (availablePlans.isEmpty()) {
                        Surface(
                            color = StatusWarningAmber.copy(alpha = 0.14f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Chưa có gói giá cho mục này.",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = StatusWarningAmber,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.weight(1f)
                                )
                                TextButton(
                                    onClick = onOpenSettingsToConfigurePrices,
                                    modifier = Modifier.testTag("goto_settings_price_btn")
                                ) {
                                    Text("Mở Bảng giá")
                                }
                            }
                        }
                    }

                    when (selectedService) {
                        "VE_NGAY", "VE_TUAN" -> {
                            val ticketLabel = if (selectedService == "VE_NGAY") "Vé tập Ngày" else "Vé tập Tuần"
                            Text(
                                text = "Bán $ticketLabel (Gym)",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = GymEmeraldLight
                            )

                            DateInputField(
                                label = "Ngày bán vé",
                                isoDate = paymentDateIso,
                                onIsoDateChange = { paymentDateIso = it },
                                testTagName = "ticket_sale_date_input"
                            )

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text("Số lượng vé:", style = MaterialTheme.typography.bodyMedium)
                                FilledTonalIconButton(
                                    onClick = {
                                        if (ticketQuantity > 1) {
                                            ticketQuantity--
                                            cashPaidVnd = agreedValueVnd * ticketQuantity
                                        }
                                    },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(Icons.Default.Remove, contentDescription = "Giảm")
                                }
                                Text(
                                    text = "$ticketQuantity",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                FilledTonalIconButton(
                                    onClick = {
                                        ticketQuantity++
                                        cashPaidVnd = agreedValueVnd * ticketQuantity
                                    },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = "Tăng")
                                }
                            }

                            VndAmountField(
                                label = "Đơn giá vé",
                                amountVnd = agreedValueVnd,
                                onAmountChange = {
                                    agreedValueVnd = it
                                    cashPaidVnd = it * ticketQuantity
                                },
                                testTagName = "ticket_unit_price_input"
                            )

                            val totalTicketVnd = agreedValueVnd * ticketQuantity
                            Text(
                                text = "Thành tiền: ${FormatUtils.formatVnd(totalTicketVnd)}",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = GymEmeraldLight
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                VndAmountField(
                                    label = "Tiền mặt",
                                    amountVnd = cashPaidVnd,
                                    onAmountChange = { cashPaidVnd = it },
                                    modifier = Modifier.weight(1f)
                                )
                                VndAmountField(
                                    label = "Chuyển khoản",
                                    amountVnd = transferPaidVnd,
                                    onAmountChange = { transferPaidVnd = it },
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Button(
                                onClick = {
                                    onSaveTicket(
                                        selectedService,
                                        paymentDateIso,
                                        ticketQuantity,
                                        agreedValueVnd,
                                        cashPaidVnd,
                                        transferPaidVnd
                                    ) {
                                        onBack()
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("save_ticket_btn")
                            ) {
                                Icon(Icons.Default.ConfirmationNumber, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Lưu vé")
                            }
                        }

                        "PT" -> {
                            Text(
                                text = "Hợp đồng PT — HLV Hà Đức (50% Gym / 50% HLV)",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = PtTealLight
                            )

                            if (ptClients.isNotEmpty()) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    ptClients.take(3).forEach { ptc ->
                                        FilterChip(
                                            selected = selectedPtClientId == ptc.client.id,
                                            onClick = {
                                                selectedPtClientId = ptc.client.id
                                                fullName = ptc.client.fullName
                                                phoneNumber = ptc.client.phoneNumber
                                            },
                                            label = { Text("${ptc.client.fullName} (${ptc.remainingSessionsOnActive}b)") }
                                        )
                                    }
                                }
                            }

                            OutlinedTextField(
                                value = fullName,
                                onValueChange = { fullName = it },
                                label = { Text("Họ và tên khách PT *") },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("pt_client_name_input")
                            )

                            OutlinedTextField(
                                value = phoneNumber,
                                onValueChange = { phoneNumber = it },
                                label = { Text("Số điện thoại") },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("pt_client_phone_input")
                            )

                            if (availablePlans.isNotEmpty()) {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    availablePlans.forEach { p ->
                                        FilterChip(
                                            selected = selectedPlan?.id == p.id,
                                            onClick = {
                                                selectedPlan = p
                                                ptSessionsCount = p.sessionCount.coerceAtLeast(1)
                                                agreedValueVnd = p.priceVnd
                                                cashPaidVnd = p.priceVnd
                                            },
                                            label = { Text("${p.planName} (${p.sessionCount}b)") }
                                        )
                                    }
                                }
                            }

                            OutlinedTextField(
                                value = ptSessionsCount.toString(),
                                onValueChange = { ptSessionsCount = it.filter { ch -> ch.isDigit() }.toIntOrNull() ?: 0 },
                                label = { Text("Số buổi PT đăng ký *") },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("pt_sessions_count_input")
                            )

                            VndAmountField(
                                label = "Giá trị hợp đồng PT",
                                amountVnd = agreedValueVnd,
                                onAmountChange = {
                                    agreedValueVnd = it
                                    cashPaidVnd = it
                                },
                                testTagName = "pt_agreed_value_input"
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                DateInputField(
                                    label = "Ngày đăng ký",
                                    isoDate = createdDateIso,
                                    onIsoDateChange = { createdDateIso = it },
                                    modifier = Modifier.weight(1f)
                                )
                                DateInputField(
                                    label = "Ngày thanh toán",
                                    isoDate = paymentDateIso,
                                    onIsoDateChange = { paymentDateIso = it },
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                VndAmountField(
                                    label = "Tiền mặt",
                                    amountVnd = cashPaidVnd,
                                    onAmountChange = { cashPaidVnd = it },
                                    modifier = Modifier.weight(1f)
                                )
                                VndAmountField(
                                    label = "Chuyển khoản",
                                    amountVnd = transferPaidVnd,
                                    onAmountChange = { transferPaidVnd = it },
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = onOpenPtManagement,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Mở Quản lý PT")
                                }
                                Button(
                                    onClick = {
                                        onSavePtContract(
                                            selectedPtClientId,
                                            fullName,
                                            phoneNumber,
                                            createdDateIso,
                                            paymentDateIso,
                                            ptSessionsCount,
                                            agreedValueVnd,
                                            cashPaidVnd,
                                            transferPaidVnd
                                        ) {
                                            onOpenPtManagement()
                                        }
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("save_pt_contract_btn")
                                ) {
                                    Text("Lưu Hợp đồng PT")
                                }
                            }
                        }

                        else -> {
                            // Gym or Yoga Membership Form ("NEW" or "RENEWAL") in strict Section 5.2 order
                            if (selectedService == "RENEWAL" && domainMembers.isNotEmpty()) {
                                Text(
                                    text = "Chọn hội viên $selectedDomain gia hạn:",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    domainMembers.take(5).forEach { m ->
                                        val isChosen = selectedExistingMemberId == m.member.id
                                        OutlinedCard(
                                            onClick = {
                                                selectedExistingMemberId = m.member.id
                                                fullName = m.member.fullName
                                                phoneNumber = m.member.phoneNumber
                                                customerGroup = m.member.customerGroup
                                                startDateIso = DateCalculator.calculateRenewalStartDate(
                                                    previousEndDateIso = m.endDateIso.ifBlank { todayIso },
                                                    renewalDateIso = createdDateIso
                                                )
                                            },
                                            colors = CardDefaults.outlinedCardColors(
                                                containerColor = if (isChosen) {
                                                    MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                                                } else {
                                                    MaterialTheme.colorScheme.surface
                                                }
                                            ),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = "${m.member.fullName} • Hết hạn: ${DateCalculator.formatDisplay(m.endDateIso)}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                                if (isChosen) {
                                                    Icon(
                                                        Icons.Default.CheckCircle,
                                                        contentDescription = null,
                                                        tint = StatusActiveGreen,
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            if (matchingExistingMember != null) {
                                Surface(
                                    color = StatusWarningAmber.copy(alpha = 0.16f),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "Trùng hội viên cũ: ${matchingExistingMember.member.fullName}",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = StatusWarningAmber,
                                            modifier = Modifier.weight(1f)
                                        )
                                        TextButton(
                                            onClick = {
                                                selectedExistingMemberId = matchingExistingMember.member.id
                                                selectedService = "RENEWAL"
                                                fullName = matchingExistingMember.member.fullName
                                                phoneNumber = matchingExistingMember.member.phoneNumber
                                                startDateIso = DateCalculator.calculateRenewalStartDate(
                                                    previousEndDateIso = matchingExistingMember.endDateIso.ifBlank { todayIso },
                                                    renewalDateIso = createdDateIso
                                                )
                                            }
                                        ) {
                                            Text("Chuyển sang Gia hạn")
                                        }
                                    }
                                }
                            }

                            // 1. Thông tin hội viên
                            Text(
                                text = "Thông tin hội viên",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )

                            OutlinedTextField(
                                value = fullName,
                                onValueChange = { fullName = it },
                                label = { Text("Họ và tên hội viên *") },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("contract_member_name_input")
                            )

                            OutlinedTextField(
                                value = phoneNumber,
                                onValueChange = { phoneNumber = it },
                                label = { Text("Số điện thoại") },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("contract_member_phone_input")
                            )

                            // 2. Gói tập
                            HorizontalDivider()
                            Text(
                                text = "Gói tập",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )

                            if (selectedDomain == "GYM") {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("NAM" to "Gym Nam", "NU" to "Gym Nữ", "TRE_EM" to "Trẻ em").forEach { (code, label) ->
                                        FilterChip(
                                            selected = customerGroup == code,
                                            onClick = { customerGroup = code },
                                            label = { Text(label) }
                                        )
                                    }
                                }
                            }

                            if (availablePlans.isNotEmpty()) {
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    availablePlans.chunked(2).forEach { rowPlans ->
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            rowPlans.forEach { plan ->
                                                FilterChip(
                                                    selected = selectedPlan?.id == plan.id,
                                                    onClick = {
                                                        selectedPlan = plan
                                                        customPlanName = plan.planName
                                                        durationMonths = plan.durationMonths.coerceAtLeast(1)
                                                        agreedValueVnd = plan.priceVnd
                                                        cashPaidVnd = plan.priceVnd
                                                    },
                                                    label = {
                                                        Text(
                                                            "${plan.durationMonths}T - ${FormatUtils.formatVnd(plan.priceVnd)}",
                                                            style = MaterialTheme.typography.labelMedium
                                                        )
                                                    },
                                                    modifier = Modifier.weight(1f)
                                                )
                                            }
                                            if (rowPlans.size == 1) {
                                                Spacer(modifier = Modifier.weight(1f))
                                            }
                                        }
                                    }
                                }
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = customPlanName,
                                    onValueChange = { customPlanName = it },
                                    label = { Text("Tên gói *") },
                                    singleLine = true,
                                    modifier = Modifier
                                        .weight(1.4f)
                                        .testTag("contract_plan_name_input")
                                )
                                OutlinedTextField(
                                    value = durationMonths.toString(),
                                    onValueChange = {
                                        val m = it.filter { c -> c.isDigit() }.toIntOrNull() ?: 1
                                        durationMonths = m.coerceAtLeast(1)
                                    },
                                    label = { Text("Số tháng") },
                                    singleLine = true,
                                    modifier = Modifier.weight(0.6f)
                                )
                            }

                            // 3. Mốc thời gian hợp đồng (Ngày hợp đồng -> Ngày thanh toán -> Ngày bắt đầu -> Ngày hết hạn)
                            HorizontalDivider()
                            Text(
                                text = "Thời hạn hợp đồng",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                DateInputField(
                                    label = "Ngày hợp đồng",
                                    isoDate = createdDateIso,
                                    onIsoDateChange = { newCreatedIso ->
                                        createdDateIso = newCreatedIso
                                        val existing = domainMembers.firstOrNull { it.member.id == selectedExistingMemberId }
                                        if (existing != null && existing.endDateIso.isNotBlank()) {
                                            startDateIso = DateCalculator.calculateRenewalStartDate(
                                                previousEndDateIso = existing.endDateIso,
                                                renewalDateIso = newCreatedIso
                                            )
                                        }
                                    },
                                    testTagName = "contract_created_date_input",
                                    modifier = Modifier.weight(1f)
                                )
                                DateInputField(
                                    label = "Ngày thanh toán",
                                    isoDate = paymentDateIso,
                                    onIsoDateChange = { paymentDateIso = it },
                                    testTagName = "contract_payment_date_input",
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                DateInputField(
                                    label = "Ngày bắt đầu",
                                    isoDate = startDateIso,
                                    onIsoDateChange = {
                                        // Confirmed Decision 2: changing startDateIso keeps manualEndDateIso if manually edited!
                                        startDateIso = it
                                    },
                                    testTagName = "contract_start_date_input",
                                    modifier = Modifier.weight(1f)
                                )
                                DateInputField(
                                    label = if (isEndDateManuallyEdited) "Ngày hết hạn (Chỉnh tay)" else "Ngày hết hạn (Tự động)",
                                    isoDate = effectiveEndDateIso,
                                    onIsoDateChange = { pickedEndIso ->
                                        manualEndDateIso = pickedEndIso
                                        isEndDateManuallyEdited = true
                                    },
                                    testTagName = "contract_end_date_input",
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Số ngày hiệu lực: $totalEffectiveDays ngày",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                if (isEndDateManuallyEdited) {
                                    TextButton(
                                        onClick = {
                                            isEndDateManuallyEdited = false
                                            manualEndDateIso = autoCalculatedEndDateIso
                                        },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                        modifier = Modifier.testTag("recalculate_end_date_auto_btn")
                                    ) {
                                        Icon(Icons.Default.Autorenew, contentDescription = null, modifier = Modifier.size(15.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Tính tự động lại", style = MaterialTheme.typography.labelMedium)
                                    }
                                }
                            }

                            // 4. Giá trị hợp đồng -> Đã thanh toán -> Công nợ -> Phương thức -> Ghi chú
                            HorizontalDivider()
                            Text(
                                text = "Thanh toán & Công nợ",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )

                            VndAmountField(
                                label = "Giá trị hợp đồng",
                                amountVnd = agreedValueVnd,
                                onAmountChange = {
                                    agreedValueVnd = it
                                    cashPaidVnd = it
                                },
                                testTagName = "contract_agreed_value_input"
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                VndAmountField(
                                    label = "Đã thu Tiền mặt",
                                    amountVnd = cashPaidVnd,
                                    onAmountChange = { cashPaidVnd = it },
                                    testTagName = "contract_cash_paid_input",
                                    modifier = Modifier.weight(1f)
                                )
                                VndAmountField(
                                    label = "Đã thu Chuyển khoản",
                                    amountVnd = transferPaidVnd,
                                    onAmountChange = { transferPaidVnd = it },
                                    testTagName = "contract_transfer_paid_input",
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            val totalPaidNow = cashPaidVnd + transferPaidVnd
                            val remainingDebt = (agreedValueVnd - totalPaidNow).coerceAtLeast(0L)
                            val overpaid = (totalPaidNow - agreedValueVnd).coerceAtLeast(0L)
                            val paymentMethodLabel = when {
                                cashPaidVnd > 0L && transferPaidVnd > 0L -> "Tiền mặt + Chuyển khoản"
                                transferPaidVnd > 0L -> "Chuyển khoản"
                                cashPaidVnd > 0L -> "Tiền mặt"
                                else -> "Chưa thanh toán (Nợ 100%)"
                            }

                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("Số tiền đã thanh toán:", style = MaterialTheme.typography.bodySmall)
                                        Text(
                                            FormatUtils.formatVnd(totalPaidNow),
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.Bold,
                                            color = StatusActiveGreen
                                        )
                                    }
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("Công nợ còn lại:", style = MaterialTheme.typography.bodySmall)
                                        Text(
                                            text = if (overpaid > 0L) "Thu vượt ${FormatUtils.formatVnd(overpaid)}" else FormatUtils.formatVnd(remainingDebt),
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.Bold,
                                            color = if (remainingDebt > 0L) StatusDangerRed else if (overpaid > 0L) StatusWarningAmber else MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("Phương thức thanh toán:", style = MaterialTheme.typography.bodySmall)
                                        Text(
                                            paymentMethodLabel,
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                }
                            }

                            OutlinedTextField(
                                value = note,
                                onValueChange = { note = it },
                                label = { Text("Ghi chú hợp đồng") },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("contract_note_input")
                            )

                            Button(
                                onClick = {
                                    onSaveMemberContract(
                                        selectedDomain,
                                        selectedExistingMemberId,
                                        selectedPtClientId,
                                        fullName,
                                        phoneNumber,
                                        customerGroup,
                                        null,
                                        selectedPlan?.id,
                                        customPlanName.ifBlank { "Gói $selectedDomain $durationMonths tháng" },
                                        durationMonths,
                                        agreedValueVnd,
                                        paymentDateIso,
                                        createdDateIso,
                                        startDateIso,
                                        if (isEndDateManuallyEdited) effectiveEndDateIso else null,
                                        isEndDateManuallyEdited,
                                        cashPaidVnd,
                                        transferPaidVnd,
                                        note
                                    ) {
                                        onBack()
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (selectedDomain == "GYM") GymEmeraldLight else YogaIndigoLight
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("save_member_contract_btn")
                            ) {
                                Icon(Icons.Default.Check, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Lưu hợp đồng $selectedDomain",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
