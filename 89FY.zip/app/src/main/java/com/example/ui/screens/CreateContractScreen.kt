package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.SportsGymnastics
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.MemberGroup
import com.example.data.model.MemberProfile
import com.example.data.model.PaymentMethod
import com.example.data.model.SingleTicketType
import com.example.domain.FitnessCalculator
import com.example.ui.components.DatePickerField
import com.example.ui.components.PaymentMethodSelectorSection
import com.example.ui.components.ReviewAndConfirmDialog
import com.example.ui.components.ScreenHeaderBar
import com.example.ui.theme.GymGreenBright
import com.example.ui.theme.PriceNuPink
import com.example.ui.theme.PriceTreEmOrange
import com.example.ui.theme.YogaPurpleBright
import com.example.ui.viewmodel.FitnessAppState
import com.example.ui.viewmodel.FitnessViewModel

enum class ContractCreationBranch(
    val code: String,
    val title: String,
    val subtitle: String,
    val color: Color
) {
    GYM("GYM", "1. GYM", "Tìm hồ sơ GYM trước • Tạo mới hoặc Gia hạn giữ STT", GymGreenBright),
    YOGA("YOGA", "2. YOGA", "Tìm hồ sơ YOGA trước • Tạo mới hoặc Gia hạn giữ STT", YogaPurpleBright),
    PT("PT", "3. PT", "Gói số buổi tùy chỉnh • Tối đa 1 HĐ hiệu lực/người", PriceNuPink),
    SINGLE_TICKET("VE_LE", "4. VÉ LẺ", "Vé ngày / Vé tuần • Không tạo hồ sơ hội viên", PriceTreEmOrange)
}

@Composable
fun CreateContractScreen(
    appState: FitnessAppState,
    viewModel: FitnessViewModel,
    initialBranch: ContractCreationBranch? = null,
    preselectedMember: MemberProfile? = null,
    onBack: () -> Unit
) {
    var selectedBranch by remember(initialBranch, preselectedMember) {
        mutableStateOf(
            when (preselectedMember?.type) {
                "GYM" -> ContractCreationBranch.GYM
                "YOGA" -> ContractCreationBranch.YOGA
                "PT" -> ContractCreationBranch.PT
                else -> initialBranch
            }
        )
    }

    BackHandler {
        if (selectedBranch != null && initialBranch == null && preselectedMember == null) {
            selectedBranch = null
        } else {
            onBack()
        }
    }

    Scaffold(
        topBar = {
            ScreenHeaderBar(
                title = selectedBranch?.let { "TẠO HỢP ĐỒNG — ${it.title}" } ?: "3. TẠO HỢP ĐỒNG",
                subtitle = "Đúng 4 lựa chọn: GYM • YOGA • PT • VÉ LẺ",
                accentColor = selectedBranch?.color ?: Color(0xFF0284C7),
                onBack = {
                    if (selectedBranch != null && initialBranch == null && preselectedMember == null) {
                        selectedBranch = null
                    } else {
                        onBack()
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 4 lựa chọn nhánh
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ContractCreationBranch.entries.forEach { branch ->
                    val isSelected = selectedBranch == branch
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedBranch = branch },
                        label = { Text(branch.code.replace("VE_LE", "VÉ LẺ")) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = branch.color,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("branch_chip_${branch.code}")
                    )
                }
            }

            when (val branch = selectedBranch) {
                null -> {
                    Text(
                        text = "Chọn loại hợp đồng hoặc vé lẻ cần tạo:",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    ContractCreationBranch.entries.forEach { item ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedBranch = item }
                                .testTag("branch_card_${item.code}"),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.5.dp, item.color.copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(18.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = when (item) {
                                        ContractCreationBranch.GYM -> Icons.Default.FitnessCenter
                                        ContractCreationBranch.YOGA -> Icons.Default.SelfImprovement
                                        ContractCreationBranch.PT -> Icons.Default.SportsGymnastics
                                        ContractCreationBranch.SINGLE_TICKET -> Icons.Default.ConfirmationNumber
                                    },
                                    contentDescription = null,
                                    tint = item.color,
                                    modifier = Modifier.size(32.dp)
                                )
                                Spacer(modifier = Modifier.width(14.dp))
                                Column {
                                    Text(
                                        text = item.title,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = item.color
                                    )
                                    Text(
                                        text = item.subtitle,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }

                ContractCreationBranch.GYM, ContractCreationBranch.YOGA -> {
                    GymOrYogaContractCreationFlow(
                        serviceType = branch.code,
                        accentColor = branch.color,
                        appState = appState,
                        viewModel = viewModel,
                        preselectedMember = preselectedMember?.takeIf { it.type == branch.code },
                        onFinish = onBack
                    )
                }

                ContractCreationBranch.PT -> {
                    PtContractCreationFlow(
                        accentColor = branch.color,
                        appState = appState,
                        viewModel = viewModel,
                        preselectedMember = preselectedMember?.takeIf { it.type == "PT" },
                        onFinish = onBack
                    )
                }

                ContractCreationBranch.SINGLE_TICKET -> {
                    SingleTicketCreationFlow(
                        accentColor = branch.color,
                        appState = appState,
                        viewModel = viewModel,
                        onFinish = onBack
                    )
                }
            }
        }
    }
}

@Composable
private fun GymOrYogaContractCreationFlow(
    serviceType: String,
    accentColor: Color,
    appState: FitnessAppState,
    viewModel: FitnessViewModel,
    preselectedMember: MemberProfile?,
    onFinish: () -> Unit
) {
    val isYoga = serviceType == "YOGA"
    val existingPool = if (isYoga) appState.activeYogaMembers else appState.activeGymMembers

    var searchQuery by remember(serviceType, preselectedMember) {
        mutableStateOf(preselectedMember?.fullName ?: "")
    }
    var selectedExistingMember by remember(serviceType, preselectedMember) {
        mutableStateOf(preselectedMember)
    }
    var isCreatingNewProfile by remember(serviceType, preselectedMember) {
        mutableStateOf(false)
    }

    // Không hiển thị danh sách mặc định khi chưa nhập từ khóa tìm kiếm!
    val searchResults = remember(searchQuery, existingPool) {
        val q = searchQuery.trim().lowercase()
        if (q.isEmpty()) emptyList()
        else {
            existingPool.filter { m ->
                "stt${m.stt}".contains(q) ||
                    m.stt.toString() == q ||
                    m.fullName.lowercase().contains(q) ||
                    m.phone.lowercase().contains(q)
            }
        }
    }

    // Bước 1: Tìm kiếm trước, hệ thống nhận diện hồ sơ cũ / mới
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.4f))
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "BƯỚC 1: TÌM KIẾM HỒ SƠ $serviceType",
                style = MaterialTheme.typography.titleSmall,
                color = accentColor,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Nhập STT, Họ tên hoặc Số điện thoại để kiểm tra hồ sơ đã có hay chưa (không hiện danh sách mặc định).",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            OutlinedTextField(
                value = searchQuery,
                onValueChange = {
                    searchQuery = it
                    selectedExistingMember = null
                    isCreatingNewProfile = false
                },
                label = { Text("Tìm theo STT / Họ tên / SĐT") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("contract_search_member_input")
            )

            if (searchQuery.trim().isNotEmpty()) {
                if (searchResults.isNotEmpty()) {
                    Text(
                        text = "Tìm thấy ${searchResults.size} hồ sơ $serviceType đã có (Chọn để Gia hạn giữ nguyên STT):",
                        style = MaterialTheme.typography.labelLarge,
                        color = accentColor
                    )
                    searchResults.forEach { member ->
                        val memberContracts = appState.activeContracts
                            .filter { it.memberId == member.id }
                            .sortedByDescending { it.endDate }
                        val isPicked = selectedExistingMember?.id == member.id && !isCreatingNewProfile

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedExistingMember = member
                                    isCreatingNewProfile = false
                                },
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isPicked) accentColor.copy(alpha = 0.12f)
                                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                            ),
                            border = BorderStroke(if (isPicked) 2.dp else 1.dp, accentColor)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "STT${member.stt} — ${member.fullName}",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "SĐT: ${member.phone.ifBlank { "Chưa có" }} • Đã có ${memberContracts.size} hợp đồng",
                                    style = MaterialTheme.typography.bodySmall
                                )
                                if (memberContracts.isNotEmpty()) {
                                    val latest = memberContracts.first()
                                    Text(
                                        text = "HĐ gần nhất: ${latest.contractCode} (Hết hạn: ${FitnessCalculator.formatDisplayDate(latest.endDate)})",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                } else {
                    Text(
                        text = "Không tìm thấy hồ sơ $serviceType khớp từ khóa \"$searchQuery\".",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                OutlinedButton(
                    onClick = {
                        selectedExistingMember = null
                        isCreatingNewProfile = true
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("create_new_profile_button")
                ) {
                    Icon(Icons.Default.PersonAdd, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Tạo hồ sơ $serviceType mới + Hợp đồng đầu tiên")
                }
            }
        }
    }

    // Bước 2: Biểu mẫu hợp đồng (hiển thị khi đã chọn hồ sơ cũ để gia hạn HOẶC chọn tạo hồ sơ mới)
    if (selectedExistingMember != null || isCreatingNewProfile) {
        val existing = selectedExistingMember
        val previewStt = existing?.stt ?: ((if (isYoga) appState.config.lastYogaStt else appState.config.lastGymStt) + 1L)
        val previewSeq = existing?.nextContractSeq ?: 1L
        val previewContractCode = FitnessCalculator.buildContractCode(serviceType, previewStt, previewSeq)

        var fullName by remember(existing, searchQuery) {
            mutableStateOf(existing?.fullName ?: searchQuery.trim())
        }
        var phone by remember(existing) { mutableStateOf(existing?.phone ?: "") }
        var memberGroup by remember(existing, isYoga) {
            mutableStateOf(
                if (isYoga) "NONE"
                else existing?.memberGroup?.takeIf { it != "NONE" } ?: "NAM"
            )
        }
        val durationOptions = if (isYoga) listOf(1, 2, 3) else listOf(1, 2, 3, 12)
        var durationMonths by remember(serviceType) { mutableIntStateOf(1) }

        // Nếu gia hạn từ hợp đồng còn hạn, gợi ý ngày bắt đầu tiếp nối hoặc hôm nay
        var startDate by remember(existing) {
            mutableStateOf(FitnessCalculator.todayIso())
        }
        var endDate by remember(startDate, durationMonths) {
            mutableStateOf(FitnessCalculator.calculateEndDate(startDate, durationMonths))
        }

        val defaultPrice = remember(serviceType, memberGroup, durationMonths, appState.config) {
            if (isYoga) {
                appState.config.getYogaPrice(durationMonths)
            } else {
                appState.config.getGymPrice(MemberGroup.fromCode(memberGroup), durationMonths)
            }
        }

        var packageValueText by remember(defaultPrice) { mutableStateOf(defaultPrice.toString()) }
        var paidAmountText by remember(defaultPrice) { mutableStateOf(defaultPrice.toString()) }
        var paymentMethod by remember { mutableStateOf(PaymentMethod.TRANSFER.code) }
        var cashText by remember { mutableStateOf("0") }
        var transferText by remember(defaultPrice) { mutableStateOf(defaultPrice.toString()) }
        var paymentDate by remember { mutableStateOf(FitnessCalculator.todayIso()) }
        var showReviewDialog by remember { mutableStateOf(false) }

        val pkgValue = packageValueText.toLongOrNull() ?: 0L
        val paidValue = paidAmountText.toLongOrNull() ?: 0L
        val cashValue = cashText.toLongOrNull() ?: 0L
        val transferValue = transferText.toLongOrNull() ?: 0L

        val startTriple = FitnessCalculator.parseIso(startDate)
        val previewAllocation = remember(pkgValue, startDate, endDate, startTriple) {
            if (startTriple == null) Triple(0L, 0L, 0L)
            else FitnessCalculator.calculateContractAllocatedRevenue(
                packageValue = pkgValue,
                startDateIso = startDate,
                endDateIso = endDate,
                year = startTriple.first,
                month = startTriple.second
            )
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.5.dp, accentColor)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = if (existing != null) {
                        "BƯỚC 2: GIA HẠN HỢP ĐỒNG (GIỮ NGUYÊN STT${existing.stt})"
                    } else {
                        "BƯỚC 2: HỒ SƠ MỚI (CẤP STT$previewStt) & HỢP ĐỒNG ĐẦU TIÊN"
                    },
                    style = MaterialTheme.typography.titleSmall,
                    color = accentColor,
                    fontWeight = FontWeight.Bold
                )

                Surface(
                    color = accentColor.copy(alpha = 0.1f),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "Mã hợp đồng dự kiến: $previewContractCode",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = accentColor
                        )
                        Text(
                            text = if (existing != null) "Loại: Hợp đồng Gia hạn" else "Loại: Đăng ký mới",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }

                if (existing == null) {
                    OutlinedTextField(
                        value = fullName,
                        onValueChange = { fullName = it },
                        label = { Text("Họ và tên đầy đủ *") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("new_member_name_input")
                    )
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("Số điện thoại") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("new_member_phone_input")
                    )
                } else {
                    // Hiện lịch sử tóm tắt của hồ sơ cũ
                    val history = appState.activeContracts
                        .filter { it.memberId == existing.id }
                        .sortedByDescending { it.endDate }
                    Text(
                        text = "Hội viên: STT${existing.stt} — ${existing.fullName} (SĐT: ${existing.phone.ifBlank { "Chưa có" }})",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    if (history.isNotEmpty()) {
                        Text(
                            text = "Lịch sử hợp đồng (${history.size} HĐ): " +
                                history.take(3).joinToString(" | ") { "${it.contractCode} (${FitnessCalculator.formatDisplayDate(it.endDate)})" },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Nhóm giá (Chỉ cho GYM)
                if (!isYoga) {
                    Text("Nhóm giá GYM:", style = MaterialTheme.typography.labelLarge)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(MemberGroup.NAM, MemberGroup.NU, MemberGroup.TRE_EM).forEach { grp ->
                            FilterChip(
                                selected = memberGroup == grp.code,
                                onClick = { memberGroup = grp.code },
                                label = { Text(grp.label) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = accentColor,
                                    selectedLabelColor = Color.White
                                ),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                // Chọn gói tháng
                Text("Gói thời hạn ($serviceType):", style = MaterialTheme.typography.labelLarge)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    durationOptions.forEach { m ->
                        FilterChip(
                            selected = durationMonths == m,
                            onClick = {
                                durationMonths = m
                                endDate = FitnessCalculator.calculateEndDate(startDate, m)
                            },
                            label = { Text("$m tháng") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = accentColor,
                                selectedLabelColor = Color.White
                            ),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                // Ngày đăng ký & Ngày hết hạn (Date Picker)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    DatePickerField(
                        label = "Ngày đăng ký",
                        isoDate = startDate,
                        onDateSelected = {
                            startDate = it
                            paymentDate = it
                            endDate = FitnessCalculator.calculateEndDate(it, durationMonths)
                        },
                        modifier = Modifier.weight(1f),
                        accentColor = accentColor
                    )
                    DatePickerField(
                        label = "Ngày hết hạn",
                        isoDate = endDate,
                        onDateSelected = { endDate = it },
                        modifier = Modifier.weight(1f),
                        accentColor = accentColor
                    )
                }

                // Giá trị gói & Số tiền thanh toán
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = packageValueText,
                        onValueChange = {
                            val clean = it.filter { ch -> ch.isDigit() }
                            packageValueText = clean
                            paidAmountText = clean
                        },
                        label = { Text("Giá trị gói (VND)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = paidAmountText,
                        onValueChange = { paidAmountText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Số tiền TT (VND)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                // Hiển thị Doanh thu phân bổ tháng tự động
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "Doanh thu phân bổ tháng ${startTriple?.second ?: ""}/${startTriple?.first ?: ""}: ${FitnessCalculator.formatCurrency(previewAllocation.first)}",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = accentColor
                        )
                        Text(
                            text = "Công thức: ${FitnessCalculator.formatCurrency(pkgValue)} / ${previewAllocation.second} ngày hiệu lực × ${previewAllocation.third} ngày trong tháng (làm tròn đồng)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Phương thức thanh toán
                PaymentMethodSelectorSection(
                    paidAmount = paidValue,
                    selectedMethod = paymentMethod,
                    onMethodChange = { paymentMethod = it },
                    cashAmountText = cashText,
                    onCashAmountChange = { cashText = it },
                    transferAmountText = transferText,
                    onTransferAmountChange = { transferText = it },
                    accentColor = accentColor
                )

                val isFormValid = fullName.isNotBlank() &&
                    pkgValue > 0L &&
                    (paymentMethod != "COMBINED" || (cashValue + transferValue == paidValue))

                Button(
                    onClick = { showReviewDialog = true },
                    enabled = isFormValid,
                    colors = ButtonDefaults.buttonColors(containerColor = accentColor, contentColor = Color.White),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("review_contract_button"),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Kiểm tra & Xác nhận trước khi lưu", style = MaterialTheme.typography.titleMedium)
                }
            }
        }

        if (showReviewDialog) {
            ReviewAndConfirmDialog(
                title = "Xác nhận lưu hợp đồng $previewContractCode",
                summaryItems = buildList {
                    add("Mã hợp đồng" to previewContractCode)
                    add("STT & Họ tên" to "STT$previewStt — ${fullName.trim()}")
                    add("Số điện thoại" to phone.trim().ifBlank { "Không có" })
                    if (!isYoga) add("Nhóm giá" to MemberGroup.fromCode(memberGroup).label)
                    add("Gói đăng ký" to "$durationMonths tháng (${if (existing != null) "Gia hạn" else "Đăng ký mới"})")
                    add("Ngày đăng ký" to FitnessCalculator.formatDisplayDate(startDate))
                    add("Ngày hết hạn" to FitnessCalculator.formatDisplayDate(endDate))
                    add("Giá trị gói" to FitnessCalculator.formatCurrency(pkgValue))
                    add("Số tiền thanh toán" to FitnessCalculator.formatCurrency(paidValue))
                    add("Phân bổ tháng ĐK" to FitnessCalculator.formatCurrency(previewAllocation.first))
                    add("Phương thức TT" to PaymentMethod.fromCode(paymentMethod).label)
                    if (paymentMethod == "COMBINED") {
                        add("• Tiền mặt" to FitnessCalculator.formatCurrency(cashValue))
                        add("• Chuyển khoản" to FitnessCalculator.formatCurrency(transferValue))
                    }
                },
                accentColor = accentColor,
                onConfirm = {
                    showReviewDialog = false
                    val finalCash = when (paymentMethod) {
                        "CASH" -> paidValue
                        "COMBINED" -> cashValue
                        else -> 0L
                    }
                    val finalTransfer = when (paymentMethod) {
                        "TRANSFER" -> paidValue
                        "COMBINED" -> transferValue
                        else -> 0L
                    }
                    if (existing != null) {
                        viewModel.createRenewalContract(
                            member = existing,
                            memberGroup = memberGroup,
                            durationMonths = durationMonths.toLong(),
                            startDate = startDate,
                            endDate = endDate,
                            totalSessions = 0L,
                            packageValue = pkgValue,
                            paidAmount = paidValue,
                            paymentMethod = paymentMethod,
                            cashAmount = finalCash,
                            transferAmount = finalTransfer,
                            paymentDate = paymentDate,
                            onSuccess = { onFinish() }
                        )
                    } else {
                        viewModel.createNewMemberAndContract(
                            serviceType = serviceType,
                            fullName = fullName,
                            phone = phone,
                            memberGroup = memberGroup,
                            durationMonths = durationMonths.toLong(),
                            startDate = startDate,
                            endDate = endDate,
                            totalSessions = 0L,
                            packageValue = pkgValue,
                            paidAmount = paidValue,
                            paymentMethod = paymentMethod,
                            cashAmount = finalCash,
                            transferAmount = finalTransfer,
                            paymentDate = paymentDate,
                            onSuccess = { _, _ -> onFinish() }
                        )
                    }
                },
                onDismiss = { showReviewDialog = false }
            )
        }
    }
}

@Composable
private fun PtContractCreationFlow(
    accentColor: Color,
    appState: FitnessAppState,
    viewModel: FitnessViewModel,
    preselectedMember: MemberProfile?,
    onFinish: () -> Unit
) {
    val existingPool = appState.activePtMembers
    var searchQuery by remember(preselectedMember) { mutableStateOf(preselectedMember?.fullName ?: "") }
    var selectedMember by remember(preselectedMember) { mutableStateOf(preselectedMember) }
    var isCreatingNew by remember { mutableStateOf(false) }

    val searchResults = remember(searchQuery, existingPool) {
        val q = searchQuery.trim().lowercase()
        if (q.isEmpty()) emptyList()
        else {
            existingPool.filter { m ->
                "stt${m.stt}".contains(q) ||
                    m.stt.toString() == q ||
                    m.fullName.lowercase().contains(q) ||
                    m.phone.lowercase().contains(q)
            }
        }
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.4f))
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "BƯỚC 1: TÌM HỒ SƠ PT HOẶC TẠO MỚI",
                style = MaterialTheme.typography.titleSmall,
                color = accentColor,
                fontWeight = FontWeight.Bold
            )
            OutlinedTextField(
                value = searchQuery,
                onValueChange = {
                    searchQuery = it
                    selectedMember = null
                    isCreatingNew = false
                },
                label = { Text("Tìm STT PT / Họ tên / SĐT") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            if (searchQuery.trim().isNotEmpty()) {
                searchResults.forEach { member ->
                    val isPicked = selectedMember?.id == member.id && !isCreatingNew
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                selectedMember = member
                                isCreatingNew = false
                            },
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isPicked) accentColor.copy(alpha = 0.12f)
                            else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                        ),
                        border = BorderStroke(if (isPicked) 2.dp else 1.dp, accentColor)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "PT-STT${member.stt} — ${member.fullName}",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text("SĐT: ${member.phone.ifBlank { "Chưa có" }}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }

                OutlinedButton(
                    onClick = {
                        selectedMember = null
                        isCreatingNew = true
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.PersonAdd, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Tạo hồ sơ PT mới (Cấp STT PT tiếp theo)")
                }
            }
        }
    }

    if (selectedMember != null || isCreatingNew) {
        val existing = selectedMember
        // Kiểm tra có hợp đồng PT đang hiệu lực hay không (tối đa 1 HĐ PT hiệu lực tại 1 thời điểm)
        val activePtContract = remember(existing, appState.activeContracts) {
            existing?.let { mem ->
                appState.activeContracts.firstOrNull {
                    it.memberId == mem.id &&
                        it.serviceType == "PT" &&
                        it.ptStatus == "ACTIVE" &&
                        it.usedSessions < it.totalSessions
                }
            }
        }

        if (activePtContract != null) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(32.dp)
                    )
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Không thể tạo hợp đồng PT song song!",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                        Text(
                            text = "Hội viên STT${existing?.stt} đang có hợp đồng ${activePtContract.contractCode} còn hiệu lực (Đã tập ${activePtContract.usedSessions}/${activePtContract.totalSessions} buổi, còn lại ${activePtContract.remainingSessions} buổi). Chỉ khi tập hết số buổi của gói hiện tại mới được tạo hợp đồng PT gia hạn mới.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
            }
            return
        }

        val previewStt = existing?.stt ?: (appState.config.lastPtStt + 1L)
        val previewSeq = existing?.nextContractSeq ?: 1L
        val previewCode = FitnessCalculator.buildContractCode("PT", previewStt, previewSeq)

        var fullName by remember(existing, searchQuery) { mutableStateOf(existing?.fullName ?: searchQuery.trim()) }
        var phone by remember(existing) { mutableStateOf(existing?.phone ?: "") }
        var sessionsText by remember { mutableStateOf("20") }
        var packageValueText by remember { mutableStateOf("3000000") }
        var paidAmountText by remember { mutableStateOf("3000000") }
        var startDate by remember { mutableStateOf(FitnessCalculator.todayIso()) }
        var paymentMethod by remember { mutableStateOf(PaymentMethod.TRANSFER.code) }
        var cashText by remember { mutableStateOf("0") }
        var transferText by remember { mutableStateOf("3000000") }
        var showReview by remember { mutableStateOf(false) }

        val totalSessions = sessionsText.toLongOrNull() ?: 0L
        val pkgVal = packageValueText.toLongOrNull() ?: 0L
        val paidVal = paidAmountText.toLongOrNull() ?: 0L
        val cashVal = cashText.toLongOrNull() ?: 0L
        val transferVal = transferText.toLongOrNull() ?: 0L

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.5.dp, accentColor)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = if (existing != null) "BƯỚC 2: GIA HẠN HỢP ĐỒNG PT (GIỮ STT$previewStt)"
                    else "BƯỚC 2: HỒ SƠ PT MỚI (STT$previewStt) & HỢP ĐỒNG PT",
                    style = MaterialTheme.typography.titleSmall,
                    color = accentColor,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = "Mã hợp đồng PT: $previewCode (Không có ngày hết hạn cố định theo tháng)",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold
                )

                if (existing == null) {
                    OutlinedTextField(
                        value = fullName,
                        onValueChange = { fullName = it },
                        label = { Text("Họ và tên hội viên PT *") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("Số điện thoại") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = sessionsText,
                        onValueChange = { sessionsText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Số buổi gói PT *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    DatePickerField(
                        label = "Ngày đăng ký",
                        isoDate = startDate,
                        onDateSelected = { startDate = it },
                        modifier = Modifier.weight(1f),
                        accentColor = accentColor
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = packageValueText,
                        onValueChange = {
                            val clean = it.filter { ch -> ch.isDigit() }
                            packageValueText = clean
                            paidAmountText = clean
                        },
                        label = { Text("Giá trị gói PT (VND)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = paidAmountText,
                        onValueChange = { paidAmountText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Số tiền TT (VND)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                if (totalSessions > 0L && pkgVal > 0L) {
                    val perSession = pkgVal / totalSessions
                    val gymSharePerSession = perSession / 2
                    Text(
                        text = "Đơn giá 1 buổi: ${FitnessCalculator.formatCurrency(perSession)} • Phần phòng tập (50%): ${FitnessCalculator.formatCurrency(gymSharePerSession)}/buổi",
                        style = MaterialTheme.typography.bodySmall,
                        color = accentColor,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                PaymentMethodSelectorSection(
                    paidAmount = paidVal,
                    selectedMethod = paymentMethod,
                    onMethodChange = { paymentMethod = it },
                    cashAmountText = cashText,
                    onCashAmountChange = { cashText = it },
                    transferAmountText = transferText,
                    onTransferAmountChange = { transferText = it },
                    accentColor = accentColor
                )

                val isValid = fullName.isNotBlank() &&
                    totalSessions > 0L &&
                    pkgVal > 0L &&
                    (paymentMethod != "COMBINED" || (cashVal + transferVal == paidVal))

                Button(
                    onClick = { showReview = true },
                    enabled = isValid,
                    colors = ButtonDefaults.buttonColors(containerColor = accentColor, contentColor = Color.White),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Xem lại & Xác nhận hợp đồng PT")
                }
            }
        }

        if (showReview) {
            ReviewAndConfirmDialog(
                title = "Xác nhận lưu HĐ PT $previewCode",
                summaryItems = buildList {
                    add("Mã hợp đồng" to previewCode)
                    add("Hội viên PT" to "STT$previewStt — ${fullName.trim()}")
                    add("Số điện thoại" to phone.trim().ifBlank { "Không có" })
                    add("Tổng số buổi gói" to "$totalSessions buổi (Không hạn tháng cố định)")
                    add("Ngày đăng ký" to FitnessCalculator.formatDisplayDate(startDate))
                    add("Giá trị gói PT" to FitnessCalculator.formatCurrency(pkgVal))
                    add("Số tiền thanh toán" to FitnessCalculator.formatCurrency(paidVal))
                    add("Phương thức TT" to PaymentMethod.fromCode(paymentMethod).label)
                },
                accentColor = accentColor,
                onConfirm = {
                    showReview = false
                    val finalCash = when (paymentMethod) {
                        "CASH" -> paidVal
                        "COMBINED" -> cashVal
                        else -> 0L
                    }
                    val finalTransfer = when (paymentMethod) {
                        "TRANSFER" -> paidVal
                        "COMBINED" -> transferVal
                        else -> 0L
                    }
                    if (existing != null) {
                        viewModel.createRenewalContract(
                            member = existing,
                            memberGroup = "NONE",
                            durationMonths = 0L,
                            startDate = startDate,
                            endDate = "",
                            totalSessions = totalSessions,
                            packageValue = pkgVal,
                            paidAmount = paidVal,
                            paymentMethod = paymentMethod,
                            cashAmount = finalCash,
                            transferAmount = finalTransfer,
                            paymentDate = startDate,
                            onSuccess = { onFinish() }
                        )
                    } else {
                        viewModel.createNewMemberAndContract(
                            serviceType = "PT",
                            fullName = fullName,
                            phone = phone,
                            memberGroup = "NONE",
                            durationMonths = 0L,
                            startDate = startDate,
                            endDate = "",
                            totalSessions = totalSessions,
                            packageValue = pkgVal,
                            paidAmount = paidVal,
                            paymentMethod = paymentMethod,
                            cashAmount = finalCash,
                            transferAmount = finalTransfer,
                            paymentDate = startDate,
                            onSuccess = { _, _ -> onFinish() }
                        )
                    }
                },
                onDismiss = { showReview = false }
            )
        }
    }
}

@Composable
private fun SingleTicketCreationFlow(
    accentColor: Color,
    appState: FitnessAppState,
    viewModel: FitnessViewModel,
    onFinish: () -> Unit
) {
    var ticketType by remember { mutableStateOf(SingleTicketType.DAILY.code) }
    var saleDate by remember { mutableStateOf(FitnessCalculator.todayIso()) }
    var quantity by remember { mutableLongStateOf(1L) }
    var unitPriceText by remember { mutableStateOf(appState.config.singleDailyPrice.toString()) }
    var paymentMethod by remember { mutableStateOf(PaymentMethod.TRANSFER.code) }
    var cashText by remember { mutableStateOf("0") }
    var transferText by remember { mutableStateOf(appState.config.singleDailyPrice.toString()) }
    var showReview by remember { mutableStateOf(false) }

    LaunchedEffect(ticketType) {
        val suggested = if (ticketType == SingleTicketType.WEEKLY.code) {
            appState.config.singleWeeklyPrice
        } else {
            appState.config.singleDailyPrice
        }
        unitPriceText = suggested.toString()
    }

    val unitPrice = unitPriceText.toLongOrNull() ?: 0L
    val totalAmount = quantity * unitPrice
    val cashVal = cashText.toLongOrNull() ?: 0L
    val transferVal = transferText.toLongOrNull() ?: 0L

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.5.dp, accentColor)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(
                text = "BÁN VÉ LẺ (KHÔNG TẠO HỒ SƠ / STT KHÁCH HÀNG)",
                style = MaterialTheme.typography.titleSmall,
                color = accentColor,
                fontWeight = FontWeight.Bold
            )

            // Chọn vé ngày / vé tuần
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                SingleTicketType.entries.forEach { t ->
                    FilterChip(
                        selected = ticketType == t.code,
                        onClick = { ticketType = t.code },
                        label = { Text(t.label) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = accentColor,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Ngày bán (Date Picker)
            DatePickerField(
                label = "Ngày bán",
                isoDate = saleDate,
                onDateSelected = { saleDate = it },
                accentColor = accentColor
            )

            // Số lượng mặc định 1 với nút +/-
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Số lượng vé:", style = MaterialTheme.typography.titleMedium)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = { if (quantity > 1L) quantity-- },
                        modifier = Modifier.testTag("ticket_minus_button")
                    ) {
                        Icon(Icons.Default.Remove, contentDescription = "Giảm số lượng")
                    }
                    Text(
                        text = quantity.toString(),
                        style = MaterialTheme.typography.headlineMedium,
                        color = accentColor
                    )
                    OutlinedButton(
                        onClick = { quantity++ },
                        modifier = Modifier.testTag("ticket_plus_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Tăng số lượng")
                    }
                }
            }

            // Đơn giá
            OutlinedTextField(
                value = unitPriceText,
                onValueChange = { unitPriceText = it.filter { ch -> ch.isDigit() } },
                label = { Text("Đơn giá (VND)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            // Tổng tự tính = số lượng × đơn giá
            Surface(
                color = accentColor.copy(alpha = 0.12f),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Tổng thành tiền ($quantity × ${FitnessCalculator.formatCurrency(unitPrice)}):", style = MaterialTheme.typography.bodyMedium)
                    Text(
                        text = FitnessCalculator.formatCurrency(totalAmount),
                        style = MaterialTheme.typography.titleLarge,
                        color = accentColor,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            PaymentMethodSelectorSection(
                paidAmount = totalAmount,
                selectedMethod = paymentMethod,
                onMethodChange = { paymentMethod = it },
                cashAmountText = cashText,
                onCashAmountChange = { cashText = it },
                transferAmountText = transferText,
                onTransferAmountChange = { transferText = it },
                accentColor = accentColor
            )

            val isValid = quantity >= 1L &&
                unitPrice > 0L &&
                (paymentMethod != "COMBINED" || (cashVal + transferVal == totalAmount))

            Button(
                onClick = { showReview = true },
                enabled = isValid,
                colors = ButtonDefaults.buttonColors(containerColor = accentColor, contentColor = Color.White),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("save_single_ticket_button"),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.CheckCircle, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Xem lại & Lưu vé lẻ")
            }
        }
    }

    if (showReview) {
        ReviewAndConfirmDialog(
            title = "Xác nhận lưu giao dịch Vé lẻ",
            summaryItems = listOf(
                "Loại vé" to SingleTicketType.fromCode(ticketType).label,
                "Ngày bán" to FitnessCalculator.formatDisplayDate(saleDate),
                "Số lượng" to "$quantity vé",
                "Đơn giá" to FitnessCalculator.formatCurrency(unitPrice),
                "Tổng tiền" to FitnessCalculator.formatCurrency(totalAmount),
                "Phương thức TT" to PaymentMethod.fromCode(paymentMethod).label
            ),
            accentColor = accentColor,
            onConfirm = {
                showReview = false
                val finalCash = when (paymentMethod) {
                    "CASH" -> totalAmount
                    "COMBINED" -> cashVal
                    else -> 0L
                }
                val finalTransfer = when (paymentMethod) {
                    "TRANSFER" -> totalAmount
                    "COMBINED" -> transferVal
                    else -> 0L
                }
                viewModel.createSingleTicket(
                    ticketType = ticketType,
                    saleDate = saleDate,
                    quantity = quantity,
                    unitPrice = unitPrice,
                    paymentMethod = paymentMethod,
                    cashAmount = finalCash,
                    transferAmount = finalTransfer,
                    onSuccess = { onFinish() }
                )
            },
            onDismiss = { showReview = false }
        )
    }
}
