package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Autorenew
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TableView
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.ContractRecord
import com.example.data.model.MemberGroup
import com.example.data.model.MemberProfile
import com.example.data.model.PaymentMethod
import com.example.data.model.StudioConfig
import com.example.domain.FitnessCalculator
import com.example.domain.MemberCardSummary
import com.example.domain.MemberExpiryState
import com.example.domain.ReportExporter
import com.example.ui.components.ConfirmDeleteDialog
import com.example.ui.components.DatePickerField
import com.example.ui.components.PaymentMethodSelectorSection
import com.example.ui.components.ReviewAndConfirmDialog
import com.example.ui.components.ScreenHeaderBar
import com.example.ui.theme.GymGreenBright
import com.example.ui.theme.StatusActiveGreen
import com.example.ui.theme.StatusExpiredRed
import com.example.ui.theme.YogaPurpleBright
import com.example.ui.viewmodel.FitnessAppState
import com.example.ui.viewmodel.FitnessViewModel

enum class MemberSortOption(val label: String) {
    STT_ASC("STT tăng dần"),
    STT_DESC("STT giảm dần"),
    NAME_ASC("Tên A–Z"),
    NAME_DESC("Tên Z–A"),
    REG_NEWEST("Ngày ĐK mới nhất"),
    REG_OLDEST("Ngày ĐK cũ nhất"),
    EXP_NEAREST("Ngày hết hạn gần nhất"),
    EXP_FARTHEST("Ngày hết hạn xa nhất"),
    ACTIVE_FIRST("Còn hạn trước"),
    EXPIRED_FIRST("Hết hạn trước")
}

enum class ExpiryFilterOption(val label: String) {
    ALL("Tất cả"),
    ACTIVE("Còn hạn"),
    EXPIRED("Hết hạn"),
    EXPIRED_TODAY("Hết hạn hôm nay"),
    EXPIRING_SOON("Sắp hết hạn (7 ngày)")
}

enum class RegDateFilterOption(val label: String) {
    ALL("Tất cả"),
    TODAY("Hôm nay"),
    LAST_7_DAYS("7 ngày gần nhất"),
    LAST_30_DAYS("30 ngày gần nhất"),
    THIS_MONTH("Tháng này"),
    CUSTOM_RANGE("Tùy chọn")
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun GymYogaMemberScreen(
    serviceType: String, // "GYM" or "YOGA"
    appState: FitnessAppState,
    viewModel: FitnessViewModel,
    onBack: () -> Unit,
    onNavigateToCreateOrRenew: (MemberProfile?) -> Unit
) {
    val isYoga = serviceType == "YOGA"
    val accentColor = if (isYoga) YogaPurpleBright else GymGreenBright
    val context = LocalContext.current

    var selectedMemberId by remember { mutableStateOf<String?>(null) }
    var searchQuery by remember { mutableStateOf("") }
    var showOptionsPanel by remember { mutableStateOf(false) }

    // 5 Nhóm tùy chọn (YOGA chỉ có 4 nhóm — không có lọc nhóm nam/nữ/trẻ em)
    var sortOption by remember { mutableStateOf(MemberSortOption.STT_ASC) }
    var expiryFilter by remember { mutableStateOf(ExpiryFilterOption.ALL) }
    var groupFilter by remember { mutableStateOf("ALL") } // ALL, NAM, NU, TRE_EM
    var regDateFilter by remember { mutableStateOf(RegDateFilterOption.ALL) }
    var customStartDate by remember { mutableStateOf(FitnessCalculator.todayIso()) }
    var customEndDate by remember { mutableStateOf(FitnessCalculator.todayIso()) }

    // Tùy chọn hiển thị
    var showPhoneOnCard by remember { mutableStateOf(true) }
    var compactCardMode by remember { mutableStateOf(false) }

    val rawMembers = if (isYoga) appState.activeYogaMembers else appState.activeGymMembers
    val todayIso = FitnessCalculator.todayIso()
    val todayEpoch = FitnessCalculator.toEpochDay(todayIso) ?: 0L
    val (currentYear, currentMonth) = FitnessCalculator.currentYearMonth()
    val currentMonthPrefix = String.format("%04d-%02d-", currentYear, currentMonth)

    val allCardSummaries: List<MemberCardSummary> = remember(rawMembers, appState.activeContracts, todayIso) {
        rawMembers.map { m ->
            val memberContracts = appState.activeContracts.filter { it.memberId == m.id && it.serviceType == serviceType }
            FitnessCalculator.evaluateMemberCardSummary(m, memberContracts, todayIso)
        }
    }

    val filteredAndSortedCards = remember(
        allCardSummaries,
        searchQuery,
        sortOption,
        expiryFilter,
        groupFilter,
        regDateFilter,
        customStartDate,
        customEndDate
    ) {
        allCardSummaries
            .filter { card ->
                FitnessCalculator.matchesMemberSearchQuery(card.member, searchQuery)
            }
            .filter { card ->
                when (expiryFilter) {
                    ExpiryFilterOption.ALL -> true
                    ExpiryFilterOption.ACTIVE -> card.isActive
                    ExpiryFilterOption.EXPIRED -> card.expiryState == MemberExpiryState.EXPIRED || card.expiryState == MemberExpiryState.EXPIRED_TODAY
                    ExpiryFilterOption.EXPIRED_TODAY -> card.expiryState == MemberExpiryState.EXPIRED_TODAY
                    ExpiryFilterOption.EXPIRING_SOON -> card.expiryState == MemberExpiryState.EXPIRING_SOON_7_DAYS
                }
            }
            .filter { card ->
                if (isYoga || groupFilter == "ALL") true
                else card.member.memberGroup == groupFilter
            }
            .filter { card ->
                val regDate = card.latestContract?.startDate ?: ""
                val regEpoch = FitnessCalculator.toEpochDay(regDate)
                when (regDateFilter) {
                    RegDateFilterOption.ALL -> true
                    RegDateFilterOption.TODAY -> regDate == todayIso
                    RegDateFilterOption.LAST_7_DAYS -> regEpoch != null && (todayEpoch - regEpoch) in 0..6
                    RegDateFilterOption.LAST_30_DAYS -> regEpoch != null && (todayEpoch - regEpoch) in 0..29
                    RegDateFilterOption.THIS_MONTH -> regDate.startsWith(currentMonthPrefix)
                    RegDateFilterOption.CUSTOM_RANGE -> {
                        val sEpoch = FitnessCalculator.toEpochDay(customStartDate) ?: Long.MIN_VALUE
                        val eEpoch = FitnessCalculator.toEpochDay(customEndDate) ?: Long.MAX_VALUE
                        regEpoch != null && regEpoch in sEpoch..eEpoch
                    }
                }
            }
            .let { list ->
                when (sortOption) {
                    MemberSortOption.STT_ASC -> list.sortedBy { it.member.stt }
                    MemberSortOption.STT_DESC -> list.sortedByDescending { it.member.stt }
                    MemberSortOption.NAME_ASC -> list.sortedBy { it.member.fullName.lowercase() }
                    MemberSortOption.NAME_DESC -> list.sortedByDescending { it.member.fullName.lowercase() }
                    MemberSortOption.REG_NEWEST -> list.sortedByDescending { it.latestContract?.startDate ?: "" }
                    MemberSortOption.REG_OLDEST -> list.sortedBy { it.latestContract?.startDate ?: "9999-99-99" }
                    MemberSortOption.EXP_NEAREST -> list.sortedBy { it.latestContract?.endDate ?: "9999-99-99" }
                    MemberSortOption.EXP_FARTHEST -> list.sortedByDescending { it.latestContract?.endDate ?: "" }
                    MemberSortOption.ACTIVE_FIRST -> list.sortedWith(
                        compareByDescending<MemberCardSummary> { it.isActive }.thenBy { it.member.stt }
                    )
                    MemberSortOption.EXPIRED_FIRST -> list.sortedWith(
                        compareBy<MemberCardSummary> { it.isActive }.thenBy { it.member.stt }
                    )
                }
            }
    }

    val selectedCard = allCardSummaries.firstOrNull { it.member.id == selectedMemberId }

    BackHandler {
        if (selectedMemberId != null) {
            selectedMemberId = null
        } else {
            onBack()
        }
    }

    if (selectedCard != null) {
        MemberDetailSubScreen(
            cardSummary = selectedCard,
            serviceType = serviceType,
            accentColor = accentColor,
            config = appState.config,
            viewModel = viewModel,
            onBack = { selectedMemberId = null },
            onRenew = { onNavigateToCreateOrRenew(selectedCard.member) }
        )
        return
    }

    Scaffold(
        topBar = {
            ScreenHeaderBar(
                title = serviceType,
                subtitle = "Hồ sơ: ${rawMembers.size} • Hiển thị: ${filteredAndSortedCards.size}",
                accentColor = accentColor,
                onBack = onBack,
                actions = {
                    IconButton(
                        onClick = {
                            val file = ReportExporter.exportMembersToXlsx(context, serviceType, filteredAndSortedCards)
                            ReportExporter.shareFile(context, file, ReportExporter.XLSX_MIME_TYPE, "Xuất Excel danh sách $serviceType")
                        },
                        modifier = Modifier.testTag("export_excel_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.TableView,
                            contentDescription = "Xuất Excel",
                            tint = Color.White
                        )
                    }
                    IconButton(
                        onClick = {
                            val file = ReportExporter.exportMembersToPdf(context, serviceType, filteredAndSortedCards)
                            ReportExporter.shareFile(context, file, "application/pdf", "Xuất PDF danh sách $serviceType")
                        },
                        modifier = Modifier.testTag("export_pdf_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PictureAsPdf,
                            contentDescription = "Xuất PDF",
                            tint = Color.White
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { onNavigateToCreateOrRenew(null) },
                containerColor = accentColor,
                contentColor = Color.White,
                modifier = Modifier.testTag("add_member_fab")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Thêm hội viên $serviceType")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Thanh tìm kiếm 1 dòng + nút mở tùy chọn lọc/sắp xếp
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 2.dp
            ) {
                Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Tìm STT / Họ tên / SĐT...") },
                            leadingIcon = {
                                Icon(imageVector = Icons.Default.Search, contentDescription = null)
                            },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { searchQuery = "" }) {
                                        Icon(imageVector = Icons.Default.Clear, contentDescription = "Xóa tìm kiếm")
                                    }
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("member_search_input")
                        )

                        OutlinedButton(
                            onClick = { showOptionsPanel = !showOptionsPanel },
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 12.dp),
                            modifier = Modifier.testTag("toggle_options_button")
                        ) {
                            Icon(
                                imageVector = if (showOptionsPanel) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = "Mở tùy chọn lọc và sắp xếp",
                                tint = accentColor
                            )
                        }
                    }

                    val searchModeLabel = FitnessCalculator.memberSearchModeLabel(searchQuery)
                    if (searchModeLabel.isNotEmpty()) {
                        Text(
                            text = "$searchModeLabel • Kết quả: ${filteredAndSortedCards.size}",
                            style = MaterialTheme.typography.labelSmall,
                            color = accentColor,
                            modifier = Modifier.padding(top = 4.dp, start = 4.dp)
                        )
                    }

                    // Bảng tùy chọn lọc và sắp xếp
                    AnimatedVisibility(visible = showOptionsPanel) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp)
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            HorizontalDivider()

                            Text(
                                text = "Sắp xếp",
                                style = MaterialTheme.typography.labelLarge,
                                color = accentColor
                            )
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                MemberSortOption.entries.forEach { opt ->
                                    FilterChip(
                                        selected = sortOption == opt,
                                        onClick = { sortOption = opt },
                                        label = { Text(opt.label) }
                                    )
                                }
                            }

                            Text(
                                text = "Thời hạn",
                                style = MaterialTheme.typography.labelLarge,
                                color = accentColor
                            )
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                ExpiryFilterOption.entries.forEach { opt ->
                                    FilterChip(
                                        selected = expiryFilter == opt,
                                        onClick = { expiryFilter = opt },
                                        label = { Text(opt.label) }
                                    )
                                }
                            }

                            if (!isYoga) {
                                Text(
                                    text = "Nhóm hội viên",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = accentColor
                                )
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    listOf(
                                        "ALL" to "Tất cả",
                                        "NAM" to "Nam",
                                        "NU" to "Nữ",
                                        "TRE_EM" to "Trẻ em"
                                    ).forEach { (code, label) ->
                                        FilterChip(
                                            selected = groupFilter == code,
                                            onClick = { groupFilter = code },
                                            label = { Text(label) }
                                        )
                                    }
                                }
                            }

                            Text(
                                text = "Ngày đăng ký",
                                style = MaterialTheme.typography.labelLarge,
                                color = accentColor
                            )
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                RegDateFilterOption.entries.forEach { opt ->
                                    FilterChip(
                                        selected = regDateFilter == opt,
                                        onClick = { regDateFilter = opt },
                                        label = { Text(opt.label) }
                                    )
                                }
                            }
                            if (regDateFilter == RegDateFilterOption.CUSTOM_RANGE) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    DatePickerField(
                                        label = "Từ ngày",
                                        isoDate = customStartDate,
                                        onDateSelected = { customStartDate = it },
                                        modifier = Modifier.weight(1f),
                                        accentColor = accentColor
                                    )
                                    DatePickerField(
                                        label = "Đến ngày",
                                        isoDate = customEndDate,
                                        onDateSelected = { customEndDate = it },
                                        modifier = Modifier.weight(1f),
                                        accentColor = accentColor
                                    )
                                }
                            }

                            Text(
                                text = "Hiển thị",
                                style = MaterialTheme.typography.labelLarge,
                                color = accentColor
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Hiện số điện thoại", style = MaterialTheme.typography.bodyMedium)
                                Switch(checked = showPhoneOnCard, onCheckedChange = { showPhoneOnCard = it })
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Thẻ thu gọn", style = MaterialTheme.typography.bodyMedium)
                                Switch(checked = compactCardMode, onCheckedChange = { compactCardMode = it })
                            }
                        }
                    }
                }
            }

            if (filteredAndSortedCards.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = accentColor.copy(alpha = 0.5f),
                            modifier = Modifier.size(44.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (searchQuery.isNotBlank()) {
                                "Không tìm thấy hội viên phù hợp"
                            } else {
                                "Chưa có hồ sơ $serviceType"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(filteredAndSortedCards, key = { it.member.id }) { card ->
                        MemberSummaryCard(
                            card = card,
                            accentColor = accentColor,
                            showPhone = showPhoneOnCard,
                            compactMode = compactCardMode,
                            onClick = { selectedMemberId = card.member.id },
                            onRenewClick = { onNavigateToCreateOrRenew(card.member) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun MemberSummaryCard(
    card: MemberCardSummary,
    accentColor: Color,
    showPhone: Boolean = true,
    compactMode: Boolean = false,
    onClick: () -> Unit,
    onRenewClick: () -> Unit
) {
    val statusColor = if (card.isActive) StatusActiveGreen else StatusExpiredRed
    val statusText = when {
        card.daysRemainingOrOverdue > 0 -> "Còn ${card.daysRemainingOrOverdue} ngày"
        card.daysRemainingOrOverdue == 0 -> "Hết hạn hôm nay"
        else -> "Hết hạn ${-card.daysRemainingOrOverdue} ngày"
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("member_card_${card.member.stt}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        border = BorderStroke(1.2.dp, statusColor.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = if (compactMode) 8.dp else 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Text(
                    text = "STT${card.member.stt} — ${card.member.fullName}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    softWrap = true,
                    maxLines = Int.MAX_VALUE
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (showPhone && card.member.phone.isNotBlank()) {
                        Text(
                            text = "SĐT: ${card.member.phone}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Surface(
                        color = statusColor.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, statusColor.copy(alpha = 0.35f))
                    ) {
                        Text(
                            text = statusText,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = statusColor,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            Button(
                onClick = onRenewClick,
                colors = ButtonDefaults.buttonColors(
                    containerColor = accentColor,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                modifier = Modifier.testTag("renew_button_${card.member.stt}")
            ) {
                Icon(
                    imageVector = Icons.Default.Autorenew,
                    contentDescription = null,
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text("Gia hạn", style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}

@Composable
private fun MemberDetailSubScreen(
    cardSummary: MemberCardSummary,
    serviceType: String,
    accentColor: Color,
    config: StudioConfig,
    viewModel: FitnessViewModel,
    onBack: () -> Unit,
    onRenew: () -> Unit
) {
    val member = cardSummary.member
    var showEditMemberDialog by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var selectedHistoricalContract by remember { mutableStateOf<ContractRecord?>(null) }
    var contractToEdit by remember { mutableStateOf<ContractRecord?>(null) }

    Scaffold(
        topBar = {
            ScreenHeaderBar(
                title = "STT${member.stt} — ${member.fullName}",
                accentColor = accentColor,
                onBack = onBack,
                actions = {
                    IconButton(onClick = { showEditMemberDialog = true }) {
                        Icon(imageVector = Icons.Default.Edit, contentDescription = "Sửa hồ sơ", tint = Color.White)
                    }
                    IconButton(onClick = { showDeleteConfirm = true }) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Xóa hồ sơ", tint = Color.White)
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // 1. Thông tin cá nhân
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "THÔNG TIN HỘI VIÊN",
                                style = MaterialTheme.typography.titleSmall,
                                color = accentColor,
                                fontWeight = FontWeight.Bold
                            )
                            TextButton(onClick = { showEditMemberDialog = true }) {
                                Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Sửa")
                            }
                        }
                        HorizontalDivider()
                        DetailRow("STT:", "STT${member.stt} ($serviceType)")
                        DetailRow("Họ và tên:", member.fullName)
                        DetailRow("Số điện thoại:", member.phone.ifBlank { "Chưa cập nhật" })
                        if (serviceType == "GYM") {
                            DetailRow("Nhóm hội viên:", MemberGroup.fromCode(member.memberGroup).label)
                        }
                        DetailRow("Tổng hợp đồng:", "${cardSummary.allContracts.size} hợp đồng")
                    }
                }
            }

            // 2. Hợp đồng hiện tại
            item {
                val current = cardSummary.latestContract
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.2.dp, accentColor.copy(alpha = 0.45f))
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "HỢP ĐỒNG HIỆN TẠI",
                                style = MaterialTheme.typography.titleSmall,
                                color = accentColor,
                                fontWeight = FontWeight.Bold
                            )
                            Button(
                                onClick = onRenew,
                                colors = ButtonDefaults.buttonColors(containerColor = accentColor, contentColor = Color.White),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.Autorenew, contentDescription = null, modifier = Modifier.size(15.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Gia hạn")
                            }
                        }
                        HorizontalDivider()
                        if (current == null) {
                            Text("Chưa có hợp đồng hiện tại.", style = MaterialTheme.typography.bodyMedium)
                        } else {
                            DetailRow("Mã hợp đồng:", current.contractCode)
                            DetailRow("Loại hợp đồng:", if (current.isRenewal) "Gia hạn" else "Đăng ký mới")
                            DetailRow("Gói thời hạn:", "${current.durationMonths} tháng")
                            DetailRow("Ngày đăng ký:", FitnessCalculator.formatDisplayDate(current.startDate))
                            DetailRow("Ngày hết hạn:", FitnessCalculator.formatDisplayDate(current.endDate))
                            DetailRow("Giá trị gói:", FitnessCalculator.formatCurrency(current.packageValue))
                            DetailRow("Thanh toán:", FitnessCalculator.formatCurrency(current.paidAmount))
                            DetailRow("Phương thức TT:", PaymentMethod.fromCode(current.paymentMethod).label)
                            if (current.paymentMethod == "COMBINED") {
                                DetailRow("• Tiền mặt:", FitnessCalculator.formatCurrency(current.cashAmount))
                                DetailRow("• Chuyển khoản:", FitnessCalculator.formatCurrency(current.transferAmount))
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                OutlinedButton(onClick = { selectedHistoricalContract = current }) {
                                    Text("Phân bổ tháng")
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                OutlinedButton(onClick = { contractToEdit = current }) {
                                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("Sửa HĐ")
                                }
                            }
                        }
                    }
                }
            }

            // 3. Lịch sử hợp đồng
            item {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(top = 2.dp)
                ) {
                    Icon(Icons.Default.History, contentDescription = null, tint = accentColor, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = "LỊCH SỬ HỢP ĐỒNG (${cardSummary.allContracts.size})",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            items(cardSummary.allContracts, key = { it.id }) { contract ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedHistoricalContract = contract },
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = contract.contractCode,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = accentColor
                            )
                            Text(
                                text = "Gói ${contract.durationMonths} tháng • ${FitnessCalculator.formatDisplayDate(contract.startDate)} → ${FitnessCalculator.formatDisplayDate(contract.endDate)}",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = FitnessCalculator.formatCurrency(contract.packageValue),
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (contract.isRenewal) "Gia hạn" else "Đăng ký mới",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }

    if (selectedHistoricalContract != null) {
        ContractHistoryDetailDialog(
            contract = selectedHistoricalContract!!,
            accentColor = accentColor,
            onDismiss = { selectedHistoricalContract = null },
            onEditContract = { c ->
                selectedHistoricalContract = null
                contractToEdit = c
            },
            onDeleteContract = { c ->
                selectedHistoricalContract = null
                viewModel.softDeleteContract(c)
            }
        )
    }

    if (showEditMemberDialog) {
        EditMemberProfileDialog(
            member = member,
            accentColor = accentColor,
            onDismiss = { showEditMemberDialog = false },
            onConfirmSave = { newName, newPhone, newGroup ->
                viewModel.updateMemberProfile(member, newName, newPhone, newGroup) {
                    showEditMemberDialog = false
                }
            }
        )
    }

    if (contractToEdit != null) {
        EditGymYogaContractDialog(
            contract = contractToEdit!!,
            config = config,
            accentColor = accentColor,
            onDismiss = { contractToEdit = null },
            onConfirmSave = { updated ->
                viewModel.updateContract(updated) {
                    contractToEdit = null
                }
            }
        )
    }

    if (showDeleteConfirm) {
        ConfirmDeleteDialog(
            title = "Xóa hồ sơ STT${member.stt}?",
            message = "Hồ sơ ${member.fullName} cùng các hợp đồng liên quan sẽ được chuyển vào Thùng rác.",
            isPermanent = false,
            onConfirm = {
                showDeleteConfirm = false
                viewModel.softDeleteMember(member) {
                    onBack()
                }
            },
            onDismiss = { showDeleteConfirm = false }
        )
    }
}

@Composable
fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(0.42f)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface,
            softWrap = true,
            modifier = Modifier.weight(0.58f)
        )
    }
}

@Composable
private fun ContractHistoryDetailDialog(
    contract: ContractRecord,
    accentColor: Color,
    onDismiss: () -> Unit,
    onEditContract: (ContractRecord) -> Unit,
    onDeleteContract: (ContractRecord) -> Unit
) {
    var askDelete by remember { mutableStateOf(false) }

    val monthlyBreakdowns = remember(contract) {
        val startTriple = FitnessCalculator.parseIso(contract.startDate)
        val endTriple = FitnessCalculator.parseIso(contract.endDate)
        if (startTriple == null || endTriple == null) {
            emptyList()
        } else {
            val list = mutableListOf<Triple<String, Long, Long>>()
            var ym = startTriple.first * 12 + (startTriple.second - 1)
            val endYm = endTriple.first * 12 + (endTriple.second - 1)
            while (ym <= endYm) {
                val y = ym / 12
                val m = (ym % 12) + 1
                val (allocated, _, overlapDays) = FitnessCalculator.calculateContractAllocatedRevenue(
                    packageValue = contract.packageValue,
                    startDateIso = contract.startDate,
                    endDateIso = contract.endDate,
                    year = y,
                    month = m
                )
                if (overlapDays > 0L) {
                    list.add(Triple(String.format("Tháng %02d/%04d", m, y), overlapDays, allocated))
                }
                ym++
            }
            list
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "HĐ: ${contract.contractCode}",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = accentColor
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                DetailRow("Mã hợp đồng:", contract.contractCode)
                DetailRow("Hội viên:", "STT${contract.memberSttSnapshot} — ${contract.memberNameSnapshot}")
                DetailRow("Số điện thoại:", contract.memberPhoneSnapshot.ifBlank { "Không có" })
                if (contract.serviceType == "GYM") {
                    DetailRow("Nhóm giá:", MemberGroup.fromCode(contract.memberGroup).label)
                }
                DetailRow("Gói đăng ký:", "${contract.durationMonths} tháng (${if (contract.isRenewal) "Gia hạn" else "Đăng ký mới"})")
                DetailRow("Ngày đăng ký:", FitnessCalculator.formatDisplayDate(contract.startDate))
                DetailRow("Ngày hết hạn:", FitnessCalculator.formatDisplayDate(contract.endDate))
                val totalDays = FitnessCalculator.totalValidDaysInclusive(contract.startDate, contract.endDate)
                DetailRow("Tổng ngày hiệu lực:", "$totalDays ngày")
                DetailRow("Giá trị gói:", FitnessCalculator.formatCurrency(contract.packageValue))
                DetailRow("Thanh toán:", FitnessCalculator.formatCurrency(contract.paidAmount))
                DetailRow("Phương thức TT:", PaymentMethod.fromCode(contract.paymentMethod).label)
                if (contract.paymentMethod == "COMBINED") {
                    DetailRow("• Tiền mặt:", FitnessCalculator.formatCurrency(contract.cashAmount))
                    DetailRow("• Chuyển khoản:", FitnessCalculator.formatCurrency(contract.transferAmount))
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Doanh thu phân bổ theo tháng:",
                    style = MaterialTheme.typography.labelLarge,
                    color = accentColor
                )
                HorizontalDivider()
                monthlyBreakdowns.forEach { (monthLabel, overlapDays, allocated) ->
                    DetailRow(
                        "$monthLabel ($overlapDays ngày):",
                        FitnessCalculator.formatCurrency(allocated)
                    )
                }
            }
        },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { onEditContract(contract) }) {
                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Sửa HĐ")
                }
                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = accentColor, contentColor = Color.White)
                ) {
                    Text("Đóng")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = { askDelete = true }) {
                Text("Xóa vào Thùng rác", color = MaterialTheme.colorScheme.error)
            }
        }
    )

    if (askDelete) {
        ConfirmDeleteDialog(
            title = "Xóa hợp đồng ${contract.contractCode}?",
            message = "Hợp đồng này sẽ được chuyển vào Thùng rác.",
            isPermanent = false,
            onConfirm = {
                askDelete = false
                onDeleteContract(contract)
            },
            onDismiss = { askDelete = false }
        )
    }
}

@Composable
private fun EditMemberProfileDialog(
    member: MemberProfile,
    accentColor: Color,
    onDismiss: () -> Unit,
    onConfirmSave: (String, String, String) -> Unit
) {
    var fullName by remember { mutableStateOf(member.fullName) }
    var phone by remember { mutableStateOf(member.phone) }
    var group by remember { mutableStateOf(member.memberGroup) }
    var showReview by remember { mutableStateOf(false) }

    if (showReview) {
        ReviewAndConfirmDialog(
            title = "Xác nhận sửa hồ sơ STT${member.stt}",
            summaryItems = buildList {
                add("STT" to "STT${member.stt}")
                add("Họ và tên" to fullName.trim())
                add("Số điện thoại" to phone.trim())
                if (member.type == "GYM") {
                    add("Nhóm hội viên" to MemberGroup.fromCode(group).label)
                }
            },
            accentColor = accentColor,
            onConfirm = {
                showReview = false
                onConfirmSave(fullName, phone, group)
            },
            onDismiss = { showReview = false }
        )
        return
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Sửa hồ sơ STT${member.stt}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = fullName,
                    onValueChange = { fullName = it },
                    label = { Text("Họ và tên đầy đủ") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Số điện thoại") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (member.type == "GYM") {
                    Text("Nhóm hội viên:", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(MemberGroup.NAM, MemberGroup.NU, MemberGroup.TRE_EM).forEach { g ->
                            FilterChip(
                                selected = group == g.code,
                                onClick = { group = g.code },
                                label = { Text(g.label) }
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { if (fullName.isNotBlank()) showReview = true },
                enabled = fullName.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = accentColor, contentColor = Color.White)
            ) {
                Text("Xem lại & Lưu")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Hủy")
            }
        }
    )
}

@Composable
internal fun EditGymYogaContractDialog(
    contract: ContractRecord,
    config: StudioConfig = StudioConfig(),
    accentColor: Color,
    onDismiss: () -> Unit,
    onConfirmSave: (ContractRecord) -> Unit
) {
    val validDurations = remember(contract.serviceType) {
        FitnessCalculator.validDurationsForService(contract.serviceType)
    }
    var durationMonths by remember(contract) {
        mutableIntStateOf(contract.durationMonths.toInt().coerceAtLeast(1))
    }
    var startDate by remember(contract) { mutableStateOf(contract.startDate) }
    var endDate by remember(contract) { mutableStateOf(contract.endDate) }
    var packageValueText by remember(contract) { mutableStateOf(contract.packageValue.toString()) }
    var paidAmountText by remember(contract) { mutableStateOf(contract.paidAmount.toString()) }
    var paymentMethod by remember(contract) { mutableStateOf(contract.paymentMethod) }
    var cashText by remember(contract) { mutableStateOf(contract.cashAmount.toString()) }
    var transferText by remember(contract) { mutableStateOf(contract.transferAmount.toString()) }
    var showReview by remember { mutableStateOf(false) }

    val pkgVal = packageValueText.toLongOrNull() ?: 0L
    val paidVal = paidAmountText.toLongOrNull() ?: 0L
    val cashVal = cashText.toLongOrNull() ?: 0L
    val transferVal = transferText.toLongOrNull() ?: 0L
    val validPayment = paymentMethod != "COMBINED" || (cashVal + transferVal == paidVal)

    if (showReview) {
        ReviewAndConfirmDialog(
            title = "Xác nhận sửa ${contract.contractCode}",
            summaryItems = listOf(
                "Mã hợp đồng" to contract.contractCode,
                "Gói đăng ký cũ" to "${contract.durationMonths} tháng",
                "Gói đăng ký mới" to "$durationMonths tháng",
                "Ngày đăng ký" to FitnessCalculator.formatDisplayDate(startDate),
                "Ngày hết hạn mới" to FitnessCalculator.formatDisplayDate(endDate),
                "Giá trị gói" to FitnessCalculator.formatCurrency(pkgVal),
                "Số tiền thanh toán" to FitnessCalculator.formatCurrency(paidVal),
                "Phương thức TT" to PaymentMethod.fromCode(paymentMethod).label
            ),
            accentColor = accentColor,
            onConfirm = {
                showReview = false
                onConfirmSave(
                    contract.copy(
                        durationMonths = durationMonths.toLong(),
                        startDate = startDate,
                        endDate = endDate,
                        packageValue = pkgVal,
                        paidAmount = paidVal,
                        paymentMethod = paymentMethod,
                        cashAmount = if (paymentMethod == "COMBINED") cashVal else if (paymentMethod == "CASH") paidVal else 0L,
                        transferAmount = if (paymentMethod == "COMBINED") transferVal else if (paymentMethod == "TRANSFER") paidVal else 0L
                    )
                )
            },
            onDismiss = { showReview = false }
        )
        return
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Sửa HĐ ${contract.contractCode}") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Gói đăng ký (${contract.serviceType}):",
                    style = MaterialTheme.typography.labelLarge
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    validDurations.forEach { m ->
                        FilterChip(
                            selected = durationMonths == m,
                            onClick = {
                                durationMonths = m
                                endDate = FitnessCalculator.calculateEndDate(startDate, m)
                                val suggestedPrice = if (contract.serviceType == "YOGA") {
                                    config.getYogaPrice(m)
                                } else {
                                    config.getGymPrice(MemberGroup.fromCode(contract.memberGroup), m)
                                }
                                packageValueText = suggestedPrice.toString()
                                // Giữ nguyên tuyệt đối paidAmountText, cashText, transferText và paymentMethod
                            },
                            label = { Text("$m tháng") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = accentColor,
                                selectedLabelColor = Color.White
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("edit_contract_duration_${m}m")
                        )
                    }
                }
                DatePickerField(
                    label = "Ngày đăng ký",
                    isoDate = startDate,
                    onDateSelected = {
                        startDate = it
                        endDate = FitnessCalculator.calculateEndDate(it, durationMonths)
                    },
                    accentColor = accentColor
                )
                DatePickerField(
                    label = "Ngày hết hạn",
                    isoDate = endDate,
                    onDateSelected = { endDate = it },
                    accentColor = accentColor
                )
                OutlinedTextField(
                    value = packageValueText,
                    onValueChange = { packageValueText = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Giá trị gói (VND)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("edit_contract_package_value")
                )
                OutlinedTextField(
                    value = paidAmountText,
                    onValueChange = { paidAmountText = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Số tiền thanh toán (VND)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("edit_contract_paid_amount")
                )
                PaymentMethodSelectorSection(
                    paidAmount = paidVal,
                    selectedMethod = paymentMethod,
                    onMethodChange = { paymentMethod = it },
                    cashAmountText = cashText,
                    onCashAmountChange = { cashText = it },
                    transferAmountText = transferText,
                    onTransferAmountChange = { transferText = it },
                    accentColor = accentColor
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { showReview = true },
                enabled = validPayment && pkgVal > 0L,
                colors = ButtonDefaults.buttonColors(containerColor = accentColor, contentColor = Color.White),
                modifier = Modifier.testTag("edit_contract_review_button")
            ) {
                Text("Xem lại & Lưu")
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("edit_contract_cancel_button")
            ) {
                Text("Hủy")
            }
        }
    )
}

