package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.preferences.AppPreferencesState
import com.example.ui.AppScreen
import com.example.ui.MemberSummaryUi
import com.example.ui.PtClientSummaryUi
import com.example.ui.theme.*

private data class DashboardModuleCard(
    val id: String,
    val numberLabel: String,
    val title: String,
    val subtitle: String,
    val badgeText: String,
    val icon: ImageVector,
    val accentColor: Color,
    val targetScreen: AppScreen
)

/**
 * Home Dashboard (Section 3):
 * Displays the 7 core modules clearly without crowding their internal content onto one page,
 * plus sync status banner and quick PT access.
 */
@Composable
fun HomeDashboardScreen(
    gymMembers: List<MemberSummaryUi>,
    yogaMembers: List<MemberSummaryUi>,
    ptClients: List<PtClientSummaryUi>,
    trashCount: Int,
    preferences: AppPreferencesState,
    onNavigate: (AppScreen) -> Unit
) {
    val gymValidCount = gymMembers.count { it.isValid }
    val yogaValidCount = yogaMembers.count { it.isValid }
    val gymExpiringCount = gymMembers.count { it.isExpiringSoon }
    val yogaExpiringCount = yogaMembers.count { it.isExpiringSoon }

    val modules = listOf(
        DashboardModuleCard(
            id = "module_gym_list",
            numberLabel = "01",
            title = "Danh sách Gym",
            subtitle = "Hội viên, tìm kiếm & gia hạn nhanh",
            badgeText = "${gymMembers.size} HV • $gymValidCount còn hạn",
            icon = Icons.Default.FitnessCenter,
            accentColor = GymEmeraldLight,
            targetScreen = AppScreen.MemberList(domain = "GYM")
        ),
        DashboardModuleCard(
            id = "module_yoga_list",
            numberLabel = "02",
            title = "Danh sách Yoga",
            subtitle = "Quản lý hội viên Yoga độc lập",
            badgeText = "${yogaMembers.size} HV • $yogaValidCount còn hạn",
            icon = Icons.Default.SelfImprovement,
            accentColor = YogaIndigoLight,
            targetScreen = AppScreen.MemberList(domain = "YOGA")
        ),
        DashboardModuleCard(
            id = "module_create_contract",
            numberLabel = "03",
            title = "Tạo hợp đồng",
            subtitle = "Đăng ký mới, Gia hạn, PT, Vé ngày/tuần",
            badgeText = "Quy trình 4 bước",
            icon = Icons.Default.PostAdd,
            accentColor = Color(0xFF0284C7),
            targetScreen = AppScreen.CreateContract()
        ),
        DashboardModuleCard(
            id = "module_revenue",
            numberLabel = "04",
            title = "Doanh thu",
            subtitle = "Phân bổ theo ngày & Xuất Excel / PDF",
            badgeText = "Gym (5) • Yoga (3)",
            icon = Icons.Default.Assessment,
            accentColor = Color(0xFF059669),
            targetScreen = AppScreen.Revenue()
        ),
        DashboardModuleCard(
            id = "module_tracking",
            numberLabel = "05",
            title = "Theo dõi",
            subtitle = "Tình trạng hội viên & Thu công nợ",
            badgeText = "${gymExpiringCount + yogaExpiringCount} sắp hết hạn",
            icon = Icons.Default.TrackChanges,
            accentColor = StatusWarningAmber,
            targetScreen = AppScreen.Tracking()
        ),
        DashboardModuleCard(
            id = "module_settings",
            numberLabel = "06",
            title = "Cài đặt",
            subtitle = "Bảng giá Gym/Yoga, Giao diện & Google Drive",
            badgeText = if (preferences.isDarkMode) "Dark Mode" else "Light Mode",
            icon = Icons.Default.Settings,
            accentColor = Color(0xFF475569),
            targetScreen = AppScreen.Settings
        ),
        DashboardModuleCard(
            id = "module_trash",
            numberLabel = "07",
            title = "Thùng rác",
            subtitle = "Hợp đồng đã hủy, xóa mềm & khôi phục",
            badgeText = "$trashCount mục đã xóa",
            icon = Icons.Default.RestoreFromTrash,
            accentColor = StatusDangerRed,
            targetScreen = AppScreen.Trash
        )
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Executive Header Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF064E3B),
                            Color(0xFF0F172A)
                        )
                    )
                )
                .padding(horizontal = 20.dp, vertical = 18.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "89 FITNESS & YOGA",
                            style = MaterialTheme.typography.headlineMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Hệ thống quản lý vận hành & tài chính chính xác",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFA7F3D0)
                        )
                    }
                    FilledTonalButton(
                        onClick = { onNavigate(AppScreen.PtManagement) },
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = Color(0xFF10B981).copy(alpha = 0.22f),
                            contentColor = Color(0xFFA7F3D0)
                        ),
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("home_pt_quick_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.SportsKabaddi,
                            contentDescription = "Quản lý PT",
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("PT (${ptClients.size})", style = MaterialTheme.typography.labelLarge)
                    }
                }

                // Sync & Offline-First Status Bar
                Surface(
                    color = Color.White.copy(alpha = 0.1f),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigate(AppScreen.Settings) }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CloudDone,
                                contentDescription = "Trạng thái dữ liệu",
                                tint = Color(0xFF34D399),
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = preferences.lastSyncStatus,
                                style = MaterialTheme.typography.labelMedium,
                                color = Color.White
                            )
                        }
                        Text(
                            text = if (preferences.googleAccountEmail.isBlank()) "Sao lưu Drive →" else preferences.googleAccountEmail,
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFFA7F3D0)
                        )
                    }
                }
            }
        }

        // 7 Core Modules Grid
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 160.dp),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(
                items = modules,
                span = { item ->
                    if (item.id == "module_create_contract" || item.id == "module_trash") {
                        GridItemSpan(maxLineSpan)
                    } else {
                        GridItemSpan(1)
                    }
                }
            ) { module ->
                ElevatedCard(
                    onClick = { onNavigate(module.targetScreen) },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.elevatedCardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag(module.id)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(module.accentColor.copy(alpha = 0.14f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = module.icon,
                                    contentDescription = module.title,
                                    tint = module.accentColor,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = module.numberLabel,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = module.title,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = module.subtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                minLines = 2
                            )
                        }

                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = module.badgeText,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = module.accentColor
                            )
                            Icon(
                                imageVector = Icons.Default.ChevronRight,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
