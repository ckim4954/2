package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.preferences.AppPreferencesState
import com.example.ui.AppScreen
import com.example.ui.MemberSummaryUi
import com.example.ui.PtClientSummaryUi
import com.example.ui.theme.*

private data class CompactHomeTile(
    val id: String,
    val title: String,
    val countBadge: String?,
    val icon: ImageVector,
    val accentColor: Color,
    val targetScreen: AppScreen
)

/**
 * Home Screen (Section 4 of Upgrade PRD):
 * - Menu grid with 3 square tiles per row (GridCells.Fixed(3))
 * - Uniform tile dimensions (aspectRatio(1f))
 * - Easy-to-recognize icons & short function names
 * - No large banner, no long descriptive paragraphs
 * - Direct navigation to each module
 */
@Composable
fun HomeDashboardScreen(
    gymMembers: List<MemberSummaryUi>,
    yogaMembers: List<MemberSummaryUi>,
    ptClients: List<PtClientSummaryUi>,
    trashCount: Int,
    preferences: AppPreferencesState,
    onNavigate: (AppScreen) -> Unit
) {
    val tiles = listOf(
        CompactHomeTile(
            id = "module_gym_list",
            title = "Gym",
            countBadge = "${gymMembers.size}",
            icon = Icons.Default.FitnessCenter,
            accentColor = GymEmeraldLight,
            targetScreen = AppScreen.MemberList(domain = "GYM")
        ),
        CompactHomeTile(
            id = "module_yoga_list",
            title = "Yoga",
            countBadge = "${yogaMembers.size}",
            icon = Icons.Default.SelfImprovement,
            accentColor = YogaIndigoLight,
            targetScreen = AppScreen.MemberList(domain = "YOGA")
        ),
        CompactHomeTile(
            id = "module_create_contract",
            title = "Tạo HĐ",
            countBadge = null,
            icon = Icons.Default.PostAdd,
            accentColor = Color(0xFF0284C7),
            targetScreen = AppScreen.CreateContract()
        ),
        CompactHomeTile(
            id = "module_revenue",
            title = "Doanh thu",
            countBadge = null,
            icon = Icons.Default.Assessment,
            accentColor = Color(0xFF059669),
            targetScreen = AppScreen.Revenue(initialSubScreen = 0)
        ),
        CompactHomeTile(
            id = "module_tracking",
            title = "Theo dõi",
            countBadge = null,
            icon = Icons.Default.TrackChanges,
            accentColor = StatusWarningAmber,
            targetScreen = AppScreen.Tracking()
        ),
        CompactHomeTile(
            id = "module_pt",
            title = "Quản lý PT",
            countBadge = "${ptClients.size}",
            icon = Icons.Default.SportsKabaddi,
            accentColor = PtTealLight,
            targetScreen = AppScreen.PtManagement
        ),
        CompactHomeTile(
            id = "module_settings",
            title = "Cài đặt",
            countBadge = null,
            icon = Icons.Default.Settings,
            accentColor = Color(0xFF475569),
            targetScreen = AppScreen.Settings
        ),
        CompactHomeTile(
            id = "module_trash",
            title = "Thùng rác",
            countBadge = if (trashCount > 0) "$trashCount" else null,
            icon = Icons.Default.RestoreFromTrash,
            accentColor = StatusDangerRed,
            targetScreen = AppScreen.Trash
        )
    )

    Scaffold(
        topBar = {
            FitnessTopAppBar(
                title = "89 FITNESS & YOGA"
            )
        }
    ) { innerPadding ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            contentPadding = PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            items(tiles, key = { it.id }) { tile ->
                ElevatedCard(
                    onClick = { onNavigate(tile.targetScreen) },
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.elevatedCardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1f)
                        .testTag(tile.id)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(10.dp)
                    ) {
                        if (!tile.countBadge.isNullOrBlank()) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(tile.accentColor.copy(alpha = 0.15f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = tile.countBadge,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = tile.accentColor
                                )
                            }
                        }

                        Column(
                            modifier = Modifier.align(Alignment.Center),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(tile.accentColor.copy(alpha = 0.14f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = tile.icon,
                                    contentDescription = tile.title,
                                    tint = tile.accentColor,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            Text(
                                text = tile.title,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                textAlign = TextAlign.Center,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}
