package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SportsGymnastics
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.theme.GymGreenBright
import com.example.ui.theme.PriceNamGreen
import com.example.ui.theme.PriceNuPink
import com.example.ui.theme.PriceTreEmOrange
import com.example.ui.theme.StatusExpiredRed
import com.example.ui.theme.YogaPurpleBright
import com.example.ui.viewmodel.FitnessAppState

enum class MainMenuDestination(
    val number: Int,
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val accentColor: Color,
    val tag: String
) {
    GYM(
        1,
        "1. GYM",
        "Quản lý mọi hồ sơ GYM & gia hạn",
        Icons.Default.FitnessCenter,
        GymGreenBright,
        "menu_1_gym"
    ),
    YOGA(
        2,
        "2. YOGA",
        "Quản lý mọi hồ sơ YOGA & gia hạn",
        Icons.Default.SelfImprovement,
        YogaPurpleBright,
        "menu_2_yoga"
    ),
    CREATE_CONTRACT(
        3,
        "3. TẠO HỢP ĐỒNG",
        "GYM • YOGA • PT • VÉ LẺ",
        Icons.Default.Description,
         Color(0xFF0284C7),
        "menu_3_create_contract"
    ),
    REVENUE(
        4,
        "4. DOANH THU",
        "Phân bổ • Dòng tiền • Xuất báo cáo",
        Icons.Default.MonetizationOn,
        PriceTreEmOrange,
        "menu_4_revenue"
    ),
    MEMBER_TRACKING(
        5,
        "5. THEO DÕI HỘI VIÊN",
        "Còn hạn • Hết hạn • Sắp hết hạn 7 ngày",
        Icons.Default.NotificationsActive,
        Color(0xFF0D9488),
        "menu_5_tracking"
    ),
    PT_MANAGEMENT(
        6,
        "6. QUẢN LÍ PT",
        "Hội viên PT • Hợp đồng • Buổi tập",
        Icons.Default.SportsGymnastics,
        PriceNuPink,
        "menu_6_pt"
    ),
    SETTINGS(
        7,
        "7. CÀI ĐẶT",
        "Bảng giá • Sáng/Tối • Đồng bộ & Sao lưu",
        Icons.Default.Settings,
        Color(0xFF4F46E5),
        "menu_7_settings"
    ),
    TRASH(
        8,
        "8. THÙNG RÁC",
        "8 danh mục xóa mềm • Khôi phục",
        Icons.Default.DeleteSweep,
        StatusExpiredRed,
        "menu_8_trash"
    )
}

@Composable
fun HomeScreen(
    appState: FitnessAppState,
    userEmail: String?,
    onSelectMenu: (MainMenuDestination) -> Unit,
    onToggleDarkMode: (Boolean) -> Unit,
    onSignOut: () -> Unit
) {
    val gymCount = appState.activeGymMembers.size
    val yogaCount = appState.activeYogaMembers.size
    val ptCount = appState.activePtMembers.size
    val trashCount = appState.allMembers.count { it.isDeleted } +
        appState.allContracts.count { it.isDeleted } +
        appState.allPtSessions.count { it.isDeleted } +
        appState.allSingleTickets.count { it.isDeleted }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Hero Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF0F172A),
                            Color(0xFF14532D),
                            Color(0xFF4C1D95)
                        )
                    )
                )
                .padding(horizontal = 18.dp, vertical = 20.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "89 FITNESS & YOGA",
                            style = MaterialTheme.typography.headlineMedium,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CloudDone,
                                contentDescription = null,
                                tint = Color(0xFF4ADE80),
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = userEmail ?: appState.syncStatusMessage,
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.85f)
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { onToggleDarkMode(!appState.config.isDarkMode) },
                            modifier = Modifier.testTag("theme_toggle_button")
                        ) {
                            Icon(
                                imageVector = if (appState.config.isDarkMode) Icons.Default.LightMode else Icons.Default.DarkMode,
                                contentDescription = "Chuyển giao diện Sáng/Tối",
                                tint = Color.White
                            )
                        }
                        IconButton(
                            onClick = onSignOut,
                            modifier = Modifier.testTag("sign_out_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Logout,
                                contentDescription = "Đăng xuất",
                                tint = Color.White
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Quick Overview Strip
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    QuickMetricPill(
                        label = "Hồ sơ GYM",
                        value = gymCount.toString(),
                        accent = Color(0xFF4ADE80),
                        modifier = Modifier.weight(1f)
                    )
                    QuickMetricPill(
                        label = "Hồ sơ YOGA",
                        value = yogaCount.toString(),
                        accent = Color(0xFFC084FC),
                        modifier = Modifier.weight(1f)
                    )
                    QuickMetricPill(
                        label = "Hồ sơ PT",
                        value = ptCount.toString(),
                        accent = Color(0xFFF472B6),
                        modifier = Modifier.weight(1f)
                    )
                    QuickMetricPill(
                        label = "Thùng rác",
                        value = trashCount.toString(),
                        accent = Color(0xFFFCA5A5),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // 8 Main Menus Grid
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 160.dp),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Text(
                    text = "8 MENU CHỨC NĂNG CHÍNH",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 2.dp)
                )
            }

            items(MainMenuDestination.entries) { menu ->
                val badgeText = when (menu) {
                    MainMenuDestination.GYM -> "$gymCount hồ sơ"
                    MainMenuDestination.YOGA -> "$yogaCount hồ sơ"
                    MainMenuDestination.PT_MANAGEMENT -> "$ptCount hồ sơ"
                    MainMenuDestination.TRASH -> "$trashCount mục"
                    else -> null
                }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectMenu(menu) }
                        .testTag(menu.tag),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                    border = BorderStroke(1.5.dp, menu.accentColor.copy(alpha = 0.45f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape),
                                color = menu.accentColor.copy(alpha = 0.14f)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = menu.icon,
                                        contentDescription = menu.title,
                                        tint = menu.accentColor,
                                        modifier = Modifier.size(26.dp)
                                    )
                                }
                            }

                            if (badgeText != null) {
                                Surface(
                                    color = menu.accentColor.copy(alpha = 0.14f),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text(
                                        text = badgeText,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = menu.accentColor,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = menu.title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = menu.subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickMetricPill(
    label: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = Color.White.copy(alpha = 0.1f),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier.padding(vertical = 8.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                color = accent,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall,
                color = Color.White.copy(alpha = 0.85f)
            )
        }
    }
}
