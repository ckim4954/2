package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.local.ContractEntity
import com.example.domain.DateCalculator
import com.example.domain.FormatUtils
import com.example.ui.MemberSummaryUi
import com.example.ui.theme.*
import java.io.File

/**
 * Member Detail & Contract Inspection Screen (Sections 5.2 & 10 of Upgrade PRD):
 * - All fields of saved member profiles and saved contracts default to READ-ONLY mode (no text input cursor).
 * - Only after pressing "Sửa hợp đồng" (or "Sửa hồ sơ") do the fields switch to editable mode.
 * - Supports manual endDate adjustment via native Android DatePickerDialog, preserving the manual end date
 *   even if startDate changes unless user clicks "Tính tự động lại" (Confirmed Decision 2).
 * - Every delete/cancel action requires explicit confirmation.
 */
@Composable
fun MemberDetailScreen(
    summary: MemberSummaryUi?,
    onBack: () -> Unit,
    onRenewClick: (String) -> Unit,
    onPickAvatar: (Uri, (String) -> Unit) -> Unit,
    onUpdateProfile: (String, String, String, String, String?) -> Unit,
    onUpdateContract: (String, String, Int, Long, String, String, String, String?, Boolean, String) -> Unit,
    onFreezeContract: (String, String, Int, String) -> Unit,
    onRecordPayment: (String, String, Long, Long, String) -> Unit,
    onCancelContractAndRefund: (String, String, String, String, Long, Long, String) -> Unit,
    onSoftDeleteContract: (String) -> Unit,
    onSoftDeleteMember: (String) -> Unit
) {
    if (summary == null) {
        Scaffold(
            topBar = { FitnessTopAppBar(title = "Chi tiết hội viên", onBackClick = onBack) }
        ) { pad ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(pad),
                contentAlignment = Alignment.Center
            ) {
                Text("Không tìm thấy hồ sơ hội viên.")
            }
        }
        return
    }

    val member = summary.member
    val currentContract = summary.currentContract

    // Read-only by default for member profile & each contract (Section 5.2)
    var isEditingMemberProfile by remember { mutableStateOf(false) }
    var editingContractId by remember { mutableStateOf<String?>(null) }

    var contractToFreeze by remember { mutableStateOf<ContractEntity?>(null) }
    var contractToPay by remember { mutableStateOf<ContractEntity?>(null) }
    var contractToCancel by remember { mutableStateOf<ContractEntity?>(null) }
    var contractToDeleteConfirm by remember { mutableStateOf<ContractEntity?>(null) }
    var showDeleteMemberConfirm by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            onPickAvatar(uri) { savedPath ->
                onUpdateProfile(
                    member.id,
                    member.fullName,
                    member.phoneNumber,
                    member.customerGroup,
                    savedPath
                )
            }
        }
    }

    Scaffold(
        topBar = {
            FitnessTopAppBar(
                title = member.fullName,
                domainBadge = member.domain,
                onBackClick = onBack,
                actions = {
                    IconButton(
                        onClick = { showDeleteMemberConfirm = true },
                        modifier = Modifier.testTag("delete_member_btn")
                    ) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Xóa hội viên")
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            if (summary.hasOverpaymentWarning) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = StatusDangerRed.copy(alpha = 0.12f)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = StatusDangerRed)
                            Text(
                                text = "Cảnh báo: Tổng tiền đã thu lớn hơn giá trị hợp đồng sau chỉnh sửa.",
                                style = MaterialTheme.typography.bodySmall,
                                color = StatusDangerRed,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            // 1. Member Profile Card (Read-Only by default, editable only after pressing "Sửa hồ sơ")
            item {
                var editName by remember(member.fullName, isEditingMemberProfile) { mutableStateOf(member.fullName) }
                var editPhone by remember(member.phoneNumber, isEditingMemberProfile) { mutableStateOf(member.phoneNumber) }
                var editGroup by remember(member.customerGroup, isEditingMemberProfile) { mutableStateOf(member.customerGroup) }

                ElevatedCard(
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(56.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.surfaceVariant),
                                contentAlignment = Alignment.Center
                            ) {
                                val avatarFile = member.avatarPath?.let { File(it) }
                                if (avatarFile != null && avatarFile.exists()) {
                                    AsyncImage(
                                        model = avatarFile,
                                        contentDescription = member.fullName,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = member.fullName,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "SĐT: ${member.phoneNumber.ifBlank { "—" }}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            StatusPill(
                                text = summary.statusText,
                                tone = when {
                                    summary.isExpired -> StatusTone.DANGER
                                    summary.isExpiringSoon -> StatusTone.WARNING
                                    else -> StatusTone.SUCCESS
                                }
                            )
                        }

                        if (!isEditingMemberProfile) {
                            // Read-Only Mode (No input cursor!)
                            ReadOnlyInfoRow(label = "Họ và tên", value = member.fullName)
                            ReadOnlyInfoRow(label = "Số điện thoại", value = member.phoneNumber)
                            if (member.domain == "GYM") {
                                ReadOnlyInfoRow(label = "Nhóm đối tượng", value = member.customerGroup)
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = { isEditingMemberProfile = true },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("edit_member_profile_btn")
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Sửa hồ sơ")
                                }
                                Button(
                                    onClick = { onRenewClick(member.id) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("detail_renew_btn")
                                ) {
                                    Icon(Icons.Default.Autorenew, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Gia hạn")
                                }
                            }
                        } else {
                            // Edit Mode enabled after clicking "Sửa hồ sơ"
                            OutlinedTextField(
                                value = editName,
                                onValueChange = { editName = it },
                                label = { Text("Họ và tên") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = editPhone,
                                onValueChange = { editPhone = it },
                                label = { Text("Số điện thoại") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            if (member.domain == "GYM") {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    listOf("NAM", "NU", "TRE_EM").forEach { g ->
                                        FilterChip(
                                            selected = editGroup == g,
                                            onClick = { editGroup = g },
                                            label = { Text(g) }
                                        )
                                    }
                                    Spacer(modifier = Modifier.weight(1f))
                                    TextButton(onClick = {
                                        photoPickerLauncher.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    }) {
                                        Icon(Icons.Default.PhotoCamera, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Đổi ảnh")
                                    }
                                }
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                TextButton(onClick = { isEditingMemberProfile = false }) {
                                    Text("Hủy")
                                }
                                Button(onClick = {
                                    onUpdateProfile(member.id, editName, editPhone, editGroup, member.avatarPath)
                                    isEditingMemberProfile = false
                                }) {
                                    Text("Lưu hồ sơ")
                                }
                            }
                        }
                    }
                }
            }

            // 2. Compact Financial Summary Row
            item {
                ElevatedCard(
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Tổng HĐ", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(FormatUtils.formatVnd(summary.totalAgreedVnd), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("Đã thanh toán", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(FormatUtils.formatVnd(summary.totalPaidVnd), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = StatusActiveGreen)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Công nợ còn lại", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                text = FormatUtils.formatVnd(summary.totalDebtVnd),
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (summary.totalDebtVnd > 0L) StatusDangerRed else MaterialTheme.colorScheme.onSurface
                            )
                        }
                        if (currentContract != null && currentContract.status == "ACTIVE" && summary.totalDebtVnd > 0L) {
                            FilledTonalButton(
                                onClick = { contractToPay = currentContract },
                                modifier = Modifier.testTag("detail_collect_debt_btn")
                            ) {
                                Text("Thu nợ")
                            }
                        }
                    }
                }
            }

            // 3. Contracts List (Read-Only by default; editable only after clicking "Sửa hợp đồng")
            item {
                Text(
                    text = "Hợp đồng (${summary.allContracts.size})",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
            }

            items(summary.allContracts, key = { it.id }) { contract ->
                val isEditingThisContract = editingContractId == contract.id
                val paidForContract = summary.payments.filter { it.contractId == contract.id }.sumOf { it.totalAmountVnd }
                val debtForContract = (contract.agreedValueVnd - paidForContract).coerceAtLeast(0L)

                var planName by remember(contract, isEditingThisContract) { mutableStateOf(contract.planNameSnapshot) }
                var durationMonths by remember(contract, isEditingThisContract) { mutableIntStateOf(contract.durationMonths) }
                var agreedVnd by remember(contract, isEditingThisContract) { mutableLongStateOf(contract.agreedValueVnd) }
                var createdDateIso by remember(contract, isEditingThisContract) { mutableStateOf(contract.createdDateIso) }
                var paymentDateIso by remember(contract, isEditingThisContract) { mutableStateOf(contract.paymentDateIso) }
                var startDateIso by remember(contract, isEditingThisContract) { mutableStateOf(contract.startDateIso) }
                var endDateIso by remember(contract, isEditingThisContract) { mutableStateOf(contract.endDateIso) }
                var isEndDateManual by remember(contract, isEditingThisContract) { mutableStateOf(contract.isEndDateManuallyEdited) }
                var contractNote by remember(contract, isEditingThisContract) { mutableStateOf(contract.note) }

                val effectiveDays = remember(startDateIso, endDateIso) {
                    DateCalculator.daysBetween(startDateIso, endDateIso)
                }

                ElevatedCard(
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = contract.contractCode,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            StatusPill(
                                text = when {
                                    contract.status == "CANCELLED" -> "Đã hủy"
                                    contract.contractType == "NEW" -> "Đăng ký mới"
                                    else -> "Gia hạn"
                                },
                                tone = when {
                                    contract.status == "CANCELLED" -> StatusTone.DANGER
                                    contract.contractType == "NEW" -> StatusTone.SUCCESS
                                    else -> StatusTone.INFO
                                }
                            )
                        }

                        if (!isEditingThisContract) {
                            // Read-Only Contract Fields (Section 5.2: Default all fields to read-only, no cursor)
                            ReadOnlyInfoRow(label = "Gói tập", value = "${contract.planNameSnapshot} (${contract.durationMonths} tháng)")
                            ReadOnlyInfoRow(label = "Ngày hợp đồng", value = DateCalculator.formatDisplay(contract.createdDateIso))
                            ReadOnlyInfoRow(label = "Ngày thanh toán", value = DateCalculator.formatDisplay(contract.paymentDateIso))
                            ReadOnlyInfoRow(label = "Ngày bắt đầu hiệu lực", value = DateCalculator.formatDisplay(contract.startDateIso))
                            ReadOnlyInfoRow(
                                label = "Ngày hết hạn (${DateCalculator.daysBetween(contract.startDateIso, contract.endDateIso)} ngày hiệu lực)",
                                value = DateCalculator.formatDisplay(contract.endDateIso)
                            )
                            ReadOnlyInfoRow(label = "Giá trị hợp đồng", value = FormatUtils.formatVnd(contract.agreedValueVnd))
                            ReadOnlyInfoRow(label = "Đã thanh toán", value = FormatUtils.formatVnd(paidForContract))
                            ReadOnlyInfoRow(label = "Công nợ còn lại", value = FormatUtils.formatVnd(debtForContract))
                            if (contract.note.isNotBlank()) {
                                ReadOnlyInfoRow(label = "Ghi chú", value = contract.note)
                            }

                            if (contract.status == "ACTIVE") {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    OutlinedButton(
                                        onClick = { editingContractId = contract.id },
                                        modifier = Modifier.testTag("btn_edit_contract_${contract.id}")
                                    ) {
                                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Sửa hợp đồng")
                                    }
                                    Row {
                                        TextButton(onClick = { contractToFreeze = contract }) {
                                            Text("Đóng băng")
                                        }
                                        TextButton(
                                            onClick = { contractToCancel = contract },
                                            colors = ButtonDefaults.textButtonColors(contentColor = StatusDangerRed)
                                        ) {
                                            Text("Hủy HĐ")
                                        }
                                        IconButton(onClick = { contractToDeleteConfirm = contract }) {
                                            Icon(
                                                imageVector = Icons.Default.DeleteOutline,
                                                contentDescription = "Xóa hợp đồng",
                                                tint = StatusDangerRed
                                            )
                                        }
                                    }
                                }
                            }
                        } else {
                            // Editable Mode (Only unlocked after clicking "Sửa hợp đồng")
                            OutlinedTextField(
                                value = planName,
                                onValueChange = { planName = it },
                                label = { Text("Gói tập") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf(1, 2, 3, 12).forEach { m ->
                                    FilterChip(
                                        selected = durationMonths == m,
                                        onClick = {
                                            durationMonths = m
                                            // Confirmed Decision 2: Only recalculate endDate if not manually edited
                                            if (!isEndDateManual) {
                                                endDateIso = DateCalculator.calculateEndDate(startDateIso, m, contract.frozenDays)
                                            }
                                        },
                                        label = { Text("${m}T") }
                                    )
                                }
                            }

                            DateInputField(
                                label = "Ngày hợp đồng",
                                isoDate = createdDateIso,
                                onIsoDateChange = { createdDateIso = it }
                            )
                            DateInputField(
                                label = "Ngày thanh toán",
                                isoDate = paymentDateIso,
                                onIsoDateChange = { paymentDateIso = it }
                            )
                            DateInputField(
                                label = "Ngày bắt đầu hiệu lực",
                                isoDate = startDateIso,
                                onIsoDateChange = { newStart ->
                                    startDateIso = newStart
                                    // Confirmed Decision 2: Keep manual end date even when startDate changes!
                                    if (!isEndDateManual) {
                                        endDateIso = DateCalculator.calculateEndDate(newStart, durationMonths, contract.frozenDays)
                                    }
                                }
                            )

                            DateInputField(
                                label = if (isEndDateManual) "Ngày hết hạn (Đã chỉnh tay)" else "Ngày hết hạn (Tự động)",
                                isoDate = endDateIso,
                                onIsoDateChange = { pickedEnd ->
                                    endDateIso = pickedEnd
                                    isEndDateManual = true
                                }
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Số ngày hiệu lực: $effectiveDays ngày",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Bold
                                )
                                if (isEndDateManual) {
                                    TextButton(
                                        onClick = {
                                            isEndDateManual = false
                                            endDateIso = DateCalculator.calculateEndDate(startDateIso, durationMonths, contract.frozenDays)
                                        }
                                    ) {
                                        Text("Tính tự động lại")
                                    }
                                }
                            }

                            VndAmountField(
                                label = "Giá trị hợp đồng",
                                amountVnd = agreedVnd,
                                onAmountChange = { agreedVnd = it }
                            )

                            OutlinedTextField(
                                value = contractNote,
                                onValueChange = { contractNote = it },
                                label = { Text("Ghi chú hợp đồng") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                TextButton(onClick = { editingContractId = null }) {
                                    Text("Hủy")
                                }
                                Button(
                                    onClick = {
                                        onUpdateContract(
                                            contract.id,
                                            planName,
                                            durationMonths,
                                            agreedVnd,
                                            paymentDateIso,
                                            createdDateIso,
                                            startDateIso,
                                            endDateIso,
                                            isEndDateManual,
                                            contractNote
                                        )
                                        editingContractId = null
                                    }
                                ) {
                                    Text("Lưu hợp đồng")
                                }
                            }
                        }
                    }
                }
            }

            // 4. Payment History
            if (summary.payments.isNotEmpty()) {
                item {
                    Text(
                        text = "Lịch sử thanh toán (${summary.payments.size})",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                }
                items(summary.payments, key = { it.id }) { pay ->
                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(10.dp),
                        tonalElevation = 1.dp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${pay.transactionCode} • ${DateCalculator.formatDisplay(pay.paymentDateIso)}",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "${pay.paymentMethodLabel} (TM: ${FormatUtils.formatVnd(pay.cashAmountVnd)} | CK: ${FormatUtils.formatVnd(pay.transferAmountVnd)})",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(
                                text = "+${FormatUtils.formatVnd(pay.totalAmountVnd)}",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = StatusActiveGreen
                            )
                        }
                    }
                }
            }
        }
    }

    // Dialog: Freeze Contract
    contractToFreeze?.let { c ->
        var freezeStartIso by remember { mutableStateOf(DateCalculator.todayIso()) }
        var daysStr by remember { mutableStateOf("7") }
        var reason by remember { mutableStateOf("Tạm nghỉ cá nhân") }

        AlertDialog(
            onDismissRequest = { contractToFreeze = null },
            title = { Text("Đóng băng HĐ ${c.contractCode}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    DateInputField(
                        label = "Ngày bắt đầu tạm dừng",
                        isoDate = freezeStartIso,
                        onIsoDateChange = { freezeStartIso = it }
                    )
                    OutlinedTextField(
                        value = daysStr,
                        onValueChange = { daysStr = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Số ngày đóng băng") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = reason,
                        onValueChange = { reason = it },
                        label = { Text("Lý do") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    val days = daysStr.toIntOrNull() ?: 0
                    onFreezeContract(c.id, freezeStartIso, days, reason)
                    contractToFreeze = null
                }) {
                    Text("Xác nhận")
                }
            },
            dismissButton = {
                TextButton(onClick = { contractToFreeze = null }) {
                    Text("Hủy")
                }
            }
        )
    }

    // Dialog: Collect Debt Payment
    contractToPay?.let { c ->
        var payDateIso by remember { mutableStateOf(DateCalculator.todayIso()) }
        var cashVnd by remember { mutableStateOf(summary.totalDebtVnd) }
        var transferVnd by remember { mutableStateOf(0L) }
        var note by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { contractToPay = null },
            title = { Text("Thu tiền HĐ ${c.contractCode}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    DateInputField(
                        label = "Ngày thu tiền",
                        isoDate = payDateIso,
                        onIsoDateChange = { payDateIso = it }
                    )
                    VndAmountField(
                        label = "Tiền mặt",
                        amountVnd = cashVnd,
                        onAmountChange = { cashVnd = it }
                    )
                    VndAmountField(
                        label = "Chuyển khoản",
                        amountVnd = transferVnd,
                        onAmountChange = { transferVnd = it }
                    )
                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it },
                        label = { Text("Ghi chú") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    onRecordPayment(c.id, payDateIso, cashVnd, transferVnd, note)
                    contractToPay = null
                }) {
                    Text("Ghi nhận")
                }
            },
            dismissButton = {
                TextButton(onClick = { contractToPay = null }) {
                    Text("Hủy")
                }
            }
        )
    }

    // Dialog: Cancel Contract & Refund (Section 9.6)
    contractToCancel?.let { c ->
        var cancelDateIso by remember { mutableStateOf(DateCalculator.todayIso()) }
        var refundDateIso by remember { mutableStateOf(DateCalculator.todayIso()) }
        var reason by remember { mutableStateOf("Hội viên nghỉ tập, hoàn tiền") }
        var refundCashVnd by remember { mutableStateOf(0L) }
        var refundTransferVnd by remember { mutableStateOf(0L) }
        var note by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { contractToCancel = null },
            title = { Text("Hủy hợp đồng & Hoàn tiền (${c.contractCode})") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = reason,
                        onValueChange = { reason = it },
                        label = { Text("Lý do hủy *") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    DateInputField(
                        label = "Ngày hủy",
                        isoDate = cancelDateIso,
                        onIsoDateChange = { cancelDateIso = it }
                    )
                    DateInputField(
                        label = "Ngày hoàn tiền",
                        isoDate = refundDateIso,
                        onIsoDateChange = { refundDateIso = it }
                    )
                    VndAmountField(
                        label = "Hoàn tiền mặt (nhập thực tế)",
                        amountVnd = refundCashVnd,
                        onAmountChange = { refundCashVnd = it }
                    )
                    VndAmountField(
                        label = "Hoàn chuyển khoản",
                        amountVnd = refundTransferVnd,
                        onAmountChange = { refundTransferVnd = it }
                    )
                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it },
                        label = { Text("Ghi chú") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onCancelContractAndRefund(
                            c.id,
                            cancelDateIso,
                            refundDateIso,
                            reason,
                            refundCashVnd,
                            refundTransferVnd,
                            note
                        )
                        contractToCancel = null
                        onBack()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusDangerRed)
                ) {
                    Text("Xác nhận Hủy HĐ")
                }
            },
            dismissButton = {
                TextButton(onClick = { contractToCancel = null }) {
                    Text("Đóng")
                }
            }
        )
    }

    // Confirmation Dialog: Soft Delete Single Contract (Section 10)
    contractToDeleteConfirm?.let { c ->
        AlertDialog(
            onDismissRequest = { contractToDeleteConfirm = null },
            title = { Text("Xác nhận xóa hợp đồng?") },
            text = {
                Text("Hợp đồng ${c.contractCode} sẽ được chuyển vào Thùng rác. Lịch sử thanh toán vẫn được giữ nguyên.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        onSoftDeleteContract(c.id)
                        contractToDeleteConfirm = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusDangerRed)
                ) {
                    Text("Xóa vào Thùng rác")
                }
            },
            dismissButton = {
                TextButton(onClick = { contractToDeleteConfirm = null }) {
                    Text("Hủy")
                }
            }
        )
    }

    // Confirmation Dialog: Soft Delete Member (Section 10)
    if (showDeleteMemberConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteMemberConfirm = false },
            title = { Text("Xác nhận xóa hội viên?") },
            text = {
                Text("Hồ sơ hội viên ${member.fullName} sẽ được chuyển vào Thùng rác. Dữ liệu hợp đồng và lịch sử giao dịch vẫn được bảo toàn.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteMemberConfirm = false
                        onSoftDeleteMember(member.id)
                        onBack()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusDangerRed)
                ) {
                    Text("Xác nhận xóa")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteMemberConfirm = false }) {
                    Text("Hủy")
                }
            }
        )
    }
}
