package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.local.ContractEntity
import com.example.domain.DateCalculator
import com.example.domain.FormatUtils
import com.example.ui.MemberSummaryUi
import com.example.ui.theme.*
import java.io.File

/**
 * Member Detail Screen (Section 4.5):
 * - Loads compressed avatar ONLY on this detail screen
 * - Shows personal info, current package, registration/expiry dates, status,
 *   full contract history, payment history, debt, and freeze records
 * - Allows editing member profile, editing any contract, freezing a contract,
 *   collecting debt payment, or cancelling & refunding a contract.
 */
@Composable
fun MemberDetailScreen(
    summary: MemberSummaryUi?,
    onBack: () -> Unit,
    onRenewClick: (String) -> Unit,
    onPickAvatar: (Uri, (String) -> Unit) -> Unit,
    onUpdateProfile: (String, String, String, String, String?) -> Unit,
    onUpdateContract: (String, String, Int, Long, String, String, String, String?) -> Unit,
    onFreezeContract: (String, String, Int, String) -> Unit,
    onRecordPayment: (String, String, Long, Long, String) -> Unit,
    onCancelContractAndRefund: (String, String, String, String, Long, Long, String) -> Unit,
    onSoftDeleteMember: (String) -> Unit
) {
    if (summary == null) {
        Scaffold(
            topBar = { FitnessTopAppBar(title = "Chi tiết hội viên", onBackClick = onBack) }
        ) { pad ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(pad),
                contentAlignment = Alignment.Center
            ) {
                Text("Không tìm thấy hồ sơ hội viên.")
            }
        }
        return
    }

    val member = summary.member
    val currentContract = summary.currentContract

    var showEditMemberDialog by remember { mutableStateOf(false) }
    var contractToEdit by remember { mutableStateOf<ContractEntity?>(null) }
    var contractToFreeze by remember { mutableStateOf<ContractEntity?>(null) }
    var contractToPay by remember { mutableStateOf<ContractEntity?>(null) }
    var contractToCancel by remember { mutableStateOf<ContractEntity?>(null) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            onPickAvatar(uri) { savedPath ->
                onUpdateProfile(
                    member.id,
                    member.fullName,
                    member.phoneNumber,
                    member.customerGroup,
                    savedPath
                )
            }
        }
    }

    Scaffold(
        topBar = {
            FitnessTopAppBar(
                title = member.fullName,
                subtitle = "Hồ sơ hội viên ${member.domain}",
                domainBadge = member.domain,
                onBackClick = onBack,
                actions = {
                    IconButton(
                        onClick = { showEditMemberDialog = true },
                        modifier = Modifier.testTag("edit_member_profile_btn")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = "Sửa thông tin hội viên")
                    }
                    IconButton(
                        onClick = { showDeleteConfirm = true },
                        modifier = Modifier.testTag("delete_member_btn")
                    ) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Chuyển vào thùng rác")
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Overpayment alert if contract value was edited below paid amount (Section 12.4)
            if (summary.hasOverpaymentWarning) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = StatusDangerRed.copy(alpha = 0.12f)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = StatusDangerRed)
                            Column {
                                Text(
                                    text = "Cảnh báo: Thanh toán vượt giá trị hợp đồng",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = StatusDangerRed,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Tổng tiền đã thu lớn hơn giá trị hợp đồng sau chỉnh sửa. Vui lòng kiểm tra và đối soát với hội viên.",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }
                }
            }

            // 1. Profile & Avatar Card
            item {
                ElevatedCard(
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(72.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.surfaceVariant),
                                contentAlignment = Alignment.Center
                            ) {
                                val avatarFile = member.avatarPath?.let { File(it) }
                                if (avatarFile != null && avatarFile.exists()) {
                                    AsyncImage(
                                        model = avatarFile,
                                        contentDescription = "Ảnh đại diện ${member.fullName}",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = "Ảnh mặc định",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(36.dp)
                                    )
                                }
                            }

                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = member.fullName,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "SĐT: ${member.phoneNumber.ifBlank { "Chưa cập nhật" }}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (member.domain == "GYM") {
                                    Text(
                                        text = "Nhóm bảng giá: ${member.customerGroup}",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                if (!member.linkedPtClientId.isNullOrBlank()) {
                                    StatusPill(text = "Liên kết từ hồ sơ PT", tone = StatusTone.INFO)
                                }
                            }

                            OutlinedButton(
                                onClick = {
                                    photoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                }
                            ) {
                                Icon(Icons.Default.PhotoCamera, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Ảnh", style = MaterialTheme.typography.labelMedium)
                            }
                        }

                        HorizontalDivider()

                        // Current Membership Summary
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = "Gói hiện tại: ${summary.planName}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                if (currentContract != null) {
                                    Text(
                                        text = "Bắt đầu: ${DateCalculator.formatDisplay(currentContract.startDateIso)} • Hết hạn: ${DateCalculator.formatDisplay(currentContract.endDateIso)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    if (currentContract.frozenDays > 0) {
                                        Text(
                                            text = "Đã cộng bù đóng băng: ${currentContract.frozenDays} ngày",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = StatusWarningAmber
                                        )
                                    }
                                }
                            }
                            StatusPill(
                                text = summary.statusText,
                                tone = when {
                                    summary.isExpired -> StatusTone.DANGER
                                    summary.isExpiringSoon -> StatusTone.WARNING
                                    else -> StatusTone.SUCCESS
                                }
                            )
                        }

                        // Quick Action Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { onRenewClick(member.id) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("detail_renew_btn")
                            ) {
                                Icon(Icons.Default.Autorenew, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Gia hạn")
                            }
                            if (currentContract != null && currentContract.status == "ACTIVE") {
                                OutlinedButton(
                                    onClick = { contractToPay = currentContract },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("detail_collect_debt_btn")
                                ) {
                                    Icon(Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Thu tiền")
                                }
                            }
                        }
                    }
                }
            }

            // 2. Financial Summary Card
            item {
                ElevatedCard(
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Tổng giá trị HĐ", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(FormatUtils.formatVnd(summary.totalAgreedVnd), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("Đã thanh toán", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(FormatUtils.formatVnd(summary.totalPaidVnd), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = StatusActiveGreen)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Công nợ hiện tại", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                text = FormatUtils.formatVnd(summary.totalDebtVnd),
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (summary.totalDebtVnd > 0L) StatusDangerRed else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            // 3. Contract Registration & Renewal History
            item {
                Text(
                    text = "Lịch sử Hợp đồng Đăng ký & Gia hạn (${summary.allContracts.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            items(summary.allContracts, key = { it.id }) { contract ->
                val paidForContract = summary.payments.filter { it.contractId == contract.id }.sumOf { it.totalAmountVnd }
                val debtForContract = (contract.agreedValueVnd - paidForContract).coerceAtLeast(0L)

                OutlinedCard(
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${contract.contractCode} • ${contract.planNameSnapshot}",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            StatusPill(
                                text = when {
                                    contract.status == "CANCELLED" -> "Đã hủy"
                                    contract.contractType == "NEW" -> "Đăng ký mới"
                                    else -> "Gia hạn"
                                },
                                tone = when {
                                    contract.status == "CANCELLED" -> StatusTone.DANGER
                                    contract.contractType == "NEW" -> StatusTone.SUCCESS
                                    else -> StatusTone.INFO
                                }
                            )
                        }
                        Text(
                            text = "Thời hạn: ${contract.durationMonths} tháng (${DateCalculator.formatDisplay(contract.startDateIso)} → ${DateCalculator.formatDisplay(contract.endDateIso)})",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = "Giá trị HĐ: ${FormatUtils.formatVnd(contract.agreedValueVnd)} • Đã thu: ${FormatUtils.formatVnd(paidForContract)} • Nợ: ${FormatUtils.formatVnd(debtForContract)}",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Medium
                        )

                        if (contract.status == "ACTIVE") {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                TextButton(onClick = { contractToEdit = contract }) {
                                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Sửa HĐ")
                                }
                                TextButton(onClick = { contractToFreeze = contract }) {
                                    Icon(Icons.Default.AcUnit, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Đóng băng")
                                }
                                TextButton(
                                    onClick = { contractToCancel = contract },
                                    colors = ButtonDefaults.textButtonColors(contentColor = StatusDangerRed)
                                ) {
                                    Icon(Icons.Default.Cancel, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Hủy & Hoàn tiền")
                                }
                            }
                        }
                    }
                }
            }

            // 4. Payment History
            item {
                Text(
                    text = "Lịch sử Thanh toán (${summary.payments.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            if (summary.payments.isEmpty()) {
                item {
                    Text(
                        text = "Chưa có giao dịch thanh toán nào.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                items(summary.payments, key = { it.id }) { pay ->
                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(10.dp),
                        tonalElevation = 1.dp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${pay.transactionCode} • ${DateCalculator.formatDisplay(pay.paymentDateIso)}",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "${pay.paymentMethodLabel} (TM: ${FormatUtils.formatVnd(pay.cashAmountVnd)} | CK: ${FormatUtils.formatVnd(pay.transferAmountVnd)})",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(
                                text = "+${FormatUtils.formatVnd(pay.totalAmountVnd)}",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = StatusActiveGreen
                            )
                        }
                    }
                }
            }
        }
    }

    // Dialog: Edit Member Profile
    if (showEditMemberDialog) {
        var name by remember { mutableStateOf(member.fullName) }
        var phone by remember { mutableStateOf(member.phoneNumber) }
        var group by remember { mutableStateOf(member.customerGroup) }

        AlertDialog(
            onDismissRequest = { showEditMemberDialog = false },
            title = { Text("Chỉnh sửa thông tin hội viên") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Họ và tên") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("Số điện thoại") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (member.domain == "GYM") {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("NAM", "NU", "TRE_EM").forEach { g ->
                                FilterChip(
                                    selected = group == g,
                                    onClick = { group = g },
                                    label = { Text(g) }
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    onUpdateProfile(member.id, name, phone, group, member.avatarPath)
                    showEditMemberDialog = false
                }) {
                    Text("Lưu thay đổi")
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditMemberDialog = false }) {
                    Text("Hủy")
                }
            }
        )
    }

    // Dialog: Edit Contract Details (Section 5.5)
    contractToEdit?.let { c ->
        var planName by remember { mutableStateOf(c.planNameSnapshot) }
        var monthsStr by remember { mutableStateOf(c.durationMonths.toString()) }
        var agreedVnd by remember { mutableStateOf(c.agreedValueVnd) }
        var paymentDateIso by remember { mutableStateOf(c.paymentDateIso) }
        var createdDateIso by remember { mutableStateOf(c.createdDateIso) }
        var startDateIso by remember { mutableStateOf(c.startDateIso) }

        val previewEndIso = remember(startDateIso, monthsStr) {
            val m = monthsStr.toIntOrNull() ?: c.durationMonths
            DateCalculator.calculateEndDate(startDateIso, m, c.frozenDays)
        }

        AlertDialog(
            onDismissRequest = { contractToEdit = null },
            title = { Text("Chỉnh sửa hợp đồng ${c.contractCode}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = planName,
                        onValueChange = { planName = it },
                        label = { Text("Tên gói đăng ký") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = monthsStr,
                        onValueChange = { monthsStr = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Số tháng đăng ký") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    VndAmountField(
                        label = "Giá trị hợp đồng",
                        amountVnd = agreedVnd,
                        onAmountChange = { agreedVnd = it }
                    )
                    DateInputField(
                        label = "Ngày bắt đầu hiệu lực",
                        isoDate = startDateIso,
                        onIsoDateChange = { startDateIso = it }
                    )
                    DateInputField(
                        label = "Ngày thanh toán",
                        isoDate = paymentDateIso,
                        onIsoDateChange = { paymentDateIso = it }
                    )
                    Text(
                        text = "Ngày hết hạn tự động tính lại: ${DateCalculator.formatDisplay(previewEndIso)}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    val m = (monthsStr.toIntOrNull() ?: c.durationMonths).coerceAtLeast(1)
                    onUpdateContract(c.id, planName, m, agreedVnd, paymentDateIso, createdDateIso, startDateIso, null)
                    contractToEdit = null
                }) {
                    Text("Cập nhật HĐ")
                }
            },
            dismissButton = {
                TextButton(onClick = { contractToEdit = null }) {
                    Text("Đóng")
                }
            }
        )
    }

    // Dialog: Freeze Contract
    contractToFreeze?.let { c ->
        var freezeStartIso by remember { mutableStateOf(DateCalculator.todayIso()) }
        var daysStr by remember { mutableStateOf("7") }
        var reason by remember { mutableStateOf("Tạm nghỉ cá nhân") }

        AlertDialog(
            onDismissRequest = { contractToFreeze = null },
            title = { Text("Đóng băng hợp đồng ${c.contractCode}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    DateInputField(
                        label = "Ngày bắt đầu tạm dừng",
                        isoDate = freezeStartIso,
                        onIsoDateChange = { freezeStartIso = it }
                    )
                    OutlinedTextField(
                        value = daysStr,
                        onValueChange = { daysStr = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Số ngày đóng băng (cộng bù vào ngày hết hạn)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = reason,
                        onValueChange = { reason = it },
                        label = { Text("Lý do tạm dừng") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    val days = daysStr.toIntOrNull() ?: 0
                    onFreezeContract(c.id, freezeStartIso, days, reason)
                    contractToFreeze = null
                }) {
                    Text("Xác nhận đóng băng")
                }
            },
            dismissButton = {
                TextButton(onClick = { contractToFreeze = null }) {
                    Text("Hủy")
                }
            }
        )
    }

    // Dialog: Collect Payment (Section 12.3)
    contractToPay?.let { c ->
        var payDateIso by remember { mutableStateOf(DateCalculator.todayIso()) }
        var cashVnd by remember { mutableStateOf(summary.totalDebtVnd) }
        var transferVnd by remember { mutableStateOf(0L) }
        var note by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { contractToPay = null },
            title = { Text("Thu tiền hợp đồng ${c.contractCode}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    DateInputField(
                        label = "Ngày thu tiền",
                        isoDate = payDateIso,
                        onIsoDateChange = { payDateIso = it }
                    )
                    VndAmountField(
                        label = "Số tiền mặt (Tiền mặt)",
                        amountVnd = cashVnd,
                        onAmountChange = { cashVnd = it }
                    )
                    VndAmountField(
                        label = "Số tiền chuyển khoản (Chuyển khoản)",
                        amountVnd = transferVnd,
                        onAmountChange = { transferVnd = it }
                    )
                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it },
                        label = { Text("Ghi chú") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        text = "Tổng thu lần này: ${FormatUtils.formatVnd(cashVnd + transferVnd)}",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = StatusActiveGreen
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    onRecordPayment(c.id, payDateIso, cashVnd, transferVnd, note)
                    contractToPay = null
                }) {
                    Text("Ghi nhận thanh toán")
                }
            },
            dismissButton = {
                TextButton(onClick = { contractToPay = null }) {
                    Text("Hủy")
                }
            }
        )
    }

    // Dialog: Cancel Contract & Refund (Section 14)
    contractToCancel?.let { c ->
        var cancelDateIso by remember { mutableStateOf(DateCalculator.todayIso()) }
        var refundDateIso by remember { mutableStateOf(DateCalculator.todayIso()) }
        var reason by remember { mutableStateOf("Hội viên đổi ý, yêu cầu hoàn tiền") }
        var refundCashVnd by remember { mutableStateOf(0L) }
        var refundTransferVnd by remember { mutableStateOf(0L) }
        var note by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { contractToCancel = null },
            title = { Text("Hủy hợp đồng & Hoàn tiền (${c.contractCode})") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Nhân viên tự nhập số tiền hoàn thực tế (không tự động khấu trừ ngày đã tập). Hồ sơ và hợp đồng sẽ chuyển vào Thùng rác.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = reason,
                        onValueChange = { reason = it },
                        label = { Text("Lý do hủy hợp đồng *") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    DateInputField(
                        label = "Ngày hủy",
                        isoDate = cancelDateIso,
                        onIsoDateChange = { cancelDateIso = it }
                    )
                    DateInputField(
                        label = "Ngày hoàn tiền",
                        isoDate = refundDateIso,
                        onIsoDateChange = { refundDateIso = it }
                    )
                    VndAmountField(
                        label = "Hoàn tiền mặt",
                        amountVnd = refundCashVnd,
                        onAmountChange = { refundCashVnd = it }
                    )
                    VndAmountField(
                        label = "Hoàn chuyển khoản",
                        amountVnd = refundTransferVnd,
                        onAmountChange = { refundTransferVnd = it }
                    )
                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it },
                        label = { Text("Ghi chú hoàn tiền") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onCancelContractAndRefund(
                            c.id,
                            cancelDateIso,
                            refundDateIso,
                            reason,
                            refundCashVnd,
                            refundTransferVnd,
                            note
                        )
                        contractToCancel = null
                        onBack()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusDangerRed)
                ) {
                    Text("Xác nhận Hủy & Hoàn tiền")
                }
            },
            dismissButton = {
                TextButton(onClick = { contractToCancel = null }) {
                    Text("Đóng")
                }
            }
        )
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Chuyển hồ sơ vào Thùng rác?") },
            text = {
                Text("Hồ sơ hội viên ${member.fullName} sẽ được xóa mềm và chuyển vào Thùng rác. Lịch sử tài chính vẫn được bảo toàn.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirm = false
                        onSoftDeleteMember(member.id)
                        onBack()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusDangerRed)
                ) {
                    Text("Chuyển vào Thùng rác")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("Hủy")
                }
            }
        )
    }
}
