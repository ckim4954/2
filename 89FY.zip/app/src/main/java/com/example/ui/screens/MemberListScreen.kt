package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.export.ReportTableData
import com.example.domain.DateCalculator
import com.example.domain.FormatUtils
import com.example.ui.ExpirySortOrder
import com.example.ui.MemberExpiryFilter
import com.example.ui.MemberSummaryUi
import com.example.ui.theme.*

/**
 * Member List Screen for Gym or Yoga (Section 5.1 of Upgrade PRD):
 * - Displays concise member count: "X hội viên" (no "Danh sách Hội viên 1/1 hội viên")
 * - No avatar in list
 * - Compact 2-line row per member:
 *   Line 1: STT — Họ tên — Trạng thái thời hạn ("Còn X ngày", "Hết hạn X ngày", "Hết hạn hôm nay")
 *   Line 2: Ngày hết hạn — Nút Gia hạn
 * - Search by STT, Họ tên đầy đủ, Số điện thoại with explicit placeholder
 * - No expiry filter chips here (filters belong exclusively to Theo dõi module)
 * - Exports full member list of the domain to real Excel and PDF files on device
 */
@Composable
fun MemberListScreen(
    domain: String, // "GYM" or "YOGA"
    initialFilter: MemberExpiryFilter,
    members: List<MemberSummaryUi>,
    onBack: () -> Unit,
    onMemberClick: (String) -> Unit,
    onRenewClick: (String) -> Unit,
    onCreateNewClick: () -> Unit,
    onExportMemberList: (ReportTableData, Boolean) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var sortOrder by remember { mutableStateOf(ExpirySortOrder.ASCENDING) }

    val sortedWithStt = remember(members, sortOrder) {
        val sorted = when (sortOrder) {
            ExpirySortOrder.ASCENDING -> members.sortedBy { it.endDateIso.ifEmpty { "9999-12-31" } }
            ExpirySortOrder.DESCENDING -> members.sortedByDescending { it.endDateIso }
        }
        sorted.mapIndexed { idx, item ->
            val stt = FormatUtils.formatStt(idx + 1)
            stt to item
        }
    }

    val filteredMembers = remember(sortedWithStt, searchQuery) {
        val q = searchQuery.trim().lowercase()
        if (q.isEmpty()) sortedWithStt
        else sortedWithStt.filter { (stt, item) ->
            stt.lowercase().contains(q) ||
                stt.trimStart('0').equals(q, ignoreCase = true) ||
                item.member.fullName.lowercase().contains(q) ||
                item.member.phoneNumber.lowercase().contains(q)
        }
    }

    val domainTitle = if (domain == "GYM") "Hội viên Gym" else "Hội viên Yoga"
    val accentColor = if (domain == "GYM") GymEmeraldLight else YogaIndigoLight

    // Section 5.1: Export ALL members belonging to the corresponding domain
    fun buildFullDomainExportTable(): ReportTableData {
        val headers = listOf(
            "STT",
            "Họ và Tên",
            "Số điện thoại",
            "Gói đăng ký",
            "Số tháng",
            "Ngày đăng ký",
            "Ngày hết hạn",
            "Trạng thái"
        )
        val rows = sortedWithStt.map { (stt, m) ->
            listOf(
                stt,
                m.member.fullName,
                m.member.phoneNumber,
                m.planName,
                "${m.durationMonths} tháng",
                DateCalculator.formatDisplay(m.startDateIso),
                DateCalculator.formatDisplay(m.endDateIso),
                m.statusText
            )
        }
        return ReportTableData(
            reportTitle = "DANH SÁCH HỘI VIÊN $domain",
            subtitle = "${sortedWithStt.size} hội viên • Ngày xuất: ${DateCalculator.formatDisplay(DateCalculator.todayIso())}",
            fileNamePrefix = "Danh_sach_${domain}_${DateCalculator.todayIso()}",
            headers = headers,
            rows = rows,
            summaryLines = listOf("Tổng số hội viên $domain" to "${sortedWithStt.size} hội viên")
        )
    }

    Scaffold(
        topBar = {
            FitnessTopAppBar(
                title = domainTitle,
                subtitle = "${members.size} hội viên",
                domainBadge = domain,
                onBackClick = onBack,
                actions = {
                    IconButton(
                        onClick = { onExportMemberList(buildFullDomainExportTable(), true) },
                        modifier = Modifier.testTag("export_members_excel_btn")
                    ) {
                        Icon(Icons.Default.TableView, contentDescription = "Xuất Excel")
                    }
                    IconButton(
                        onClick = { onExportMemberList(buildFullDomainExportTable(), false) },
                        modifier = Modifier.testTag("export_members_pdf_btn")
                    ) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = "Xuất PDF")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onCreateNewClick,
                containerColor = accentColor,
                contentColor = androidx.compose.ui.graphics.Color.White,
                modifier = Modifier.testTag("fab_add_member_contract")
            ) {
                Icon(Icons.Default.PersonAdd, contentDescription = "Tạo hợp đồng $domain")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Compact Search Bar (STT, Họ tên đầy đủ, Số điện thoại) & Sort Toggle
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 1.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Tìm theo STT, Họ tên, SĐT...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Xóa tìm kiếm")
                                }
                            }
                        },
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("member_search_input")
                    )

                    FilledTonalIconButton(
                        onClick = {
                            sortOrder = if (sortOrder == ExpirySortOrder.ASCENDING) {
                                ExpirySortOrder.DESCENDING
                            } else {
                                ExpirySortOrder.ASCENDING
                            }
                        },
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("sort_expiry_button")
                    ) {
                        Icon(
                            imageVector = if (sortOrder == ExpirySortOrder.ASCENDING) {
                                Icons.Default.ArrowUpward
                            } else {
                                Icons.Default.ArrowDownward
                            },
                            contentDescription = sortOrder.label
                        )
                    }
                }
            }

            if (filteredMembers.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (members.isEmpty()) "Chưa có hội viên $domain." else "Không tìm thấy hội viên phù hợp.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(start = 10.dp, end = 10.dp, top = 8.dp, bottom = 84.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(
                        items = filteredMembers,
                        key = { (_, item) -> item.member.id }
                    ) { (stt, item) ->
                        val statusColor = when {
                            item.isExpired -> StatusDangerRed
                            item.isExpiringSoon -> StatusWarningAmber
                            else -> StatusActiveGreen
                        }

                        ElevatedCard(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.elevatedCardColors(
                                containerColor = MaterialTheme.colorScheme.surface
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("member_row_${item.member.id}")
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onMemberClick(item.member.id) }
                                    .padding(horizontal = 12.dp, vertical = 9.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                // Line 1: STT — Họ tên — Trạng thái thời hạn
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "$stt — ${item.member.fullName}",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.weight(1f, fill = false)
                                    )
                                    Text(
                                        text = item.statusText,
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = statusColor
                                    )
                                }

                                // Line 2: Ngày hết hạn — Nút Gia hạn
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "Hết hạn: ${DateCalculator.formatDisplay(item.endDateIso)}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        if (item.totalDebtVnd > 0L) {
                                            Text(
                                                text = "• Nợ: ${FormatUtils.formatVnd(item.totalDebtVnd)}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = StatusDangerRed,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                    }

                                    Button(
                                        onClick = { onRenewClick(item.member.id) },
                                        colors = ButtonDefaults.buttonColors(containerColor = accentColor),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                        modifier = Modifier
                                            .defaultMinSize(minWidth = 84.dp, minHeight = 36.dp)
                                            .testTag("renew_btn_${item.member.id}")
                                    ) {
                                        Text(
                                            text = "Gia hạn",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
