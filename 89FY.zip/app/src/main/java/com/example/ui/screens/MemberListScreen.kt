package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.export.ReportTableData
import com.example.domain.DateCalculator
import com.example.domain.FormatUtils
import com.example.ui.ExpirySortOrder
import com.example.ui.MemberExpiryFilter
import com.example.ui.MemberSummaryUi
import com.example.ui.theme.*

/**
 * Member List Screen for Gym or Yoga (Section 4):
 * - Strictly separated by [domain] ("GYM" or "YOGA")
 * - Two-line row layout:
 *   Line 1: "01. Nguyễn Văn A — Còn 91 ngày"
 *   Line 2: "Hết hạn: 15/12/2026                 [Gia hạn]"
 * - No avatar in list for maximum performance
 * - Compact search & 4 filters (Tất cả, Còn hạn, Sắp hết hạn, Đã hết hạn)
 * - Sort ascending / descending by expiry date
 * - Export Member List to PDF / Excel (Section 11)
 */
@Composable
fun MemberListScreen(
    domain: String, // "GYM" or "YOGA"
    initialFilter: MemberExpiryFilter,
    members: List<MemberSummaryUi>,
    onBack: () -> Unit,
    onMemberClick: (String) -> Unit,
    onRenewClick: (String) -> Unit,
    onCreateNewClick: () -> Unit,
    onExportMemberList: (ReportTableData, Boolean) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember(initialFilter) { mutableStateOf(initialFilter) }
    var sortOrder by remember { mutableStateOf(ExpirySortOrder.ASCENDING) }

    val filteredAndSorted = remember(members, searchQuery, selectedFilter, sortOrder) {
        val q = searchQuery.trim().lowercase()
        val filtered = members.filter { item ->
            val matchesFilter = when (selectedFilter) {
                MemberExpiryFilter.ALL -> true
                MemberExpiryFilter.VALID -> item.isValid // Expiring soon is still included in Valid per Section 4.3!
                MemberExpiryFilter.EXPIRING_SOON -> item.isExpiringSoon
                MemberExpiryFilter.EXPIRED -> item.isExpired
            }
            val matchesQuery = q.isEmpty() ||
                item.member.fullName.lowercase().contains(q) ||
                item.member.phoneNumber.lowercase().contains(q)
            matchesFilter && matchesQuery
        }

        when (sortOrder) {
            ExpirySortOrder.ASCENDING -> filtered.sortedBy { it.endDateIso.ifEmpty { "9999-12-31" } }
            ExpirySortOrder.DESCENDING -> filtered.sortedByDescending { it.endDateIso }
        }
    }

    val domainTitle = if (domain == "GYM") "Danh sách Hội viên Gym" else "Danh sách Hội viên Yoga"
    val accentColor = if (domain == "GYM") GymEmeraldLight else YogaIndigoLight

    fun buildExportTable(): ReportTableData {
        val headers = listOf(
            "STT",
            "Họ và Tên",
            "Số điện thoại",
            "Gói đăng ký",
            "Số tháng",
            "Ngày đăng ký",
            "Ngày hết hạn",
            "Trạng thái"
        )
        val rows = filteredAndSorted.mapIndexed { idx, m ->
            listOf(
                FormatUtils.formatStt(idx + 1),
                m.member.fullName,
                m.member.phoneNumber,
                m.planName,
                "${m.durationMonths} tháng",
                DateCalculator.formatDisplay(m.startDateIso),
                DateCalculator.formatDisplay(m.endDateIso),
                m.statusText
            )
        }
        return ReportTableData(
            reportTitle = domainTitle.uppercase(),
            subtitle = "Bộ lọc: ${selectedFilter.label} • Tổng số: ${filteredAndSorted.size} hội viên",
            fileNamePrefix = "Danh_sach_${domain}_${DateCalculator.todayIso()}",
            headers = headers,
            rows = rows,
            summaryLines = listOf("Tổng số hội viên trong danh sách" to "${filteredAndSorted.size} người")
        )
    }

    Scaffold(
        topBar = {
            FitnessTopAppBar(
                title = domainTitle,
                subtitle = "${filteredAndSorted.size} / ${members.size} hội viên",
                domainBadge = domain,
                onBackClick = onBack,
                actions = {
                    IconButton(
                        onClick = { onExportMemberList(buildExportTable(), true) },
                        modifier = Modifier.testTag("export_members_excel_btn")
                    ) {
                        Icon(Icons.Default.TableView, contentDescription = "Xuất Excel danh sách")
                    }
                    IconButton(
                        onClick = { onExportMemberList(buildExportTable(), false) },
                        modifier = Modifier.testTag("export_members_pdf_btn")
                    ) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = "Xuất PDF danh sách")
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onCreateNewClick,
                containerColor = accentColor,
                contentColor = androidx.compose.ui.graphics.Color.White,
                modifier = Modifier.testTag("fab_add_member_contract")
            ) {
                Icon(Icons.Default.PersonAdd, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Tạo hợp đồng $domain")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Compact Search & Filter Bar (Section 4.3 & 4.4)
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 1.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Tìm họ tên hoặc số điện thoại...") },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { searchQuery = "" }) {
                                        Icon(Icons.Default.Clear, contentDescription = "Xóa tìm kiếm")
                                    }
                                }
                            },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("member_search_input")
                        )

                        FilledTonalIconButton(
                            onClick = {
                                sortOrder = if (sortOrder == ExpirySortOrder.ASCENDING) {
                                    ExpirySortOrder.DESCENDING
                                } else {
                                    ExpirySortOrder.ASCENDING
                                }
                            },
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("sort_expiry_button")
                        ) {
                            Icon(
                                imageVector = if (sortOrder == ExpirySortOrder.ASCENDING) {
                                    Icons.Default.ArrowUpward
                                } else {
                                    Icons.Default.ArrowDownward
                                },
                                contentDescription = sortOrder.label
                            )
                        }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        MemberExpiryFilter.entries.forEach { filter ->
                            val selected = selectedFilter == filter
                            FilterChip(
                                selected = selected,
                                onClick = { selectedFilter = filter },
                                label = { Text(filter.label) },
                                modifier = Modifier.testTag("filter_chip_${filter.name.lowercase()}")
                            )
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = sortOrder.label,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            if (filteredAndSorted.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = if (domain == "GYM") Icons.Default.FitnessCenter else Icons.Default.SelfImprovement,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.size(56.dp)
                        )
                        Text(
                            text = if (members.isEmpty()) {
                                "Chưa có hội viên $domain nào được lưu."
                            } else {
                                "Không tìm thấy hội viên phù hợp với bộ lọc."
                            },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Nhấn nút 'Tạo hợp đồng $domain' bên dưới để đăng ký hội viên thực tế.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 10.dp, bottom = 88.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    itemsIndexed(
                        items = filteredAndSorted,
                        key = { _, item -> item.member.id }
                    ) { index, item ->
                        val stt = FormatUtils.formatStt(index + 1)
                        val statusColor = when {
                            item.isExpired -> StatusDangerRed
                            item.isExpiringSoon -> StatusWarningAmber
                            else -> StatusActiveGreen
                        }

                        ElevatedCard(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.elevatedCardColors(
                                containerColor = MaterialTheme.colorScheme.surface
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("member_row_${item.member.id}")
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onMemberClick(item.member.id) }
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                // Line 1: "01. Nguyễn Văn A — Còn 91 ngày" (full name not truncated unnecessarily)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.Top
                                ) {
                                    Text(
                                        text = "$stt. ${item.member.fullName} — ",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.weight(1f, fill = false)
                                    )
                                    Text(
                                        text = item.statusText,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = statusColor
                                    )
                                }

                                // Line 2: "Hết hạn: 15/12/2026                 [Gia hạn]"
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                        Text(
                                            text = "Hết hạn: ${DateCalculator.formatDisplay(item.endDateIso)}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Medium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        if (item.totalDebtVnd > 0L) {
                                            Text(
                                                text = "Còn nợ: ${FormatUtils.formatVnd(item.totalDebtVnd)}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = StatusDangerRed,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                    }

                                    Button(
                                        onClick = { onRenewClick(item.member.id) },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = accentColor
                                        ),
                                        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 10.dp),
                                        modifier = Modifier
                                            .defaultMinSize(minWidth = 104.dp, minHeight = 48.dp)
                                            .testTag("renew_btn_${item.member.id}")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Autorenew,
                                            contentDescription = null,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "Gia hạn",
                                            style = MaterialTheme.typography.labelLarge,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
