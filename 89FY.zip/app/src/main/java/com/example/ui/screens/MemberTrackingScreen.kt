package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Autorenew
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.TrackChanges
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.MemberProfile
import com.example.domain.FitnessCalculator
import com.example.domain.MemberCardSummary
import com.example.domain.MemberExpiryState
import com.example.ui.components.ScreenHeaderBar
import com.example.ui.theme.GymGreenBright
import com.example.ui.theme.StatusActiveGreen
import com.example.ui.theme.StatusExpiredRed
import com.example.ui.theme.StatusWarningAmber
import com.example.ui.theme.TrackingTealBright
import com.example.ui.theme.YogaPurpleBright
import com.example.ui.viewmodel.FitnessAppState

enum class TrackingCategoryOption(
    val code: String,
    val label: String,
    val color: Color,
    val icon: ImageVector
) {
    ACTIVE(
        code = "ACTIVE",
        label = "Còn hạn",
        color = StatusActiveGreen,
        icon = Icons.Default.CheckCircle
    ),
    EXPIRED(
        code = "EXPIRED",
        label = "Hết hạn",
        color = StatusExpiredRed,
        icon = Icons.Default.ErrorOutline
    ),
    EXPIRING_7_DAYS(
        code = "EXPIRING_7_DAYS",
        label = "Sắp hết hạn 7 ngày",
        color = StatusWarningAmber,
        icon = Icons.Default.NotificationsActive
    )
}

@Composable
fun MemberTrackingScreen(
    appState: FitnessAppState,
    onBack: () -> Unit,
    onNavigateToRenew: (MemberProfile) -> Unit
) {
    var selectedService by remember { mutableStateOf<String?>(null) } // "GYM" or "YOGA"
    var selectedCategory by remember { mutableStateOf<TrackingCategoryOption?>(null) }
    var searchQuery by remember { mutableStateOf("") }

    BackHandler {
        onBack()
    }

    val todayIso = FitnessCalculator.todayIso()

    val generatedSummaries: List<MemberCardSummary> = remember(
        selectedService,
        selectedCategory,
        appState.activeGymMembers,
        appState.activeYogaMembers,
        appState.activeContracts,
        todayIso
    ) {
        val service = selectedService ?: return@remember emptyList()
        val category = selectedCategory ?: return@remember emptyList()
        val members = if (service == "YOGA") appState.activeYogaMembers else appState.activeGymMembers

        members.map { m ->
            val contracts = appState.activeContracts.filter { it.memberId == m.id && it.serviceType == service }
            FitnessCalculator.evaluateMemberCardSummary(m, contracts, todayIso)
        }.filter { summary ->
            when (category) {
                TrackingCategoryOption.ACTIVE -> summary.isActive
                TrackingCategoryOption.EXPIRED ->
                    summary.expiryState == MemberExpiryState.EXPIRED ||
                        summary.expiryState == MemberExpiryState.EXPIRED_TODAY
                TrackingCategoryOption.EXPIRING_7_DAYS ->
                    summary.expiryState == MemberExpiryState.EXPIRING_SOON_7_DAYS
            }
        }.sortedWith(
            when (category) {
                TrackingCategoryOption.EXPIRING_7_DAYS -> compareBy<MemberCardSummary> { it.daysRemainingOrOverdue }.thenBy { it.member.stt }
                TrackingCategoryOption.EXPIRED -> compareBy<MemberCardSummary> { it.daysRemainingOrOverdue }.thenBy { it.member.stt }
                TrackingCategoryOption.ACTIVE -> compareBy { it.member.stt }
            }
        )
    }

    val filteredSummaries = remember(generatedSummaries, searchQuery) {
        generatedSummaries.filter { s ->
            FitnessCalculator.matchesMemberSearchQuery(s.member, searchQuery)
        }
    }

    Scaffold(
        topBar = {
            ScreenHeaderBar(
                title = "THEO DÕI HỘI VIÊN",
                accentColor = TrackingTealBright,
                onBack = onBack
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Khối điều khiển gộp gọn: Dịch vụ [GYM] [YOGA] + Trạng thái [Còn hạn] [Hết hạn] [Sắp hết hạn 7 ngày]
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, TrackingTealBright.copy(alpha = 0.4f))
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "Dịch vụ:",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold
                            )
                            val isGym = selectedService == "GYM"
                            val isYoga = selectedService == "YOGA"
                            FilterChip(
                                selected = isGym,
                                onClick = {
                                    if (selectedService != "GYM") {
                                        selectedService = "GYM"
                                        searchQuery = ""
                                    }
                                },
                                label = { Text("GYM (${appState.activeGymMembers.size})", fontWeight = FontWeight.Bold) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.FitnessCenter,
                                        contentDescription = null,
                                        tint = if (isGym) Color.White else GymGreenBright,
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = GymGreenBright,
                                    selectedLabelColor = Color.White
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("tracking_select_gym")
                            )

                            FilterChip(
                                selected = isYoga,
                                onClick = {
                                    if (selectedService != "YOGA") {
                                        selectedService = "YOGA"
                                        searchQuery = ""
                                    }
                                },
                                label = { Text("YOGA (${appState.activeYogaMembers.size})", fontWeight = FontWeight.Bold) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.SelfImprovement,
                                        contentDescription = null,
                                        tint = if (isYoga) Color.White else YogaPurpleBright,
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = YogaPurpleBright,
                                    selectedLabelColor = Color.White
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("tracking_select_yoga")
                            )
                        }

                        if (selectedService != null) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                TrackingCategoryOption.entries.forEach { option ->
                                    val isSelected = selectedCategory == option
                                    FilterChip(
                                        selected = isSelected,
                                        onClick = {
                                            selectedCategory = option
                                            searchQuery = ""
                                        },
                                        label = { Text(option.label, style = MaterialTheme.typography.labelMedium) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = option.color,
                                            selectedLabelColor = Color.White
                                        ),
                                        modifier = Modifier.testTag("tracking_category_${option.code}")
                                    )
                                }
                            }
                        }
                    }
                }
            }

            if (selectedService == null || selectedCategory == null) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 28.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.TrackChanges,
                                contentDescription = null,
                                tint = TrackingTealBright.copy(alpha = 0.55f),
                                modifier = Modifier.size(44.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (selectedService == null) {
                                    "Chọn dịch vụ GYM hoặc YOGA"
                                } else {
                                    "Chọn trạng thái để hiển thị danh sách"
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else {
                item {
                    val category = selectedCategory!!
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "$selectedService — ${category.label.uppercase()}",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = category.color
                                )
                                Surface(
                                    color = category.color.copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = "${filteredSummaries.size} hội viên",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = category.color,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }

                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                placeholder = { Text("Tìm STT / Họ tên / SĐT...") },
                                leadingIcon = {
                                    Icon(imageVector = Icons.Default.Search, contentDescription = null)
                                },
                                trailingIcon = {
                                    if (searchQuery.isNotEmpty()) {
                                        IconButton(onClick = { searchQuery = "" }) {
                                            Icon(imageVector = Icons.Default.Clear, contentDescription = "Xóa")
                                        }
                                    }
                                },
                                singleLine = true,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("tracking_search_input")
                            )

                            val modeLabel = FitnessCalculator.memberSearchModeLabel(searchQuery)
                            if (modeLabel.isNotEmpty()) {
                                Text(
                                    text = modeLabel,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TrackingTealBright
                                )
                            }
                        }
                    }
                }

                if (filteredSummaries.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (searchQuery.isNotBlank()) "Không tìm thấy hội viên phù hợp" else "Không có hội viên trong danh sách này.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                } else {
                    items(filteredSummaries, key = { it.member.id }) { summary ->
                        val statusColor = when (selectedCategory) {
                            TrackingCategoryOption.ACTIVE -> StatusActiveGreen
                            TrackingCategoryOption.EXPIRED -> StatusExpiredRed
                            TrackingCategoryOption.EXPIRING_7_DAYS -> StatusWarningAmber
                            null -> TrackingTealBright
                        }
                        val daysText = when {
                            summary.daysRemainingOrOverdue > 0 -> "Còn ${summary.daysRemainingOrOverdue} ngày"
                            summary.daysRemainingOrOverdue == 0 -> "Hết hạn hôm nay"
                            else -> "Hết hạn ${-summary.daysRemainingOrOverdue} ngày"
                        }

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.2.dp, statusColor.copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(
                                    modifier = Modifier.weight(1f),
                                    verticalArrangement = Arrangement.spacedBy(3.dp)
                                ) {
                                    Text(
                                        text = "STT${summary.member.stt} — ${summary.member.fullName}",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        softWrap = true,
                                        maxLines = Int.MAX_VALUE
                                    )
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        if (summary.member.phone.isNotBlank()) {
                                            Text(
                                                text = "SĐT: ${summary.member.phone}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        Surface(
                                            color = statusColor.copy(alpha = 0.14f),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text(
                                                text = daysText,
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = statusColor,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.width(8.dp))

                                Button(
                                    onClick = { onNavigateToRenew(summary.member) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = TrackingTealBright,
                                        contentColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Icon(Icons.Default.Autorenew, contentDescription = null, modifier = Modifier.size(15.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("Gia hạn", style = MaterialTheme.typography.labelMedium)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
