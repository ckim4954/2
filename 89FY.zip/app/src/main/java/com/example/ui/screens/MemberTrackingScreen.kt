package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Autorenew
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.TrackChanges
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.MemberGroup
import com.example.data.model.MemberProfile
import com.example.domain.FitnessCalculator
import com.example.domain.MemberCardSummary
import com.example.domain.MemberExpiryState
import com.example.ui.components.ScreenHeaderBar
import com.example.ui.theme.GymGreenBright
import com.example.ui.theme.StatusActiveGreen
import com.example.ui.theme.StatusExpiredRed
import com.example.ui.theme.StatusWarningAmber
import com.example.ui.theme.TrackingTealBright
import com.example.ui.theme.YogaPurpleBright
import com.example.ui.viewmodel.FitnessAppState

enum class TrackingCategoryOption(
    val code: String,
    val label: String,
    val subtitle: String,
    val color: Color,
    val icon: ImageVector
) {
    ACTIVE(
        code = "ACTIVE",
        label = "Còn hạn",
        subtitle = "Hợp đồng đang còn hiệu lực (bao gồm cả sắp hết hạn)",
        color = StatusActiveGreen,
        icon = Icons.Default.CheckCircle
    ),
    EXPIRED(
        code = "EXPIRED",
        label = "Hết hạn",
        subtitle = "Hợp đồng hết hạn hôm nay hoặc đã quá hạn",
        color = StatusExpiredRed,
        icon = Icons.Default.ErrorOutline
    ),
    EXPIRING_7_DAYS(
        code = "EXPIRING_7_DAYS",
        label = "Sắp hết hạn trong 7 ngày",
        subtitle = "Còn hạn từ 1 đến 7 ngày — cần nhắc gia hạn sớm",
        color = StatusWarningAmber,
        icon = Icons.Default.NotificationsActive
    )
}

@Composable
fun MemberTrackingScreen(
    appState: FitnessAppState,
    onBack: () -> Unit,
    onNavigateToRenew: (MemberProfile) -> Unit
) {
    // Theo PRD Mục 5:
    // - Phải chọn GYM hoặc YOGA trước
    // - Sau đó chọn 1 trong 3 danh sách: Còn hạn | Hết hạn | Sắp hết hạn trong 7 ngày
    // - KHÔNG tự sinh danh sách ngay khi vừa mở
    // - KHÔNG có danh sách "Tất cả"
    // - Có thanh tìm kiếm trong danh sách đã sinh
    // - KHÔNG có mục công nợ
    var selectedService by remember { mutableStateOf<String?>(null) } // "GYM" or "YOGA"
    var selectedCategory by remember { mutableStateOf<TrackingCategoryOption?>(null) }
    var searchQuery by remember { mutableStateOf("") }

    BackHandler {
        onBack()
    }

    val todayIso = FitnessCalculator.todayIso()

    val generatedSummaries: List<MemberCardSummary> = remember(
        selectedService,
        selectedCategory,
        appState.activeGymMembers,
        appState.activeYogaMembers,
        appState.activeContracts,
        todayIso
    ) {
        val service = selectedService ?: return@remember emptyList()
        val category = selectedCategory ?: return@remember emptyList()
        val members = if (service == "YOGA") appState.activeYogaMembers else appState.activeGymMembers

        members.map { m ->
            val contracts = appState.activeContracts.filter { it.memberId == m.id && it.serviceType == service }
            FitnessCalculator.evaluateMemberCardSummary(m, contracts, todayIso)
        }.filter { summary ->
            when (category) {
                TrackingCategoryOption.ACTIVE -> summary.isActive
                TrackingCategoryOption.EXPIRED ->
                    summary.expiryState == MemberExpiryState.EXPIRED ||
                        summary.expiryState == MemberExpiryState.EXPIRED_TODAY
                TrackingCategoryOption.EXPIRING_7_DAYS ->
                    summary.expiryState == MemberExpiryState.EXPIRING_SOON_7_DAYS
            }
        }.sortedWith(
            when (category) {
                TrackingCategoryOption.EXPIRING_7_DAYS -> compareBy<MemberCardSummary> { it.daysRemainingOrOverdue }.thenBy { it.member.stt }
                TrackingCategoryOption.EXPIRED -> compareBy<MemberCardSummary> { it.daysRemainingOrOverdue }.thenBy { it.member.stt }
                TrackingCategoryOption.ACTIVE -> compareBy { it.member.stt }
            }
        )
    }

    val filteredSummaries = remember(generatedSummaries, searchQuery) {
        val q = searchQuery.trim().lowercase()
        if (q.isEmpty()) generatedSummaries
        else generatedSummaries.filter { s ->
            "stt${s.member.stt}".contains(q) ||
                s.member.stt.toString() == q ||
                s.member.fullName.lowercase().contains(q) ||
                s.member.phone.lowercase().contains(q)
        }
    }

    Scaffold(
        topBar = {
            ScreenHeaderBar(
                title = "THEO DÕI HỘI VIÊN",
                subtitle = "Chọn dịch vụ và loại danh sách để tra cứu trạng thái hạn tập",
                accentColor = TrackingTealBright,
                onBack = onBack
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Bước 1: Chọn dịch vụ GYM hoặc YOGA
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, TrackingTealBright.copy(alpha = 0.4f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "BƯỚC 1: CHỌN DỊCH VỤ CẦN THEO DÕI",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = TrackingTealBright
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            val isGym = selectedService == "GYM"
                            val isYoga = selectedService == "YOGA"
                            FilterChip(
                                selected = isGym,
                                onClick = {
                                    if (selectedService != "GYM") {
                                        selectedService = "GYM"
                                        selectedCategory = null
                                        searchQuery = ""
                                    }
                                },
                                label = {
                                    Text(
                                        text = "Hội viên GYM (${appState.activeGymMembers.size})",
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(vertical = 6.dp)
                                    )
                                },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.FitnessCenter,
                                        contentDescription = null,
                                        tint = if (isGym) Color.White else GymGreenBright
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = GymGreenBright,
                                    selectedLabelColor = Color.White
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("tracking_select_gym")
                            )

                            FilterChip(
                                selected = isYoga,
                                onClick = {
                                    if (selectedService != "YOGA") {
                                        selectedService = "YOGA"
                                        selectedCategory = null
                                        searchQuery = ""
                                    }
                                },
                                label = {
                                    Text(
                                        text = "Hội viên YOGA (${appState.activeYogaMembers.size})",
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(vertical = 6.dp)
                                    )
                                },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.SelfImprovement,
                                        contentDescription = null,
                                        tint = if (isYoga) Color.White else YogaPurpleBright
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = YogaPurpleBright,
                                    selectedLabelColor = Color.White
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("tracking_select_yoga")
                            )
                        }
                    }
                }
            }

            // Bước 2: Chỉ hiển thị sau khi đã chọn GYM hoặc YOGA
            if (selectedService != null) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, TrackingTealBright.copy(alpha = 0.4f))
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "BƯỚC 2: CHỌN 1 TRONG 3 DANH SÁCH ($selectedService)",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = TrackingTealBright
                            )
                            TrackingCategoryOption.entries.forEach { option ->
                                val isSelected = selectedCategory == option
                                Surface(
                                    onClick = {
                                        selectedCategory = option
                                        searchQuery = ""
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (isSelected) option.color.copy(alpha = 0.16f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                    border = BorderStroke(
                                        width = if (isSelected) 2.dp else 1.dp,
                                        color = if (isSelected) option.color else option.color.copy(alpha = 0.35f)
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("tracking_category_${option.code}")
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Icon(
                                                imageVector = option.icon,
                                                contentDescription = null,
                                                tint = option.color,
                                                modifier = Modifier.size(24.dp)
                                            )
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Column {
                                                Text(
                                                    text = option.label,
                                                    style = MaterialTheme.typography.titleSmall,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (isSelected) option.color else MaterialTheme.colorScheme.onSurface
                                                )
                                                Text(
                                                    text = option.subtitle,
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }
                                        if (isSelected) {
                                            Surface(
                                                color = option.color,
                                                contentColor = Color.White,
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                Text(
                                                    text = "Đang xem",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Nếu chưa chọn đủ 2 bước -> hiển thị hướng dẫn (Không tự sinh danh sách khi vừa mở)
            if (selectedService == null || selectedCategory == null) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 36.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.TrackChanges,
                                contentDescription = null,
                                tint = TrackingTealBright.copy(alpha = 0.55f),
                                modifier = Modifier.size(56.dp)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = if (selectedService == null) {
                                    "Vui lòng chọn GYM hoặc YOGA ở Bước 1"
                                } else {
                                    "Vui lòng chọn 1 trong 3 danh sách ở Bước 2 để sinh danh sách"
                                },
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else {
                // Thanh tìm kiếm trong danh sách đã sinh + số lượng kết quả
                item {
                    val category = selectedCategory!!
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "DANH SÁCH $selectedService — ${category.label.uppercase()}",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = category.color
                                )
                                Surface(
                                    color = category.color.copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text(
                                        text = "${filteredSummaries.size} hội viên",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = category.color,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                placeholder = { Text("Tìm kiếm STT, Họ tên hoặc SĐT trong danh sách đã sinh...") },
                                leadingIcon = {
                                    Icon(imageVector = Icons.Default.Search, contentDescription = null)
                                },
                                trailingIcon = {
                                    if (searchQuery.isNotEmpty()) {
                                        IconButton(onClick = { searchQuery = "" }) {
                                            Icon(imageVector = Icons.Default.Clear, contentDescription = "Xóa")
                                        }
                                    }
                                },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("tracking_search_input")
                            )
                        }
                    }
                }

                if (filteredSummaries.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 28.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Không có hội viên nào trong danh sách này.",
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                } else {
                    items(filteredSummaries, key = { it.member.id }) { summary ->
                        val statusColor = when (selectedCategory) {
                            TrackingCategoryOption.ACTIVE -> StatusActiveGreen
                            TrackingCategoryOption.EXPIRED -> StatusExpiredRed
                            TrackingCategoryOption.EXPIRING_7_DAYS -> StatusWarningAmber
                            null -> TrackingTealBright
                        }
                        val daysText = when {
                            summary.daysRemainingOrOverdue > 0 -> "Còn ${summary.daysRemainingOrOverdue} ngày"
                            summary.daysRemainingOrOverdue == 0 -> "Hết hạn hôm nay"
                            else -> "Quá hạn ${-summary.daysRemainingOrOverdue} ngày"
                        }

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.2.dp, statusColor.copy(alpha = 0.55f))
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.Top
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "STT${summary.member.stt} — ${summary.member.fullName}",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            softWrap = true,
                                            maxLines = Int.MAX_VALUE
                                        )
                                        Text(
                                            text = "SĐT: ${summary.member.phone.ifBlank { "Chưa có" }}" +
                                                if (summary.member.type == "GYM") " • Nhóm: ${MemberGroup.fromCode(summary.member.memberGroup).label}" else "",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Surface(
                                        color = statusColor.copy(alpha = 0.14f),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text(
                                            text = daysText,
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = statusColor,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }

                                HorizontalDivider()

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = "Hạn dùng: ${summary.latestContract?.endDate?.let { FitnessCalculator.formatDisplayDate(it) } ?: "Chưa có"}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.SemiBold,
                                            color = statusColor
                                        )
                                        summary.latestContract?.let { c ->
                                            Text(
                                                text = "HĐ hiện tại: ${c.contractCode} (${c.durationMonths} tháng)",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }

                                    Button(
                                        onClick = { onNavigateToRenew(summary.member) },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = TrackingTealBright,
                                            contentColor = Color.White
                                        ),
                                        shape = RoundedCornerShape(10.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                    ) {
                                        Icon(Icons.Default.Autorenew, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text("Gia hạn")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
