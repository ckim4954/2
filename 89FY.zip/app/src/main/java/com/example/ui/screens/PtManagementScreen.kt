package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.PtContractEntity
import com.example.domain.DateCalculator
import com.example.domain.FormatUtils
import com.example.ui.PtClientSummaryUi
import com.example.ui.theme.*

/**
 * Compact PT Management Screen (HLV Hà Đức):
 * - Separate PT client profile from regular Gym profile
 * - Tracks contract code, client name, register date, total sessions, contract value,
 *   used sessions, remaining sessions, and per-session log
 * - Requires confirmation dialog before deleting a PT client (Section 10.1)
 */
@Composable
fun PtManagementScreen(
    ptClients: List<PtClientSummaryUi>,
    onBack: () -> Unit,
    onCreateNewPtContractClick: () -> Unit,
    onTransitionPtToGymClick: (String) -> Unit,
    onRecordPtSession: (PtContractEntity, Int, String, Int, String) -> Unit,
    onUpdatePtContract: (PtContractEntity, Int, Long, String, Int) -> Unit,
    onSoftDeletePtClient: (String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var sessionTarget by remember { mutableStateOf<Pair<PtContractEntity, Int>?>(null) }
    var editTarget by remember { mutableStateOf<Pair<PtContractEntity, Int>?>(null) }
    var clientToDeleteConfirm by remember { mutableStateOf<PtClientSummaryUi?>(null) }

    val filteredClients = remember(ptClients, searchQuery) {
        val q = searchQuery.trim().lowercase()
        if (q.isEmpty()) ptClients
        else ptClients.filter {
            it.client.fullName.lowercase().contains(q) ||
                it.client.phoneNumber.lowercase().contains(q) ||
                it.activeContract?.contractCode?.lowercase()?.contains(q) == true
        }
    }

    Scaffold(
        topBar = {
            FitnessTopAppBar(
                title = "Quản lý PT (HLV Hà Đức)",
                subtitle = "${ptClients.size} học viên",
                domainBadge = "GYM",
                onBackClick = onBack
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onCreateNewPtContractClick,
                containerColor = PtTealLight,
                contentColor = Color.White,
                modifier = Modifier.testTag("fab_new_pt_contract")
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Hợp đồng PT mới")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 1.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Tìm học viên PT, SĐT, mã HĐ...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                )
            }

            if (filteredClients.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.SportsKabaddi,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.size(48.dp)
                        )
                        Text(
                            text = "Chưa có học viên PT",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 84.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(filteredClients, key = { it.client.id }) { item ->
                        val active = item.activeContract
                        ElevatedCard(
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = item.client.fullName,
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "SĐT: ${item.client.phoneNumber.ifBlank { "Chưa có" }} • HLV: ${item.client.trainerName}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    if (active != null) {
                                        StatusPill(
                                            text = if (item.remainingSessionsOnActive > 0) {
                                                "Còn ${item.remainingSessionsOnActive}/${active.totalSessions} buổi"
                                            } else {
                                                "Hết buổi"
                                            },
                                            tone = if (item.remainingSessionsOnActive > 0) StatusTone.SUCCESS else StatusTone.NEUTRAL
                                        )
                                    }
                                }

                                if (active != null) {
                                    HorizontalDivider()
                                    Text(
                                        text = "${active.contractCode} • ĐK: ${DateCalculator.formatDisplay(active.registerDateIso)} • Giá trị: ${FormatUtils.formatVnd(active.agreedValueVnd)}",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                    Text(
                                        text = "Đã tập: ${item.usedSessionsOnActive} buổi • Còn lại: ${item.remainingSessionsOnActive} buổi",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Bold,
                                        color = PtTealLight
                                    )

                                    if (item.allSessions.isNotEmpty()) {
                                        Text(
                                            text = "Gần đây: " + item.allSessions.take(4).joinToString(", ") {
                                                "${DateCalculator.formatDisplay(it.sessionDateIso)} (${it.sessionsUsed}b)"
                                            },
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Button(
                                            onClick = { sessionTarget = active to item.usedSessionsOnActive },
                                            enabled = item.remainingSessionsOnActive > 0,
                                            colors = ButtonDefaults.buttonColors(containerColor = PtTealLight),
                                            modifier = Modifier
                                                .weight(1f)
                                                .testTag("record_pt_session_btn_${item.client.id}")
                                        ) {
                                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Chấm buổi tập")
                                        }

                                        OutlinedButton(
                                            onClick = { onTransitionPtToGymClick(item.client.id) },
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text("ĐK Gym tháng", style = MaterialTheme.typography.labelMedium)
                                        }
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End
                                    ) {
                                        TextButton(onClick = { editTarget = active to item.usedSessionsOnActive }) {
                                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Sửa HĐ PT")
                                        }
                                        TextButton(
                                            onClick = { clientToDeleteConfirm = item },
                                            colors = ButtonDefaults.textButtonColors(contentColor = StatusDangerRed)
                                        ) {
                                            Icon(Icons.Default.DeleteOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Xóa")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Confirmation Dialog: Delete PT Client (Section 10.1)
    clientToDeleteConfirm?.let { target ->
        AlertDialog(
            onDismissRequest = { clientToDeleteConfirm = null },
            title = { Text("Xác nhận xóa học viên PT") },
            text = {
                Text("Bạn có chắc chắn muốn chuyển hồ sơ PT của '${target.client.fullName}' vào Thùng rác không?")
            },
            confirmButton = {
                Button(
                    onClick = {
                        onSoftDeletePtClient(target.client.id)
                        clientToDeleteConfirm = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusDangerRed)
                ) {
                    Text("Chuyển vào Thùng rác")
                }
            },
            dismissButton = {
                TextButton(onClick = { clientToDeleteConfirm = null }) {
                    Text("Hủy")
                }
            }
        )
    }

    // Dialog: Record PT Session
    sessionTarget?.let { (contract, usedCount) ->
        val remaining = (contract.totalSessions - usedCount).coerceAtLeast(0)
        var sessionDateIso by remember { mutableStateOf(DateCalculator.todayIso()) }
        var sessionsUsedStr by remember { mutableStateOf("1") }
        var note by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { sessionTarget = null },
            title = { Text("Ghi nhận buổi tập PT (${contract.contractCode})") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Số buổi còn lại: $remaining buổi",
                        style = MaterialTheme.typography.labelLarge,
                        color = PtTealLight
                    )
                    DateInputField(
                        label = "Ngày tập thực tế",
                        isoDate = sessionDateIso,
                        onIsoDateChange = { sessionDateIso = it },
                        testTagName = "pt_session_date_input"
                    )
                    OutlinedTextField(
                        value = sessionsUsedStr,
                        onValueChange = { sessionsUsedStr = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Số buổi sử dụng (tối đa $remaining)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it },
                        label = { Text("Ghi chú buổi tập") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    val count = sessionsUsedStr.toIntOrNull() ?: 1
                    onRecordPtSession(contract, usedCount, sessionDateIso, count, note)
                    sessionTarget = null
                }) {
                    Text("Lưu buổi tập")
                }
            },
            dismissButton = {
                TextButton(onClick = { sessionTarget = null }) {
                    Text("Hủy")
                }
            }
        )
    }

    // Dialog: Edit PT Contract
    editTarget?.let { (contract, usedCount) ->
        var totalSessionsStr by remember { mutableStateOf(contract.totalSessions.toString()) }
        var agreedVnd by remember { mutableStateOf(contract.agreedValueVnd) }
        var regDateIso by remember { mutableStateOf(contract.registerDateIso) }

        AlertDialog(
            onDismissRequest = { editTarget = null },
            title = { Text("Sửa Hợp đồng PT ${contract.contractCode}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = totalSessionsStr,
                        onValueChange = { totalSessionsStr = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Tổng số buổi đăng ký") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    VndAmountField(
                        label = "Giá trị hợp đồng PT",
                        amountVnd = agreedVnd,
                        onAmountChange = { agreedVnd = it }
                    )
                    DateInputField(
                        label = "Ngày đăng ký",
                        isoDate = regDateIso,
                        onIsoDateChange = { regDateIso = it }
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    val total = totalSessionsStr.toIntOrNull() ?: contract.totalSessions
                    onUpdatePtContract(contract, total, agreedVnd, regDateIso, usedCount)
                    editTarget = null
                }) {
                    Text("Cập nhật")
                }
            },
            dismissButton = {
                TextButton(onClick = { editTarget = null }) {
                    Text("Đóng")
                }
            }
        )
    }
}
