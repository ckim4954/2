package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Autorenew
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EventAvailable
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SportsKabaddi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.ContractRecord
import com.example.data.model.MemberProfile
import com.example.data.model.PaymentMethod
import com.example.data.model.PtSessionRecord
import com.example.domain.FitnessCalculator
import com.example.ui.components.ConfirmDeleteDialog
import com.example.ui.components.DatePickerField
import com.example.ui.components.ReviewAndConfirmDialog
import com.example.ui.components.ScreenHeaderBar
import com.example.ui.theme.PtOrangeBright
import com.example.ui.theme.StatusActiveGreen
import com.example.ui.theme.StatusExpiredRed
import com.example.ui.viewmodel.FitnessAppState
import com.example.ui.viewmodel.FitnessViewModel

enum class PtManagementTab(val index: Int, val label: String) {
    PT_MEMBERS(1, "1. Hội viên PT"),
    PT_CONTRACTS(2, "2. Hợp đồng PT"),
    PT_SESSIONS(3, "3. Buổi tập")
}

@Composable
fun PtManagementScreen(
    appState: FitnessAppState,
    viewModel: FitnessViewModel,
    onBack: () -> Unit,
    onNavigateToCreateOrRenewPt: (MemberProfile?) -> Unit
) {
    // Theo PRD Mục 6:
    // Gồm 3 nhóm: 1. Hội viên PT | 2. Hợp đồng PT | 3. Buổi tập
    // Quy tắc cốt lõi:
    // - Phải có hợp đồng PT đang hiệu lực mới ghi được buổi tập
    // - Tối đa 1 buổi/người/ngày
    // - Khi tạo mới: chọn trực tiếp tổng số buổi và số tiền thanh toán
    // - Hết buổi tự động kết thúc (COMPLETED), mở khóa gia hạn
    // - Cho phép sửa hoặc xóa mềm buổi tập (tự động tính lại số buổi đã tập & trạng thái hợp đồng)
    var currentTab by remember { mutableStateOf(PtManagementTab.PT_MEMBERS) }
    var searchQuery by remember { mutableStateOf("") }

    // State cho Tab 3: Ghi nhận buổi tập
    var selectedPtMemberIdForSession by remember { mutableStateOf<String?>(null) }
    var sessionDateIso by remember { mutableStateOf(FitnessCalculator.todayIso()) }
    var sessionNote by remember { mutableStateOf("") }
    var showConfirmNewSession by remember { mutableStateOf(false) }

    // State cho chỉnh sửa / xóa hồ sơ, hợp đồng, buổi tập
    var memberToEdit by remember { mutableStateOf<MemberProfile?>(null) }
    var memberToDelete by remember { mutableStateOf<MemberProfile?>(null) }
    var contractToViewHistory by remember { mutableStateOf<ContractRecord?>(null) }
    var sessionToEdit by remember { mutableStateOf<PtSessionRecord?>(null) }
    var sessionToDelete by remember { mutableStateOf<PtSessionRecord?>(null) }

    BackHandler {
        onBack()
    }

    val ptMembers = remember(appState.activePtMembers) {
        appState.activePtMembers.sortedBy { it.stt }
    }
    val ptContracts = remember(appState.activeContracts) {
        appState.activeContracts
            .filter { it.serviceType == "PT" }
            .sortedByDescending { it.startDate }
    }
    val ptSessions = remember(appState.activePtSessions) {
        appState.activePtSessions.sortedByDescending { it.sessionDate }
    }

    Scaffold(
        topBar = {
            ScreenHeaderBar(
                title = "QUẢN LÍ PT",
                subtitle = "Hồ sơ PT (${ptMembers.size}) • Hợp đồng PT (${ptContracts.size}) • Buổi tập (${ptSessions.size})",
                accentColor = PtOrangeBright,
                onBack = onBack,
                actions = {
                    Button(
                        onClick = { onNavigateToCreateOrRenewPt(null) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.White.copy(alpha = 0.2f),
                            contentColor = Color.White
                        ),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("pt_create_contract_top_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Tạo HĐ PT")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Thanh chuyển 3 nhóm chức năng
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 2.dp
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        PtManagementTab.entries.forEach { tab ->
                            val selected = currentTab == tab
                            FilterChip(
                                selected = selected,
                                onClick = {
                                    currentTab = tab
                                    searchQuery = ""
                                },
                                label = {
                                    Text(
                                        text = tab.label,
                                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = PtOrangeBright,
                                    selectedLabelColor = Color.White
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("pt_tab_${tab.index}")
                            )
                        }
                    }

                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = {
                            Text(
                                when (currentTab) {
                                    PtManagementTab.PT_MEMBERS -> "Tìm hội viên PT theo STT, Họ tên, SĐT..."
                                    PtManagementTab.PT_CONTRACTS -> "Tìm hợp đồng PT theo Mã HĐ, STT, Họ tên..."
                                    PtManagementTab.PT_SESSIONS -> "Tìm lịch sử buổi tập theo STT, Họ tên, Ngày..."
                                }
                            )
                        },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Xóa")
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("pt_search_input")
                    )
                }
            }

            when (currentTab) {
                PtManagementTab.PT_MEMBERS -> {
                    val q = searchQuery.trim().lowercase()
                    val filteredMembers = ptMembers.filter { m ->
                        q.isEmpty() ||
                            "stt${m.stt}".contains(q) ||
                            m.stt.toString() == q ||
                            m.fullName.lowercase().contains(q) ||
                            m.phone.lowercase().contains(q)
                    }

                    if (filteredMembers.isEmpty()) {
                        EmptyPtPlaceholder(
                            title = "Chưa có hồ sơ Hội viên PT",
                            subtitle = "Nhấn 'Tạo HĐ PT' ở góc trên để tạo hồ sơ PT và hợp đồng đầu tiên.",
                            onAction = { onNavigateToCreateOrRenewPt(null) }
                        )
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(filteredMembers, key = { it.id }) { member ->
                                val memberContracts = ptContracts.filter { it.memberId == member.id }
                                val activeContract = FitnessCalculator.findActivePtContract(memberContracts)
                                val latestContract = memberContracts.firstOrNull()
                                val memberSessions = ptSessions.filter { it.memberId == member.id }

                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    border = BorderStroke(
                                        1.2.dp,
                                        if (activeContract != null) StatusActiveGreen.copy(alpha = 0.55f)
                                        else StatusExpiredRed.copy(alpha = 0.45f)
                                    )
                                ) {
                                    Column(
                                        modifier = Modifier.padding(14.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.Top
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = "STT${member.stt} — ${member.fullName}",
                                                    style = MaterialTheme.typography.titleMedium,
                                                    fontWeight = FontWeight.Bold,
                                                    softWrap = true,
                                                    maxLines = Int.MAX_VALUE
                                                )
                                                Text(
                                                    text = "SĐT: ${member.phone.ifBlank { "Chưa cập nhật" }} • Tổng HĐ PT: ${memberContracts.size}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                            Surface(
                                                color = if (activeContract != null) StatusActiveGreen.copy(alpha = 0.14f)
                                                else StatusExpiredRed.copy(alpha = 0.14f),
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                Text(
                                                    text = if (activeContract != null) {
                                                        "Còn ${activeContract.remainingSessions}/${activeContract.totalSessions} buổi"
                                                    } else {
                                                        "Hết buổi / Chưa có HĐ hiệu lực"
                                                    },
                                                    style = MaterialTheme.typography.labelMedium,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (activeContract != null) StatusActiveGreen else StatusExpiredRed,
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                )
                                            }
                                        }

                                        if (latestContract != null) {
                                            Text(
                                                text = "HĐ gần nhất: ${latestContract.contractCode} • Đã tập: ${latestContract.usedSessions}/${latestContract.totalSessions} buổi",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }

                                        HorizontalDivider()

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                OutlinedButton(
                                                    onClick = { memberToEdit = member },
                                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                                                ) {
                                                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(15.dp))
                                                    Spacer(Modifier.width(4.dp))
                                                    Text("Sửa")
                                                }
                                                OutlinedButton(
                                                    onClick = { memberToDelete = member },
                                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                                                ) {
                                                    Icon(
                                                        Icons.Default.Delete,
                                                        contentDescription = null,
                                                        tint = MaterialTheme.colorScheme.error,
                                                        modifier = Modifier.size(15.dp)
                                                    )
                                                    Spacer(Modifier.width(4.dp))
                                                    Text("Xóa", color = MaterialTheme.colorScheme.error)
                                                }
                                            }

                                            if (activeContract != null) {
                                                Button(
                                                    onClick = {
                                                        selectedPtMemberIdForSession = member.id
                                                        currentTab = PtManagementTab.PT_SESSIONS
                                                    },
                                                    colors = ButtonDefaults.buttonColors(
                                                        containerColor = PtOrangeBright,
                                                        contentColor = Color.White
                                                    ),
                                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                                ) {
                                                    Icon(Icons.Default.EventAvailable, contentDescription = null, modifier = Modifier.size(16.dp))
                                                    Spacer(Modifier.width(4.dp))
                                                    Text("Ghi buổi tập (${memberSessions.size})")
                                                }
                                            } else {
                                                Button(
                                                    onClick = { onNavigateToCreateOrRenewPt(member) },
                                                    colors = ButtonDefaults.buttonColors(
                                                        containerColor = PtOrangeBright,
                                                        contentColor = Color.White
                                                    ),
                                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                                ) {
                                                    Icon(Icons.Default.Autorenew, contentDescription = null, modifier = Modifier.size(16.dp))
                                                    Spacer(Modifier.width(4.dp))
                                                    Text("Gia hạn HĐ PT")
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                PtManagementTab.PT_CONTRACTS -> {
                    val q = searchQuery.trim().lowercase()
                    val filteredContracts = ptContracts.filter { c ->
                        q.isEmpty() ||
                            c.contractCode.lowercase().contains(q) ||
                            "stt${c.memberSttSnapshot}".contains(q) ||
                            c.memberNameSnapshot.lowercase().contains(q) ||
                            c.memberPhoneSnapshot.lowercase().contains(q)
                    }

                    if (filteredContracts.isEmpty()) {
                        EmptyPtPlaceholder(
                            title = "Chưa có Hợp đồng PT",
                            subtitle = "Tạo hợp đồng PT mới với tổng số buổi và số tiền thanh toán trực tiếp.",
                            onAction = { onNavigateToCreateOrRenewPt(null) }
                        )
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(filteredContracts, key = { it.id }) { contract ->
                                val isActive = contract.ptStatus == "ACTIVE" && contract.usedSessions < contract.totalSessions
                                val parentMember = ptMembers.firstOrNull { it.id == contract.memberId }

                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { contractToViewHistory = contract },
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    border = BorderStroke(
                                        1.2.dp,
                                        if (isActive) StatusActiveGreen.copy(alpha = 0.55f) else StatusExpiredRed.copy(alpha = 0.45f)
                                    )
                                ) {
                                    Column(
                                        modifier = Modifier.padding(14.dp),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = contract.contractCode,
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = PtOrangeBright
                                            )
                                            Surface(
                                                color = if (isActive) StatusActiveGreen.copy(alpha = 0.15f)
                                                else StatusExpiredRed.copy(alpha = 0.15f),
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                Text(
                                                    text = if (isActive) "Đang hiệu lực" else "Hoàn thành (Hết buổi)",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (isActive) StatusActiveGreen else StatusExpiredRed,
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                )
                                            }
                                        }

                                        Text(
                                            text = "Hội viên: STT${contract.memberSttSnapshot} — ${contract.memberNameSnapshot}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.SemiBold,
                                            softWrap = true,
                                            maxLines = Int.MAX_VALUE
                                        )
                                        Text(
                                            text = "Tiến độ buổi tập: Đã tập ${contract.usedSessions} / ${contract.totalSessions} buổi (Còn ${contract.remainingSessions} buổi)",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = if (isActive) StatusActiveGreen else StatusExpiredRed,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            text = "Ngày ĐK: ${FitnessCalculator.formatDisplayDate(contract.startDate)} • Thanh toán: ${FitnessCalculator.formatCurrency(contract.paidAmount)} (${PaymentMethod.fromCode(contract.paymentMethod).label})",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )

                                        if (!isActive && parentMember != null) {
                                            val memberStillHasAnotherActive = ptContracts.any {
                                                it.memberId == parentMember.id && it.ptStatus == "ACTIVE" && it.usedSessions < it.totalSessions
                                            }
                                            if (!memberStillHasAnotherActive) {
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Button(
                                                    onClick = { onNavigateToCreateOrRenewPt(parentMember) },
                                                    colors = ButtonDefaults.buttonColors(
                                                        containerColor = PtOrangeBright,
                                                        contentColor = Color.White
                                                    ),
                                                    modifier = Modifier.align(Alignment.End)
                                                ) {
                                                    Icon(Icons.Default.Autorenew, contentDescription = null, modifier = Modifier.size(16.dp))
                                                    Spacer(Modifier.width(6.dp))
                                                    Text("Gia hạn HĐ PT mới")
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                PtManagementTab.PT_SESSIONS -> {
                    val selectedMember = ptMembers.firstOrNull { it.id == selectedPtMemberIdForSession }
                        ?: ptMembers.firstOrNull()
                    val activeContractForSelected = selectedMember?.let { m ->
                        FitnessCalculator.findActivePtContract(ptContracts.filter { it.memberId == m.id })
                    }

                    val q = searchQuery.trim().lowercase()
                    val filteredSessions = ptSessions.filter { s ->
                        q.isEmpty() ||
                            "stt${s.memberSttSnapshot}".contains(q) ||
                            s.memberNameSnapshot.lowercase().contains(q) ||
                            s.sessionDate.contains(q) ||
                            FitnessCalculator.formatDisplayDate(s.sessionDate).contains(q)
                    }

                    LazyColumn(
                        contentPadding = PaddingValues(14.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        // Khung ghi nhận buổi tập PT mới
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(1.5.dp, PtOrangeBright.copy(alpha = 0.55f))
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Text(
                                        text = "GHI NHẬN BUỔI TẬP PT MỚI",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = PtOrangeBright
                                    )
                                    Text(
                                        text = "Quy tắc: Phải có hợp đồng PT đang hiệu lực • Tối đa 1 buổi/người/ngày",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )

                                    if (ptMembers.isEmpty()) {
                                        Text(
                                            text = "Chưa có hội viên PT nào. Hãy tạo Hợp đồng PT trước.",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.error
                                        )
                                    } else {
                                        Text(
                                            text = "Chọn Hội viên PT:",
                                            style = MaterialTheme.typography.labelMedium
                                        )
                                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                            ptMembers.forEach { m ->
                                                val isChosen = selectedMember?.id == m.id
                                                val mActiveContract = FitnessCalculator.findActivePtContract(
                                                    ptContracts.filter { it.memberId == m.id }
                                                )
                                                Surface(
                                                    onClick = { selectedPtMemberIdForSession = m.id },
                                                    shape = RoundedCornerShape(10.dp),
                                                    color = if (isChosen) PtOrangeBright.copy(alpha = 0.14f)
                                                    else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                                    border = BorderStroke(
                                                        1.dp,
                                                        if (isChosen) PtOrangeBright else Color.Transparent
                                                    ),
                                                    modifier = Modifier.fillMaxWidth()
                                                ) {
                                                    Row(
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .padding(horizontal = 12.dp, vertical = 8.dp),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text(
                                                            text = "STT${m.stt} — ${m.fullName}",
                                                            style = MaterialTheme.typography.bodyMedium,
                                                            fontWeight = if (isChosen) FontWeight.Bold else FontWeight.Normal,
                                                            modifier = Modifier.weight(1f)
                                                        )
                                                        Text(
                                                            text = if (mActiveContract != null) {
                                                                "Còn ${mActiveContract.remainingSessions}/${mActiveContract.totalSessions} buổi"
                                                            } else {
                                                                "Hết buổi"
                                                            },
                                                            style = MaterialTheme.typography.labelSmall,
                                                            fontWeight = FontWeight.Bold,
                                                            color = if (mActiveContract != null) StatusActiveGreen else StatusExpiredRed
                                                        )
                                                    }
                                                }
                                            }
                                        }

                                        if (selectedMember != null && activeContractForSelected == null) {
                                            Surface(
                                                color = StatusExpiredRed.copy(alpha = 0.12f),
                                                shape = RoundedCornerShape(10.dp),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Row(
                                                    modifier = Modifier.padding(12.dp),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.SpaceBetween
                                                ) {
                                                    Text(
                                                        text = "STT${selectedMember.stt} hiện không có HĐ PT hiệu lực (đã hết buổi).",
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = StatusExpiredRed,
                                                        modifier = Modifier.weight(1f)
                                                    )
                                                    Spacer(Modifier.width(8.dp))
                                                    Button(
                                                        onClick = { onNavigateToCreateOrRenewPt(selectedMember) },
                                                        colors = ButtonDefaults.buttonColors(containerColor = PtOrangeBright)
                                                    ) {
                                                        Text("Gia hạn ngay")
                                                    }
                                                }
                                            }
                                        } else if (selectedMember != null && activeContractForSelected != null) {
                                            DatePickerField(
                                                label = "Ngày tập PT",
                                                isoDate = sessionDateIso,
                                                onDateSelected = { sessionDateIso = it },
                                                accentColor = PtOrangeBright
                                            )

                                            OutlinedTextField(
                                                value = sessionNote,
                                                onValueChange = { sessionNote = it },
                                                label = { Text("Ghi chú buổi tập (bài tập, giáo án...)") },
                                                singleLine = true,
                                                modifier = Modifier.fillMaxWidth()
                                            )

                                            val duplicateOnDate = ptSessions.any {
                                                it.memberId == selectedMember.id && it.sessionDate == sessionDateIso
                                            }
                                            if (duplicateOnDate) {
                                                Text(
                                                    text = "⚠ Hội viên này đã có 1 buổi tập trong ngày ${FitnessCalculator.formatDisplayDate(sessionDateIso)} (tối đa 1 buổi/người/ngày).",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.error,
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                            }

                                            Button(
                                                onClick = { showConfirmNewSession = true },
                                                enabled = !duplicateOnDate,
                                                colors = ButtonDefaults.buttonColors(
                                                    containerColor = PtOrangeBright,
                                                    contentColor = Color.White
                                                ),
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .testTag("record_pt_session_button")
                                            ) {
                                                Icon(Icons.Default.CheckCircle, contentDescription = null)
                                                Spacer(Modifier.width(8.dp))
                                                Text("Xác nhận ghi buổi tập (${activeContractForSelected.usedSessions + 1}/${activeContractForSelected.totalSessions})")
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Danh sách lịch sử các buổi tập đã ghi nhận
                        item {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(top = 4.dp)
                            ) {
                                Icon(Icons.Default.History, contentDescription = null, tint = PtOrangeBright)
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    text = "LỊCH SỬ BUỔI TẬP ĐÃ GHI NHẬN (${filteredSessions.size})",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        items(filteredSessions, key = { it.id }) { session ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "STT${session.memberSttSnapshot} — ${session.memberNameSnapshot}",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            softWrap = true,
                                            maxLines = Int.MAX_VALUE
                                        )
                                        Text(
                                            text = "Ngày tập: ${FitnessCalculator.formatDisplayDate(session.sessionDate)} • Mã HĐ: ${session.contractCodeSnapshot}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = PtOrangeBright,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        if (session.note.isNotBlank()) {
                                            Text(
                                                text = "Ghi chú: ${session.note}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                    Row {
                                        IconButton(onClick = { sessionToEdit = session }) {
                                            Icon(Icons.Default.Edit, contentDescription = "Sửa buổi tập", tint = PtOrangeBright)
                                        }
                                        IconButton(onClick = { sessionToDelete = session }) {
                                            Icon(
                                                Icons.Default.Delete,
                                                contentDescription = "Xóa buổi tập",
                                                tint = MaterialTheme.colorScheme.error
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (showConfirmNewSession && selectedMember != null && activeContractForSelected != null) {
                        ReviewAndConfirmDialog(
                            title = "Xác nhận ghi buổi tập PT",
                            summaryItems = listOf(
                                "Hội viên PT" to "STT${selectedMember.stt} — ${selectedMember.fullName}",
                                "Mã hợp đồng PT" to activeContractForSelected.contractCode,
                                "Ngày tập" to FitnessCalculator.formatDisplayDate(sessionDateIso),
                                "Số buổi sau khi lưu" to "${activeContractForSelected.usedSessions + 1} / ${activeContractForSelected.totalSessions} buổi",
                                "Ghi chú" to sessionNote.ifBlank { "Không có" }
                            ),
                            accentColor = PtOrangeBright,
                            onConfirm = {
                                showConfirmNewSession = false
                                viewModel.recordPtSession(
                                    member = selectedMember,
                                    contract = activeContractForSelected,
                                    sessionDate = sessionDateIso,
                                    note = sessionNote,
                                    onSuccess = { sessionNote = "" }
                                )
                            },
                            onDismiss = { showConfirmNewSession = false }
                        )
                    }
                }
            }
        }
    }

    // Dialog sửa hồ sơ PT
    memberToEdit?.let { m ->
        EditPtMemberDialog(
            member = m,
            onDismiss = { memberToEdit = null },
            onSave = { newName, newPhone ->
                viewModel.updateMemberProfile(m, newName, newPhone, "NONE") {
                    memberToEdit = null
                }
            }
        )
    }

    // Dialog xóa mềm hồ sơ PT
    memberToDelete?.let { m ->
        ConfirmDeleteDialog(
            title = "Xóa mềm hồ sơ PT STT${m.stt}?",
            message = "Hồ sơ STT${m.stt} (${m.fullName}) cùng các hợp đồng PT và buổi tập liên quan sẽ được chuyển đồng bộ vào Thùng rác (có thể khôi phục lại).",
            isPermanent = false,
            onConfirm = {
                viewModel.softDeleteMember(m) { memberToDelete = null }
            },
            onDismiss = { memberToDelete = null }
        )
    }

    // Dialog xem chi tiết hợp đồng PT
    contractToViewHistory?.let { c ->
        val relatedSessions = ptSessions.filter { it.contractId == c.id }
        AlertDialog(
            onDismissRequest = { contractToViewHistory = null },
            title = { Text("Chi tiết ${c.contractCode}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Hội viên lúc tạo: STT${c.memberSttSnapshot} — ${c.memberNameSnapshot}", fontWeight = FontWeight.Bold)
                    Text("Số điện thoại: ${c.memberPhoneSnapshot.ifBlank { "Chưa có" }}")
                    Text("Loại HĐ: ${if (c.isRenewal) "Gia hạn" else "Đăng ký mới"}")
                    Text("Ngày ĐK: ${FitnessCalculator.formatDisplayDate(c.startDate)}")
                    Text("Tổng số buổi: ${c.totalSessions} buổi")
                    Text("Đã tập: ${c.usedSessions} buổi • Còn lại: ${c.remainingSessions} buổi")
                    Text("Thanh toán: ${FitnessCalculator.formatCurrency(c.paidAmount)} (${PaymentMethod.fromCode(c.paymentMethod).label})")
                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                    Text("Các ngày đã tập (${relatedSessions.size}):", fontWeight = FontWeight.SemiBold)
                    if (relatedSessions.isEmpty()) {
                        Text("Chưa có buổi tập nào được ghi nhận.", style = MaterialTheme.typography.bodySmall)
                    } else {
                        relatedSessions.take(8).forEach { s ->
                            Text(
                                text = "• ${FitnessCalculator.formatDisplayDate(s.sessionDate)}" +
                                    if (s.note.isNotBlank()) " (${s.note})" else "",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { contractToViewHistory = null },
                    colors = ButtonDefaults.buttonColors(containerColor = PtOrangeBright)
                ) {
                    Text("Đóng")
                }
            }
        )
    }

    // Dialog sửa buổi tập PT
    sessionToEdit?.let { s ->
        EditPtSessionDialog(
            session = s,
            onDismiss = { sessionToEdit = null },
            onSave = { newDate, newNote ->
                viewModel.updatePtSession(s, newDate, newNote) {
                    sessionToEdit = null
                }
            }
        )
    }

    // Dialog xóa mềm buổi tập PT
    sessionToDelete?.let { s ->
        ConfirmDeleteDialog(
            title = "Xóa mềm buổi tập ngày ${FitnessCalculator.formatDisplayDate(s.sessionDate)}?",
            message = "Buổi tập của STT${s.memberSttSnapshot} (${s.memberNameSnapshot}) sẽ chuyển vào Thùng rác (Danh mục 8. Dữ liệu khác) và tự động hoàn lại 1 buổi vào Hợp đồng PT.",
            isPermanent = false,
            onConfirm = {
                viewModel.softDeletePtSession(s) { sessionToDelete = null }
            },
            onDismiss = { sessionToDelete = null }
        )
    }
}

@Composable
private fun EmptyPtPlaceholder(
    title: String,
    subtitle: String,
    onAction: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = Icons.Default.SportsKabaddi,
                contentDescription = null,
                tint = PtOrangeBright.copy(alpha = 0.55f),
                modifier = Modifier.size(56.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(text = title, style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(14.dp))
            Button(
                onClick = onAction,
                colors = ButtonDefaults.buttonColors(containerColor = PtOrangeBright, contentColor = Color.White)
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("Tạo Hợp đồng PT mới")
            }
        }
    }
}

@Composable
private fun EditPtMemberDialog(
    member: MemberProfile,
    onDismiss: () -> Unit,
    onSave: (String, String) -> Unit
) {
    var fullName by remember(member) { mutableStateOf(member.fullName) }
    var phone by remember(member) { mutableStateOf(member.phone) }
    var showReview by remember { mutableStateOf(false) }

    if (showReview) {
        ReviewAndConfirmDialog(
            title = "Xác nhận sửa hồ sơ PT STT${member.stt}",
            summaryItems = listOf(
                "STT bất biến" to "STT${member.stt}",
                "Họ tên mới" to fullName.trim(),
                "Số điện thoại mới" to phone.trim()
            ),
            accentColor = PtOrangeBright,
            onConfirm = {
                showReview = false
                onSave(fullName.trim(), phone.trim())
            },
            onDismiss = { showReview = false }
        )
        return
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Sửa hồ sơ PT STT${member.stt}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = fullName,
                    onValueChange = { fullName = it },
                    label = { Text("Họ và tên đầy đủ") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Số điện thoại") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { if (fullName.isNotBlank()) showReview = true },
                enabled = fullName.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = PtOrangeBright)
            ) {
                Text("Xem lại & Lưu")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) { Text("Hủy") }
        }
    )
}

@Composable
private fun EditPtSessionDialog(
    session: PtSessionRecord,
    onDismiss: () -> Unit,
    onSave: (String, String) -> Unit
) {
    var dateIso by remember(session) { mutableStateOf(session.sessionDate) }
    var note by remember(session) { mutableStateOf(session.note) }
    var showReview by remember { mutableStateOf(false) }

    if (showReview) {
        ReviewAndConfirmDialog(
            title = "Xác nhận sửa buổi tập PT",
            summaryItems = listOf(
                "Hội viên" to "STT${session.memberSttSnapshot} — ${session.memberNameSnapshot}",
                "Ngày tập mới" to FitnessCalculator.formatDisplayDate(dateIso),
                "Ghi chú mới" to note.trim().ifBlank { "Không có" }
            ),
            accentColor = PtOrangeBright,
            onConfirm = {
                showReview = false
                onSave(dateIso, note.trim())
            },
            onDismiss = { showReview = false }
        )
        return
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Sửa buổi tập PT") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "STT${session.memberSttSnapshot} — ${session.memberNameSnapshot}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold
                )
                DatePickerField(
                    label = "Ngày tập PT",
                    isoDate = dateIso,
                    onDateSelected = { dateIso = it },
                    accentColor = PtOrangeBright
                )
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("Ghi chú buổi tập") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { showReview = true },
                colors = ButtonDefaults.buttonColors(containerColor = PtOrangeBright)
            ) {
                Text("Xem lại & Lưu")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) { Text("Hủy") }
        }
    )
}
