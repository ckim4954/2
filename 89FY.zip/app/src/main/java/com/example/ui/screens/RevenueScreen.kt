package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TableView
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.PaymentMethod
import com.example.domain.AllocatedMonthlySummary
import com.example.domain.AllocatedReportType
import com.example.domain.FitnessCalculator
import com.example.domain.ReportExporter
import com.example.ui.components.MonthYearPickerRow
import com.example.ui.components.ScreenHeaderBar
import com.example.ui.theme.GymGreenBright
import com.example.ui.theme.PriceNuPink
import com.example.ui.theme.PriceTreEmOrange
import com.example.ui.theme.YogaPurpleBright
import com.example.ui.viewmodel.FitnessAppState

enum class RevenueBranch(val title: String) {
    ALLOCATED("Doanh thu phân bổ"),
    CASHFLOW("Dòng tiền tháng"),
    EXPORT("Xuất báo cáo")
}

@Composable
fun RevenueScreen(
    appState: FitnessAppState,
    onBack: () -> Unit
) {
    val (initY, initM) = FitnessCalculator.currentYearMonth()
    var selectedYear by remember { mutableIntStateOf(initY) }
    var selectedMonth by remember { mutableIntStateOf(initM) }
    var currentBranch by remember { mutableStateOf(RevenueBranch.ALLOCATED) }
    var inspectReportType by remember { mutableStateOf<AllocatedReportType?>(null) }

    val allocatedSummary = remember(
        selectedYear,
        selectedMonth,
        appState.allContracts,
        appState.allPtSessions,
        appState.allSingleTickets
    ) {
        FitnessCalculator.computeAllocatedMonthlySummary(
            year = selectedYear,
            month = selectedMonth,
            contracts = appState.allContracts,
            ptSessions = appState.allPtSessions,
            singleTickets = appState.allSingleTickets
        )
    }

    val cashflowSummary = remember(
        selectedYear,
        selectedMonth,
        appState.allContracts,
        appState.allSingleTickets
    ) {
        FitnessCalculator.computeMonthlyCashflow(
            year = selectedYear,
            month = selectedMonth,
            contracts = appState.allContracts,
            singleTickets = appState.allSingleTickets
        )
    }

    BackHandler {
        if (inspectReportType != null) {
            inspectReportType = null
        } else {
            onBack()
        }
    }

    Scaffold(
        topBar = {
            ScreenHeaderBar(
                title = "DOANH THU",
                accentColor = PriceTreEmOrange,
                onBack = onBack
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // 3 nhánh Doanh thu
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                RevenueBranch.entries.forEach { branch ->
                    val selected = currentBranch == branch
                    FilterChip(
                        selected = selected,
                        onClick = { currentBranch = branch },
                        label = { Text(branch.title, style = MaterialTheme.typography.labelMedium) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PriceTreEmOrange,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("revenue_branch_${branch.name}")
                    )
                }
            }

            when (currentBranch) {
                RevenueBranch.ALLOCATED -> {
                    AllocatedRevenueTab(
                        summary = allocatedSummary,
                        onYearMonthChange = { y, m ->
                            selectedYear = y
                            selectedMonth = m
                        },
                        onInspectReport = { inspectReportType = it }
                    )
                }

                RevenueBranch.CASHFLOW -> {
                    MonthlyCashflowTab(
                        summary = cashflowSummary,
                        onYearMonthChange = { y, m ->
                            selectedYear = y
                            selectedMonth = m
                        }
                    )
                }

                RevenueBranch.EXPORT -> {
                    ExportSingleReportTab(
                        summary = allocatedSummary,
                        cashflowSummary = cashflowSummary,
                        onYearMonthChange = { y, m ->
                            selectedYear = y
                            selectedMonth = m
                        }
                    )
                }
            }
        }
    }

    if (inspectReportType != null) {
        val rep = inspectReportType!!
        val items = allocatedSummary.itemsForReport(rep)
        val total = allocatedSummary.totalForReport(rep)
        AlertDialog(
            onDismissRequest = { inspectReportType = null },
            title = {
                Text(
                    text = rep.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    item {
                        Text(
                            text = "Tháng ${allocatedSummary.month}/${allocatedSummary.year} • Tổng: ${FitnessCalculator.formatCurrency(total)}",
                            style = MaterialTheme.typography.titleSmall,
                            color = if (rep.serviceCategory == "YOGA") YogaPurpleBright else GymGreenBright
                        )
                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                    }
                    if (items.isEmpty()) {
                        item {
                            Text("Không có dữ liệu phân bổ trong tháng này.", style = MaterialTheme.typography.bodyMedium)
                        }
                    } else {
                        items(items, key = { it.id }) { line ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                                )
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "${line.codeOrLabel} (${line.memberSttText})",
                                            style = MaterialTheme.typography.labelLarge,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = FitnessCalculator.formatCurrency(line.allocatedAmount),
                                            style = MaterialTheme.typography.labelLarge,
                                            fontWeight = FontWeight.Bold,
                                            color = if (rep.serviceCategory == "YOGA") YogaPurpleBright else GymGreenBright
                                        )
                                    }
                                    Text(
                                        text = line.memberName,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                    Text(
                                        text = "${line.periodText} • ${line.monthUnitText}/${line.totalUnitText}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { inspectReportType = null }) {
                    Text("Đóng")
                }
            }
        )
    }
}

@Composable
private fun AllocatedRevenueTab(
    summary: AllocatedMonthlySummary,
    onYearMonthChange: (Int, Int) -> Unit,
    onInspectReport: (AllocatedReportType) -> Unit
) {
    val gymReports = listOf(
        AllocatedReportType.GYM_NEW_AND_ACTIVE,
        AllocatedReportType.GYM_RENEWAL,
        AllocatedReportType.GYM_PT,
        AllocatedReportType.GYM_SINGLE_TICKET,
        AllocatedReportType.GYM_TOTAL
    )
    val yogaReports = listOf(
        AllocatedReportType.YOGA_NEW_AND_ACTIVE,
        AllocatedReportType.YOGA_RENEWAL,
        AllocatedReportType.YOGA_TOTAL
    )

    LazyColumn(
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            MonthYearPickerRow(
                year = summary.year,
                month = summary.month,
                onYearMonthChange = onYearMonthChange,
                accentColor = PriceTreEmOrange
            )
        }

        item {
            Text(
                text = "GYM — 5 BÁO CÁO PHÂN BỔ",
                style = MaterialTheme.typography.titleSmall,
                color = GymGreenBright,
                fontWeight = FontWeight.Bold
            )
        }

        items(gymReports) { rep ->
            val isTotal = rep == AllocatedReportType.GYM_TOTAL
            val amount = summary.totalForReport(rep)
            val count = summary.itemsForReport(rep).size
            ReportSummaryCard(
                reportType = rep,
                amount = amount,
                itemCount = count,
                accentColor = GymGreenBright,
                isHighlightTotal = isTotal,
                onClick = { onInspectReport(rep) }
            )
        }

        item {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "YOGA — 3 BÁO CÁO PHÂN BỔ",
                style = MaterialTheme.typography.titleSmall,
                color = YogaPurpleBright,
                fontWeight = FontWeight.Bold
            )
        }

        items(yogaReports) { rep ->
            val isTotal = rep == AllocatedReportType.YOGA_TOTAL
            val amount = summary.totalForReport(rep)
            val count = summary.itemsForReport(rep).size
            ReportSummaryCard(
                reportType = rep,
                amount = amount,
                itemCount = count,
                accentColor = YogaPurpleBright,
                isHighlightTotal = isTotal,
                onClick = { onInspectReport(rep) }
            )
        }
    }
}

@Composable
private fun ReportSummaryCard(
    reportType: AllocatedReportType,
    amount: Long,
    itemCount: Int,
    accentColor: Color,
    isHighlightTotal: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isHighlightTotal) accentColor.copy(alpha = 0.14f)
            else MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(if (isHighlightTotal) 1.8.dp else 1.dp, accentColor.copy(alpha = 0.6f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "${reportType.index}. ${reportType.title}",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = if (isHighlightTotal) FontWeight.Bold else FontWeight.SemiBold,
                    color = if (isHighlightTotal) accentColor else MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "$itemCount khoản mục",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = FitnessCalculator.formatCurrency(amount),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = accentColor
            )
        }
    }
}

@Composable
private fun MonthlyCashflowTab(
    summary: com.example.domain.MonthlyCashflowSummary,
    onYearMonthChange: (Int, Int) -> Unit
) {
    val context = LocalContext.current

    LazyColumn(
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            MonthYearPickerRow(
                year = summary.year,
                month = summary.month,
                onYearMonthChange = onYearMonthChange,
                accentColor = PriceTreEmOrange
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.2.dp, PriceTreEmOrange)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, tint = PriceTreEmOrange, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = "THỰC THU THÁNG ${summary.month}/${summary.year}",
                            style = MaterialTheme.typography.titleSmall,
                            color = PriceTreEmOrange,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = FitnessCalculator.formatCurrency(summary.totalCashflow),
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))
                    Text("Theo dịch vụ:", style = MaterialTheme.typography.labelLarge, color = PriceTreEmOrange)
                    DetailRow("• GYM:", FitnessCalculator.formatCurrency(summary.gymTotal))
                    DetailRow("• YOGA:", FitnessCalculator.formatCurrency(summary.yogaTotal))
                    DetailRow("• PT:", FitnessCalculator.formatCurrency(summary.ptTotal))
                    DetailRow("• Vé lẻ:", FitnessCalculator.formatCurrency(summary.singleTicketTotal))

                    HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))
                    Text("Theo phương thức thanh toán:", style = MaterialTheme.typography.labelLarge, color = PriceTreEmOrange)
                    DetailRow("• Chuyển khoản:", FitnessCalculator.formatCurrency(summary.pureTransferMethodTotal))
                    DetailRow("• Tiền mặt:", FitnessCalculator.formatCurrency(summary.pureCashMethodTotal))
                    DetailRow("• Kết hợp:", FitnessCalculator.formatCurrency(summary.combinedMethodTotal))
                    DetailRow("→ Thực thu Chuyển khoản:", FitnessCalculator.formatCurrency(summary.actualTransferReceived))
                    DetailRow("→ Thực thu Tiền mặt:", FitnessCalculator.formatCurrency(summary.actualCashReceived))

                    if (!summary.isReconciled) {
                        HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))
                        Text(
                            text = "CẢNH BÁO ĐỐI CHIẾU: Chênh lệch ${FitnessCalculator.formatCurrency(summary.reconciliationDifference)} (${summary.discrepancies.size} giao dịch không khớp Tiền mặt + Chuyển khoản)",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.error,
                            fontWeight = FontWeight.Bold
                        )
                        summary.discrepancies.forEach { d ->
                            Text(
                                text = "• ${d.title}: ${d.reason}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                val file = ReportExporter.exportMonthlyCashflowToPdf(context, summary)
                                ReportExporter.shareFile(
                                    context,
                                    file,
                                    ReportExporter.PDF_MIME_TYPE,
                                    "Xuất PDF: Báo cáo dòng tiền tháng ${summary.month}/${summary.year}"
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626), contentColor = Color.White),
                            modifier = Modifier
                                .weight(1f)
                                .height(42.dp)
                                .testTag("export_cashflow_pdf_button"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("PDF")
                        }

                        Button(
                            onClick = {
                                val file = ReportExporter.exportMonthlyCashflowToXlsx(context, summary)
                                ReportExporter.shareFile(
                                    context,
                                    file,
                                    ReportExporter.XLSX_MIME_TYPE,
                                    "Xuất Excel: Báo cáo dòng tiền tháng ${summary.month}/${summary.year}"
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = GymGreenBright, contentColor = Color.White),
                            modifier = Modifier
                                .weight(1f)
                                .height(42.dp)
                                .testTag("export_cashflow_excel_button"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.TableView, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Excel")
                        }

                        Button(
                            onClick = {
                                ReportExporter.shareMonthlyCashflowQuickText(context, summary)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7), contentColor = Color.White),
                            modifier = Modifier
                                .weight(1f)
                                .height(42.dp)
                                .testTag("export_cashflow_share_button"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Chia sẻ")
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "GIAO DỊCH TRONG THÁNG (${summary.transactions.size})",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
        }

        if (summary.transactions.isEmpty()) {
            item {
                Text(
                    text = "Chưa có giao dịch thu tiền trong tháng ${summary.month}/${summary.year}.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            items(summary.transactions, key = { it.id }) { tx ->
                val catColor = when (tx.serviceCategory) {
                    "GYM" -> GymGreenBright
                    "YOGA" -> YogaPurpleBright
                    "PT" -> PriceNuPink
                    else -> PriceTreEmOrange
                }
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = tx.title,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = catColor
                            )
                            Text(
                                text = "${FitnessCalculator.formatDisplayDate(tx.date)} • ${tx.subtitle}",
                                style = MaterialTheme.typography.bodySmall
                            )
                            Text(
                                text = PaymentMethod.fromCode(tx.paymentMethod).label +
                                    if (tx.paymentMethod == "COMBINED") {
                                        " (TM: ${FitnessCalculator.formatCurrency(tx.cashAmount)} + CK: ${FitnessCalculator.formatCurrency(tx.transferAmount)})"
                                    } else "",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            text = FitnessCalculator.formatCurrency(tx.paidAmount),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ExportSingleReportTab(
    summary: AllocatedMonthlySummary,
    cashflowSummary: com.example.domain.MonthlyCashflowSummary,
    onYearMonthChange: (Int, Int) -> Unit
) {
    val context = LocalContext.current
    var selectedReport by remember { mutableStateOf<AllocatedReportType?>(AllocatedReportType.GYM_TOTAL) }
    var isCashflowSelected by remember { mutableStateOf(false) }

    LazyColumn(
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            MonthYearPickerRow(
                year = summary.year,
                month = summary.month,
                onYearMonthChange = onYearMonthChange,
                accentColor = PriceTreEmOrange
            )
        }

        items(AllocatedReportType.entries) { rep ->
            val isSelected = !isCashflowSelected && selectedReport == rep
            val accent = if (rep.serviceCategory == "YOGA") YogaPurpleBright else GymGreenBright
            val amount = summary.totalForReport(rep)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        isCashflowSelected = false
                        selectedReport = rep
                    },
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) accent.copy(alpha = 0.12f)
                    else MaterialTheme.colorScheme.surface
                ),
                border = BorderStroke(if (isSelected) 1.8.dp else 1.dp, accent.copy(alpha = 0.6f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = isSelected,
                        onClick = {
                            isCashflowSelected = false
                            selectedReport = rep
                        }
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${rep.index}. ${rep.title}",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = FitnessCalculator.formatCurrency(amount),
                            style = MaterialTheme.typography.bodySmall,
                            color = accent,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        item {
            val isSelected = isCashflowSelected
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { isCashflowSelected = true }
                    .testTag("export_option_cashflow"),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) PriceTreEmOrange.copy(alpha = 0.12f)
                    else MaterialTheme.colorScheme.surface
                ),
                border = BorderStroke(if (isSelected) 1.8.dp else 1.dp, PriceTreEmOrange.copy(alpha = 0.6f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = isSelected,
                        onClick = { isCashflowSelected = true }
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "9. Báo cáo dòng tiền thực thu tháng",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = FitnessCalculator.formatCurrency(cashflowSummary.totalCashflow),
                            style = MaterialTheme.typography.bodySmall,
                            color = PriceTreEmOrange,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        if (isCashflowSelected) {
                            val file = ReportExporter.exportMonthlyCashflowToPdf(context, cashflowSummary)
                            ReportExporter.shareFile(
                                context,
                                file,
                                ReportExporter.PDF_MIME_TYPE,
                                "Xuất PDF: Báo cáo dòng tiền tháng ${cashflowSummary.month}/${cashflowSummary.year}"
                            )
                        } else {
                            val rep = selectedReport ?: AllocatedReportType.GYM_TOTAL
                            val file = ReportExporter.exportSingleAllocatedReportToPdf(context, rep, summary)
                            ReportExporter.shareFile(context, file, ReportExporter.PDF_MIME_TYPE, "Xuất PDF: ${rep.title}")
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626), contentColor = Color.White),
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp)
                        .testTag("export_single_pdf_button"),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("PDF")
                }

                Button(
                    onClick = {
                        if (isCashflowSelected) {
                            val file = ReportExporter.exportMonthlyCashflowToXlsx(context, cashflowSummary)
                            ReportExporter.shareFile(
                                context,
                                file,
                                ReportExporter.XLSX_MIME_TYPE,
                                "Xuất Excel: Báo cáo dòng tiền tháng ${cashflowSummary.month}/${cashflowSummary.year}"
                            )
                        } else {
                            val rep = selectedReport ?: AllocatedReportType.GYM_TOTAL
                            val file = ReportExporter.exportSingleAllocatedReportToXlsx(context, rep, summary)
                            ReportExporter.shareFile(context, file, ReportExporter.XLSX_MIME_TYPE, "Xuất Excel: ${rep.title}")
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GymGreenBright, contentColor = Color.White),
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp)
                        .testTag("export_single_excel_button"),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.TableView, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Excel")
                }

                Button(
                    onClick = {
                        if (isCashflowSelected) {
                            ReportExporter.shareMonthlyCashflowQuickText(context, cashflowSummary)
                        } else {
                            val rep = selectedReport ?: AllocatedReportType.GYM_TOTAL
                            ReportExporter.shareAllocatedReportQuickText(context, rep, summary)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7), contentColor = Color.White),
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp)
                        .testTag("export_single_share_button"),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Chia sẻ")
                }
            }
        }
    }
}

