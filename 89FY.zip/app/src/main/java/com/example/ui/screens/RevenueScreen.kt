package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.export.ReportTableData
import com.example.domain.DateCalculator
import com.example.domain.FormatUtils
import com.example.domain.RevenueAllocationEngine
import com.example.ui.AppDataSnapshot
import com.example.ui.GymReportType
import com.example.ui.YogaReportType
import com.example.ui.theme.*
import java.util.Calendar

/**
 * Revenue & Report Export Screen (Sections 8, 9, 10, 11):
 * - Separated Gym (5 reports) & Yoga (3 reports)
 * - Month & Year selector
 * - Daily proration formula: ROUND(Contract Value / Total Effective Days * Effective Days in Month)
 * - PT 50% Gym share allocated by actual sessions trained in the selected month
 * - Dedicated Report Preview & Export Sub-Section (Excel & PDF with Android Share)
 */
@Composable
fun RevenueScreen(
    initialDomain: String,
    snapshot: AppDataSnapshot,
    onBack: () -> Unit,
    onExportReport: (ReportTableData, Boolean) -> Unit
) {
    val currentCal = remember { Calendar.getInstance() }
    var selectedDomain by remember(initialDomain) { mutableStateOf(initialDomain) }
    var selectedMonth by remember { mutableIntStateOf(currentCal.get(Calendar.MONTH) + 1) }
    var selectedYear by remember { mutableIntStateOf(currentCal.get(Calendar.YEAR)) }

    var selectedGymReport by remember { mutableStateOf(GymReportType.TOTAL_GYM) }
    var selectedYogaReport by remember { mutableStateOf(YogaReportType.TOTAL_YOGA) }

    val membersById = remember(snapshot.members) { snapshot.members.associateBy { it.id } }
    val ptClientsById = remember(snapshot.ptClients) { snapshot.ptClients.associateBy { it.id } }

    // Build Contract Allocation Inputs for selected domain
    val contractInputs = remember(snapshot.contracts, membersById, selectedDomain) {
        snapshot.contracts
            .filter { it.domain == selectedDomain && (!it.isDeleted || it.deleteType == "CONTRACT_CANCELLED") }
            .map { c ->
                val memberName = membersById[c.memberId]?.fullName ?: "Hội viên"
                RevenueAllocationEngine.ContractAllocationInput(
                    contractId = c.id,
                    contractCode = c.contractCode,
                    memberId = c.memberId,
                    memberName = memberName,
                    durationMonths = c.durationMonths,
                    startDateIso = c.startDateIso,
                    endDateIso = c.endDateIso,
                    agreedValueVnd = c.agreedValueVnd,
                    isRenewal = c.contractType == "RENEWAL",
                    isCancelled = c.status == "CANCELLED",
                    cancelledDateIso = c.cancelledDateIso,
                    refundedAmountVnd = c.refundedAmountVnd
                )
            }
    }

    val (newMemberRows, newMemberTotalVnd) = remember(contractInputs, selectedYear, selectedMonth) {
        RevenueAllocationEngine.calculateMonthlyContractReport(
            contracts = contractInputs.filter { !it.isRenewal },
            year = selectedYear,
            month = selectedMonth
        )
    }

    val (renewalMemberRows, renewalMemberTotalVnd) = remember(contractInputs, selectedYear, selectedMonth) {
        RevenueAllocationEngine.calculateMonthlyContractReport(
            contracts = contractInputs.filter { it.isRenewal },
            year = selectedYear,
            month = selectedMonth
        )
    }

    // PT Allocation for Gym (50% Gym share based on sessions completed in selectedMonth/selectedYear)
    val (ptRows, ptTotalGymVnd) = remember(snapshot.ptContracts, snapshot.ptSessions, ptClientsById, selectedYear, selectedMonth) {
        val monthSessionsByContract = snapshot.ptSessions.filter { s ->
            val ym = DateCalculator.getYearMonth(s.sessionDateIso)
            ym != null && ym.first == selectedYear && ym.second == selectedMonth
        }.groupBy { it.ptContractId }

        val rows = snapshot.ptContracts.filter { !it.isDeleted }.mapNotNull { ptc ->
            val sessionsInMonth = (monthSessionsByContract[ptc.id] ?: emptyList()).sumOf { it.sessionsUsed }
            if (sessionsInMonth <= 0) null
            else {
                val clientName = ptClientsById[ptc.ptClientId]?.fullName ?: "Khách PT"
                RevenueAllocationEngine.allocatePtForMonth(
                    RevenueAllocationEngine.PtAllocationInput(
                        ptContractId = ptc.id,
                        contractCode = ptc.contractCode,
                        clientName = clientName,
                        registerDateIso = ptc.registerDateIso,
                        totalSessions = ptc.totalSessions,
                        agreedValueVnd = ptc.agreedValueVnd,
                        sessionsInTargetMonth = sessionsInMonth
                    )
                )
            }
        }
        rows to rows.sumOf { it.gymAllocatedRevenueVnd }
    }

    // Short-term Tickets for Gym in selectedMonth/selectedYear
    val (monthTickets, ticketsTotalVnd) = remember(snapshot.shortTermTickets, selectedYear, selectedMonth) {
        val list = snapshot.shortTermTickets.filter { t ->
            !t.isDeleted && DateCalculator.getYearMonth(t.saleDateIso) == (selectedYear to selectedMonth)
        }
        list to list.sumOf { it.totalAmountVnd }
    }

    val totalGymRevenueVnd = newMemberTotalVnd + renewalMemberTotalVnd + ptTotalGymVnd + ticketsTotalVnd
    val totalYogaRevenueVnd = newMemberTotalVnd + renewalMemberTotalVnd

    // Build ReportTableData for current selection (used both for preview & Excel/PDF export)
    val currentReportTable = remember(
        selectedDomain,
        selectedMonth,
        selectedYear,
        selectedGymReport,
        selectedYogaReport,
        newMemberRows,
        renewalMemberRows,
        ptRows,
        monthTickets,
        totalGymRevenueVnd,
        totalYogaRevenueVnd
    ) {
        val periodStr = String.format("%02d/%04d", selectedMonth, selectedYear)
        val filePeriod = String.format("%02d_%04d", selectedMonth, selectedYear)

        if (selectedDomain == "GYM") {
            when (selectedGymReport) {
                GymReportType.NEW_MEMBERS -> buildContractReportTable(
                    title = "BÁO CÁO DOANH THU PHÂN BỔ HỘI VIÊN GYM ĐĂNG KÝ MỚI",
                    periodStr = periodStr,
                    filePrefix = "Bao_cao_Gym_Dang_ky_moi_$filePeriod",
                    rows = newMemberRows,
                    totalVnd = newMemberTotalVnd
                )
                GymReportType.RENEWAL_MEMBERS -> buildContractReportTable(
                    title = "BÁO CÁO DOANH THU PHÂN BỔ HỘI VIÊN GYM GIA HẠN",
                    periodStr = periodStr,
                    filePrefix = "Bao_cao_Gym_Gia_han_$filePeriod",
                    rows = renewalMemberRows,
                    totalVnd = renewalMemberTotalVnd
                )
                GymReportType.PT_REVENUE -> ReportTableData(
                    reportTitle = "BÁO CÁO DOANH THU PHÂN BỔ PT (50% THUỘC GYM - HLV HÀ ĐỨC)",
                    subtitle = "Kỳ báo cáo: Tháng $periodStr",
                    fileNamePrefix = "Bao_cao_Gym_PT_$filePeriod",
                    headers = listOf("STT", "Họ và tên", "Ngày đăng ký", "Số buổi ĐK", "Giá trị HĐ", "Số buổi tập T$selectedMonth", "Doanh thu Gym (50%)"),
                    rows = ptRows.mapIndexed { idx, r ->
                        listOf(
                            FormatUtils.formatStt(idx + 1),
                            r.clientName,
                            DateCalculator.formatDisplay(r.registerDateIso),
                            "${r.totalSessions}",
                            FormatUtils.formatVnd(r.agreedValueVnd),
                            "${r.sessionsInMonth}",
                            FormatUtils.formatVnd(r.gymAllocatedRevenueVnd)
                        )
                    },
                    numericColumnIndices = setOf(3, 4, 5, 6),
                    summaryLines = listOf(
                        "Tổng doanh thu PT thuộc về Gym (50%)" to FormatUtils.formatVnd(ptTotalGymVnd)
                    )
                )
                GymReportType.TICKETS_REVENUE -> ReportTableData(
                    reportTitle = "BÁO CÁO DOANH THU VÉ NGÀY VÀ VÉ TUẦN GYM",
                    subtitle = "Kỳ báo cáo: Tháng $periodStr",
                    fileNamePrefix = "Bao_cao_Gym_Ve_ngay_tuan_$filePeriod",
                    headers = listOf("STT", "Mã GD", "Loại vé", "Ngày bán", "Số lượng", "Đơn giá", "Thành tiền", "Thanh toán"),
                    rows = monthTickets.mapIndexed { idx, t ->
                        listOf(
                            FormatUtils.formatStt(idx + 1),
                            t.ticketCode,
                            if (t.ticketType == "VE_NGAY") "Vé ngày" else "Vé tuần",
                            DateCalculator.formatDisplay(t.saleDateIso),
                            "${t.quantity}",
                            FormatUtils.formatVnd(t.unitPriceVnd),
                            FormatUtils.formatVnd(t.totalAmountVnd),
                            t.paymentMethodLabel
                        )
                    },
                    numericColumnIndices = setOf(4, 5, 6),
                    summaryLines = listOf(
                        "Tổng doanh thu vé ngày & vé tuần" to FormatUtils.formatVnd(ticketsTotalVnd)
                    )
                )
                GymReportType.TOTAL_GYM -> ReportTableData(
                    reportTitle = "BÁO CÁO TỔNG DOANH THU PHÂN BỔ GYM",
                    subtitle = "Kỳ báo cáo: Tháng $periodStr (Tổng hợp 4 báo cáo thành phần)",
                    fileNamePrefix = "Bao_cao_Tong_Doanh_thu_Gym_$filePeriod",
                    headers = listOf("STT", "Hạng mục báo cáo thành phần", "Số lượng bản ghi", "Doanh thu phân bổ tháng"),
                    rows = listOf(
                        listOf("01", "Doanh thu phân bổ hội viên đăng ký mới", "${newMemberRows.size} HĐ", FormatUtils.formatVnd(newMemberTotalVnd)),
                        listOf("02", "Doanh thu phân bổ hội viên gia hạn", "${renewalMemberRows.size} HĐ", FormatUtils.formatVnd(renewalMemberTotalVnd)),
                        listOf("03", "Doanh thu phân bổ PT (50% thuộc Gym)", "${ptRows.size} HĐ PT", FormatUtils.formatVnd(ptTotalGymVnd)),
                        listOf("04", "Doanh thu vé ngày và vé tuần", "${monthTickets.size} giao dịch", FormatUtils.formatVnd(ticketsTotalVnd))
                    ),
                    numericColumnIndices = setOf(3),
                    summaryLines = listOf(
                        "TỔNG DOANH THU GYM THÁNG $periodStr" to FormatUtils.formatVnd(totalGymRevenueVnd)
                    )
                )
            }
        } else {
            when (selectedYogaReport) {
                YogaReportType.NEW_MEMBERS -> buildContractReportTable(
                    title = "BÁO CÁO DOANH THU PHÂN BỔ HỘI VIÊN YOGA ĐĂNG KÝ MỚI",
                    periodStr = periodStr,
                    filePrefix = "Bao_cao_Yoga_Dang_ky_moi_$filePeriod",
                    rows = newMemberRows,
                    totalVnd = newMemberTotalVnd
                )
                YogaReportType.RENEWAL_MEMBERS -> buildContractReportTable(
                    title = "BÁO CÁO DOANH THU PHÂN BỔ HỘI VIÊN YOGA GIA HẠN",
                    periodStr = periodStr,
                    filePrefix = "Bao_cao_Yoga_Gia_han_$filePeriod",
                    rows = renewalMemberRows,
                    totalVnd = renewalMemberTotalVnd
                )
                YogaReportType.TOTAL_YOGA -> ReportTableData(
                    reportTitle = "BÁO CÁO TỔNG DOANH THU PHÂN BỔ YOGA",
                    subtitle = "Kỳ báo cáo: Tháng $periodStr (Tổng hợp 2 báo cáo thành phần)",
                    fileNamePrefix = "Bao_cao_Tong_Doanh_thu_Yoga_$filePeriod",
                    headers = listOf("STT", "Hạng mục báo cáo thành phần", "Số lượng bản ghi", "Doanh thu phân bổ tháng"),
                    rows = listOf(
                        listOf("01", "Doanh thu phân bổ hội viên Yoga đăng ký mới", "${newMemberRows.size} HĐ", FormatUtils.formatVnd(newMemberTotalVnd)),
                        listOf("02", "Doanh thu phân bổ hội viên Yoga gia hạn", "${renewalMemberRows.size} HĐ", FormatUtils.formatVnd(renewalMemberTotalVnd))
                    ),
                    numericColumnIndices = setOf(3),
                    summaryLines = listOf(
                        "TỔNG DOANH THU YOGA THÁNG $periodStr" to FormatUtils.formatVnd(totalYogaRevenueVnd)
                    )
                )
            }
        }
    }

    Scaffold(
        topBar = {
            FitnessTopAppBar(
                title = "Doanh thu & Xuất báo cáo",
                subtitle = "Phân bổ theo số ngày hiệu lực thực tế",
                domainBadge = selectedDomain,
                onBackClick = onBack
            )
        }
    ) { innerPadding ->
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // 1. Domain & Period Selector Card
            item {
                ElevatedCard(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            FilterChip(
                                selected = selectedDomain == "GYM",
                                onClick = { selectedDomain = "GYM" },
                                label = { Text("Báo cáo GYM (5)") },
                                leadingIcon = { Icon(Icons.Default.FitnessCenter, contentDescription = null) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("revenue_domain_gym")
                            )
                            FilterChip(
                                selected = selectedDomain == "YOGA",
                                onClick = { selectedDomain = "YOGA" },
                                label = { Text("Báo cáo YOGA (3)") },
                                leadingIcon = { Icon(Icons.Default.SelfImprovement, contentDescription = null) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("revenue_domain_yoga")
                            )
                        }

                        // Month & Year Picker Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Kỳ báo cáo:",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                FilledTonalIconButton(
                                    onClick = {
                                        if (selectedMonth == 1) {
                                            selectedMonth = 12
                                            selectedYear--
                                        } else {
                                            selectedMonth--
                                        }
                                    },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(Icons.Default.ChevronLeft, contentDescription = "Tháng trước")
                                }
                                Text(
                                    text = String.format("Tháng %02d / %04d", selectedMonth, selectedYear),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                FilledTonalIconButton(
                                    onClick = {
                                        if (selectedMonth == 12) {
                                            selectedMonth = 1
                                            selectedYear++
                                        } else {
                                            selectedMonth++
                                        }
                                    },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(Icons.Default.ChevronRight, contentDescription = "Tháng sau")
                                }
                            }
                        }
                    }
                }
            }

            // 2. Total Summary Banner & Component Breakdown
            item {
                val grandTotal = if (selectedDomain == "GYM") totalGymRevenueVnd else totalYogaRevenueVnd
                val bannerColor = if (selectedDomain == "GYM") GymEmeraldLight else YogaIndigoLight

                Card(
                    colors = CardDefaults.cardColors(containerColor = bannerColor),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "TỔNG DOANH THU PHÂN BỔ $selectedDomain (THÁNG $selectedMonth/$selectedYear)",
                            style = MaterialTheme.typography.labelMedium,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                        Text(
                            text = FormatUtils.formatVnd(grandTotal),
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            modifier = Modifier.testTag("revenue_grand_total_text")
                        )
                        HorizontalDivider(color = Color.White.copy(alpha = 0.25f))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "ĐK mới: ${FormatUtils.formatVnd(newMemberTotalVnd)}",
                                style = MaterialTheme.typography.labelMedium,
                                color = Color.White
                            )
                            Text(
                                text = "Gia hạn: ${FormatUtils.formatVnd(renewalMemberTotalVnd)}",
                                style = MaterialTheme.typography.labelMedium,
                                color = Color.White
                            )
                        }
                        if (selectedDomain == "GYM") {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "PT (50% Gym): ${FormatUtils.formatVnd(ptTotalGymVnd)}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = Color.White
                                )
                                Text(
                                    text = "Vé ngày/tuần: ${FormatUtils.formatVnd(ticketsTotalVnd)}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }

            // 3. Report Type Selector
            item {
                Text(
                    text = "Chọn báo cáo chi tiết để xem trước & xuất tệp:",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (selectedDomain == "GYM") {
                        GymReportType.entries.forEach { report ->
                            FilterChip(
                                selected = selectedGymReport == report,
                                onClick = { selectedGymReport = report },
                                label = { Text(report.title) }
                            )
                        }
                    } else {
                        YogaReportType.entries.forEach { report ->
                            FilterChip(
                                selected = selectedYogaReport == report,
                                onClick = { selectedYogaReport = report },
                                label = { Text(report.title) }
                            )
                        }
                    }
                }
            }

            // 4. Dedicated Export Sub-Section (Section 11)
            item {
                ElevatedCard(
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "Phân hệ Xuất Báo Cáo & Chia sẻ (Excel / PDF)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Đang chọn: ${currentReportTable.reportTitle} (${currentReportTable.rows.size} dòng)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = { onExportReport(currentReportTable, true) },
                                colors = ButtonDefaults.buttonColors(containerColor = GymEmeraldLight),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("export_revenue_excel_btn")
                            ) {
                                Icon(Icons.Default.TableView, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Xuất Excel & Chia sẻ")
                            }
                            Button(
                                onClick = { onExportReport(currentReportTable, false) },
                                colors = ButtonDefaults.buttonColors(containerColor = YogaIndigoLight),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("export_revenue_pdf_btn")
                            ) {
                                Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Xuất PDF & Chia sẻ")
                            }
                        }
                    }
                }
            }

            // 5. Data Preview Rows (Section 10)
            item {
                Text(
                    text = "Xem trước dữ liệu báo cáo (${currentReportTable.rows.size} bản ghi)",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
            }

            if (currentReportTable.rows.isEmpty()) {
                item {
                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Không có dữ liệu phát sinh doanh thu phân bổ trong tháng $selectedMonth/$selectedYear cho báo cáo này.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
            } else {
                itemsIndexed(currentReportTable.rows) { _, row ->
                    OutlinedCard(
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            currentReportTable.headers.forEachIndexed { colIdx, header ->
                                val cellVal = row.getOrNull(colIdx) ?: ""
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = header,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = cellVal,
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = if (colIdx == currentReportTable.headers.lastIndex) {
                                            FontWeight.Bold
                                        } else {
                                            FontWeight.Normal
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun buildContractReportTable(
    title: String,
    periodStr: String,
    filePrefix: String,
    rows: List<RevenueAllocationEngine.ContractAllocationRow>,
    totalVnd: Long
): ReportTableData {
    // Required columns per Section 10:
    // STT | Họ và tên | Số tháng đăng ký | Ngày đăng ký | Ngày hết hạn | Giá trị hợp đồng | Doanh thu phân bổ tháng
    val headers = listOf(
        "STT",
        "Họ và tên",
        "Số tháng ĐK",
        "Ngày đăng ký",
        "Ngày hết hạn",
        "Ngày hiệu lực T/Tổng",
        "Giá trị hợp đồng",
        "Doanh thu phân bổ tháng"
    )
    val tableRows = rows.mapIndexed { idx, r ->
        listOf(
            FormatUtils.formatStt(idx + 1),
            r.memberName,
            "${r.durationMonths} tháng",
            DateCalculator.formatDisplay(r.startDateIso),
            DateCalculator.formatDisplay(r.endDateIso),
            "${r.effectiveDaysInMonth}/${r.totalEffectiveDays} ngày",
            FormatUtils.formatVnd(r.agreedValueVnd),
            FormatUtils.formatVnd(r.allocatedRevenueVnd)
        )
    }
    return ReportTableData(
        reportTitle = title,
        subtitle = "Kỳ báo cáo: Tháng $periodStr (Làm tròn đến đồng cho từng HĐ trước khi cộng tổng)",
        fileNamePrefix = filePrefix,
        headers = headers,
        rows = tableRows,
        numericColumnIndices = setOf(6, 7),
        summaryLines = listOf(
            "Tổng doanh thu phân bổ tháng $periodStr" to FormatUtils.formatVnd(totalVnd)
        )
    )
}
