package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.export.ReportTableData
import com.example.domain.DateCalculator
import com.example.domain.FormatUtils
import com.example.domain.RevenueAllocationEngine
import com.example.ui.AppDataSnapshot
import com.example.ui.GymReportType
import com.example.ui.YogaReportType
import com.example.ui.theme.*
import java.util.Calendar

/**
 * Revenue & Report Export Module (Section 7 of Upgrade PRD):
 * - Section 7.1: Main Revenue Screen has 3 square tiles (`GridCells.Fixed(3)`):
 *   1. Doanh thu Gym
 *   2. Doanh thu Yoga
 *   3. Xuất báo cáo
 * - Section 7.2: Gym Revenue displays New Members, Renewals, PT, Daily Tickets, Weekly Tickets, Total Gym Revenue
 * - Section 7.3: Yoga Revenue is strictly independent from Gym
 * - Section 7.4: Report Export supports the exact 8 reports (5 Gym + 3 Yoga) to real Excel & PDF files saved on device
 * - Section 7.5: Compact month/year selector across all views
 */
@Composable
fun RevenueScreen(
    initialSubScreen: Int = 0,
    snapshot: AppDataSnapshot,
    onBack: () -> Unit,
    onExportReport: (ReportTableData, Boolean) -> Unit
) {
    val currentCal = remember { Calendar.getInstance() }
    // 0 = Main 3-tile screen, 1 = Doanh thu Gym, 2 = Doanh thu Yoga, 3 = Xuất báo cáo
    var subScreen by remember(initialSubScreen) { mutableIntStateOf(initialSubScreen) }
    var selectedMonth by remember { mutableIntStateOf(currentCal.get(Calendar.MONTH) + 1) }
    var selectedYear by remember { mutableIntStateOf(currentCal.get(Calendar.YEAR)) }

    var exportDomain by remember { mutableStateOf("GYM") }
    var selectedGymReport by remember { mutableStateOf(GymReportType.TOTAL_GYM) }
    var selectedYogaReport by remember { mutableStateOf(YogaReportType.TOTAL_YOGA) }

    BackHandler(enabled = subScreen != 0) {
        subScreen = 0
    }

    val membersById = remember(snapshot.members) { snapshot.members.associateBy { it.id } }
    val ptClientsById = remember(snapshot.ptClients) { snapshot.ptClients.associateBy { it.id } }

    // --- Gym Calculations ---
    val gymContractInputs = remember(snapshot.contracts, membersById) {
        snapshot.contracts
            .filter { it.domain == "GYM" && (!it.isDeleted || it.deleteType == "CONTRACT_CANCELLED") }
            .map { c ->
                RevenueAllocationEngine.ContractAllocationInput(
                    contractId = c.id,
                    contractCode = c.contractCode,
                    memberId = c.memberId,
                    memberName = membersById[c.memberId]?.fullName ?: "Hội viên",
                    durationMonths = c.durationMonths,
                    startDateIso = c.startDateIso,
                    endDateIso = c.endDateIso,
                    agreedValueVnd = c.agreedValueVnd,
                    isRenewal = c.contractType == "RENEWAL",
                    isCancelled = c.status == "CANCELLED",
                    cancelledDateIso = c.cancelledDateIso,
                    refundedAmountVnd = c.refundedAmountVnd
                )
            }
    }

    val (gymNewRows, gymNewTotalVnd) = remember(gymContractInputs, selectedYear, selectedMonth) {
        RevenueAllocationEngine.calculateMonthlyContractReport(
            contracts = gymContractInputs.filter { !it.isRenewal },
            year = selectedYear,
            month = selectedMonth
        )
    }

    val (gymRenewalRows, gymRenewalTotalVnd) = remember(gymContractInputs, selectedYear, selectedMonth) {
        RevenueAllocationEngine.calculateMonthlyContractReport(
            contracts = gymContractInputs.filter { it.isRenewal },
            year = selectedYear,
            month = selectedMonth
        )
    }

    val (ptRows, ptTotalGymVnd) = remember(snapshot.ptContracts, snapshot.ptSessions, ptClientsById, selectedYear, selectedMonth) {
        val monthSessionsByContract = snapshot.ptSessions.filter { s ->
            val ym = DateCalculator.getYearMonth(s.sessionDateIso)
            ym != null && ym.first == selectedYear && ym.second == selectedMonth
        }.groupBy { it.ptContractId }

        val rows = snapshot.ptContracts.filter { !it.isDeleted }.mapNotNull { ptc ->
            val sessionsInMonth = (monthSessionsByContract[ptc.id] ?: emptyList()).sumOf { it.sessionsUsed }
            if (sessionsInMonth <= 0) null
            else {
                val clientName = ptClientsById[ptc.ptClientId]?.fullName ?: "Khách PT"
                RevenueAllocationEngine.allocatePtForMonth(
                    RevenueAllocationEngine.PtAllocationInput(
                        ptContractId = ptc.id,
                        contractCode = ptc.contractCode,
                        clientName = clientName,
                        registerDateIso = ptc.registerDateIso,
                        totalSessions = ptc.totalSessions,
                        agreedValueVnd = ptc.agreedValueVnd,
                        sessionsInTargetMonth = sessionsInMonth
                    )
                )
            }
        }
        rows to rows.sumOf { it.gymAllocatedRevenueVnd }
    }

    val monthTickets = remember(snapshot.shortTermTickets, selectedYear, selectedMonth) {
        snapshot.shortTermTickets.filter { t ->
            !t.isDeleted && DateCalculator.getYearMonth(t.saleDateIso) == (selectedYear to selectedMonth)
        }
    }
    val dailyTicketsTotalVnd = remember(monthTickets) {
        monthTickets.filter { it.ticketType == "VE_NGAY" }.sumOf { it.totalAmountVnd }
    }
    val weeklyTicketsTotalVnd = remember(monthTickets) {
        monthTickets.filter { it.ticketType == "VE_TUAN" }.sumOf { it.totalAmountVnd }
    }
    val ticketsTotalVnd = dailyTicketsTotalVnd + weeklyTicketsTotalVnd
    val totalGymRevenueVnd = gymNewTotalVnd + gymRenewalTotalVnd + ptTotalGymVnd + ticketsTotalVnd

    // --- Yoga Calculations (Strictly independent from Gym) ---
    val yogaContractInputs = remember(snapshot.contracts, membersById) {
        snapshot.contracts
            .filter { it.domain == "YOGA" && (!it.isDeleted || it.deleteType == "CONTRACT_CANCELLED") }
            .map { c ->
                RevenueAllocationEngine.ContractAllocationInput(
                    contractId = c.id,
                    contractCode = c.contractCode,
                    memberId = c.memberId,
                    memberName = membersById[c.memberId]?.fullName ?: "Hội viên",
                    durationMonths = c.durationMonths,
                    startDateIso = c.startDateIso,
                    endDateIso = c.endDateIso,
                    agreedValueVnd = c.agreedValueVnd,
                    isRenewal = c.contractType == "RENEWAL",
                    isCancelled = c.status == "CANCELLED",
                    cancelledDateIso = c.cancelledDateIso,
                    refundedAmountVnd = c.refundedAmountVnd
                )
            }
    }

    val (yogaNewRows, yogaNewTotalVnd) = remember(yogaContractInputs, selectedYear, selectedMonth) {
        RevenueAllocationEngine.calculateMonthlyContractReport(
            contracts = yogaContractInputs.filter { !it.isRenewal },
            year = selectedYear,
            month = selectedMonth
        )
    }

    val (yogaRenewalRows, yogaRenewalTotalVnd) = remember(yogaContractInputs, selectedYear, selectedMonth) {
        RevenueAllocationEngine.calculateMonthlyContractReport(
            contracts = yogaContractInputs.filter { it.isRenewal },
            year = selectedYear,
            month = selectedMonth
        )
    }
    val totalYogaRevenueVnd = yogaNewTotalVnd + yogaRenewalTotalVnd

    // Build ReportTableData for the 8 required reports (5 Gym + 3 Yoga)
    val currentReportTable = remember(
        exportDomain,
        selectedMonth,
        selectedYear,
        selectedGymReport,
        selectedYogaReport,
        gymNewRows,
        gymRenewalRows,
        ptRows,
        monthTickets,
        totalGymRevenueVnd,
        yogaNewRows,
        yogaRenewalRows,
        totalYogaRevenueVnd
    ) {
        val periodStr = String.format("%02d/%04d", selectedMonth, selectedYear)
        val filePeriod = String.format("%02d_%04d", selectedMonth, selectedYear)

        if (exportDomain == "GYM") {
            when (selectedGymReport) {
                GymReportType.NEW_MEMBERS -> buildContractReportTable(
                    title = "BÁO CÁO DOANH THU PHÂN BỔ HỘI VIÊN GYM ĐĂNG KÝ MỚI",
                    periodStr = periodStr,
                    filePrefix = "Bao_cao_Gym_Dang_ky_moi_$filePeriod",
                    rows = gymNewRows,
                    totalVnd = gymNewTotalVnd
                )
                GymReportType.RENEWAL_MEMBERS -> buildContractReportTable(
                    title = "BÁO CÁO DOANH THU PHÂN BỔ HỘI VIÊN GYM GIA HẠN",
                    periodStr = periodStr,
                    filePrefix = "Bao_cao_Gym_Gia_han_$filePeriod",
                    rows = gymRenewalRows,
                    totalVnd = gymRenewalTotalVnd
                )
                GymReportType.PT_REVENUE -> ReportTableData(
                    reportTitle = "BÁO CÁO DOANH THU PHÂN BỔ PT (50% THUỘC GYM - HLV HÀ ĐỨC)",
                    subtitle = "Kỳ báo cáo: Tháng $periodStr",
                    fileNamePrefix = "Bao_cao_Gym_PT_$filePeriod",
                    headers = listOf("STT", "Họ và tên", "Ngày đăng ký", "Số buổi ĐK", "Giá trị HĐ", "Số buổi tập T$selectedMonth", "Doanh thu Gym (50%)"),
                    rows = ptRows.mapIndexed { idx, r ->
                        listOf(
                            FormatUtils.formatStt(idx + 1),
                            r.clientName,
                            DateCalculator.formatDisplay(r.registerDateIso),
                            "${r.totalSessions}",
                            FormatUtils.formatVnd(r.agreedValueVnd),
                            "${r.sessionsInMonth}",
                            FormatUtils.formatVnd(r.gymAllocatedRevenueVnd)
                        )
                    },
                    numericColumnIndices = setOf(3, 4, 5, 6),
                    summaryLines = listOf(
                        "Tổng doanh thu PT thuộc về Gym (50%)" to FormatUtils.formatVnd(ptTotalGymVnd)
                    )
                )
                GymReportType.TICKETS_REVENUE -> ReportTableData(
                    reportTitle = "BÁO CÁO DOANH THU VÉ NGÀY VÀ VÉ TUẦN GYM",
                    subtitle = "Kỳ báo cáo: Tháng $periodStr",
                    fileNamePrefix = "Bao_cao_Gym_Ve_ngay_tuan_$filePeriod",
                    headers = listOf("STT", "Mã GD", "Loại vé", "Ngày bán", "Số lượng", "Đơn giá", "Thành tiền", "Thanh toán"),
                    rows = monthTickets.mapIndexed { idx, t ->
                        listOf(
                            FormatUtils.formatStt(idx + 1),
                            t.ticketCode,
                            if (t.ticketType == "VE_NGAY") "Vé ngày" else "Vé tuần",
                            DateCalculator.formatDisplay(t.saleDateIso),
                            "${t.quantity}",
                            FormatUtils.formatVnd(t.unitPriceVnd),
                            FormatUtils.formatVnd(t.totalAmountVnd),
                            t.paymentMethodLabel
                        )
                    },
                    numericColumnIndices = setOf(4, 5, 6),
                    summaryLines = listOf(
                        "Doanh thu vé ngày" to FormatUtils.formatVnd(dailyTicketsTotalVnd),
                        "Doanh thu vé tuần" to FormatUtils.formatVnd(weeklyTicketsTotalVnd),
                        "Tổng doanh thu vé ngày & vé tuần" to FormatUtils.formatVnd(ticketsTotalVnd)
                    )
                )
                GymReportType.TOTAL_GYM -> ReportTableData(
                    reportTitle = "BÁO CÁO TỔNG DOANH THU PHÂN BỔ GYM",
                    subtitle = "Kỳ báo cáo: Tháng $periodStr",
                    fileNamePrefix = "Bao_cao_Tong_Doanh_thu_Gym_$filePeriod",
                    headers = listOf("STT", "Hạng mục báo cáo", "Số lượng", "Doanh thu phân bổ tháng"),
                    rows = listOf(
                        listOf("01", "Doanh thu hội viên mới", "${gymNewRows.size} HĐ", FormatUtils.formatVnd(gymNewTotalVnd)),
                        listOf("02", "Doanh thu gia hạn", "${gymRenewalRows.size} HĐ", FormatUtils.formatVnd(gymRenewalTotalVnd)),
                        listOf("03", "Doanh thu PT (50% thuộc Gym)", "${ptRows.size} HĐ PT", FormatUtils.formatVnd(ptTotalGymVnd)),
                        listOf("04", "Doanh thu vé ngày", "${monthTickets.count { it.ticketType == "VE_NGAY" }} GD", FormatUtils.formatVnd(dailyTicketsTotalVnd)),
                        listOf("05", "Doanh thu vé tuần", "${monthTickets.count { it.ticketType == "VE_TUAN" }} GD", FormatUtils.formatVnd(weeklyTicketsTotalVnd))
                    ),
                    numericColumnIndices = setOf(3),
                    summaryLines = listOf(
                        "TỔNG DOANH THU GYM THÁNG $periodStr" to FormatUtils.formatVnd(totalGymRevenueVnd)
                    )
                )
            }
        } else {
            when (selectedYogaReport) {
                YogaReportType.NEW_MEMBERS -> buildContractReportTable(
                    title = "BÁO CÁO DOANH THU PHÂN BỔ HỘI VIÊN YOGA ĐĂNG KÝ MỚI",
                    periodStr = periodStr,
                    filePrefix = "Bao_cao_Yoga_Dang_ky_moi_$filePeriod",
                    rows = yogaNewRows,
                    totalVnd = yogaNewTotalVnd
                )
                YogaReportType.RENEWAL_MEMBERS -> buildContractReportTable(
                    title = "BÁO CÁO DOANH THU PHÂN BỔ HỘI VIÊN YOGA GIA HẠN",
                    periodStr = periodStr,
                    filePrefix = "Bao_cao_Yoga_Gia_han_$filePeriod",
                    rows = yogaRenewalRows,
                    totalVnd = yogaRenewalTotalVnd
                )
                YogaReportType.TOTAL_YOGA -> ReportTableData(
                    reportTitle = "BÁO CÁO TỔNG DOANH THU PHÂN BỔ YOGA",
                    subtitle = "Kỳ báo cáo: Tháng $periodStr",
                    fileNamePrefix = "Bao_cao_Tong_Doanh_thu_Yoga_$filePeriod",
                    headers = listOf("STT", "Hạng mục báo cáo", "Số lượng", "Doanh thu phân bổ tháng"),
                    rows = listOf(
                        listOf("01", "Doanh thu hội viên mới Yoga", "${yogaNewRows.size} HĐ", FormatUtils.formatVnd(yogaNewTotalVnd)),
                        listOf("02", "Doanh thu gia hạn Yoga", "${yogaRenewalRows.size} HĐ", FormatUtils.formatVnd(yogaRenewalTotalVnd))
                    ),
                    numericColumnIndices = setOf(3),
                    summaryLines = listOf(
                        "TỔNG DOANH THU YOGA THÁNG $periodStr" to FormatUtils.formatVnd(totalYogaRevenueVnd)
                    )
                )
            }
        }
    }

    val topBarTitle = when (subScreen) {
        1 -> "Doanh thu Gym"
        2 -> "Doanh thu Yoga"
        3 -> "Xuất báo cáo"
        else -> "Doanh thu"
    }

    Scaffold(
        topBar = {
            FitnessTopAppBar(
                title = topBarTitle,
                domainBadge = when (subScreen) {
                    1 -> "GYM"
                    2 -> "YOGA"
                    3 -> exportDomain
                    else -> null
                },
                onBackClick = {
                    if (subScreen != 0) subScreen = 0 else onBack()
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Compact Month / Year Selector (Section 7.5)
            CompactMonthSelectorBar(
                selectedMonth = selectedMonth,
                selectedYear = selectedYear,
                onPreviousMonth = {
                    if (selectedMonth == 1) {
                        selectedMonth = 12
                        selectedYear--
                    } else {
                        selectedMonth--
                    }
                },
                onNextMonth = {
                    if (selectedMonth == 12) {
                        selectedMonth = 1
                        selectedYear++
                    } else {
                        selectedMonth++
                    }
                }
            )

            when (subScreen) {
                0 -> {
                    // Section 7.1: 3 uniform square tiles on main Revenue screen
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(3),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            item {
                                RevenueSquareTile(
                                    title = "Doanh thu Gym",
                                    subtitle = FormatUtils.formatVnd(totalGymRevenueVnd),
                                    icon = Icons.Default.FitnessCenter,
                                    accentColor = GymEmeraldLight,
                                    testTag = "tile_revenue_gym",
                                    onClick = { subScreen = 1 }
                                )
                            }
                            item {
                                RevenueSquareTile(
                                    title = "Doanh thu Yoga",
                                    subtitle = FormatUtils.formatVnd(totalYogaRevenueVnd),
                                    icon = Icons.Default.SelfImprovement,
                                    accentColor = YogaIndigoLight,
                                    testTag = "tile_revenue_yoga",
                                    onClick = { subScreen = 2 }
                                )
                            }
                            item {
                                RevenueSquareTile(
                                    title = "Xuất báo cáo",
                                    subtitle = "8 báo cáo",
                                    icon = Icons.Default.FileDownload,
                                    accentColor = PtTealLight,
                                    testTag = "tile_revenue_export",
                                    onClick = { subScreen = 3 }
                                )
                            }
                        }

                        // Compact overview summary below the 3 square tiles
                        ElevatedCard(
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "Tóm tắt tháng %02d/%04d".format(selectedMonth, selectedYear),
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                CompactRevenueRow("Tổng doanh thu Gym", totalGymRevenueVnd, GymEmeraldLight, bold = true) {
                                    subScreen = 1
                                }
                                CompactRevenueRow("Tổng doanh thu Yoga", totalYogaRevenueVnd, YogaIndigoLight, bold = true) {
                                    subScreen = 2
                                }
                            }
                        }
                    }
                }

                1 -> {
                    // Section 7.2: Doanh thu Gym
                    LazyColumn(
                        contentPadding = PaddingValues(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        item {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = GymEmeraldLight),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = "TỔNG DOANH THU GYM (T$selectedMonth/$selectedYear)",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = Color.White.copy(alpha = 0.9f)
                                    )
                                    Text(
                                        text = FormatUtils.formatVnd(totalGymRevenueVnd),
                                        style = MaterialTheme.typography.headlineSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        modifier = Modifier.testTag("revenue_grand_total_text")
                                    )
                                }
                            }
                        }

                        item {
                            ElevatedCard(shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                                Column(
                                    modifier = Modifier.padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    CompactRevenueRow(
                                        label = "1. Doanh thu hội viên mới (${gymNewRows.size} HĐ)",
                                        amountVnd = gymNewTotalVnd,
                                        accent = GymEmeraldLight
                                    )
                                    HorizontalDivider()
                                    CompactRevenueRow(
                                        label = "2. Doanh thu gia hạn (${gymRenewalRows.size} HĐ)",
                                        amountVnd = gymRenewalTotalVnd,
                                        accent = GymEmeraldLight
                                    )
                                    HorizontalDivider()
                                    CompactRevenueRow(
                                        label = "3. Doanh thu PT - 50% Gym (${ptRows.size} HĐ)",
                                        amountVnd = ptTotalGymVnd,
                                        accent = PtTealLight
                                    )
                                    HorizontalDivider()
                                    CompactRevenueRow(
                                        label = "4. Doanh thu vé ngày (${monthTickets.count { it.ticketType == "VE_NGAY" }} GD)",
                                        amountVnd = dailyTicketsTotalVnd,
                                        accent = GymEmeraldLight
                                    )
                                    HorizontalDivider()
                                    CompactRevenueRow(
                                        label = "5. Doanh thu vé tuần (${monthTickets.count { it.ticketType == "VE_TUAN" }} GD)",
                                        amountVnd = weeklyTicketsTotalVnd,
                                        accent = GymEmeraldLight
                                    )
                                    HorizontalDivider()
                                    CompactRevenueRow(
                                        label = "Tổng doanh thu Gym",
                                        amountVnd = totalGymRevenueVnd,
                                        accent = GymEmeraldLight,
                                        bold = true
                                    )
                                }
                            }
                        }

                        item {
                            Button(
                                onClick = {
                                    exportDomain = "GYM"
                                    selectedGymReport = GymReportType.TOTAL_GYM
                                    subScreen = 3
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = GymEmeraldLight),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Mở Xuất báo cáo Gym (5 báo cáo)")
                            }
                        }
                    }
                }

                2 -> {
                    // Section 7.3: Doanh thu Yoga (Độc lập với Gym)
                    LazyColumn(
                        contentPadding = PaddingValues(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        item {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = YogaIndigoLight),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = "TỔNG DOANH THU YOGA (T$selectedMonth/$selectedYear)",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = Color.White.copy(alpha = 0.9f)
                                    )
                                    Text(
                                        text = FormatUtils.formatVnd(totalYogaRevenueVnd),
                                        style = MaterialTheme.typography.headlineSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        modifier = Modifier.testTag("yoga_revenue_total_text")
                                    )
                                }
                            }
                        }

                        item {
                            ElevatedCard(shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                                Column(
                                    modifier = Modifier.padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    CompactRevenueRow(
                                        label = "1. Doanh thu hội viên mới Yoga (${yogaNewRows.size} HĐ)",
                                        amountVnd = yogaNewTotalVnd,
                                        accent = YogaIndigoLight
                                    )
                                    HorizontalDivider()
                                    CompactRevenueRow(
                                        label = "2. Doanh thu gia hạn Yoga (${yogaRenewalRows.size} HĐ)",
                                        amountVnd = yogaRenewalTotalVnd,
                                        accent = YogaIndigoLight
                                    )
                                    HorizontalDivider()
                                    CompactRevenueRow(
                                        label = "Tổng doanh thu Yoga",
                                        amountVnd = totalYogaRevenueVnd,
                                        accent = YogaIndigoLight,
                                        bold = true
                                    )
                                }
                            }
                        }

                        item {
                            Button(
                                onClick = {
                                    exportDomain = "YOGA"
                                    selectedYogaReport = YogaReportType.TOTAL_YOGA
                                    subScreen = 3
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = YogaIndigoLight),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Mở Xuất báo cáo Yoga (3 báo cáo)")
                            }
                        }
                    }
                }

                3 -> {
                    // Section 7.4: Xuất báo cáo (5 báo cáo Gym + 3 báo cáo Yoga = 8 báo cáo)
                    LazyColumn(
                        contentPadding = PaddingValues(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                FilterChip(
                                    selected = exportDomain == "GYM",
                                    onClick = { exportDomain = "GYM" },
                                    label = { Text("Báo cáo GYM (5)") },
                                    leadingIcon = { Icon(Icons.Default.FitnessCenter, contentDescription = null, modifier = Modifier.size(16.dp)) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("revenue_domain_gym")
                                )
                                FilterChip(
                                    selected = exportDomain == "YOGA",
                                    onClick = { exportDomain = "YOGA" },
                                    label = { Text("Báo cáo YOGA (3)") },
                                    leadingIcon = { Icon(Icons.Default.SelfImprovement, contentDescription = null, modifier = Modifier.size(16.dp)) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("revenue_domain_yoga")
                                )
                            }
                        }

                        item {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                if (exportDomain == "GYM") {
                                    GymReportType.entries.forEach { report ->
                                        FilterChip(
                                            selected = selectedGymReport == report,
                                            onClick = { selectedGymReport = report },
                                            label = { Text(report.title) }
                                        )
                                    }
                                } else {
                                    YogaReportType.entries.forEach { report ->
                                        FilterChip(
                                            selected = selectedYogaReport == report,
                                            onClick = { selectedYogaReport = report },
                                            label = { Text(report.title) }
                                        )
                                    }
                                }
                            }
                        }

                        item {
                            ElevatedCard(
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = currentReportTable.reportTitle,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "${currentReportTable.subtitle} • ${currentReportTable.rows.size} dòng",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Button(
                                            onClick = { onExportReport(currentReportTable, true) },
                                            colors = ButtonDefaults.buttonColors(containerColor = GymEmeraldLight),
                                            modifier = Modifier
                                                .weight(1f)
                                                .testTag("export_revenue_excel_btn")
                                        ) {
                                            Icon(Icons.Default.TableView, contentDescription = null, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Lưu Excel (.xls)")
                                        }
                                        Button(
                                            onClick = { onExportReport(currentReportTable, false) },
                                            colors = ButtonDefaults.buttonColors(containerColor = YogaIndigoLight),
                                            modifier = Modifier
                                                .weight(1f)
                                                .testTag("export_revenue_pdf_btn")
                                        ) {
                                            Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Lưu PDF (.pdf)")
                                        }
                                    }
                                }
                            }
                        }

                        if (currentReportTable.rows.isEmpty()) {
                            item {
                                Surface(
                                    color = MaterialTheme.colorScheme.surface,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = "Không có dữ liệu trong tháng $selectedMonth/$selectedYear cho báo cáo này.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(12.dp)
                                    )
                                }
                            }
                        } else {
                            itemsIndexed(currentReportTable.rows) { _, row ->
                                OutlinedCard(
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(
                                        modifier = Modifier.padding(10.dp),
                                        verticalArrangement = Arrangement.spacedBy(3.dp)
                                    ) {
                                        currentReportTable.headers.forEachIndexed { colIdx, header ->
                                            val cellVal = row.getOrNull(colIdx) ?: ""
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text(
                                                    text = header,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                                Text(
                                                    text = cellVal,
                                                    style = MaterialTheme.typography.bodySmall,
                                                    fontWeight = if (colIdx == currentReportTable.headers.lastIndex) {
                                                        FontWeight.Bold
                                                    } else {
                                                        FontWeight.Normal
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CompactMonthSelectorBar(
    selectedMonth: Int,
    selectedYear: Int,
    onPreviousMonth: () -> Unit,
    onNextMonth: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 1.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Kỳ báo cáo:",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                FilledTonalIconButton(
                    onClick = onPreviousMonth,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(Icons.Default.ChevronLeft, contentDescription = "Tháng trước", modifier = Modifier.size(18.dp))
                }
                Text(
                    text = String.format("Tháng %02d / %04d", selectedMonth, selectedYear),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(horizontal = 6.dp)
                )
                FilledTonalIconButton(
                    onClick = onNextMonth,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(Icons.Default.ChevronRight, contentDescription = "Tháng sau", modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}

@Composable
private fun RevenueSquareTile(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    testTag: String,
    onClick: () -> Unit
) {
    ElevatedCard(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .testTag(testTag)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Surface(
                color = accentColor.copy(alpha = 0.14f),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.size(36.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = accentColor,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                maxLines = 1
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = accentColor,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun CompactRevenueRow(
    label: String,
    amountVnd: Long,
    accent: Color,
    bold: Boolean = false,
    onClick: (() -> Unit)? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = if (bold) MaterialTheme.typography.titleSmall else MaterialTheme.typography.bodyMedium,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal
        )
        Text(
            text = FormatUtils.formatVnd(amountVnd),
            style = if (bold) MaterialTheme.typography.titleSmall else MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold,
            color = accent
        )
    }
}

private fun buildContractReportTable(
    title: String,
    periodStr: String,
    filePrefix: String,
    rows: List<RevenueAllocationEngine.ContractAllocationRow>,
    totalVnd: Long
): ReportTableData {
    val headers = listOf(
        "STT",
        "Họ và tên",
        "Số tháng ĐK",
        "Ngày đăng ký",
        "Ngày hết hạn",
        "Ngày hiệu lực T/Tổng",
        "Giá trị hợp đồng",
        "Doanh thu phân bổ tháng"
    )
    val tableRows = rows.mapIndexed { idx, r ->
        listOf(
            FormatUtils.formatStt(idx + 1),
            r.memberName,
            "${r.durationMonths} tháng",
            DateCalculator.formatDisplay(r.startDateIso),
            DateCalculator.formatDisplay(r.endDateIso),
            "${r.effectiveDaysInMonth}/${r.totalEffectiveDays} ngày",
            FormatUtils.formatVnd(r.agreedValueVnd),
            FormatUtils.formatVnd(r.allocatedRevenueVnd)
        )
    }
    return ReportTableData(
        reportTitle = title,
        subtitle = "Kỳ báo cáo: Tháng $periodStr",
        fileNamePrefix = filePrefix,
        headers = headers,
        rows = tableRows,
        numericColumnIndices = setOf(6, 7),
        summaryLines = listOf(
            "Tổng doanh thu phân bổ tháng $periodStr" to FormatUtils.formatVnd(totalVnd)
        )
    )
}
