package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.*
import com.example.data.preferences.AppPreferencesState
import com.example.domain.DateCalculator
import com.example.domain.FormatUtils
import com.example.ui.AppDataSnapshot
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Settings Screen (Sections 16, 17, 18, 19, 20, 21, 22):
 * - Light / Dark Mode switch (persisted in DataStore, defaults to Light Mode)
 * - Separated Gym Price Catalog (Nam, Nữ, Trẻ em 1, 2, 3, 12 tháng + Vé ngày + Vé tuần + Gói PT)
 * - Separated Yoga Price Catalog (1, 2, 3 tháng)
 * - Google Sign-In & Google Drive Backup / Restore
 */
@Composable
fun SettingsScreen(
    preferences: AppPreferencesState,
    pricePlans: List<PricePlanEntity>,
    onBack: () -> Unit,
    onToggleDarkMode: (Boolean) -> Unit,
    onSavePricePlan: (String?, String, String, String, Int, Int, Long) -> Unit,
    onTogglePlanActive: (PricePlanEntity) -> Unit,
    onSignInGoogle: (android.content.Context) -> Unit,
    onConnectGoogleManual: (String, String) -> Unit,
    onSignOutGoogle: () -> Unit,
    onBackupToDrive: () -> Unit,
    onRestoreFromUri: (Uri) -> Unit,
    onRestoreLocalSnapshot: () -> Unit
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) } // 0 = Bảng giá Gym, 1 = Bảng giá Yoga, 2 = Giao diện & Google Drive
    var showAddPlanDialog by remember { mutableStateOf(false) }
    var editingPlan by remember { mutableStateOf<PricePlanEntity?>(null) }
    var showManualGoogleDialog by remember { mutableStateOf(false) }

    val restoreFilePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            onRestoreFromUri(uri)
        }
    }

    val gymPlans = remember(pricePlans) { pricePlans.filter { it.domain == "GYM" } }
    val yogaPlans = remember(pricePlans) { pricePlans.filter { it.domain == "YOGA" } }

    Scaffold(
        topBar = {
            FitnessTopAppBar(
                title = "Cài đặt hệ thống",
                subtitle = "Bảng giá Gym/Yoga, Giao diện & Sao lưu Google Drive",
                onBackClick = onBack
            )
        },
        floatingActionButton = {
            if (selectedTab == 0 || selectedTab == 1) {
                ExtendedFloatingActionButton(
                    onClick = {
                        editingPlan = null
                        showAddPlanDialog = true
                    },
                    containerColor = if (selectedTab == 0) GymEmeraldLight else YogaIndigoLight,
                    contentColor = androidx.compose.ui.graphics.Color.White,
                    modifier = Modifier.testTag("fab_add_price_plan")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (selectedTab == 0) "Thêm gói giá Gym" else "Thêm gói giá Yoga")
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            TabRow(selectedTabIndex = selectedTab) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Bảng giá Gym (${gymPlans.size})") },
                    modifier = Modifier.testTag("settings_tab_gym_prices")
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Bảng giá Yoga (${yogaPlans.size})") },
                    modifier = Modifier.testTag("settings_tab_yoga_prices")
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("Giao diện & Drive") },
                    modifier = Modifier.testTag("settings_tab_drive_theme")
                )
            }

            when (selectedTab) {
                0, 1 -> {
                    val domain = if (selectedTab == 0) "GYM" else "YOGA"
                    val plans = if (selectedTab == 0) gymPlans else yogaPlans

                    LazyColumn(
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 88.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        item {
                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = if (domain == "GYM") {
                                        "Bảng giá Gym độc lập với Yoga. Hỗ trợ các nhóm: Nam, Nữ, Trẻ em (1, 2, 3, 12 tháng), Vé ngày, Vé tuần và Gói PT theo số buổi. Thay đổi bảng giá không làm thay đổi giá trị các hợp đồng đã ký trước đó."
                                    } else {
                                        "Bảng giá Yoga độc lập với Gym (1 tháng, 2 tháng, 3 tháng...). Khi gói không còn kinh doanh, hãy vô hiệu hóa thay vì xóa."
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        }

                        if (plans.isEmpty()) {
                            item {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(32.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text(
                                            text = "Chưa có gói giá $domain nào được thiết lập.",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "Ứng dụng không tự tạo giá giả. Nhấn 'Thêm gói giá $domain' để nhập bảng giá thực tế.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        } else {
                            items(plans, key = { it.id }) { plan ->
                                ElevatedCard(
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(14.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(
                                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = plan.planName,
                                                    style = MaterialTheme.typography.titleMedium,
                                                    fontWeight = FontWeight.Bold
                                                )
                                                StatusPill(
                                                    text = if (plan.isActive) "Đang áp dụng" else "Đã vô hiệu hóa",
                                                    tone = if (plan.isActive) StatusTone.SUCCESS else StatusTone.NEUTRAL
                                                )
                                            }
                                            val detailText = when (plan.category) {
                                                "PT" -> "Nhóm: PT • ${plan.sessionCount} buổi"
                                                "VE_NGAY" -> "Loại: Vé tập Ngày"
                                                "VE_TUAN" -> "Loại: Vé tập Tuần"
                                                else -> "Nhóm: ${plan.category} • Thời hạn: ${plan.durationMonths} tháng"
                                            }
                                            Text(
                                                text = "$detailText • Giá: ${FormatUtils.formatVnd(plan.priceVnd)}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        Row {
                                            IconButton(onClick = {
                                                editingPlan = plan
                                                showAddPlanDialog = true
                                            }) {
                                                Icon(Icons.Default.Edit, contentDescription = "Chỉnh sửa gói")
                                            }
                                            IconButton(onClick = { onTogglePlanActive(plan) }) {
                                                Icon(
                                                    imageVector = if (plan.isActive) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                                    contentDescription = "Bật/Tắt gói"
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                2 -> {
                    // Tab 2: Theme (Light/Dark Mode) & Google Drive Backup/Restore
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        // Light / Dark Mode Card (Section 16)
                        item {
                            ElevatedCard(
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "Giao diện Sáng / Tối (Dark Mode)",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "Mặc định Light Mode. Tự động lưu và duy trì sau khi đóng ứng dụng.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Switch(
                                        checked = preferences.isDarkMode,
                                        onCheckedChange = onToggleDarkMode,
                                        modifier = Modifier.testTag("dark_mode_switch")
                                    )
                                }
                            }
                        }

                        // Google Login & Google Drive Backup Card (Sections 20-22)
                        item {
                            ElevatedCard(
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.CloudSync,
                                            contentDescription = null,
                                            tint = GymEmeraldLight
                                        )
                                        Column {
                                            Text(
                                                text = "Google Login & Google Drive Backup",
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = "Sao lưu và khôi phục dữ liệu thủ công qua Google Drive, chống trùng lặp UUID.",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }

                                    HorizontalDivider()

                                    Text(
                                        text = "Trạng thái: ${preferences.lastSyncStatus}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.primary
                                    )

                                    if (preferences.lastBackupTimestamp > 0L) {
                                        val formattedTime = remember(preferences.lastBackupTimestamp) {
                                            SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
                                                .format(Date(preferences.lastBackupTimestamp))
                                        }
                                        Text(
                                            text = "Lần sao lưu gần nhất: $formattedTime",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    if (preferences.googleAccountEmail.isBlank()) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Button(
                                                onClick = { onSignInGoogle(context) },
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .testTag("google_sign_in_btn")
                                            ) {
                                                Icon(Icons.Default.AccountCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("Đăng nhập Google")
                                            }
                                            OutlinedButton(
                                                onClick = { showManualGoogleDialog = true },
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Text("Cấu hình tài khoản")
                                            }
                                        }
                                    } else {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "Tài khoản: ${preferences.googleAccountEmail}",
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.Medium
                                            )
                                            TextButton(onClick = onSignOutGoogle) {
                                                Text("Đăng xuất", color = StatusDangerRed)
                                            }
                                        }
                                    }

                                    HorizontalDivider()

                                    Button(
                                        onClick = onBackupToDrive,
                                        colors = ButtonDefaults.buttonColors(containerColor = GymEmeraldLight),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("backup_google_drive_btn")
                                    ) {
                                        Icon(Icons.Default.CloudUpload, contentDescription = null)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Sao lưu dữ liệu lên Google Drive ngay")
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        OutlinedButton(
                                            onClick = { restoreFilePicker.launch("application/json") },
                                            modifier = Modifier
                                                .weight(1f)
                                                .testTag("restore_drive_file_btn")
                                        ) {
                                            Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Khôi phục từ Drive")
                                        }
                                        OutlinedButton(
                                            onClick = onRestoreLocalSnapshot,
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Bản lưu trên máy")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Dialog: Add / Edit Price Plan
    if (showAddPlanDialog) {
        val currentDomain = editingPlan?.domain ?: if (selectedTab == 0) "GYM" else "YOGA"
        var category by remember(editingPlan, currentDomain) {
            mutableStateOf(editingPlan?.category ?: if (currentDomain == "YOGA") "YOGA" else "NAM")
        }
        var planName by remember(editingPlan) { mutableStateOf(editingPlan?.planName ?: "") }
        var durationMonths by remember(editingPlan) {
            mutableIntStateOf(editingPlan?.durationMonths?.takeIf { it > 0 } ?: 1)
        }
        var sessionCount by remember(editingPlan) {
            mutableIntStateOf(editingPlan?.sessionCount?.takeIf { it > 0 } ?: 12)
        }
        var priceVnd by remember(editingPlan) { mutableLongStateOf(editingPlan?.priceVnd ?: 0L) }

        AlertDialog(
            onDismissRequest = { showAddPlanDialog = false },
            title = { Text(if (editingPlan == null) "Thêm gói giá $currentDomain" else "Sửa gói giá $currentDomain") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (currentDomain == "GYM") {
                        Text("Nhóm bảng giá Gym:", style = MaterialTheme.typography.labelMedium)
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf("NAM" to "Nam", "NU" to "Nữ", "TRE_EM" to "Trẻ em").forEach { (c, l) ->
                                    FilterChip(
                                        selected = category == c,
                                        onClick = { category = c },
                                        label = { Text(l) }
                                    )
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf("VE_NGAY" to "Vé ngày", "VE_TUAN" to "Vé tuần", "PT" to "Gói PT").forEach { (c, l) ->
                                    FilterChip(
                                        selected = category == c,
                                        onClick = { category = c },
                                        label = { Text(l) }
                                    )
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = planName,
                        onValueChange = { planName = it },
                        label = { Text("Tên gói * (VD: Gym Nam 1 tháng)") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("price_plan_name_input")
                    )

                    if (category == "PT") {
                        OutlinedTextField(
                            value = sessionCount.toString(),
                            onValueChange = { sessionCount = it.filter { ch -> ch.isDigit() }.toIntOrNull() ?: 1 },
                            label = { Text("Số buổi PT") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else if (category != "VE_NGAY" && category != "VE_TUAN") {
                        Text("Thời hạn gói (tháng):", style = MaterialTheme.typography.labelMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            val monthChoices = if (currentDomain == "GYM") listOf(1, 2, 3, 12) else listOf(1, 2, 3)
                            monthChoices.forEach { m ->
                                FilterChip(
                                    selected = durationMonths == m,
                                    onClick = { durationMonths = m },
                                    label = { Text(if (m == 12) "1 năm" else "$m T") }
                                )
                            }
                        }
                    }

                    VndAmountField(
                        label = "Giá niêm yết (VNĐ)",
                        amountVnd = priceVnd,
                        onAmountChange = { priceVnd = it },
                        testTagName = "price_plan_vnd_input"
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onSavePricePlan(
                            editingPlan?.id,
                            currentDomain,
                            category,
                            planName,
                            if (category in listOf("PT", "VE_NGAY", "VE_TUAN")) 0 else durationMonths,
                            if (category == "PT") sessionCount else 0,
                            priceVnd
                        )
                        showAddPlanDialog = false
                    },
                    modifier = Modifier.testTag("confirm_save_price_plan_btn")
                ) {
                    Text("Lưu gói giá")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddPlanDialog = false }) {
                    Text("Hủy")
                }
            }
        )
    }

    if (showManualGoogleDialog) {
        var email by remember { mutableStateOf(preferences.googleAccountEmail) }
        var token by remember { mutableStateOf(preferences.googleAccessToken) }

        AlertDialog(
            onDismissRequest = { showManualGoogleDialog = false },
            title = { Text("Kết nối tài khoản Google Drive") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Email Google (VD: bamuoitb5@gmail.com)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = token,
                        onValueChange = { token = it },
                        label = { Text("OAuth Access Token (Tùy chọn cho API trực tiếp)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    onConnectGoogleManual(email, token)
                    showManualGoogleDialog = false
                }) {
                    Text("Lưu")
                }
            },
            dismissButton = {
                TextButton(onClick = { showManualGoogleDialog = false }) {
                    Text("Hủy")
                }
            }
        )
    }
}

/**
 * Trash Screen (Section 15):
 * - Top-level module on equal footing with the other 6 modules
 * - Contains deleted Gym members, deleted Yoga members, cancelled/deleted contracts,
 *   deleted PT profiles, and soft-deleted tickets
 * - Clearly distinguishes between "Hủy hợp đồng & Hoàn tiền" and "Xóa nhầm"
 * - Supports Search, Inspect details, Restore, Permanent Delete, and Empty Trash confirmation
 */
@Composable
fun TrashScreen(
    snapshot: AppDataSnapshot,
    onBack: () -> Unit,
    onRestoreMember: (String) -> Unit,
    onPermanentlyDeleteMember: (String) -> Unit,
    onRestoreContract: (String) -> Unit,
    onPermanentlyDeleteContract: (String) -> Unit,
    onRestorePtClient: (String) -> Unit,
    onPermanentlyDeletePtClient: (String) -> Unit,
    onRestoreTicket: (ShortTermTicketEntity) -> Unit,
    onPermanentlyDeleteTicket: (String) -> Unit,
    onEmptyTrashAll: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var showEmptyConfirm by remember { mutableStateOf(false) }

    val deletedMembers = remember(snapshot.members, searchQuery) {
        val q = searchQuery.trim().lowercase()
        snapshot.members.filter {
            it.isDeleted && (q.isEmpty() || it.fullName.lowercase().contains(q) || it.phoneNumber.lowercase().contains(q))
        }
    }

    val deletedContracts = remember(snapshot.contracts, searchQuery) {
        val q = searchQuery.trim().lowercase()
        snapshot.contracts.filter {
            it.isDeleted && (q.isEmpty() || it.contractCode.lowercase().contains(q) || it.planNameSnapshot.lowercase().contains(q))
        }
    }

    val deletedPtClients = remember(snapshot.ptClients, searchQuery) {
        val q = searchQuery.trim().lowercase()
        snapshot.ptClients.filter {
            it.isDeleted && (q.isEmpty() || it.fullName.lowercase().contains(q))
        }
    }

    val deletedTickets = remember(snapshot.shortTermTickets, searchQuery) {
        val q = searchQuery.trim().lowercase()
        snapshot.shortTermTickets.filter {
            it.isDeleted && (q.isEmpty() || it.ticketCode.lowercase().contains(q))
        }
    }

    val totalTrashCount = deletedMembers.size + deletedContracts.size + deletedPtClients.size + deletedTickets.size

    Scaffold(
        topBar = {
            FitnessTopAppBar(
                title = "Thùng rác ($totalTrashCount)",
                subtitle = "Khôi phục dữ liệu xóa nhầm & Đối soát HĐ đã hủy",
                onBackClick = onBack,
                actions = {
                    if (totalTrashCount > 0) {
                        TextButton(
                            onClick = { showEmptyConfirm = true },
                            colors = ButtonDefaults.textButtonColors(contentColor = StatusDangerRed),
                            modifier = Modifier.testTag("empty_trash_all_btn")
                        ) {
                            Icon(Icons.Default.DeleteForever, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Xóa tất cả")
                        }
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 1.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Tìm trong Thùng rác theo tên, SĐT, mã HĐ...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp)
                )
            }

            if (totalTrashCount == 0) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.RestoreFromTrash,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.size(56.dp)
                        )
                        Text(
                            text = "Thùng rác đang trống",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Các hồ sơ xóa nhầm hoặc hợp đồng đã hủy & hoàn tiền sẽ được lưu tại đây.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    // 1. Deleted / Cancelled Contracts
                    if (deletedContracts.isNotEmpty()) {
                        item {
                            Text(
                                text = "Hợp đồng đã hủy / đã xóa (${deletedContracts.size})",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        items(deletedContracts, key = { it.id }) { c ->
                            val isCancelledRefund = c.deleteType == "CONTRACT_CANCELLED" || c.status == "CANCELLED"
                            ElevatedCard(
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "${c.contractCode} (${c.domain}) • ${c.planNameSnapshot}",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold
                                        )
                                        StatusPill(
                                            text = if (isCancelledRefund) "Hủy HĐ & Hoàn tiền" else "Xóa nhầm",
                                            tone = if (isCancelledRefund) StatusTone.DANGER else StatusTone.WARNING
                                        )
                                    }
                                    Text(
                                        text = "Giá trị HĐ: ${FormatUtils.formatVnd(c.agreedValueVnd)} • Đã hoàn: ${FormatUtils.formatVnd(c.refundedAmountVnd)}",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                    if (!c.cancelReason.isNullOrBlank()) {
                                        Text(
                                            text = "Lý do hủy: ${c.cancelReason} (Ngày hủy: ${DateCalculator.formatDisplay(c.cancelledDateIso ?: "")})",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End
                                    ) {
                                        TextButton(onClick = { onRestoreContract(c.id) }) {
                                            Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(if (isCancelledRefund) "Khôi phục tra cứu (Giữ TT Đã hủy)" else "Khôi phục")
                                        }
                                        TextButton(
                                            onClick = { onPermanentlyDeleteContract(c.id) },
                                            colors = ButtonDefaults.textButtonColors(contentColor = StatusDangerRed)
                                        ) {
                                            Text("Xóa vĩnh viễn")
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // 2. Deleted Gym / Yoga Members
                    if (deletedMembers.isNotEmpty()) {
                        item {
                            Text(
                                text = "Hồ sơ hội viên đã xóa (${deletedMembers.size})",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        items(deletedMembers, key = { it.id }) { m ->
                            val isFromCancel = m.deleteType == "CONTRACT_CANCELLED"
                            ElevatedCard(
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "${m.fullName} (${m.domain})",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold
                                        )
                                        StatusPill(
                                            text = if (isFromCancel) "Từ Hủy hợp đồng" else "Xóa nhầm",
                                            tone = if (isFromCancel) StatusTone.DANGER else StatusTone.WARNING
                                        )
                                    }
                                    Text(
                                        text = "SĐT: ${m.phoneNumber} • Ghi chú: ${m.deleteReason ?: "Xóa mềm"}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End
                                    ) {
                                        TextButton(
                                            onClick = { onRestoreMember(m.id) },
                                            modifier = Modifier.testTag("restore_member_btn_${m.id}")
                                        ) {
                                            Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Khôi phục")
                                        }
                                        TextButton(
                                            onClick = { onPermanentlyDeleteMember(m.id) },
                                            colors = ButtonDefaults.textButtonColors(contentColor = StatusDangerRed)
                                        ) {
                                            Text("Xóa vĩnh viễn")
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // 3. Deleted PT Clients
                    if (deletedPtClients.isNotEmpty()) {
                        item {
                            Text(
                                text = "Hồ sơ PT đã xóa (${deletedPtClients.size})",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        items(deletedPtClients, key = { it.id }) { pt ->
                            ElevatedCard(
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(pt.fullName, fontWeight = FontWeight.Bold)
                                        Text("SĐT: ${pt.phoneNumber}", style = MaterialTheme.typography.bodySmall)
                                    }
                                    Row {
                                        TextButton(onClick = { onRestorePtClient(pt.id) }) {
                                            Text("Khôi phục")
                                        }
                                        TextButton(
                                            onClick = { onPermanentlyDeletePtClient(pt.id) },
                                            colors = ButtonDefaults.textButtonColors(contentColor = StatusDangerRed)
                                        ) {
                                            Text("Xóa vĩnh viễn")
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // 4. Deleted Short-Term Tickets
                    if (deletedTickets.isNotEmpty()) {
                        item {
                            Text(
                                text = "Giao dịch vé đã xóa (${deletedTickets.size})",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        items(deletedTickets, key = { it.id }) { t ->
                            ElevatedCard(
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(t.ticketCode, fontWeight = FontWeight.Bold)
                                        Text(FormatUtils.formatVnd(t.totalAmountVnd), style = MaterialTheme.typography.bodySmall)
                                    }
                                    Row {
                                        TextButton(onClick = { onRestoreTicket(t) }) {
                                            Text("Khôi phục")
                                        }
                                        TextButton(
                                            onClick = { onPermanentlyDeleteTicket(t.id) },
                                            colors = ButtonDefaults.textButtonColors(contentColor = StatusDangerRed)
                                        ) {
                                            Text("Xóa vĩnh viễn")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showEmptyConfirm) {
        AlertDialog(
            onDismissRequest = { showEmptyConfirm = false },
            title = { Text("Xác nhận dọn sạch Thùng rác?") },
            text = {
                Text("Toàn bộ hồ sơ đã xóa trong Thùng rác sẽ bị xóa vĩnh viễn. Lịch sử giao dịch thu/hoàn tiền độc lập vẫn được lưu giữ để đối soát.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showEmptyConfirm = false
                        onEmptyTrashAll()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusDangerRed)
                ) {
                    Text("Xóa vĩnh viễn toàn bộ")
                }
            },
            dismissButton = {
                TextButton(onClick = { showEmptyConfirm = false }) {
                    Text("Hủy")
                }
            }
        )
    }
}
