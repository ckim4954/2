package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.*
import com.example.data.preferences.AppPreferencesState
import com.example.domain.DateCalculator
import com.example.domain.FormatUtils
import com.example.ui.AppDataSnapshot
import com.example.ui.TrashItemType
import com.example.ui.TrashSelectableItem
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Settings Module (Section 6 of Upgrade PRD):
 * - No search bar, no long instructional paragraphs
 * - 4 Main Sections:
 *   1. Bảng giá & Gói tập (with 14 auto-seeded standard Gym & Yoga plans + Add/Edit/Deactivate/Delete with confirmation)
 *   2. Giao diện & Chủ đề (Light / Dark Mode)
 *   3. Dữ liệu & Sao lưu (Google Login, Google Drive Backup & Restore with confirmation)
 *   4. Thùng rác (Opens the unified Trash module)
 */
@Composable
fun SettingsScreen(
    preferences: AppPreferencesState,
    pricePlans: List<PricePlanEntity>,
    trashCount: Int,
    onBack: () -> Unit,
    onOpenTrash: () -> Unit,
    onToggleDarkMode: (Boolean) -> Unit,
    onSavePricePlan: (String?, String, String, String, Int, Int, Long) -> Unit,
    onTogglePlanActive: (PricePlanEntity) -> Unit,
    onDeleteOrDeactivatePricePlan: (PricePlanEntity) -> Unit,
    onSignInGoogle: (android.content.Context) -> Unit,
    onConnectGoogleManual: (String, String) -> Unit,
    onSignOutGoogle: () -> Unit,
    onBackupToDrive: () -> Unit,
    onRestoreFromUri: (Uri) -> Unit,
    onRestoreLocalSnapshot: () -> Unit
) {
    val context = LocalContext.current
    // 0 = Bảng giá & Gói tập, 1 = Giao diện & Chủ đề, 2 = Dữ liệu & Sao lưu
    var selectedSection by remember { mutableIntStateOf(0) }
    var selectedPriceDomain by remember { mutableStateOf("GYM") }
    var showAddPlanDialog by remember { mutableStateOf(false) }
    var editingPlan by remember { mutableStateOf<PricePlanEntity?>(null) }
    var planToDeleteConfirm by remember { mutableStateOf<PricePlanEntity?>(null) }
    var showManualGoogleDialog by remember { mutableStateOf(false) }
    var pendingRestoreUri by remember { mutableStateOf<Uri?>(null) }
    var showConfirmLocalRestore by remember { mutableStateOf(false) }

    val restoreFilePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            pendingRestoreUri = uri
        }
    }

    val activeVisiblePlans = remember(pricePlans, selectedPriceDomain) {
        pricePlans.filter { !it.isDeleted && it.domain == selectedPriceDomain }
    }

    Scaffold(
        topBar = {
            FitnessTopAppBar(
                title = "Cài đặt",
                onBackClick = onBack
            )
        },
        floatingActionButton = {
            if (selectedSection == 0) {
                ExtendedFloatingActionButton(
                    onClick = {
                        editingPlan = null
                        showAddPlanDialog = true
                    },
                    containerColor = if (selectedPriceDomain == "GYM") GymEmeraldLight else YogaIndigoLight,
                    contentColor = Color.White,
                    modifier = Modifier.testTag("fab_add_price_plan")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Thêm gói $selectedPriceDomain")
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // 4 Main Settings Groups (Section 6):
            // 1. Bảng giá & Gói tập | 2. Giao diện & Chủ đề | 3. Dữ liệu & Sao lưu | 4. Thùng rác
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 1.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        SettingsSectionChip(
                            title = "1. Bảng giá & Gói tập",
                            selected = selectedSection == 0,
                            onClick = { selectedSection = 0 },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("settings_tab_gym_prices")
                        )
                        SettingsSectionChip(
                            title = "2. Giao diện & Chủ đề",
                            selected = selectedSection == 1,
                            onClick = { selectedSection = 1 },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("settings_tab_theme")
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        SettingsSectionChip(
                            title = "3. Dữ liệu & Sao lưu",
                            selected = selectedSection == 2,
                            onClick = { selectedSection = 2 },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("settings_tab_drive_theme")
                        )
                        SettingsSectionChip(
                            title = "4. Thùng rác ($trashCount)",
                            selected = false,
                            onClick = onOpenTrash,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("settings_open_trash_btn")
                        )
                    }
                }
            }

            when (selectedSection) {
                0 -> {
                    // Section 1: Bảng giá & Gói tập
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilterChip(
                                selected = selectedPriceDomain == "GYM",
                                onClick = { selectedPriceDomain = "GYM" },
                                label = { Text("Bảng giá GYM") },
                                leadingIcon = { Icon(Icons.Default.FitnessCenter, contentDescription = null, modifier = Modifier.size(16.dp)) },
                                modifier = Modifier.weight(1f)
                            )
                            FilterChip(
                                selected = selectedPriceDomain == "YOGA",
                                onClick = { selectedPriceDomain = "YOGA" },
                                label = { Text("Bảng giá YOGA") },
                                leadingIcon = { Icon(Icons.Default.SelfImprovement, contentDescription = null, modifier = Modifier.size(16.dp)) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("settings_tab_yoga_prices")
                            )
                        }

                        LazyColumn(
                            contentPadding = PaddingValues(bottom = 84.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(activeVisiblePlans, key = { it.id }) { plan ->
                                ElevatedCard(
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 12.dp, vertical = 8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(
                                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = plan.planName,
                                                    style = MaterialTheme.typography.titleSmall,
                                                    fontWeight = FontWeight.Bold
                                                )
                                                StatusPill(
                                                    text = if (plan.isActive) "Đang dùng" else "Ngừng dùng",
                                                    tone = if (plan.isActive) StatusTone.SUCCESS else StatusTone.NEUTRAL
                                                )
                                            }
                                            val detailText = when (plan.category) {
                                                "PT" -> "PT • ${plan.sessionCount} buổi"
                                                "VE_NGAY" -> "Vé ngày"
                                                "VE_TUAN" -> "Vé tuần"
                                                else -> "${plan.category} • ${plan.durationMonths} tháng"
                                            }
                                            Text(
                                                text = "$detailText • ${FormatUtils.formatVnd(plan.priceVnd)}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            IconButton(
                                                onClick = {
                                                    editingPlan = plan
                                                    showAddPlanDialog = true
                                                },
                                                modifier = Modifier.size(36.dp)
                                            ) {
                                                Icon(Icons.Default.Edit, contentDescription = "Sửa", modifier = Modifier.size(18.dp))
                                            }
                                            IconButton(
                                                onClick = { onTogglePlanActive(plan) },
                                                modifier = Modifier.size(36.dp)
                                            ) {
                                                Icon(
                                                    imageVector = if (plan.isActive) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                                    contentDescription = "Bật/Tắt",
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                            IconButton(
                                                onClick = { planToDeleteConfirm = plan },
                                                modifier = Modifier.size(36.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.DeleteOutline,
                                                    contentDescription = "Xóa gói",
                                                    tint = StatusDangerRed,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                1 -> {
                    // Section 2: Giao diện & Chủ đề
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        ElevatedCard(
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Chế độ Tối (Dark Mode)",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = if (preferences.isDarkMode) "Đang bật giao diện Tối" else "Đang bật giao diện Sáng",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Switch(
                                    checked = preferences.isDarkMode,
                                    onCheckedChange = onToggleDarkMode,
                                    modifier = Modifier.testTag("dark_mode_switch")
                                )
                            }
                        }
                    }
                }

                2 -> {
                    // Section 3: Dữ liệu & Sao lưu
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        ElevatedCard(
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(
                                    text = "Sao lưu & Khôi phục Google Drive",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )

                                Text(
                                    text = "Trạng thái: ${preferences.lastSyncStatus}",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.primary
                                )

                                if (preferences.lastBackupTimestamp > 0L) {
                                    val formattedTime = remember(preferences.lastBackupTimestamp) {
                                        SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
                                            .format(Date(preferences.lastBackupTimestamp))
                                    }
                                    Text(
                                        text = "Sao lưu gần nhất: $formattedTime",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                if (preferences.googleAccountEmail.isBlank()) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Button(
                                            onClick = { onSignInGoogle(context) },
                                            modifier = Modifier
                                                .weight(1f)
                                                .testTag("google_sign_in_btn")
                                        ) {
                                            Icon(Icons.Default.AccountCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Đăng nhập Google")
                                        }
                                        OutlinedButton(
                                            onClick = { showManualGoogleDialog = true },
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text("Cấu hình Email")
                                        }
                                    }
                                } else {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = preferences.googleAccountEmail,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Medium
                                        )
                                        TextButton(onClick = onSignOutGoogle) {
                                            Text("Đăng xuất", color = StatusDangerRed)
                                        }
                                    }
                                }

                                HorizontalDivider()

                                Button(
                                    onClick = onBackupToDrive,
                                    colors = ButtonDefaults.buttonColors(containerColor = GymEmeraldLight),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("backup_google_drive_btn")
                                ) {
                                    Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Sao lưu dữ liệu ngay")
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OutlinedButton(
                                        onClick = { restoreFilePicker.launch("application/json") },
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("restore_drive_file_btn")
                                    ) {
                                        Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Khôi phục từ tệp")
                                    }
                                    OutlinedButton(
                                        onClick = { showConfirmLocalRestore = true },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Bản lưu trên máy")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Confirmation Dialog: Delete / Deactivate Price Plan (Section 10.1)
    planToDeleteConfirm?.let { plan ->
        AlertDialog(
            onDismissRequest = { planToDeleteConfirm = null },
            title = { Text("Xác nhận xóa gói tập") },
            text = {
                Text(
                    "Bạn có chắc chắn muốn xóa gói '${plan.planName}'?\n" +
                        "• Nếu gói đã phát sinh hợp đồng, hệ thống sẽ chuyển sang Ngừng sử dụng để bảo toàn dữ liệu lịch sử.\n" +
                        "• Nếu chưa có hợp đồng, gói sẽ được chuyển vào Thùng rác."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteOrDeactivatePricePlan(plan)
                        planToDeleteConfirm = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusDangerRed)
                ) {
                    Text("Xác nhận")
                }
            },
            dismissButton = {
                TextButton(onClick = { planToDeleteConfirm = null }) {
                    Text("Hủy")
                }
            }
        )
    }

    // Confirmation Dialog: Restore from URI (Section 10.1)
    pendingRestoreUri?.let { uri ->
        AlertDialog(
            onDismissRequest = { pendingRestoreUri = null },
            title = { Text("Xác nhận khôi phục dữ liệu") },
            text = {
                Text("Bạn có chắc chắn muốn khôi phục và gộp dữ liệu từ tệp sao lưu đã chọn vào ứng dụng không?")
            },
            confirmButton = {
                Button(onClick = {
                    onRestoreFromUri(uri)
                    pendingRestoreUri = null
                }) {
                    Text("Đồng ý khôi phục")
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingRestoreUri = null }) {
                    Text("Hủy")
                }
            }
        )
    }

    // Confirmation Dialog: Restore from Local Snapshot (Section 10.1)
    if (showConfirmLocalRestore) {
        AlertDialog(
            onDismissRequest = { showConfirmLocalRestore = false },
            title = { Text("Xác nhận khôi phục bản lưu trên máy") },
            text = {
                Text("Bạn có chắc chắn muốn khôi phục dữ liệu từ bản sao lưu gần nhất trên thiết bị không?")
            },
            confirmButton = {
                Button(onClick = {
                    onRestoreLocalSnapshot()
                    showConfirmLocalRestore = false
                }) {
                    Text("Đồng ý khôi phục")
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmLocalRestore = false }) {
                    Text("Hủy")
                }
            }
        )
    }

    // Dialog: Add / Edit Price Plan
    if (showAddPlanDialog) {
        val currentDomain = editingPlan?.domain ?: selectedPriceDomain
        var category by remember(editingPlan, currentDomain) {
            mutableStateOf(editingPlan?.category ?: if (currentDomain == "YOGA") "YOGA" else "NAM")
        }
        var planName by remember(editingPlan) { mutableStateOf(editingPlan?.planName ?: "") }
        var durationMonths by remember(editingPlan) {
            mutableIntStateOf(editingPlan?.durationMonths?.takeIf { it > 0 } ?: 1)
        }
        var sessionCount by remember(editingPlan) {
            mutableIntStateOf(editingPlan?.sessionCount?.takeIf { it > 0 } ?: 12)
        }
        var priceVnd by remember(editingPlan) { mutableLongStateOf(editingPlan?.priceVnd ?: 0L) }

        AlertDialog(
            onDismissRequest = { showAddPlanDialog = false },
            title = { Text(if (editingPlan == null) "Thêm gói giá $currentDomain" else "Sửa gói giá $currentDomain") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (currentDomain == "GYM") {
                        Text("Nhóm bảng giá Gym:", style = MaterialTheme.typography.labelMedium)
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf("NAM" to "Nam", "NU" to "Nữ", "TRE_EM" to "Trẻ em").forEach { (c, l) ->
                                    FilterChip(
                                        selected = category == c,
                                        onClick = { category = c },
                                        label = { Text(l) }
                                    )
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf("VE_NGAY" to "Vé ngày", "VE_TUAN" to "Vé tuần", "PT" to "Gói PT").forEach { (c, l) ->
                                    FilterChip(
                                        selected = category == c,
                                        onClick = { category = c },
                                        label = { Text(l) }
                                    )
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = planName,
                        onValueChange = { planName = it },
                        label = { Text("Tên gói *") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("price_plan_name_input")
                    )

                    if (category == "PT") {
                        OutlinedTextField(
                            value = sessionCount.toString(),
                            onValueChange = { sessionCount = it.filter { ch -> ch.isDigit() }.toIntOrNull() ?: 1 },
                            label = { Text("Số buổi PT") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else if (category != "VE_NGAY" && category != "VE_TUAN") {
                        Text("Thời hạn gói (tháng):", style = MaterialTheme.typography.labelMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            val monthChoices = if (currentDomain == "GYM") listOf(1, 2, 3, 12) else listOf(1, 2, 3)
                            monthChoices.forEach { m ->
                                FilterChip(
                                    selected = durationMonths == m,
                                    onClick = { durationMonths = m },
                                    label = { Text(if (m == 12) "12T" else "$m T") }
                                )
                            }
                        }
                    }

                    VndAmountField(
                        label = "Giá niêm yết (VNĐ)",
                        amountVnd = priceVnd,
                        onAmountChange = { priceVnd = it },
                        testTagName = "price_plan_vnd_input"
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onSavePricePlan(
                            editingPlan?.id,
                            currentDomain,
                            category,
                            planName,
                            if (category in listOf("PT", "VE_NGAY", "VE_TUAN")) 0 else durationMonths,
                            if (category == "PT") sessionCount else 0,
                            priceVnd
                        )
                        showAddPlanDialog = false
                    },
                    modifier = Modifier.testTag("confirm_save_price_plan_btn")
                ) {
                    Text("Lưu gói giá")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddPlanDialog = false }) {
                    Text("Hủy")
                }
            }
        )
    }

    if (showManualGoogleDialog) {
        var email by remember { mutableStateOf(preferences.googleAccountEmail) }
        var token by remember { mutableStateOf(preferences.googleAccessToken) }

        AlertDialog(
            onDismissRequest = { showManualGoogleDialog = false },
            title = { Text("Kết nối tài khoản Google Drive") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Email Google") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = token,
                        onValueChange = { token = it },
                        label = { Text("OAuth Access Token (Tùy chọn)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    onConnectGoogleManual(email, token)
                    showManualGoogleDialog = false
                }) {
                    Text("Lưu")
                }
            },
            dismissButton = {
                TextButton(onClick = { showManualGoogleDialog = false }) {
                    Text("Hủy")
                }
            }
        )
    }
}

@Composable
private fun SettingsSectionChip(
    title: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(8.dp),
        color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
        modifier = modifier.height(38.dp)
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.padding(horizontal = 8.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                color = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
        }
    }
}

/**
 * Unified Trash Screen (Section 9 of Upgrade PRD):
 * - Single unified screen whether opened from Home Dashboard or Settings
 * - Stores deleted Members, Contracts, Price Plans, PT Clients, and Tickets indefinitely (no auto-delete)
 * - Supports individual item Restore
 * - Supports Checkbox multi-select -> "Xóa vĩnh viễn" -> Confirmation Dialog showing exact count and scope
 * - No instant "delete all" without selection and confirmation
 */
@Composable
fun TrashScreen(
    snapshot: AppDataSnapshot,
    onBack: () -> Unit,
    onRestoreItem: (TrashSelectableItem) -> Unit,
    onPermanentlyDeleteItems: (List<TrashSelectableItem>) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedKeys by remember { mutableStateOf<Set<String>>(emptySet()) }
    var itemsPendingPermanentDelete by remember { mutableStateOf<List<TrashSelectableItem>?>(null) }

    val allTrashItems = remember(snapshot, searchQuery) {
        val q = searchQuery.trim().lowercase()
        val list = mutableListOf<TrashSelectableItem>()

        // 1. Deleted / Cancelled Contracts
        snapshot.contracts.filter { it.isDeleted }.forEach { c ->
            val isCancelled = c.deleteType == "CONTRACT_CANCELLED" || c.status == "CANCELLED"
            list += TrashSelectableItem(
                type = TrashItemType.CONTRACT,
                id = c.id,
                title = "HĐ ${c.contractCode} (${c.domain}) • ${c.planNameSnapshot}",
                subtitle = "Giá trị: ${FormatUtils.formatVnd(c.agreedValueVnd)} • Hoàn: ${FormatUtils.formatVnd(c.refundedAmountVnd)}",
                badgeText = if (isCancelled) "Hủy HĐ & Hoàn tiền" else "Hợp đồng đã xóa",
                isCancelledRefund = isCancelled
            )
        }

        // 2. Deleted Members
        snapshot.members.filter { it.isDeleted }.forEach { m ->
            list += TrashSelectableItem(
                type = TrashItemType.MEMBER,
                id = m.id,
                title = "Hội viên: ${m.fullName} (${m.domain})",
                subtitle = "SĐT: ${m.phoneNumber} • ${m.deleteReason ?: "Đã xóa"}",
                badgeText = "Hội viên",
                isCancelledRefund = false
            )
        }

        // 3. Deleted Price Plans
        snapshot.pricePlans.filter { it.isDeleted }.forEach { p ->
            list += TrashSelectableItem(
                type = TrashItemType.PRICE_PLAN,
                id = p.id,
                title = "Gói tập: ${p.planName} (${p.domain})",
                subtitle = "Nhóm: ${p.category} • Giá: ${FormatUtils.formatVnd(p.priceVnd)}",
                badgeText = "Gói tập",
                isCancelledRefund = false
            )
        }

        // 4. Deleted PT Clients
        snapshot.ptClients.filter { it.isDeleted }.forEach { pt ->
            list += TrashSelectableItem(
                type = TrashItemType.PT_CLIENT,
                id = pt.id,
                title = "Khách PT: ${pt.fullName}",
                subtitle = "SĐT: ${pt.phoneNumber} • HLV: ${pt.trainerName}",
                badgeText = "Hồ sơ PT",
                isCancelledRefund = false
            )
        }

        // 5. Deleted Tickets
        snapshot.shortTermTickets.filter { it.isDeleted }.forEach { t ->
            list += TrashSelectableItem(
                type = TrashItemType.TICKET,
                id = t.id,
                title = "Vé ${t.ticketCode} (${if (t.ticketType == "VE_NGAY") "Vé ngày" else "Vé tuần"})",
                subtitle = "Ngày bán: ${DateCalculator.formatDisplay(t.saleDateIso)} • ${FormatUtils.formatVnd(t.totalAmountVnd)}",
                badgeText = "Vé ngắn hạn",
                isCancelledRefund = false
            )
        }

        if (q.isEmpty()) list
        else list.filter {
            it.title.lowercase().contains(q) || it.subtitle.lowercase().contains(q)
        }
    }

    // Keep selectedKeys valid when items list changes
    val validSelectedItems = remember(allTrashItems, selectedKeys) {
        allTrashItems.filter { "${it.type}_${it.id}" in selectedKeys }
    }

    Scaffold(
        topBar = {
            FitnessTopAppBar(
                title = "Thùng rác (${allTrashItems.size})",
                onBackClick = onBack,
                actions = {
                    if (allTrashItems.isNotEmpty()) {
                        val allSelected = validSelectedItems.size == allTrashItems.size
                        TextButton(
                            onClick = {
                                selectedKeys = if (allSelected) {
                                    emptySet()
                                } else {
                                    allTrashItems.map { "${it.type}_${it.id}" }.toSet()
                                }
                            },
                            modifier = Modifier.testTag("toggle_select_all_trash_btn")
                        ) {
                            Text(if (allSelected) "Bỏ chọn" else "Chọn tất cả")
                        }
                    }
                }
            )
        },
        bottomBar = {
            if (validSelectedItems.isNotEmpty()) {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 4.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Đã chọn ${validSelectedItems.size} mục",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Button(
                            onClick = { itemsPendingPermanentDelete = validSelectedItems },
                            colors = ButtonDefaults.buttonColors(containerColor = StatusDangerRed),
                            modifier = Modifier.testTag("delete_selected_trash_btn")
                        ) {
                            Icon(Icons.Default.DeleteForever, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Xóa vĩnh viễn (${validSelectedItems.size})")
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 1.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Tìm trong Thùng rác theo tên, SĐT, mã HĐ...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                )
            }

            if (allTrashItems.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.RestoreFromTrash,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.size(48.dp)
                        )
                        Text(
                            text = "Thùng rác trống",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(allTrashItems, key = { "${it.type}_${it.id}" }) { item ->
                        val itemKey = "${item.type}_${item.id}"
                        val isSelected = itemKey in selectedKeys

                        ElevatedCard(
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedKeys = if (isSelected) selectedKeys - itemKey else selectedKeys + itemKey
                                }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = isSelected,
                                    onCheckedChange = { checked ->
                                        selectedKeys = if (checked) selectedKeys + itemKey else selectedKeys - itemKey
                                    },
                                    modifier = Modifier.testTag("trash_checkbox_${item.id}")
                                )
                                Column(
                                    modifier = Modifier
                                        .weight(1f)
                                        .padding(horizontal = 6.dp),
                                    verticalArrangement = Arrangement.spacedBy(3.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = item.title,
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.weight(1f)
                                        )
                                        StatusPill(
                                            text = item.badgeText,
                                            tone = if (item.isCancelledRefund) StatusTone.DANGER else StatusTone.WARNING
                                        )
                                    }
                                    Text(
                                        text = item.subtitle,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End
                                    ) {
                                        TextButton(
                                            onClick = { onRestoreItem(item) },
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                            modifier = Modifier.testTag("restore_trash_btn_${item.id}")
                                        ) {
                                            Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Khôi phục", style = MaterialTheme.typography.labelMedium)
                                        }
                                        TextButton(
                                            onClick = { itemsPendingPermanentDelete = listOf(item) },
                                            colors = ButtonDefaults.textButtonColors(contentColor = StatusDangerRed),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                        ) {
                                            Text("Xóa vĩnh viễn", style = MaterialTheme.typography.labelMedium)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Confirmation Dialog for Permanent Deletion (Section 9.4 & Section 10)
    itemsPendingPermanentDelete?.let { itemsToDelete ->
        AlertDialog(
            onDismissRequest = { itemsPendingPermanentDelete = null },
            title = { Text("Xác nhận xóa vĩnh viễn (${itemsToDelete.size} mục)") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "Bạn sắp xóa vĩnh viễn ${itemsToDelete.size} mục đã chọn khỏi cơ sở dữ liệu. Hành động này không thể hoàn tác.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = StatusDangerRed,
                        fontWeight = FontWeight.SemiBold
                    )
                    itemsToDelete.take(5).forEach { item ->
                        Text("• ${item.title}", style = MaterialTheme.typography.bodySmall)
                    }
                    if (itemsToDelete.size > 5) {
                        Text("... và ${itemsToDelete.size - 5} mục khác", style = MaterialTheme.typography.bodySmall)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onPermanentlyDeleteItems(itemsToDelete)
                        selectedKeys = selectedKeys - itemsToDelete.map { "${it.type}_${it.id}" }.toSet()
                        itemsPendingPermanentDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusDangerRed),
                    modifier = Modifier.testTag("confirm_permanent_delete_trash_btn")
                ) {
                    Text("Xóa vĩnh viễn")
                }
            },
            dismissButton = {
                TextButton(onClick = { itemsPendingPermanentDelete = null }) {
                    Text("Hủy")
                }
            }
        )
    }
}
