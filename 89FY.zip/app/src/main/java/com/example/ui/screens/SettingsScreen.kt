package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.PriceChange
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import com.example.data.model.BackupBundle
import com.example.domain.FitnessCalculator
import com.example.domain.ReportExporter
import com.example.ui.auth.onGoogleSignInClicked
import com.example.ui.components.ReviewAndConfirmDialog
import com.example.ui.components.ScreenHeaderBar
import com.example.ui.theme.GymFemalePink
import com.example.ui.theme.GymGreenBright
import com.example.ui.theme.GymKidOrange
import com.example.ui.theme.SettingsIndigoBright
import com.example.ui.theme.YogaPurpleBright
import com.example.ui.viewmodel.FitnessAppState
import com.example.ui.viewmodel.FitnessViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SettingsScreen(
    appState: FitnessAppState,
    viewModel: FitnessViewModel,
    userEmail: String?,
    onGoogleConnected: (String) -> Unit = {},
    onSignOut: () -> Unit,
    onBack: () -> Unit
) {
    // Theo PRD Mục 7 (CÀI ĐẶT) & Kiến trúc Offline-first:
    // Gồm đúng 3 phần:
    // 1. Bảng giá: 4 khung màu phân biệt (GYM Nam xanh lá, GYM Nữ hồng, Trẻ em cam, YOGA tím);
    //    đổi bảng giá chỉ áp dụng cho hợp đồng tạo mới về sau.
    // 2. Giao diện sáng/tối: áp dụng toàn ứng dụng.
    // 3. Đồng bộ — Sao lưu — Khôi phục:
    //    - Đây là nơi duy nhất chứa chức năng đăng nhập Google.
    //    - Chưa đăng nhập: hiển thị nút "Đăng nhập Google để sử dụng đồng bộ và sao lưu".
    //    - Đã đăng nhập: hiển thị tài khoản Google đang kết nối, nút đăng xuất, trạng thái đồng bộ & thời gian đồng bộ gần nhất.
    //    - Khi khôi phục luôn cảnh báo và yêu cầu xác nhận trước.
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }
    val cfg = appState.config

    BackHandler {
        onBack()
    }

    // State cho 4 khung bảng giá
    var nam1M by remember(cfg) { mutableStateOf(cfg.gymNam1M.toString()) }
    var nam2M by remember(cfg) { mutableStateOf(cfg.gymNam2M.toString()) }
    var nam3M by remember(cfg) { mutableStateOf(cfg.gymNam3M.toString()) }
    var nam12M by remember(cfg) { mutableStateOf(cfg.gymNam12M.toString()) }

    var nu1M by remember(cfg) { mutableStateOf(cfg.gymNu1M.toString()) }
    var nu2M by remember(cfg) { mutableStateOf(cfg.gymNu2M.toString()) }
    var nu3M by remember(cfg) { mutableStateOf(cfg.gymNu3M.toString()) }
    var nu12M by remember(cfg) { mutableStateOf(cfg.gymNu12M.toString()) }

    var treEm1M by remember(cfg) { mutableStateOf(cfg.gymTreEm1M.toString()) }
    var treEm2M by remember(cfg) { mutableStateOf(cfg.gymTreEm2M.toString()) }
    var treEm3M by remember(cfg) { mutableStateOf(cfg.gymTreEm3M.toString()) }
    var treEm12M by remember(cfg) { mutableStateOf(cfg.gymTreEm12M.toString()) }

    var yoga1M by remember(cfg) { mutableStateOf(cfg.yoga1M.toString()) }
    var yoga2M by remember(cfg) { mutableStateOf(cfg.yoga2M.toString()) }
    var yoga3M by remember(cfg) { mutableStateOf(cfg.yoga3M.toString()) }

    var showConfirmSavePricing by remember { mutableStateOf(false) }
    var pendingRestoreJson by remember { mutableStateOf<String?>(null) }
    var pendingRestoreSourceLabel by remember { mutableStateOf("") }
    var pendingCloudRestoreBundle by remember { mutableStateOf<BackupBundle?>(null) }

    var isSigningInGoogle by remember { mutableStateOf(false) }
    var googleAuthErrorMessage by remember { mutableStateOf<String?>(null) }

    // SAF: Tạo file sao lưu .json trực tiếp vào bộ nhớ máy / Google Drive
    val createBackupDocLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                val bundle = viewModel.buildBackupBundle()
                bundle.validateIntegrity().getOrThrow()
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(bundle.toJsonString().toByteArray(Charsets.UTF_8))
                }
                viewModel.showToast("Đã xuất file sao lưu (.json) từ dữ liệu Local thành công")
            }.onFailure {
                viewModel.showToast("Không thể ghi file sao lưu: ${it.localizedMessage}")
            }
        }
    }

    // SAF: Chọn file .json từ bộ nhớ máy hoặc Google Drive để khôi phục
    val openBackupDocLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                val text = context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use {
                    it.readText()
                }
                if (!text.isNullOrBlank()) {
                    pendingRestoreSourceLabel = "Tệp sao lưu (.json) đã chọn"
                    pendingRestoreJson = text
                } else {
                    viewModel.showToast("Tệp sao lưu trống hoặc không hợp lệ")
                }
            }.onFailure {
                viewModel.showToast("Lỗi đọc tệp sao lưu: ${it.localizedMessage}")
            }
        }
    }

    Scaffold(
        topBar = {
            ScreenHeaderBar(
                title = "CÀI ĐẶT",
                subtitle = "1. Bảng giá • 2. Giao diện Sáng/Tối • 3. Đồng bộ & Sao lưu",
                accentColor = SettingsIndigoBright,
                onBack = onBack
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // =========================================================================
            // PHẦN 1: BẢNG GIÁ (4 KHUNG MÀU PHÂN BIỆT)
            // =========================================================================
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.PriceChange, contentDescription = null, tint = SettingsIndigoBright)
                            Spacer(Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "1. BẢNG GIÁ NIÊM YẾT",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = SettingsIndigoBright
                                )
                                Text(
                                    text = "Quy tắc: Đổi bảng giá chỉ áp dụng cho hợp đồng tạo mới về sau; hợp đồng cũ giữ nguyên.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        // Khung 1: GYM Nam — Xanh lá
                        PricingFrame4Months(
                            title = "GYM NAM (Khung Xanh lá)",
                            frameColor = GymGreenBright,
                            m1 = nam1M, onM1 = { nam1M = it },
                            m2 = nam2M, onM2 = { nam2M = it },
                            m3 = nam3M, onM3 = { nam3M = it },
                            m12 = nam12M, onM12 = { nam12M = it }
                        )

                        // Khung 2: GYM Nữ — Hồng
                        PricingFrame4Months(
                            title = "GYM NỮ (Khung Hồng)",
                            frameColor = GymFemalePink,
                            m1 = nu1M, onM1 = { nu1M = it },
                            m2 = nu2M, onM2 = { nu2M = it },
                            m3 = nu3M, onM3 = { nu3M = it },
                            m12 = nu12M, onM12 = { nu12M = it }
                        )

                        // Khung 3: Trẻ em — Cam
                        PricingFrame4Months(
                            title = "GYM TRẺ EM (Khung Cam)",
                            frameColor = GymKidOrange,
                            m1 = treEm1M, onM1 = { treEm1M = it },
                            m2 = treEm2M, onM2 = { treEm2M = it },
                            m3 = treEm3M, onM3 = { treEm3M = it },
                            m12 = treEm12M, onM12 = { treEm12M = it }
                        )

                        // Khung 4: YOGA — Tím
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = YogaPurpleBright.copy(alpha = 0.08f),
                            border = BorderStroke(1.5.dp, YogaPurpleBright)
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "YOGA (Khung Tím)",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = YogaPurpleBright
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    PriceInputCell("Gói 1 tháng", yoga1M, { yoga1M = it }, Modifier.weight(1f))
                                    PriceInputCell("Gói 2 tháng", yoga2M, { yoga2M = it }, Modifier.weight(1f))
                                    PriceInputCell("Gói 3 tháng", yoga3M, { yoga3M = it }, Modifier.weight(1f))
                                }
                            }
                        }

                        Button(
                            onClick = { showConfirmSavePricing = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = SettingsIndigoBright,
                                contentColor = Color.White
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("save_pricing_button")
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Xem lại & Lưu bảng giá")
                        }
                    }
                }
            }

            // =========================================================================
            // PHẦN 2: GIAO DIỆN SÁNG / TỐI
            // =========================================================================
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.DarkMode, contentDescription = null, tint = SettingsIndigoBright)
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "2. GIAO DIỆN SÁNG / TỐI",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = SettingsIndigoBright
                                )
                                Text(
                                    text = if (cfg.isDarkMode) "Đang bật Giao diện Tối toàn ứng dụng" else "Đang bật Giao diện Sáng toàn ứng dụng",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Switch(
                            checked = cfg.isDarkMode,
                            onCheckedChange = { viewModel.toggleDarkMode(it) },
                            modifier = Modifier.testTag("dark_mode_switch")
                        )
                    }
                }
            }

            // =========================================================================
            // PHẦN 3: ĐỒNG BỘ — SAO LƯU — KHÔI PHỤC (NƠI DUY NHẤT ĐĂNG NHẬP GOOGLE)
            // =========================================================================
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Backup, contentDescription = null, tint = SettingsIndigoBright)
                            Spacer(Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "3. ĐỒNG BỘ — SAO LƯU — KHÔI PHỤC",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = SettingsIndigoBright
                                )
                                Text(
                                    text = "Dữ liệu luôn lưu trực tiếp trên thiết bị (Offline-first). Đăng nhập Google khi cần đồng bộ & sao lưu Cloud.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        HorizontalDivider()

                        // Khối A: Tài khoản Google & Đồng bộ Cloud
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = SettingsIndigoBright.copy(alpha = 0.08f),
                            border = BorderStroke(1.dp, SettingsIndigoBright.copy(alpha = 0.35f))
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = if (userEmail != null) Icons.Default.CloudDone else Icons.Default.CloudOff,
                                        contentDescription = null,
                                        tint = if (userEmail != null) GymGreenBright else SettingsIndigoBright
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        text = "TÀI KHOẢN GOOGLE & ĐỒNG BỘ CLOUD",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = SettingsIndigoBright
                                    )
                                }

                                if (userEmail == null) {
                                    // TRẠNG THÁI CHƯA ĐĂNG NHẬP GOOGLE
                                    Text(
                                        text = "Trạng thái: Chưa đăng nhập Google — Ứng dụng đang hoạt động hoàn toàn Offline trên thiết bị.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )

                                    val formattedSync = if (cfg.lastSyncEpoch > 0L) {
                                        SimpleDateFormat("HH:mm dd/MM/yyyy", Locale.getDefault()).format(Date(cfg.lastSyncEpoch))
                                    } else {
                                        "Chưa đồng bộ lần nào"
                                    }
                                    Text(
                                        text = "Thời gian đồng bộ gần nhất: $formattedSync",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )

                                    if (googleAuthErrorMessage != null) {
                                        Surface(
                                            color = MaterialTheme.colorScheme.errorContainer,
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Text(
                                                text = googleAuthErrorMessage ?: "",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onErrorContainer,
                                                modifier = Modifier.padding(10.dp)
                                            )
                                        }
                                    }

                                    Button(
                                        onClick = {
                                            googleAuthErrorMessage = null
                                            isSigningInGoogle = true
                                            onGoogleSignInClicked(
                                                context = context,
                                                credentialManager = credentialManager,
                                                onAuthSuccess = { user ->
                                                    isSigningInGoogle = false
                                                    val email = user.email ?: user.displayName ?: "Tài khoản Google đã xác thực"
                                                    onGoogleConnected(email)
                                                    viewModel.showToast("Đã kết nối tài khoản Google: $email")
                                                },
                                                onAuthError = { errMsg ->
                                                    isSigningInGoogle = false
                                                    googleAuthErrorMessage = errMsg
                                                },
                                                scope = scope,
                                                onAuthCancelled = {
                                                    isSigningInGoogle = false
                                                }
                                            )
                                        },
                                        enabled = !isSigningInGoogle,
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = SettingsIndigoBright,
                                            contentColor = Color.White
                                        ),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("settings_google_sign_in_button")
                                    ) {
                                        if (isSigningInGoogle) {
                                            CircularProgressIndicator(
                                                modifier = Modifier.size(18.dp),
                                                color = Color.White,
                                                strokeWidth = 2.dp
                                            )
                                            Spacer(Modifier.width(8.dp))
                                        } else {
                                            Icon(Icons.Default.AccountCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                                            Spacer(Modifier.width(8.dp))
                                        }
                                        Text("Đăng nhập Google để sử dụng đồng bộ và sao lưu")
                                    }
                                } else {
                                    // TRẠNG THÁI ĐÃ ĐĂNG NHẬP GOOGLE
                                    Text(
                                        text = "Tài khoản Google đang kết nối: $userEmail",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.testTag("connected_google_account_text")
                                    )
                                    Text(
                                        text = "Trạng thái đồng bộ: ${appState.lastSyncActionStatus}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    val formattedSync = if (cfg.lastSyncEpoch > 0L) {
                                        SimpleDateFormat("HH:mm dd/MM/yyyy", Locale.getDefault()).format(Date(cfg.lastSyncEpoch))
                                    } else {
                                        "Chưa đồng bộ lần nào"
                                    }
                                    Text(
                                        text = "Thời gian đồng bộ gần nhất: $formattedSync",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Button(
                                            onClick = { viewModel.triggerManualCloudSync() },
                                            colors = ButtonDefaults.buttonColors(containerColor = SettingsIndigoBright),
                                            modifier = Modifier
                                                .weight(1f)
                                                .testTag("cloud_backup_button")
                                        ) {
                                            Icon(Icons.Default.CloudSync, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(Modifier.width(6.dp))
                                            Text("Sao lưu lên Cloud")
                                        }
                                        OutlinedButton(
                                            onClick = {
                                                viewModel.fetchCloudBackupForRestore { bundle ->
                                                    pendingCloudRestoreBundle = bundle
                                                }
                                            },
                                            modifier = Modifier
                                                .weight(1f)
                                                .testTag("cloud_restore_button")
                                        ) {
                                            Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(Modifier.width(6.dp))
                                            Text("Khôi phục từ Cloud")
                                        }
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        OutlinedButton(
                                            onClick = {
                                                runCatching {
                                                    val bundle = viewModel.buildBackupBundle()
                                                    bundle.validateIntegrity().getOrThrow()
                                                    val file = ReportExporter.exportBackupJsonFile(context, bundle)
                                                    ReportExporter.shareFile(
                                                        context = context,
                                                        file = file,
                                                        mimeType = "application/json",
                                                        chooserTitle = "Sao lưu lên Google Drive"
                                                    )
                                                }.onFailure {
                                                    viewModel.showToast("Lỗi tạo file sao lưu: ${it.localizedMessage}")
                                                }
                                            },
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text("Lưu lên Google Drive")
                                        }

                                        OutlinedButton(
                                            onClick = {
                                                googleAuthErrorMessage = null
                                                onSignOut()
                                            },
                                            modifier = Modifier
                                                .weight(1f)
                                                .testTag("settings_google_sign_out_button")
                                        ) {
                                            Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(Modifier.width(6.dp))
                                            Text("Đăng xuất Google")
                                        }
                                    }
                                }
                            }
                        }

                        // Khối B: Offline (Xuất file sao lưu & Chọn file khôi phục)
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "OFFLINE — XUẤT & KHÔI PHỤC TỪ TỆP SAO LƯU (.JSON)",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Đọc dữ liệu từ cơ sở dữ liệu Local trên thiết bị, kiểm tra tính toàn vẹn và xuất ra file .json hoặc chọn file để khôi phục (không cần Internet).",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = {
                                            val defaultFileName = "89Fitness_SaoLuu_${FitnessCalculator.todayIso()}.json"
                                            createBackupDocLauncher.launch(defaultFileName)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = GymGreenBright),
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("export_offline_backup_button")
                                    ) {
                                        Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text("Xuất file sao lưu")
                                    }

                                    OutlinedButton(
                                        onClick = {
                                            openBackupDocLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
                                        },
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("import_offline_backup_button")
                                    ) {
                                        Icon(Icons.Default.FileUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text("Chọn file khôi phục")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showConfirmSavePricing) {
        val updated = cfg.copy(
            gymNam1M = nam1M.toLongOrNull() ?: cfg.gymNam1M,
            gymNam2M = nam2M.toLongOrNull() ?: cfg.gymNam2M,
            gymNam3M = nam3M.toLongOrNull() ?: cfg.gymNam3M,
            gymNam12M = nam12M.toLongOrNull() ?: cfg.gymNam12M,
            gymNu1M = nu1M.toLongOrNull() ?: cfg.gymNu1M,
            gymNu2M = nu2M.toLongOrNull() ?: cfg.gymNu2M,
            gymNu3M = nu3M.toLongOrNull() ?: cfg.gymNu3M,
            gymNu12M = nu12M.toLongOrNull() ?: cfg.gymNu12M,
            gymTreEm1M = treEm1M.toLongOrNull() ?: cfg.gymTreEm1M,
            gymTreEm2M = treEm2M.toLongOrNull() ?: cfg.gymTreEm2M,
            gymTreEm3M = treEm3M.toLongOrNull() ?: cfg.gymTreEm3M,
            gymTreEm12M = treEm12M.toLongOrNull() ?: cfg.gymTreEm12M,
            yoga1M = yoga1M.toLongOrNull() ?: cfg.yoga1M,
            yoga2M = yoga2M.toLongOrNull() ?: cfg.yoga2M,
            yoga3M = yoga3M.toLongOrNull() ?: cfg.yoga3M
        )
        ReviewAndConfirmDialog(
            title = "Xác nhận lưu Bảng giá mới",
            summaryItems = listOf(
                "GYM Nam (1T/2T/3T/12T)" to "${FitnessCalculator.formatCurrency(updated.gymNam1M)} / ${FitnessCalculator.formatCurrency(updated.gymNam2M)} / ${FitnessCalculator.formatCurrency(updated.gymNam3M)} / ${FitnessCalculator.formatCurrency(updated.gymNam12M)}",
                "GYM Nữ (1T/2T/3T/12T)" to "${FitnessCalculator.formatCurrency(updated.gymNu1M)} / ${FitnessCalculator.formatCurrency(updated.gymNu2M)} / ${FitnessCalculator.formatCurrency(updated.gymNu3M)} / ${FitnessCalculator.formatCurrency(updated.gymNu12M)}",
                "Trẻ em (1T/2T/3T/12T)" to "${FitnessCalculator.formatCurrency(updated.gymTreEm1M)} / ${FitnessCalculator.formatCurrency(updated.gymTreEm2M)} / ${FitnessCalculator.formatCurrency(updated.gymTreEm3M)} / ${FitnessCalculator.formatCurrency(updated.gymTreEm12M)}",
                "YOGA (1T/2T/3T)" to "${FitnessCalculator.formatCurrency(updated.yoga1M)} / ${FitnessCalculator.formatCurrency(updated.yoga2M)} / ${FitnessCalculator.formatCurrency(updated.yoga3M)}",
                "Phạm vi áp dụng" to "Chỉ áp dụng cho hợp đồng tạo mới về sau"
            ),
            accentColor = SettingsIndigoBright,
            onConfirm = {
                showConfirmSavePricing = false
                viewModel.updatePricingTable(updated)
            },
            onDismiss = { showConfirmSavePricing = false }
        )
    }

    // Cảnh báo và yêu cầu xác nhận trước khi khôi phục từ file .json (Quy tắc bắt buộc)
    pendingRestoreJson?.let { rawJson ->
        AlertDialog(
            onDismissRequest = { pendingRestoreJson = null },
            icon = {
                Icon(
                    imageVector = Icons.Default.Restore,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(32.dp)
                )
            },
            title = { Text("Cảnh báo trước khi Khôi phục dữ liệu") },
            text = {
                Text(
                    "Bạn đang chuẩn bị khôi phục dữ liệu từ: $pendingRestoreSourceLabel.\n\n" +
                        "Hệ thống sẽ kiểm tra tính toàn vẹn của bản sao lưu và cập nhật dữ liệu vào cơ sở dữ liệu Local trên thiết bị (ưu tiên bản mới nhất). Bạn có chắc chắn muốn tiếp tục khôi phục?"
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val jsonToRestore = rawJson
                        pendingRestoreJson = null
                        viewModel.restoreFromBackupJson(jsonToRestore)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Xác nhận Khôi phục")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { pendingRestoreJson = null }) {
                    Text("Hủy")
                }
            }
        )
    }

    // Cảnh báo và yêu cầu xác nhận trước khi khôi phục từ Cloud về Local DB
    pendingCloudRestoreBundle?.let { cloudBundle ->
        AlertDialog(
            onDismissRequest = { pendingCloudRestoreBundle = null },
            icon = {
                Icon(
                    imageVector = Icons.Default.Restore,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(32.dp)
                )
            },
            title = { Text("Xác nhận Khôi phục dữ liệu từ Cloud") },
            text = {
                Text(
                    "Đã tìm thấy bản sao lưu trên Google Cloud:\n" +
                        "• Hội viên: ${cloudBundle.members.size}\n" +
                        "• Hợp đồng: ${cloudBundle.contracts.size}\n" +
                        "• Buổi tập PT: ${cloudBundle.ptSessions.size}\n" +
                        "• Vé lẻ: ${cloudBundle.singleTickets.size}\n\n" +
                        "Hệ thống đã kiểm tra tính toàn vẹn dữ liệu. Bạn có chắc chắn muốn khôi phục dữ liệu này vào cơ sở dữ liệu Local trên thiết bị không?"
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val bundleToRestore = cloudBundle
                        pendingCloudRestoreBundle = null
                        viewModel.restoreFromConfirmedBundle(bundleToRestore)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Xác nhận Khôi phục")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { pendingCloudRestoreBundle = null }) {
                    Text("Hủy")
                }
            }
        )
    }
}

@Composable
private fun PricingFrame4Months(
    title: String,
    frameColor: Color,
    m1: String, onM1: (String) -> Unit,
    m2: String, onM2: (String) -> Unit,
    m3: String, onM3: (String) -> Unit,
    m12: String, onM12: (String) -> Unit
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = frameColor.copy(alpha = 0.08f),
        border = BorderStroke(1.5.dp, frameColor)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = frameColor
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PriceInputCell("Gói 1 tháng", m1, onM1, Modifier.weight(1f))
                PriceInputCell("Gói 2 tháng", m2, onM2, Modifier.weight(1f))
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PriceInputCell("Gói 3 tháng", m3, onM3, Modifier.weight(1f))
                PriceInputCell("Gói 12 tháng", m12, onM12, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun PriceInputCell(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    OutlinedTextField(
        value = value,
        onValueChange = { onValueChange(it.filter { ch -> ch.isDigit() }) },
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        singleLine = true,
        modifier = modifier
    )
}
