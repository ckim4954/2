package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.DateCalculator
import com.example.domain.FormatUtils
import com.example.ui.ContractDebtUi
import com.example.ui.ExpirySortOrder
import com.example.ui.MemberExpiryFilter
import com.example.ui.MemberSummaryUi
import com.example.ui.theme.*

/**
 * Tracking & Debt Management Screen (Sections 12 & 13):
 * - Strictly separates Gym and Yoga
 * - Sub-tab 0: Theo dõi Hội viên (Tổng số, Còn hạn, Sắp hết hạn 7 ngày, Đã hết hạn)
 *   with search by STT, Name, Phone and ascending/descending expiry sort
 * - Sub-tab 1: Quản lý Công nợ (Công nợ Gym / Công nợ Yoga)
 *   showing count of debt contracts, total debt, search by Name/Phone/ContractCode,
 *   payment history, overpayment alerts, and [Thu tiền] button.
 */
@Composable
fun TrackingAndDebtScreen(
    initialDomain: String,
    initialSubTab: Int,
    gymMembers: List<MemberSummaryUi>,
    yogaMembers: List<MemberSummaryUi>,
    gymDebts: List<ContractDebtUi>,
    yogaDebts: List<ContractDebtUi>,
    onBack: () -> Unit,
    onMemberClick: (String) -> Unit,
    onRenewClick: (String) -> Unit,
    onRecordPayment: (String, String, Long, Long, String) -> Unit
) {
    var selectedDomain by remember(initialDomain) { mutableStateOf(initialDomain) }
    var selectedSubTab by remember(initialSubTab) { mutableIntStateOf(initialSubTab) }
    var trackingFilter by remember { mutableStateOf(MemberExpiryFilter.VALID) }
    var sortOrder by remember { mutableStateOf(ExpirySortOrder.ASCENDING) }
    var searchQuery by remember { mutableStateOf("") }

    var debtToPay by remember { mutableStateOf<ContractDebtUi?>(null) }
    var debtToInspect by remember { mutableStateOf<ContractDebtUi?>(null) }

    val activeMembers = if (selectedDomain == "GYM") gymMembers else yogaMembers
    val activeDebts = if (selectedDomain == "GYM") gymDebts else yogaDebts

    val totalCount = activeMembers.size
    val validCount = activeMembers.count { it.isValid }
    val expiringSoonCount = activeMembers.count { it.isExpiringSoon }
    val expiredCount = activeMembers.count { it.isExpired }

    val filteredTrackingMembers = remember(activeMembers, trackingFilter, sortOrder, searchQuery) {
        val q = searchQuery.trim().lowercase()
        val list = activeMembers.filter { m ->
            when (trackingFilter) {
                MemberExpiryFilter.ALL -> true
                MemberExpiryFilter.VALID -> m.isValid
                MemberExpiryFilter.EXPIRING_SOON -> m.isExpiringSoon
                MemberExpiryFilter.EXPIRED -> m.isExpired
            }
        }
        val sorted = when (sortOrder) {
            ExpirySortOrder.ASCENDING -> list.sortedBy { it.endDateIso.ifEmpty { "9999-12-31" } }
            ExpirySortOrder.DESCENDING -> list.sortedByDescending { it.endDateIso }
        }
        if (q.isEmpty()) sorted
        else sorted.filterIndexed { idx, item ->
            val sttStr = FormatUtils.formatStt(idx + 1)
            sttStr.contains(q) ||
                item.member.fullName.lowercase().contains(q) ||
                item.member.phoneNumber.lowercase().contains(q)
        }
    }

    val filteredDebts = remember(activeDebts, searchQuery) {
        val q = searchQuery.trim().lowercase()
        if (q.isEmpty()) activeDebts
        else activeDebts.filter { d ->
            d.memberName.lowercase().contains(q) ||
                d.memberPhone.lowercase().contains(q) ||
                d.contract.contractCode.lowercase().contains(q)
        }
    }

    val totalDebtAmountVnd = remember(activeDebts) { activeDebts.sumOf { it.debtVnd } }
    val debtContractsCount = remember(activeDebts) { activeDebts.count { it.debtVnd > 0L } }

    Scaffold(
        topBar = {
            FitnessTopAppBar(
                title = "Theo dõi & Công nợ",
                subtitle = "Tách biệt độc lập Gym và Yoga",
                domainBadge = selectedDomain,
                onBackClick = onBack
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Top Controls: Domain + Sub-tab (Theo dõi HV vs Công nợ)
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 1.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = selectedDomain == "GYM",
                            onClick = { selectedDomain = "GYM" },
                            label = { Text("Phân hệ GYM") },
                            leadingIcon = { Icon(Icons.Default.FitnessCenter, contentDescription = null) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("tracking_domain_gym")
                        )
                        FilterChip(
                            selected = selectedDomain == "YOGA",
                            onClick = { selectedDomain = "YOGA" },
                            label = { Text("Phân hệ YOGA") },
                            leadingIcon = { Icon(Icons.Default.SelfImprovement, contentDescription = null) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("tracking_domain_yoga")
                        )
                    }

                    TabRow(selectedTabIndex = selectedSubTab) {
                        Tab(
                            selected = selectedSubTab == 0,
                            onClick = { selectedSubTab = 0 },
                            text = { Text("Theo dõi $selectedDomain ($totalCount)") },
                            modifier = Modifier.testTag("tab_member_tracking")
                        )
                        Tab(
                            selected = selectedSubTab == 1,
                            onClick = { selectedSubTab = 1 },
                            text = { Text("Công nợ $selectedDomain ($debtContractsCount)") },
                            modifier = Modifier.testTag("tab_debt_tracking")
                        )
                    }
                }
            }

            if (selectedSubTab == 0) {
                // SUB-TAB 0: Member Status Tracking (Section 13)
                LazyColumn(
                    contentPadding = PaddingValues(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    item {
                        // 4 Interactive Statistic Cards
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                StatSelectCard(
                                    title = "Tổng số hội viên",
                                    count = totalCount,
                                    selected = trackingFilter == MemberExpiryFilter.ALL,
                                    accent = MaterialTheme.colorScheme.primary,
                                    onClick = { trackingFilter = MemberExpiryFilter.ALL },
                                    modifier = Modifier.weight(1f)
                                )
                                StatSelectCard(
                                    title = "Hội viên còn hạn",
                                    count = validCount,
                                    selected = trackingFilter == MemberExpiryFilter.VALID,
                                    accent = StatusActiveGreen,
                                    onClick = { trackingFilter = MemberExpiryFilter.VALID },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                StatSelectCard(
                                    title = "Sắp hết hạn (7 ngày)",
                                    count = expiringSoonCount,
                                    selected = trackingFilter == MemberExpiryFilter.EXPIRING_SOON,
                                    accent = StatusWarningAmber,
                                    onClick = { trackingFilter = MemberExpiryFilter.EXPIRING_SOON },
                                    modifier = Modifier.weight(1f)
                                )
                                StatSelectCard(
                                    title = "Hội viên đã hết hạn",
                                    count = expiredCount,
                                    selected = trackingFilter == MemberExpiryFilter.EXPIRED,
                                    accent = StatusDangerRed,
                                    onClick = { trackingFilter = MemberExpiryFilter.EXPIRED },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }

                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                placeholder = { Text("Tìm STT, Họ tên hoặc SĐT...") },
                                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            FilledTonalIconButton(
                                onClick = {
                                    sortOrder = if (sortOrder == ExpirySortOrder.ASCENDING) {
                                        ExpirySortOrder.DESCENDING
                                    } else {
                                        ExpirySortOrder.ASCENDING
                                    }
                                },
                                modifier = Modifier.size(48.dp)
                            ) {
                                Icon(
                                    imageVector = if (sortOrder == ExpirySortOrder.ASCENDING) {
                                        Icons.Default.ArrowUpward
                                    } else {
                                        Icons.Default.ArrowDownward
                                    },
                                    contentDescription = sortOrder.label
                                )
                            }
                        }
                    }

                    itemsIndexed(filteredTrackingMembers, key = { _, m -> m.member.id }) { idx, m ->
                        val stt = FormatUtils.formatStt(idx + 1)
                        ElevatedCard(
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onMemberClick(m.member.id) }
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "$stt. ${m.member.fullName} — ${m.statusText}",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "SĐT: ${m.member.phoneNumber} • Hết hạn: ${DateCalculator.formatDisplay(m.endDateIso)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Button(
                                    onClick = { onRenewClick(m.member.id) },
                                    modifier = Modifier.defaultMinSize(minHeight = 48.dp)
                                ) {
                                    Text("Gia hạn")
                                }
                            }
                        }
                    }
                }
            } else {
                // SUB-TAB 1: Debt Management (Section 12)
                LazyColumn(
                    contentPadding = PaddingValues(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = StatusDangerRed),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "TỔNG TIỀN CÒN NỢ ($selectedDomain)",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.9f)
                                    )
                                    Text(
                                        text = FormatUtils.formatVnd(totalDebtAmountVnd),
                                        style = MaterialTheme.typography.headlineSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = androidx.compose.ui.graphics.Color.White,
                                        modifier = Modifier.testTag("total_debt_amount_text")
                                    )
                                }
                                Surface(
                                    color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text(
                                        text = "$debtContractsCount HĐ còn nợ",
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = androidx.compose.ui.graphics.Color.White,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                    )
                                }
                            }
                        }
                    }

                    item {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Tìm theo tên, số điện thoại hoặc mã hợp đồng...") },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("debt_search_input")
                        )
                    }

                    if (filteredDebts.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(32.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "Không có hợp đồng $selectedDomain nào còn công nợ.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    } else {
                        itemsIndexed(filteredDebts, key = { _, d -> d.contract.id }) { _, debtItem ->
                            ElevatedCard(
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "${debtItem.memberName} (${debtItem.memberPhone})",
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = "Mã HĐ: ${debtItem.contract.contractCode} • ${debtItem.contract.planNameSnapshot}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        if (debtItem.overpaidVnd > 0L) {
                                            StatusPill(
                                                text = "Thu vượt: ${FormatUtils.formatVnd(debtItem.overpaidVnd)}",
                                                tone = StatusTone.WARNING
                                            )
                                        } else {
                                            StatusPill(
                                                text = "Nợ: ${FormatUtils.formatVnd(debtItem.debtVnd)}",
                                                tone = StatusTone.DANGER
                                            )
                                        }
                                    }

                                    Text(
                                        text = "Giá trị HĐ: ${FormatUtils.formatVnd(debtItem.contract.agreedValueVnd)} • Đã thu: ${FormatUtils.formatVnd(debtItem.totalPaidVnd)}",
                                        style = MaterialTheme.typography.bodySmall
                                    )

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        OutlinedButton(
                                            onClick = { debtToInspect = debtItem },
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Lịch sử (${debtItem.payments.size})")
                                        }
                                        if (debtItem.debtVnd > 0L) {
                                            Button(
                                                onClick = { debtToPay = debtItem },
                                                colors = ButtonDefaults.buttonColors(containerColor = StatusActiveGreen),
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .testTag("collect_debt_btn_${debtItem.contract.id}")
                                            ) {
                                                Icon(Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("Thu tiền")
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Dialog: Collect Debt Payment (Section 12.3)
    debtToPay?.let { item ->
        var payDateIso by remember { mutableStateOf(DateCalculator.todayIso()) }
        var cashVnd by remember { mutableStateOf(item.debtVnd) }
        var transferVnd by remember { mutableStateOf(0L) }
        var note by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { debtToPay = null },
            title = { Text("Thu công nợ — ${item.memberName}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Hợp đồng ${item.contract.contractCode} • Còn nợ: ${FormatUtils.formatVnd(item.debtVnd)}",
                        style = MaterialTheme.typography.labelLarge,
                        color = StatusDangerRed
                    )
                    Text(
                        text = "Lưu ý: Thu công nợ chỉ tăng tiền thực thu và giảm công nợ, không tạo thêm doanh thu phân bổ lần thứ hai.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    DateInputField(
                        label = "Ngày thanh toán",
                        isoDate = payDateIso,
                        onIsoDateChange = { payDateIso = it }
                    )
                    VndAmountField(
                        label = "Thu tiền mặt",
                        amountVnd = cashVnd,
                        onAmountChange = { cashVnd = it },
                        testTagName = "debt_pay_cash_input"
                    )
                    VndAmountField(
                        label = "Thu chuyển khoản",
                        amountVnd = transferVnd,
                        onAmountChange = { transferVnd = it },
                        testTagName = "debt_pay_transfer_input"
                    )
                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it },
                        label = { Text("Ghi chú giao dịch") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onRecordPayment(item.contract.id, payDateIso, cashVnd, transferVnd, note)
                        debtToPay = null
                    },
                    modifier = Modifier.testTag("confirm_debt_payment_btn")
                ) {
                    Text("Xác nhận Thu tiền")
                }
            },
            dismissButton = {
                TextButton(onClick = { debtToPay = null }) {
                    Text("Hủy")
                }
            }
        )
    }

    // Dialog: Inspect Contract & Payment History
    debtToInspect?.let { item ->
        AlertDialog(
            onDismissRequest = { debtToInspect = null },
            title = { Text("Chi tiết HĐ ${item.contract.contractCode}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Hội viên: ${item.memberName} (${item.memberPhone})", fontWeight = FontWeight.Bold)
                    Text("Gói: ${item.contract.planNameSnapshot} (${item.contract.durationMonths} tháng)")
                    Text("Hiệu lực: ${DateCalculator.formatDisplay(item.contract.startDateIso)} → ${DateCalculator.formatDisplay(item.contract.endDateIso)}")
                    Text("Giá trị HĐ: ${FormatUtils.formatVnd(item.contract.agreedValueVnd)}")
                    Text("Tổng đã thu: ${FormatUtils.formatVnd(item.totalPaidVnd)}")
                    Text("Còn nợ: ${FormatUtils.formatVnd(item.debtVnd)}", color = StatusDangerRed, fontWeight = FontWeight.Bold)
                    HorizontalDivider()
                    Text("Lịch sử giao dịch thu tiền (${item.payments.size}):", fontWeight = FontWeight.SemiBold)
                    item.payments.forEach { p ->
                        Text(
                            text = "• ${DateCalculator.formatDisplay(p.paymentDateIso)}: +${FormatUtils.formatVnd(p.totalAmountVnd)} (${p.paymentMethodLabel})",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { debtToInspect = null }) {
                    Text("Đóng")
                }
            }
        )
    }
}

@Composable
private fun StatSelectCard(
    title: String,
    count: Int,
    selected: Boolean,
    accent: androidx.compose.ui.graphics.Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    OutlinedCard(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.outlinedCardColors(
            containerColor = if (selected) accent.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface
        ),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "$count",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = accent
            )
        }
    }
}
