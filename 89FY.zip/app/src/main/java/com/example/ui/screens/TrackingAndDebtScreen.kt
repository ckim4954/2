package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.domain.DateCalculator
import com.example.domain.FormatUtils
import com.example.ui.ContractDebtUi
import com.example.ui.ExpirySortOrder
import com.example.ui.MemberExpiryFilter
import com.example.ui.MemberSummaryUi
import com.example.ui.theme.*

/**
 * Compact Tracking & Debt Management Screen (Section 8 of Upgrade PRD):
 * - Compact header & minimal whitespace to display more members on screen
 * - Preserves:
 *   - Theo dõi Gym & Theo dõi Yoga
 *   - Theo dõi Công nợ
 *   - Thống kê nhanh: Tổng số, Còn hạn, Sắp hết hạn, Đã hết hạn
 *   - Tìm kiếm theo STT, Họ tên, SĐT
 *   - Sắp xếp theo ngày hết hạn
 *   - Bộ lọc trạng thái thời hạn: Tất cả, Còn hạn, Hôm nay hết hạn, Sắp hết hạn 1–7 ngày, Sắp hết hạn 8–15 ngày, Đã hết hạn
 */
@Composable
fun TrackingAndDebtScreen(
    initialDomain: String,
    initialSubTab: Int,
    gymMembers: List<MemberSummaryUi>,
    yogaMembers: List<MemberSummaryUi>,
    gymDebts: List<ContractDebtUi>,
    yogaDebts: List<ContractDebtUi>,
    onBack: () -> Unit,
    onMemberClick: (String) -> Unit,
    onRenewClick: (String) -> Unit,
    onRecordPayment: (String, String, Long, Long, String) -> Unit
) {
    var selectedDomain by remember(initialDomain) { mutableStateOf(initialDomain) }
    var selectedSubTab by remember(initialSubTab) { mutableIntStateOf(initialSubTab) }
    var trackingFilter by remember { mutableStateOf(MemberExpiryFilter.ALL) }
    var sortOrder by remember { mutableStateOf(ExpirySortOrder.ASCENDING) }
    var searchQuery by remember { mutableStateOf("") }

    var debtToPay by remember { mutableStateOf<ContractDebtUi?>(null) }
    var debtToInspect by remember { mutableStateOf<ContractDebtUi?>(null) }

    val activeMembers = if (selectedDomain == "GYM") gymMembers else yogaMembers
    val activeDebts = if (selectedDomain == "GYM") gymDebts else yogaDebts

    val totalCount = activeMembers.size
    val validCount = activeMembers.count { it.isValid }
    val todayExpiringCount = activeMembers.count { it.isTodayExpiring }
    val expiring1To7Count = activeMembers.count { it.isExpiringSoon }
    val expiring8To15Count = activeMembers.count { it.isExpiring8To15 }
    val expiredCount = activeMembers.count { it.isExpired }

    val filteredTrackingMembers = remember(activeMembers, trackingFilter, sortOrder, searchQuery) {
        val q = searchQuery.trim().lowercase()
        val list = activeMembers.filter { m ->
            when (trackingFilter) {
                MemberExpiryFilter.ALL -> true
                MemberExpiryFilter.VALID -> m.isValid
                MemberExpiryFilter.TODAY_EXPIRING -> m.isTodayExpiring
                MemberExpiryFilter.EXPIRING_SOON -> m.isExpiringSoon
                MemberExpiryFilter.EXPIRING_8_15 -> m.isExpiring8To15
                MemberExpiryFilter.EXPIRED -> m.isExpired
            }
        }
        val sorted = when (sortOrder) {
            ExpirySortOrder.ASCENDING -> list.sortedBy { it.endDateIso.ifEmpty { "9999-12-31" } }
            ExpirySortOrder.DESCENDING -> list.sortedByDescending { it.endDateIso }
        }
        if (q.isEmpty()) sorted
        else sorted.filterIndexed { idx, item ->
            val sttPlain = (idx + 1).toString()
            val sttPadded = FormatUtils.formatStt(idx + 1).lowercase()
            sttPlain == q ||
                sttPadded.contains(q) ||
                item.member.fullName.lowercase().contains(q) ||
                item.member.phoneNumber.lowercase().contains(q)
        }
    }

    val filteredDebts = remember(activeDebts, searchQuery) {
        val q = searchQuery.trim().lowercase()
        if (q.isEmpty()) activeDebts
        else activeDebts.filter { d ->
            d.memberName.lowercase().contains(q) ||
                d.memberPhone.lowercase().contains(q) ||
                d.contract.contractCode.lowercase().contains(q)
        }
    }

    val totalDebtAmountVnd = remember(activeDebts) { activeDebts.sumOf { it.debtVnd } }
    val debtContractsCount = remember(activeDebts) { activeDebts.count { it.debtVnd > 0L } }

    Scaffold(
        topBar = {
            FitnessTopAppBar(
                title = "Theo dõi & Công nợ",
                domainBadge = selectedDomain,
                onBackClick = onBack
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Compact Header Controls: Domain + Sub-tab (Theo dõi HV vs Công nợ)
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 1.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = selectedDomain == "GYM",
                            onClick = { selectedDomain = "GYM" },
                            label = { Text("GYM") },
                            leadingIcon = { Icon(Icons.Default.FitnessCenter, contentDescription = null, modifier = Modifier.size(16.dp)) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("tracking_domain_gym")
                        )
                        FilterChip(
                            selected = selectedDomain == "YOGA",
                            onClick = { selectedDomain = "YOGA" },
                            label = { Text("YOGA") },
                            leadingIcon = { Icon(Icons.Default.SelfImprovement, contentDescription = null, modifier = Modifier.size(16.dp)) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("tracking_domain_yoga")
                        )
                    }

                    TabRow(selectedTabIndex = selectedSubTab) {
                        Tab(
                            selected = selectedSubTab == 0,
                            onClick = { selectedSubTab = 0 },
                            text = { Text("Theo dõi $selectedDomain ($totalCount)") },
                            modifier = Modifier.testTag("tab_member_tracking")
                        )
                        Tab(
                            selected = selectedSubTab == 1,
                            onClick = { selectedSubTab = 1 },
                            text = { Text("Công nợ $selectedDomain ($debtContractsCount)") },
                            modifier = Modifier.testTag("tab_debt_tracking")
                        )
                    }
                }
            }

            if (selectedSubTab == 0) {
                // SUB-TAB 0: Compact Member Expiry Tracking (Section 8)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surface)
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Compact 4-column summary strip
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        CompactStatBadge(
                            title = "Tổng",
                            count = totalCount,
                            selected = trackingFilter == MemberExpiryFilter.ALL,
                            accent = MaterialTheme.colorScheme.primary,
                            onClick = { trackingFilter = MemberExpiryFilter.ALL },
                            modifier = Modifier.weight(1f)
                        )
                        CompactStatBadge(
                            title = "Còn hạn",
                            count = validCount,
                            selected = trackingFilter == MemberExpiryFilter.VALID,
                            accent = StatusActiveGreen,
                            onClick = { trackingFilter = MemberExpiryFilter.VALID },
                            modifier = Modifier.weight(1f)
                        )
                        CompactStatBadge(
                            title = "Sắp hết",
                            count = expiring1To7Count + expiring8To15Count + todayExpiringCount,
                            selected = trackingFilter in listOf(
                                MemberExpiryFilter.TODAY_EXPIRING,
                                MemberExpiryFilter.EXPIRING_SOON,
                                MemberExpiryFilter.EXPIRING_8_15
                            ),
                            accent = StatusWarningAmber,
                            onClick = { trackingFilter = MemberExpiryFilter.EXPIRING_SOON },
                            modifier = Modifier.weight(1f)
                        )
                        CompactStatBadge(
                            title = "Hết hạn",
                            count = expiredCount,
                            selected = trackingFilter == MemberExpiryFilter.EXPIRED,
                            accent = StatusDangerRed,
                            onClick = { trackingFilter = MemberExpiryFilter.EXPIRED },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Horizontal Expiry Filter Chips (Section 8.1)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val filterItems = listOf(
                            MemberExpiryFilter.ALL to "Tất cả ($totalCount)",
                            MemberExpiryFilter.VALID to "Còn hạn ($validCount)",
                            MemberExpiryFilter.TODAY_EXPIRING to "Hôm nay hết hạn ($todayExpiringCount)",
                            MemberExpiryFilter.EXPIRING_SOON to "Sắp hết hạn 1–7 ngày ($expiring1To7Count)",
                            MemberExpiryFilter.EXPIRING_8_15 to "Sắp hết hạn 8–15 ngày ($expiring8To15Count)",
                            MemberExpiryFilter.EXPIRED to "Đã hết hạn ($expiredCount)"
                        )
                        filterItems.forEach { (filter, label) ->
                            FilterChip(
                                selected = trackingFilter == filter,
                                onClick = { trackingFilter = filter },
                                label = { Text(label, style = MaterialTheme.typography.labelSmall) },
                                modifier = Modifier.testTag("tracking_filter_${filter.name.lowercase()}")
                            )
                        }
                    }

                    // Search + Expiry Sort Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Tìm theo STT, Họ tên, SĐT...") },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { searchQuery = "" }) {
                                        Icon(Icons.Default.Clear, contentDescription = "Xóa")
                                    }
                                }
                            },
                            singleLine = true,
                            textStyle = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("tracking_search_input")
                        )
                        FilledTonalIconButton(
                            onClick = {
                                sortOrder = if (sortOrder == ExpirySortOrder.ASCENDING) {
                                    ExpirySortOrder.DESCENDING
                                } else {
                                    ExpirySortOrder.ASCENDING
                                }
                            },
                            modifier = Modifier.size(44.dp)
                        ) {
                            Icon(
                                imageVector = if (sortOrder == ExpirySortOrder.ASCENDING) {
                                    Icons.Default.ArrowUpward
                                } else {
                                    Icons.Default.ArrowDownward
                                },
                                contentDescription = sortOrder.label
                            )
                        }
                    }
                }

                LazyColumn(
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    itemsIndexed(filteredTrackingMembers, key = { _, m -> m.member.id }) { idx, m ->
                        val stt = FormatUtils.formatStt(idx + 1)
                        val statusColor = when {
                            m.isTodayExpiring -> StatusWarningAmber
                            m.isExpired -> StatusDangerRed
                            m.isExpiringSoon || m.isExpiring8To15 -> StatusWarningAmber
                            else -> StatusActiveGreen
                        }
                        ElevatedCard(
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onMemberClick(m.member.id) }
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                // Line 1: STT — Họ tên — Trạng thái thời hạn
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "$stt — ${m.member.fullName}",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = m.statusText,
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = statusColor
                                    )
                                }
                                // Line 2: Ngày hết hạn — Nút Gia hạn
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Hết hạn: ${DateCalculator.formatDisplay(m.endDateIso)} • SĐT: ${m.member.phoneNumber}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    FilledTonalButton(
                                        onClick = { onRenewClick(m.member.id) },
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                        modifier = Modifier.height(30.dp)
                                    ) {
                                        Text("Gia hạn", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                // SUB-TAB 1: Debt Management
                LazyColumn(
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = StatusDangerRed),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "TỔNG CÔNG NỢ ($selectedDomain)",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.White.copy(alpha = 0.9f)
                                    )
                                    Text(
                                        text = FormatUtils.formatVnd(totalDebtAmountVnd),
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        modifier = Modifier.testTag("total_debt_amount_text")
                                    )
                                }
                                Surface(
                                    color = Color.White.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = "$debtContractsCount HĐ nợ",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }
                    }

                    item {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Tìm tên, SĐT hoặc mã hợp đồng...") },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("debt_search_input")
                        )
                    }

                    if (filteredDebts.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "Không có hợp đồng $selectedDomain nào còn công nợ.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    } else {
                        itemsIndexed(filteredDebts, key = { _, d -> d.contract.id }) { _, debtItem ->
                            ElevatedCard(
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "${debtItem.memberName} (${debtItem.memberPhone})",
                                                style = MaterialTheme.typography.titleSmall,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = "${debtItem.contract.contractCode} • ${debtItem.contract.planNameSnapshot}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        if (debtItem.overpaidVnd > 0L) {
                                            StatusPill(
                                                text = "Vượt: ${FormatUtils.formatVnd(debtItem.overpaidVnd)}",
                                                tone = StatusTone.WARNING
                                            )
                                        } else {
                                            StatusPill(
                                                text = "Nợ: ${FormatUtils.formatVnd(debtItem.debtVnd)}",
                                                tone = StatusTone.DANGER
                                            )
                                        }
                                    }

                                    Text(
                                        text = "Giá trị HĐ: ${FormatUtils.formatVnd(debtItem.contract.agreedValueVnd)} • Đã thu: ${FormatUtils.formatVnd(debtItem.totalPaidVnd)}",
                                        style = MaterialTheme.typography.bodySmall
                                    )

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        OutlinedButton(
                                            onClick = { debtToInspect = debtItem },
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Lịch sử (${debtItem.payments.size})")
                                        }
                                        if (debtItem.debtVnd > 0L) {
                                            Button(
                                                onClick = { debtToPay = debtItem },
                                                colors = ButtonDefaults.buttonColors(containerColor = StatusActiveGreen),
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .testTag("collect_debt_btn_${debtItem.contract.id}")
                                            ) {
                                                Icon(Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("Thu tiền")
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Dialog: Collect Debt Payment
    debtToPay?.let { item ->
        var payDateIso by remember { mutableStateOf(DateCalculator.todayIso()) }
        var cashVnd by remember { mutableStateOf(item.debtVnd) }
        var transferVnd by remember { mutableStateOf(0L) }
        var note by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { debtToPay = null },
            title = { Text("Thu công nợ — ${item.memberName}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Hợp đồng ${item.contract.contractCode} • Còn nợ: ${FormatUtils.formatVnd(item.debtVnd)}",
                        style = MaterialTheme.typography.labelLarge,
                        color = StatusDangerRed
                    )
                    DateInputField(
                        label = "Ngày thanh toán",
                        isoDate = payDateIso,
                        onIsoDateChange = { payDateIso = it }
                    )
                    VndAmountField(
                        label = "Thu tiền mặt",
                        amountVnd = cashVnd,
                        onAmountChange = { cashVnd = it },
                        testTagName = "debt_pay_cash_input"
                    )
                    VndAmountField(
                        label = "Thu chuyển khoản",
                        amountVnd = transferVnd,
                        onAmountChange = { transferVnd = it },
                        testTagName = "debt_pay_transfer_input"
                    )
                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it },
                        label = { Text("Ghi chú giao dịch") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onRecordPayment(item.contract.id, payDateIso, cashVnd, transferVnd, note)
                        debtToPay = null
                    },
                    modifier = Modifier.testTag("confirm_debt_payment_btn")
                ) {
                    Text("Xác nhận Thu tiền")
                }
            },
            dismissButton = {
                TextButton(onClick = { debtToPay = null }) {
                    Text("Hủy")
                }
            }
        )
    }

    // Dialog: Inspect Contract & Payment History
    debtToInspect?.let { item ->
        AlertDialog(
            onDismissRequest = { debtToInspect = null },
            title = { Text("Chi tiết HĐ ${item.contract.contractCode}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Hội viên: ${item.memberName} (${item.memberPhone})", fontWeight = FontWeight.Bold)
                    Text("Gói: ${item.contract.planNameSnapshot} (${item.contract.durationMonths} tháng)")
                    Text("Hiệu lực: ${DateCalculator.formatDisplay(item.contract.startDateIso)} → ${DateCalculator.formatDisplay(item.contract.endDateIso)}")
                    Text("Giá trị HĐ: ${FormatUtils.formatVnd(item.contract.agreedValueVnd)}")
                    Text("Tổng đã thu: ${FormatUtils.formatVnd(item.totalPaidVnd)}")
                    Text("Còn nợ: ${FormatUtils.formatVnd(item.debtVnd)}", color = StatusDangerRed, fontWeight = FontWeight.Bold)
                    HorizontalDivider()
                    Text("Lịch sử thu tiền (${item.payments.size}):", fontWeight = FontWeight.SemiBold)
                    item.payments.forEach { p ->
                        Text(
                            text = "• ${DateCalculator.formatDisplay(p.paymentDateIso)}: +${FormatUtils.formatVnd(p.totalAmountVnd)} (${p.paymentMethodLabel})",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { debtToInspect = null }) {
                    Text("Đóng")
                }
            }
        )
    }
}

@Composable
private fun CompactStatBadge(
    title: String,
    count: Int,
    selected: Boolean,
    accent: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    OutlinedCard(
        onClick = onClick,
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.outlinedCardColors(
            containerColor = if (selected) accent.copy(alpha = 0.14f) else MaterialTheme.colorScheme.surface
        ),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
            Text(
                text = "$count",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = accent
            )
        }
    }
}
