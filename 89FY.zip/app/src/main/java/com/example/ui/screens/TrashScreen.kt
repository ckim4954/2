package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.RestoreFromTrash
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.ContractRecord
import com.example.data.model.MemberProfile
import com.example.data.model.PtSessionRecord
import com.example.data.model.SingleTicketRecord
import com.example.data.model.SingleTicketType
import com.example.data.model.TrashCategory
import com.example.domain.FitnessCalculator
import com.example.ui.components.ConfirmDeleteDialog
import com.example.ui.components.ScreenHeaderBar
import com.example.ui.theme.GymGreenBright
import com.example.ui.theme.TrashSlateBright
import com.example.ui.viewmodel.FitnessAppState
import com.example.ui.viewmodel.FitnessViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private sealed class PermanentDeleteTarget {
    data class Member(val item: MemberProfile) : PermanentDeleteTarget()
    data class Contract(val item: ContractRecord) : PermanentDeleteTarget()
    data class Ticket(val item: SingleTicketRecord) : PermanentDeleteTarget()
    data class Session(val item: PtSessionRecord) : PermanentDeleteTarget()
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TrashScreen(
    appState: FitnessAppState,
    viewModel: FitnessViewModel,
    onBack: () -> Unit
) {
    // Theo PRD Mục 8 (THÙNG RÁC):
    // Gồm đúng 8 danh mục:
    // 1. Hội viên GYM
    // 2. Hội viên YOGA
    // 3. Hợp đồng GYM
    // 4. Hợp đồng YOGA
    // 5. Hồ sơ PT
    // 6. Hợp đồng PT
    // 7. Vé lẻ
    // 8. Dữ liệu khác (buổi tập PT đã xóa mềm)
    // Quy tắc:
    // - Mọi dữ liệu xóa trong app vào Thùng rác trước
    // - Khôi phục phải trả lại đúng danh sách và liên kết cũ
    // - Xóa vĩnh viễn phải có bước xác nhận
    var selectedCategory by remember { mutableStateOf(TrashCategory.GYM_MEMBER) }
    var permanentDeleteTarget by remember { mutableStateOf<PermanentDeleteTarget?>(null) }

    BackHandler {
        onBack()
    }

    val deletedGymMembers = remember(appState.allMembers) {
        appState.allMembers.filter { it.isDeleted && it.type == "GYM" }.sortedByDescending { it.deletedAtEpoch }
    }
    val deletedYogaMembers = remember(appState.allMembers) {
        appState.allMembers.filter { it.isDeleted && it.type == "YOGA" }.sortedByDescending { it.deletedAtEpoch }
    }
    val deletedGymContracts = remember(appState.allContracts) {
        appState.allContracts.filter { it.isDeleted && it.serviceType == "GYM" }.sortedByDescending { it.deletedAtEpoch }
    }
    val deletedYogaContracts = remember(appState.allContracts) {
        appState.allContracts.filter { it.isDeleted && it.serviceType == "YOGA" }.sortedByDescending { it.deletedAtEpoch }
    }
    val deletedPtMembers = remember(appState.allMembers) {
        appState.allMembers.filter { it.isDeleted && it.type == "PT" }.sortedByDescending { it.deletedAtEpoch }
    }
    val deletedPtContracts = remember(appState.allContracts) {
        appState.allContracts.filter { it.isDeleted && it.serviceType == "PT" }.sortedByDescending { it.deletedAtEpoch }
    }
    val deletedSingleTickets = remember(appState.allSingleTickets) {
        appState.allSingleTickets.filter { it.isDeleted }.sortedByDescending { it.deletedAtEpoch }
    }
    val deletedOtherData = remember(appState.allPtSessions) {
        appState.allPtSessions.filter { it.isDeleted }.sortedByDescending { it.deletedAtEpoch }
    }

    fun countForCategory(cat: TrashCategory): Int = when (cat) {
        TrashCategory.GYM_MEMBER -> deletedGymMembers.size
        TrashCategory.YOGA_MEMBER -> deletedYogaMembers.size
        TrashCategory.GYM_CONTRACT -> deletedGymContracts.size
        TrashCategory.YOGA_CONTRACT -> deletedYogaContracts.size
        TrashCategory.PT_MEMBER -> deletedPtMembers.size
        TrashCategory.PT_CONTRACT -> deletedPtContracts.size
        TrashCategory.SINGLE_TICKET -> deletedSingleTickets.size
        TrashCategory.OTHER_DATA -> deletedOtherData.size
    }

    val totalTrashCount = TrashCategory.entries.sumOf { countForCategory(it) }

    Scaffold(
        topBar = {
            ScreenHeaderBar(
                title = "THÙNG RÁC",
                subtitle = "8 danh mục lưu trữ dữ liệu xóa mềm ($totalTrashCount mục)",
                accentColor = TrashSlateBright,
                onBack = onBack
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Bộ chọn 8 danh mục Thùng rác
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 2.dp
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "CHỌN 1 TRONG 8 DANH MỤC THÙNG RÁC:",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = TrashSlateBright
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        TrashCategory.entries.forEach { cat ->
                            val isSelected = selectedCategory == cat
                            val count = countForCategory(cat)
                            FilterChip(
                                selected = isSelected,
                                onClick = { selectedCategory = cat },
                                label = {
                                    Text(
                                        text = "${cat.title} ($count)",
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = TrashSlateBright,
                                    selectedLabelColor = Color.White
                                ),
                                modifier = Modifier.testTag("trash_category_${cat.index}")
                            )
                        }
                    }
                }
            }

            val currentCount = countForCategory(selectedCategory)
            if (currentCount == 0) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = null,
                            tint = TrashSlateBright.copy(alpha = 0.5f),
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Danh mục '${selectedCategory.title}' đang trống",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Mọi dữ liệu xóa trong ứng dụng sẽ được lưu tạm tại đây trước khi xóa vĩnh viễn.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    when (selectedCategory) {
                        TrashCategory.GYM_MEMBER,
                        TrashCategory.YOGA_MEMBER,
                        TrashCategory.PT_MEMBER -> {
                            val list = when (selectedCategory) {
                                TrashCategory.GYM_MEMBER -> deletedGymMembers
                                TrashCategory.YOGA_MEMBER -> deletedYogaMembers
                                else -> deletedPtMembers
                            }
                            items(list, key = { it.id }) { member ->
                                TrashItemCard(
                                    title = "STT${member.stt} — ${member.fullName}",
                                    subtitle = "Dịch vụ: ${member.type} • SĐT: ${member.phone.ifBlank { "Chưa có" }}",
                                    deletedAtEpoch = member.deletedAtEpoch,
                                    onRestore = { viewModel.restoreMember(member) },
                                    onPermanentDelete = { permanentDeleteTarget = PermanentDeleteTarget.Member(member) }
                                )
                            }
                        }

                        TrashCategory.GYM_CONTRACT,
                        TrashCategory.YOGA_CONTRACT,
                        TrashCategory.PT_CONTRACT -> {
                            val list = when (selectedCategory) {
                                TrashCategory.GYM_CONTRACT -> deletedGymContracts
                                TrashCategory.YOGA_CONTRACT -> deletedYogaContracts
                                else -> deletedPtContracts
                            }
                            items(list, key = { it.id }) { contract ->
                                TrashItemCard(
                                    title = "${contract.contractCode} — STT${contract.memberSttSnapshot} ${contract.memberNameSnapshot}",
                                    subtitle = if (contract.serviceType == "PT") {
                                        "PT ${contract.totalSessions} buổi • Đã thu: ${FitnessCalculator.formatCurrency(contract.paidAmount)}"
                                    } else {
                                        "Gói ${contract.durationMonths} tháng (${FitnessCalculator.formatDisplayDate(contract.startDate)} → ${FitnessCalculator.formatDisplayDate(contract.endDate)}) • ${FitnessCalculator.formatCurrency(contract.paidAmount)}"
                                    },
                                    deletedAtEpoch = contract.deletedAtEpoch,
                                    onRestore = { viewModel.restoreContract(contract) },
                                    onPermanentDelete = { permanentDeleteTarget = PermanentDeleteTarget.Contract(contract) }
                                )
                            }
                        }

                        TrashCategory.SINGLE_TICKET -> {
                            items(deletedSingleTickets, key = { it.id }) { ticket ->
                                TrashItemCard(
                                    title = "${SingleTicketType.fromCode(ticket.ticketType).label} (${ticket.quantity} vé)",
                                    subtitle = "Ngày bán: ${FitnessCalculator.formatDisplayDate(ticket.saleDate)} • Thành tiền: ${FitnessCalculator.formatCurrency(ticket.totalAmount)}",
                                    deletedAtEpoch = ticket.deletedAtEpoch,
                                    onRestore = { viewModel.restoreSingleTicket(ticket) },
                                    onPermanentDelete = { permanentDeleteTarget = PermanentDeleteTarget.Ticket(ticket) }
                                )
                            }
                        }

                        TrashCategory.OTHER_DATA -> {
                            items(deletedOtherData, key = { it.id }) { session ->
                                TrashItemCard(
                                    title = "Buổi tập PT — STT${session.memberSttSnapshot} ${session.memberNameSnapshot}",
                                    subtitle = "Ngày tập: ${FitnessCalculator.formatDisplayDate(session.sessionDate)} • Mã HĐ: ${session.contractCodeSnapshot}",
                                    deletedAtEpoch = session.deletedAtEpoch,
                                    onRestore = { viewModel.restorePtSession(session) },
                                    onPermanentDelete = { permanentDeleteTarget = PermanentDeleteTarget.Session(session) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    permanentDeleteTarget?.let { target ->
        val (titleText, detailText) = when (target) {
            is PermanentDeleteTarget.Member ->
                "Xóa vĩnh viễn hồ sơ STT${target.item.stt}?" to
                    "Hồ sơ STT${target.item.stt} (${target.item.fullName}) cùng các hợp đồng liên quan sẽ bị xóa vĩnh viễn và KHÔNG THỂ khôi phục lại."
            is PermanentDeleteTarget.Contract ->
                "Xóa vĩnh viễn hợp đồng ${target.item.contractCode}?" to
                    "Hợp đồng ${target.item.contractCode} sẽ bị xóa vĩnh viễn khỏi hệ thống và không thể khôi phục."
            is PermanentDeleteTarget.Ticket ->
                "Xóa vĩnh viễn giao dịch Vé lẻ?" to
                    "Giao dịch vé lẻ ngày ${FitnessCalculator.formatDisplayDate(target.item.saleDate)} sẽ bị xóa vĩnh viễn."
            is PermanentDeleteTarget.Session ->
                "Xóa vĩnh viễn buổi tập PT?" to
                    "Buổi tập ngày ${FitnessCalculator.formatDisplayDate(target.item.sessionDate)} của STT${target.item.memberSttSnapshot} sẽ bị xóa vĩnh viễn."
        }

        ConfirmDeleteDialog(
            title = titleText,
            message = detailText,
            isPermanent = true,
            onConfirm = {
                when (target) {
                    is PermanentDeleteTarget.Member -> viewModel.permanentDeleteMember(target.item)
                    is PermanentDeleteTarget.Contract -> viewModel.permanentDeleteContract(target.item)
                    is PermanentDeleteTarget.Ticket -> viewModel.permanentDeleteSingleTicket(target.item)
                    is PermanentDeleteTarget.Session -> viewModel.permanentDeletePtSession(target.item)
                }
                permanentDeleteTarget = null
            },
            onDismiss = { permanentDeleteTarget = null }
        )
    }
}

@Composable
private fun TrashItemCard(
    title: String,
    subtitle: String,
    deletedAtEpoch: Long,
    onRestore: () -> Unit,
    onPermanentDelete: () -> Unit
) {
    val deletedTimeStr = remember(deletedAtEpoch) {
        if (deletedAtEpoch <= 0L) "Vừa xóa"
        else SimpleDateFormat("HH:mm dd/MM/yyyy", Locale.getDefault()).format(Date(deletedAtEpoch))
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, TrashSlateBright.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                softWrap = true,
                maxLines = Int.MAX_VALUE
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "Thời điểm xóa: $deletedTimeStr",
                style = MaterialTheme.typography.labelSmall,
                color = TrashSlateBright
            )

            HorizontalDivider()

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onPermanentDelete,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) {
                    Icon(Icons.Default.DeleteForever, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Xóa vĩnh viễn")
                }
                Spacer(modifier = Modifier.width(10.dp))
                Button(
                    onClick = onRestore,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = GymGreenBright,
                        contentColor = Color.White
                    )
                ) {
                    Icon(Icons.Default.RestoreFromTrash, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Khôi phục")
                }
            }
        }
    }
}
