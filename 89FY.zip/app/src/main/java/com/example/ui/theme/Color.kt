package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Mode Palette - Athletic Precision & Executive Clarity
val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val OnBackgroundLight = Color(0xFF0F172A)
val OnSurfaceLight = Color(0xFF0F172A)
val OnSurfaceVariantLight = Color(0xFF475569)
val OutlineLight = Color(0xFFE2E8F0)

// Dark Mode Palette - Obsidian Slate
val BackgroundDark = Color(0xFF0B0F17)
val SurfaceDark = Color(0xFF151C28)
val SurfaceVariantDark = Color(0xFF1E293B)
val OnBackgroundDark = Color(0xFFF8FAFC)
val OnSurfaceDark = Color(0xFFF8FAFC)
val OnSurfaceVariantDark = Color(0xFF94A3B8)
val OutlineDark = Color(0xFF263244)

// Brand & Domain Accents
val GymEmeraldLight = Color(0xFF059669)
val GymEmeraldDark = Color(0xFF10B981)
val GymEmeraldContainerLight = Color(0xFFD1FAE5)
val GymEmeraldContainerDark = Color(0xFF064E3B)

val YogaIndigoLight = Color(0xFF4F46E5)
val YogaIndigoDark = Color(0xFF818CF8)
val YogaIndigoContainerLight = Color(0xFFE0E7FF)
val YogaIndigoContainerDark = Color(0xFF312E81)

val PtTealLight = Color(0xFF0D9488)
val PtTealDark = Color(0xFF2DD4BF)

// Semantic Status Colors
val StatusActiveGreen = Color(0xFF16A34A)
val StatusActiveBgLight = Color(0xFFDCFCE7)
val StatusActiveBgDark = Color(0xFF14532D)

val StatusWarningAmber = Color(0xFFD97706)
val StatusWarningBgLight = Color(0xFFFEF3C7)
val StatusWarningBgDark = Color(0xFF78350F)

val StatusDangerRed = Color(0xFFDC2626)
val StatusDangerBgLight = Color(0xFFFEE2E2)
val StatusDangerBgDark = Color(0xFF7F1D1D)
