package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// 89 FITNESS & YOGA Brand Palette
// GYM Primary: Xanh lá (Emerald)
val GymGreenLight = Color(0xFF15803D)
val GymGreenBright = Color(0xFF16A34A)
val GymGreenDark = Color(0xFF4ADE80)
val GymGreenSurfaceLight = Color(0xFFDCFCE7)
val GymGreenSurfaceDark = Color(0xFF052E16)

// YOGA Primary: Tím (Violet/Purple)
val YogaPurpleLight = Color(0xFF6D28D9)
val YogaPurpleBright = Color(0xFF7C3AED)
val YogaPurpleDark = Color(0xFFC084FC)
val YogaPurpleSurfaceLight = Color(0xFFEDE9FE)
val YogaPurpleSurfaceDark = Color(0xFF2E1065)

// Khung bảng giá (Cài đặt): Nam xanh lá, Nữ hồng, Trẻ em cam, YOGA tím
val PriceNamGreen = Color(0xFF16A34A)
val PriceNuPink = Color(0xFFEC4899)
val PriceTreEmOrange = Color(0xFFF97316)
val PriceYogaPurple = Color(0xFF7C3AED)
val GymFemalePink = PriceNuPink
val GymKidOrange = PriceTreEmOrange

// Màu điểm nhấn các menu chức năng
val TrackingTealBright = Color(0xFF0D9488)
val PtOrangeBright = Color(0xFFDB2777)
val SettingsIndigoBright = Color(0xFF4F46E5)
val TrashSlateBright = Color(0xFFDC2626)

// Trạng thái thời hạn
val StatusActiveGreen = Color(0xFF15803D)
val StatusExpiringAmber = Color(0xFFD97706)
val StatusWarningAmber = StatusExpiringAmber
val StatusExpiredRed = Color(0xFFDC2626)

// Neutral Athletic Surfaces
val SlateBackgroundLight = Color(0xFFF8FAFC)
val SlateSurfaceLight = Color(0xFFFFFFFF)
val SlateCardLight = Color(0xFFF1F5F9)
val SlateTextPrimaryLight = Color(0xFF0F172A)
val SlateTextSecondaryLight = Color(0xFF475569)

val SlateBackgroundDark = Color(0xFF0B1120)
val SlateSurfaceDark = Color(0xFF1E293B)
val SlateCardDark = Color(0xFF0F172A)
val SlateTextPrimaryDark = Color(0xFFF8FAFC)
val SlateTextSecondaryDark = Color(0xFF94A3B8)
