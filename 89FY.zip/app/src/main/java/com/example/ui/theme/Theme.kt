package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = GymEmeraldLight,
    onPrimary = Color.White,
    primaryContainer = GymEmeraldContainerLight,
    onPrimaryContainer = Color(0xFF064E3B),
    secondary = YogaIndigoLight,
    onSecondary = Color.White,
    secondaryContainer = YogaIndigoContainerLight,
    onSecondaryContainer = Color(0xFF1E1B4B),
    tertiary = PtTealLight,
    onTertiary = Color.White,
    background = BackgroundLight,
    onBackground = OnBackgroundLight,
    surface = SurfaceLight,
    onSurface = OnSurfaceLight,
    surfaceVariant = SurfaceVariantLight,
    onSurfaceVariant = OnSurfaceVariantLight,
    outline = OutlineLight,
    error = StatusDangerRed,
    onError = Color.White
)

private val DarkColorScheme = darkColorScheme(
    primary = GymEmeraldDark,
    onPrimary = Color(0xFF022C22),
    primaryContainer = GymEmeraldContainerDark,
    onPrimaryContainer = Color(0xFFA7F3D0),
    secondary = YogaIndigoDark,
    onSecondary = Color(0xFF1E1B4B),
    secondaryContainer = YogaIndigoContainerDark,
    onSecondaryContainer = Color(0xFFE0E7FF),
    tertiary = PtTealDark,
    onTertiary = Color(0xFF042F2E),
    background = BackgroundDark,
    onBackground = OnBackgroundDark,
    surface = SurfaceDark,
    onSurface = OnSurfaceDark,
    surfaceVariant = SurfaceVariantDark,
    onSurfaceVariant = OnSurfaceVariantDark,
    outline = OutlineDark,
    error = Color(0xFFF87171),
    onError = Color(0xFF450A0A)
)

@Composable
fun Fitness89Theme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
