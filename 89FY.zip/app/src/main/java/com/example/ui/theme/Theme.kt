package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = GymGreenDark,
    onPrimary = Color(0xFF052E16),
    primaryContainer = Color(0xFF14532D),
    onPrimaryContainer = Color(0xFFDCFCE7),
    secondary = YogaPurpleDark,
    onSecondary = Color(0xFF2E1065),
    secondaryContainer = Color(0xFF4C1D95),
    onSecondaryContainer = Color(0xFFEDE9FE),
    tertiary = PriceTreEmOrange,
    background = SlateBackgroundDark,
    onBackground = SlateTextPrimaryDark,
    surface = SlateSurfaceDark,
    onSurface = SlateTextPrimaryDark,
    surfaceVariant = Color(0xFF334155),
    onSurfaceVariant = SlateTextSecondaryDark,
    error = Color(0xFFF87171)
)

private val LightColorScheme = lightColorScheme(
    primary = GymGreenBright,
    onPrimary = Color.White,
    primaryContainer = GymGreenSurfaceLight,
    onPrimaryContainer = Color(0xFF052E16),
    secondary = YogaPurpleBright,
    onSecondary = Color.White,
    secondaryContainer = YogaPurpleSurfaceLight,
    onSecondaryContainer = Color(0xFF2E1065),
    tertiary = PriceTreEmOrange,
    background = SlateBackgroundLight,
    onBackground = SlateTextPrimaryLight,
    surface = SlateSurfaceLight,
    onSurface = SlateTextPrimaryLight,
    surfaceVariant = SlateCardLight,
    onSurfaceVariant = SlateTextSecondaryLight,
    error = StatusExpiredRed
)

@Composable
fun Fitness89Theme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    Fitness89Theme(darkTheme = darkTheme, content = content)
}
