package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.R
import com.example.data.model.BackupBundle
import com.example.data.model.ContractRecord
import com.example.data.model.MemberProfile
import com.example.data.model.PtSessionRecord
import com.example.data.model.SingleTicketRecord
import com.example.data.model.StudioConfig
import com.example.data.repository.FitnessRepository
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class FitnessAppState(
    val isLoading: Boolean = true,
    val config: StudioConfig = StudioConfig(),
    val allMembers: List<MemberProfile> = emptyList(),
    val allContracts: List<ContractRecord> = emptyList(),
    val allPtSessions: List<PtSessionRecord> = emptyList(),
    val allSingleTickets: List<SingleTicketRecord> = emptyList(),
    val syncStatusMessage: String = "Đã đồng bộ Cloud tự động",
    val errorMessage: String? = null
) {
    val activeGymMembers: List<MemberProfile>
        get() = allMembers.filter { !it.isDeleted && it.type == "GYM" }

    val activeYogaMembers: List<MemberProfile>
        get() = allMembers.filter { !it.isDeleted && it.type == "YOGA" }

    val activePtMembers: List<MemberProfile>
        get() = allMembers.filter { !it.isDeleted && it.type == "PT" }

    val activeContracts: List<ContractRecord>
        get() = allContracts.filter { !it.isDeleted }

    val activePtSessions: List<PtSessionRecord>
        get() = allPtSessions.filter { !it.isDeleted }

    val activeSingleTickets: List<SingleTicketRecord>
        get() = allSingleTickets.filter { !it.isDeleted }
}

class FitnessViewModel(
    private val repository: FitnessRepository,
    val currentUserId: String
) : ViewModel() {

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    val appState: StateFlow<FitnessAppState> = combine(
        repository.observeStudioConfig(),
        repository.observeMembers(),
        repository.observeContracts(),
        repository.observePtSessions(),
        repository.observeSingleTickets()
    ) { config, members, contracts, sessions, tickets ->
        FitnessAppState(
            isLoading = false,
            config = config,
            allMembers = members,
            allContracts = contracts,
            allPtSessions = sessions,
            allSingleTickets = tickets,
            syncStatusMessage = "Đã đồng bộ Cloud (${members.count { !it.isDeleted }} hồ sơ, ${contracts.count { !it.isDeleted }} HĐ)",
            errorMessage = null
        )
    }.catch { error ->
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val rootError = firestoreError ?: error
        val msg = if (rootError.message?.contains("Quota exceeded", ignoreCase = true) == true) {
            "Quota exceeded. Hạn mức miễn phí sẽ đặt lại vào ngày mai."
        } else {
            rootError.localizedMessage ?: "Lỗi tải dữ liệu từ Cloud"
        }
        emit(
            FitnessAppState(
                isLoading = false,
                syncStatusMessage = "Lỗi đồng bộ: $msg",
                errorMessage = msg
            )
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = FitnessAppState(isLoading = true)
    )

    init {
        viewModelScope.launch {
            runCatching { repository.getOrCreateConfig() }
        }
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    fun showToast(message: String) {
        _toastMessage.value = message
    }

    fun toggleDarkMode(enabled: Boolean) {
        viewModelScope.launch {
            val current = appState.value.config
            runCatching {
                repository.saveStudioConfig(current.copy(isDarkMode = enabled))
            }.onSuccess {
                _toastMessage.value = if (enabled) "Đã chuyển sang Giao diện Tối" else "Đã chuyển sang Giao diện Sáng"
            }.onFailure {
                _toastMessage.value = "Không thể lưu giao diện: ${it.localizedMessage}"
            }
        }
    }

    fun updatePricingTable(updatedConfig: StudioConfig, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            _isBusy.value = true
            runCatching {
                repository.saveStudioConfig(updatedConfig)
            }.onSuccess {
                _isBusy.value = false
                _toastMessage.value = "Đã lưu bảng giá mới (chỉ áp dụng cho hợp đồng tạo mới)"
                onComplete()
            }.onFailure {
                _isBusy.value = false
                _toastMessage.value = "Lỗi lưu bảng giá: ${it.localizedMessage}"
            }
        }
    }

    fun createNewMemberAndContract(
        serviceType: String,
        fullName: String,
        phone: String,
        memberGroup: String,
        durationMonths: Long,
        startDate: String,
        endDate: String,
        totalSessions: Long,
        packageValue: Long,
        paidAmount: Long,
        paymentMethod: String,
        cashAmount: Long,
        transferAmount: Long,
        paymentDate: String,
        onSuccess: (MemberProfile, ContractRecord) -> Unit = { _, _ -> }
    ) {
        viewModelScope.launch {
            _isBusy.value = true
            val result = repository.createMemberWithInitialContract(
                serviceType = serviceType,
                fullName = fullName,
                phone = phone,
                memberGroup = memberGroup,
                durationMonths = durationMonths,
                startDate = startDate,
                endDate = endDate,
                totalSessions = totalSessions,
                packageValue = packageValue,
                paidAmount = paidAmount,
                paymentMethod = paymentMethod,
                cashAmount = cashAmount,
                transferAmount = transferAmount,
                paymentDate = paymentDate
            )
            _isBusy.value = false
            result.onSuccess { (member, contract) ->
                _toastMessage.value = "Đã tạo hồ sơ STT${member.stt} và hợp đồng ${contract.contractCode}"
                onSuccess(member, contract)
            }.onFailure {
                _toastMessage.value = "Lỗi tạo hợp đồng: ${it.localizedMessage}"
            }
        }
    }

    fun createRenewalContract(
        member: MemberProfile,
        memberGroup: String,
        durationMonths: Long,
        startDate: String,
        endDate: String,
        totalSessions: Long,
        packageValue: Long,
        paidAmount: Long,
        paymentMethod: String,
        cashAmount: Long,
        transferAmount: Long,
        paymentDate: String,
        onSuccess: (ContractRecord) -> Unit = {}
    ) {
        viewModelScope.launch {
            _isBusy.value = true
            val result = repository.createRenewalContract(
                member = member,
                memberGroup = memberGroup,
                durationMonths = durationMonths,
                startDate = startDate,
                endDate = endDate,
                totalSessions = totalSessions,
                packageValue = packageValue,
                paidAmount = paidAmount,
                paymentMethod = paymentMethod,
                cashAmount = cashAmount,
                transferAmount = transferAmount,
                paymentDate = paymentDate
            )
            _isBusy.value = false
            result.onSuccess { contract ->
                _toastMessage.value = "Đã tạo hợp đồng gia hạn ${contract.contractCode} (giữ nguyên STT${member.stt})"
                onSuccess(contract)
            }.onFailure {
                _toastMessage.value = "Lỗi gia hạn: ${it.localizedMessage}"
            }
        }
    }

    fun updateMemberProfile(
        member: MemberProfile,
        newFullName: String,
        newPhone: String,
        newGroup: String,
        onSuccess: () -> Unit = {}
    ) {
        viewModelScope.launch {
            _isBusy.value = true
            val result = repository.updateMemberProfile(member, newFullName, newPhone, newGroup)
            _isBusy.value = false
            result.onSuccess {
                _toastMessage.value = "Đã cập nhật hồ sơ STT${member.stt} (lịch sử hợp đồng được giữ nguyên)"
                onSuccess()
            }.onFailure {
                _toastMessage.value = "Lỗi cập nhật hồ sơ: ${it.localizedMessage}"
            }
        }
    }

    fun updateContract(
        contract: ContractRecord,
        onSuccess: () -> Unit = {}
    ) {
        viewModelScope.launch {
            _isBusy.value = true
            val result = repository.updateContractRecord(contract)
            _isBusy.value = false
            result.onSuccess {
                _toastMessage.value = "Đã cập nhật hợp đồng ${contract.contractCode}"
                onSuccess()
            }.onFailure {
                _toastMessage.value = "Lỗi cập nhật hợp đồng: ${it.localizedMessage}"
            }
        }
    }

    fun recordPtSession(
        member: MemberProfile,
        contract: ContractRecord,
        sessionDate: String,
        note: String,
        onSuccess: () -> Unit = {}
    ) {
        // Kiểm tra tối đa 1 buổi PT/người/ngày
        val alreadyHasSessionOnDate = appState.value.activePtSessions.any {
            it.memberId == member.id && it.sessionDate == sessionDate
        }
        if (alreadyHasSessionOnDate) {
            _toastMessage.value = "Hội viên STT${member.stt} (${member.fullName}) đã có 1 buổi PT trong ngày $sessionDate. Quy tắc: tối đa 1 buổi/người/ngày."
            return
        }
        if (contract.usedSessions >= contract.totalSessions) {
            _toastMessage.value = "Hợp đồng ${contract.contractCode} đã hết buổi tập. Vui lòng gia hạn hợp đồng PT mới."
            return
        }

        viewModelScope.launch {
            _isBusy.value = true
            val result = repository.recordPtSession(member, contract, sessionDate, note)
            _isBusy.value = false
            result.onSuccess {
                val newUsed = contract.usedSessions + 1L
                val statusMsg = if (newUsed >= contract.totalSessions) {
                    "Đã ghi nhận buổi tập cuối (${newUsed}/${contract.totalSessions}). Hợp đồng PT tự động hoàn thành!"
                } else {
                    "Đã ghi nhận buổi tập PT (${newUsed}/${contract.totalSessions} buổi)"
                }
                _toastMessage.value = statusMsg
                onSuccess()
            }.onFailure {
                _toastMessage.value = "Lỗi ghi nhận buổi tập: ${it.localizedMessage}"
            }
        }
    }

    fun updatePtSession(
        session: PtSessionRecord,
        newDate: String,
        newNote: String,
        onSuccess: () -> Unit = {}
    ) {
        val conflict = appState.value.activePtSessions.any {
            it.id != session.id && it.memberId == session.memberId && it.sessionDate == newDate
        }
        if (conflict) {
            _toastMessage.value = "Hội viên đã có một buổi tập PT khác trong ngày $newDate (tối đa 1 buổi/người/ngày)."
            return
        }
        viewModelScope.launch {
            _isBusy.value = true
            val result = repository.updatePtSession(session, newDate, newNote)
            _isBusy.value = false
            result.onSuccess {
                _toastMessage.value = "Đã cập nhật buổi tập PT"
                onSuccess()
            }.onFailure {
                _toastMessage.value = "Lỗi cập nhật buổi tập: ${it.localizedMessage}"
            }
        }
    }

    fun createSingleTicket(
        ticketType: String,
        saleDate: String,
        quantity: Long,
        unitPrice: Long,
        paymentMethod: String,
        cashAmount: Long,
        transferAmount: Long,
        onSuccess: () -> Unit = {}
    ) {
        viewModelScope.launch {
            _isBusy.value = true
            val result = repository.createSingleTicket(
                ticketType = ticketType,
                saleDate = saleDate,
                quantity = quantity,
                unitPrice = unitPrice,
                paymentMethod = paymentMethod,
                cashAmount = cashAmount,
                transferAmount = transferAmount
            )
            _isBusy.value = false
            result.onSuccess {
                _toastMessage.value = "Đã lưu giao dịch Vé lẻ (${it.quantity} vé)"
                onSuccess()
            }.onFailure {
                _toastMessage.value = "Lỗi lưu vé lẻ: ${it.localizedMessage}"
            }
        }
    }

    fun softDeleteMember(member: MemberProfile, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            _isBusy.value = true
            val relatedContracts = appState.value.allContracts.filter { it.memberId == member.id }
            val relatedSessions = appState.value.allPtSessions.filter { it.memberId == member.id }
            val result = repository.softDeleteMemberCascade(member, relatedContracts, relatedSessions)
            _isBusy.value = false
            result.onSuccess {
                _toastMessage.value = "Đã chuyển hồ sơ STT${member.stt} và dữ liệu liên quan vào Thùng rác"
                onSuccess()
            }.onFailure {
                _toastMessage.value = "Lỗi xóa hồ sơ: ${it.localizedMessage}"
            }
        }
    }

    fun softDeleteContract(contract: ContractRecord, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            _isBusy.value = true
            val relatedSessions = appState.value.allPtSessions.filter { it.contractId == contract.id }
            val result = repository.softDeleteContract(contract, relatedSessions)
            _isBusy.value = false
            result.onSuccess {
                _toastMessage.value = "Đã chuyển hợp đồng ${contract.contractCode} vào Thùng rác"
                onSuccess()
            }.onFailure {
                _toastMessage.value = "Lỗi xóa hợp đồng: ${it.localizedMessage}"
            }
        }
    }

    fun softDeletePtSession(session: PtSessionRecord, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            _isBusy.value = true
            val parentContract = appState.value.allContracts.firstOrNull { it.id == session.contractId }
            val result = repository.softDeletePtSession(session, parentContract)
            _isBusy.value = false
            result.onSuccess {
                _toastMessage.value = "Đã chuyển buổi tập PT vào Thùng rác (Danh mục 8. Dữ liệu khác)"
                onSuccess()
            }.onFailure {
                _toastMessage.value = "Lỗi xóa buổi tập: ${it.localizedMessage}"
            }
        }
    }

    fun softDeleteSingleTicket(ticket: SingleTicketRecord) {
        viewModelScope.launch {
            _isBusy.value = true
            val result = repository.softDeleteSingleTicket(ticket)
            _isBusy.value = false
            result.onSuccess {
                _toastMessage.value = "Đã chuyển Vé lẻ vào Thùng rác"
            }.onFailure {
                _toastMessage.value = "Lỗi xóa vé lẻ: ${it.localizedMessage}"
            }
        }
    }

    fun restoreMember(member: MemberProfile) {
        viewModelScope.launch {
            _isBusy.value = true
            val result = repository.restoreMemberCascade(
                member = member,
                allContracts = appState.value.allContracts,
                allSessions = appState.value.allPtSessions
            )
            _isBusy.value = false
            result.onSuccess {
                _toastMessage.value = "Đã khôi phục hồ sơ STT${member.stt} và liên kết hợp đồng"
            }.onFailure {
                _toastMessage.value = "Lỗi khôi phục: ${it.localizedMessage}"
            }
        }
    }

    fun restoreContract(contract: ContractRecord) {
        viewModelScope.launch {
            _isBusy.value = true
            val parent = appState.value.allMembers.firstOrNull { it.id == contract.memberId }
            val result = repository.restoreContractWithParentCheck(
                contract = contract,
                parentMember = parent,
                allSessions = appState.value.allPtSessions
            )
            _isBusy.value = false
            result.onSuccess {
                _toastMessage.value = "Đã khôi phục hợp đồng ${contract.contractCode}"
            }.onFailure {
                _toastMessage.value = "Lỗi khôi phục hợp đồng: ${it.localizedMessage}"
            }
        }
    }

    fun restorePtSession(session: PtSessionRecord) {
        viewModelScope.launch {
            _isBusy.value = true
            val parentContract = appState.value.allContracts.firstOrNull { it.id == session.contractId }
            val result = repository.restorePtSession(session, parentContract)
            _isBusy.value = false
            result.onSuccess {
                _toastMessage.value = "Đã khôi phục buổi tập PT"
            }.onFailure {
                _toastMessage.value = "Lỗi khôi phục buổi tập: ${it.localizedMessage}"
            }
        }
    }

    fun restoreSingleTicket(ticket: SingleTicketRecord) {
        viewModelScope.launch {
            _isBusy.value = true
            val result = repository.restoreSingleTicket(ticket)
            _isBusy.value = false
            result.onSuccess {
                _toastMessage.value = "Đã khôi phục Vé lẻ"
            }.onFailure {
                _toastMessage.value = "Lỗi khôi phục vé lẻ: ${it.localizedMessage}"
            }
        }
    }

    fun permanentDeleteMember(member: MemberProfile) {
        viewModelScope.launch {
            _isBusy.value = true
            val relatedContracts = appState.value.allContracts.filter { it.memberId == member.id }
            val relatedSessions = appState.value.allPtSessions.filter { it.memberId == member.id }
            val result = repository.permanentDeleteMember(member.id, relatedContracts, relatedSessions)
            _isBusy.value = false
            result.onSuccess {
                _toastMessage.value = "Đã xóa vĩnh viễn hồ sơ STT${member.stt}"
            }.onFailure {
                _toastMessage.value = "Lỗi xóa vĩnh viễn: ${it.localizedMessage}"
            }
        }
    }

    fun permanentDeleteContract(contract: ContractRecord) {
        viewModelScope.launch {
            _isBusy.value = true
            val relatedSessions = appState.value.allPtSessions.filter { it.contractId == contract.id }
            val result = repository.permanentDeleteContract(contract.id, relatedSessions)
            _isBusy.value = false
            result.onSuccess {
                _toastMessage.value = "Đã xóa vĩnh viễn hợp đồng ${contract.contractCode}"
            }.onFailure {
                _toastMessage.value = "Lỗi xóa vĩnh viễn: ${it.localizedMessage}"
            }
        }
    }

    fun permanentDeletePtSession(session: PtSessionRecord) {
        viewModelScope.launch {
            _isBusy.value = true
            val result = repository.permanentDeletePtSession(session.id)
            _isBusy.value = false
            result.onSuccess {
                _toastMessage.value = "Đã xóa vĩnh viễn buổi tập PT"
            }.onFailure {
                _toastMessage.value = "Lỗi xóa vĩnh viễn: ${it.localizedMessage}"
            }
        }
    }

    fun permanentDeleteSingleTicket(ticket: SingleTicketRecord) {
        viewModelScope.launch {
            _isBusy.value = true
            val result = repository.permanentDeleteSingleTicket(ticket.id)
            _isBusy.value = false
            result.onSuccess {
                _toastMessage.value = "Đã xóa vĩnh viễn Vé lẻ"
            }.onFailure {
                _toastMessage.value = "Lỗi xóa vĩnh viễn: ${it.localizedMessage}"
            }
        }
    }

    fun buildBackupBundle(): BackupBundle {
        val state = appState.value
        return BackupBundle(
            exportedAtEpoch = System.currentTimeMillis(),
            config = state.config,
            members = state.allMembers,
            contracts = state.allContracts,
            ptSessions = state.allPtSessions,
            singleTickets = state.allSingleTickets
        )
    }

    fun restoreFromBackupJson(jsonContent: String, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            _isBusy.value = true
            runCatching {
                val bundle = BackupBundle.fromJsonString(jsonContent, currentUserId)
                repository.restoreFromBackupBundle(bundle).getOrThrow()
            }.onSuccess {
                _isBusy.value = false
                _toastMessage.value = "Khôi phục dữ liệu thành công (đã áp dụng bản mới nhất)"
                onSuccess()
            }.onFailure {
                _isBusy.value = false
                _toastMessage.value = "Lỗi khôi phục dữ liệu: ${it.localizedMessage}"
            }
        }
    }

    fun triggerManualCloudSync() {
        viewModelScope.launch {
            _isBusy.value = true
            val current = appState.value.config
            runCatching {
                repository.saveStudioConfig(current.copy(lastSyncEpoch = System.currentTimeMillis()))
            }.onSuccess {
                _isBusy.value = false
                _toastMessage.value = "Đồng bộ Cloud thành công lúc ${java.text.SimpleDateFormat("HH:mm dd/MM/yyyy", java.util.Locale.getDefault()).format(java.util.Date())}"
            }.onFailure {
                _isBusy.value = false
                _toastMessage.value = "Đồng bộ Cloud thất bại: ${it.localizedMessage}"
            }
        }
    }

    companion object {
        fun provideFactory(currentUserId: String): ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY]) {
                    "APPLICATION_KEY missing from CreationExtras"
                }
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                FitnessViewModel(FitnessRepository(db), currentUserId)
            }
        }
    }
}
