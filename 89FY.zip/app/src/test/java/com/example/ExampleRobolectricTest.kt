package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.FitnessLocalDatabase
import com.example.data.model.BackupBundle
import com.example.data.model.MemberGroup
import com.example.data.model.MemberProfile
import com.example.data.model.PaymentMethod
import com.example.data.model.ServiceType
import com.example.data.model.SingleTicketType
import com.example.data.repository.FitnessRepository
import com.example.domain.FitnessCalculator
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun test1_appNameAnd8MainMenusAvailableWithoutAuthentication() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("89 Fitness & Yoga", appName)

        val menus = com.example.ui.screens.MainMenuDestination.entries
        assertEquals(8, menus.size)
        assertEquals("1. GYM", menus[0].title)
        assertEquals("2. YOGA", menus[1].title)
        assertEquals("3. TẠO HỢP ĐỒNG", menus[2].title)
        assertEquals("4. DOANH THU", menus[3].title)
        assertEquals("5. THEO DÕI HỘI VIÊN", menus[4].title)
        assertEquals("6. QUẢN LÍ PT", menus[5].title)
        assertEquals("7. CÀI ĐẶT", menus[6].title)
        assertEquals("8. THÙNG RÁC", menus[7].title)
    }

    @Test
    fun test2And3_fullOfflineCrudAndPersistenceAcrossDatabaseReopenWithoutGoogleLogin() {
        runBlocking {
            val context = ApplicationProvider.getApplicationContext<Context>()
            val dbFile = File(context.cacheDir, "test_offline_persistence_${System.currentTimeMillis()}.db")

            // Lần mở app 1 (hoàn toàn Offline, không có Firebase Auth)
            val db1 = Room.databaseBuilder(context, FitnessLocalDatabase::class.java, dbFile.absolutePath)
                .allowMainThreadQueries()
                .build()
            val repo1 = FitnessRepository(localDao = db1.fitnessDao(), remoteDb = null)

            // Tạo hội viên & hợp đồng GYM, YOGA, PT hoàn toàn Offline
            val (gymMember, gymContract) = repo1.createMemberWithInitialContract(
                serviceType = ServiceType.GYM.code,
                fullName = "Nguyễn Văn A",
                phone = "0901234567",
                memberGroup = MemberGroup.NAM.code,
                durationMonths = 3L,
                startDate = "2026-05-01",
                endDate = "2026-07-30",
                totalSessions = 0L,
                packageValue = 800_000L,
                paidAmount = 800_000L,
                paymentMethod = PaymentMethod.TRANSFER.code,
                cashAmount = 0L,
                transferAmount = 800_000L,
                paymentDate = "2026-05-01"
            ).getOrThrow()

            repo1.createMemberWithInitialContract(
                serviceType = ServiceType.YOGA.code,
                fullName = "Trần Thị B",
                phone = "0902345678",
                memberGroup = MemberGroup.NONE.code,
                durationMonths = 2L,
                startDate = "2026-05-01",
                endDate = "2026-06-30",
                totalSessions = 0L,
                packageValue = 1_000_000L,
                paidAmount = 1_000_000L,
                paymentMethod = PaymentMethod.CASH.code,
                cashAmount = 1_000_000L,
                transferAmount = 0L,
                paymentDate = "2026-05-01"
            ).getOrThrow()

            val (ptMember, ptContract) = repo1.createMemberWithInitialContract(
                serviceType = ServiceType.PT.code,
                fullName = "Lê Văn C",
                phone = "0903456789",
                memberGroup = MemberGroup.NONE.code,
                durationMonths = 2L,
                startDate = "2026-05-01",
                endDate = "2026-06-30",
                totalSessions = 12L,
                packageValue = 6_000_000L,
                paidAmount = 6_000_000L,
                paymentMethod = PaymentMethod.TRANSFER.code,
                cashAmount = 0L,
                transferAmount = 6_000_000L,
                paymentDate = "2026-05-01"
            ).getOrThrow()

            // Ghi nhận buổi tập PT & Vé lẻ
            repo1.recordPtSession(
                member = ptMember,
                contract = ptContract,
                sessionDate = "2026-05-02",
                note = "Buổi tập ngực & tay sau"
            ).getOrThrow()

            repo1.createSingleTicket(
                ticketType = SingleTicketType.DAILY.code,
                saleDate = "2026-05-02",
                quantity = 2L,
                unitPrice = 50_000L,
                paymentMethod = PaymentMethod.CASH.code,
                cashAmount = 100_000L,
                transferAmount = 0L
            ).getOrThrow()

            // Cập nhật bảng giá và cài đặt
            val currentConfig = repo1.getOrCreateConfig()
            repo1.saveStudioConfig(currentConfig.copy(gymNam1M = 320_000L, isDarkMode = true))

            // Đóng DB mô phỏng việc đóng ứng dụng / khởi động lại điện thoại
            db1.close()

            // Lần mở app 2: Mở lại DB từ file trên thiết bị
            val db2 = Room.databaseBuilder(context, FitnessLocalDatabase::class.java, dbFile.absolutePath)
                .allowMainThreadQueries()
                .build()
            val repo2 = FitnessRepository(localDao = db2.fitnessDao(), remoteDb = null)

            val persistedMembers = repo2.observeMembers().first()
            val persistedContracts = repo2.observeContracts().first()
            val persistedSessions = repo2.observePtSessions().first()
            val persistedTickets = repo2.observeSingleTickets().first()
            val persistedConfig = repo2.observeStudioConfig().first()

            assertEquals(3, persistedMembers.size)
            assertEquals(3, persistedContracts.size)
            assertEquals(1, persistedSessions.size)
            assertEquals(1, persistedTickets.size)
            assertEquals(320_000L, persistedConfig.gymNam1M)
            assertTrue(persistedConfig.isDarkMode)

            // Kiểm tra tính toán doanh thu dòng tiền hoạt động offline
            val cashflow = FitnessCalculator.computeMonthlyCashflow(
                year = 2026,
                month = 5,
                contracts = persistedContracts,
                singleTickets = persistedTickets
            )
            assertEquals(
                800_000L + 1_000_000L + 6_000_000L + 100_000L,
                cashflow.actualCashReceived + cashflow.actualTransferReceived
            )

            // Kiểm tra xóa mềm vào Thùng rác và khôi phục
            repo2.softDeleteMemberCascade(
                member = gymMember,
                relatedContracts = listOf(gymContract),
                relatedSessions = emptyList()
            ).getOrThrow()

            assertTrue(repo2.observeMembers().first().first { it.id == gymMember.id }.isDeleted)
            assertTrue(repo2.observeContracts().first().first { it.id == gymContract.id }.isDeleted)

            val deletedMember = repo2.observeMembers().first().first { it.id == gymMember.id }
            repo2.restoreMemberCascade(
                member = deletedMember,
                allContracts = repo2.observeContracts().first(),
                allSessions = repo2.observePtSessions().first()
            ).getOrThrow()

            assertFalse(repo2.observeMembers().first().first { it.id == gymMember.id }.isDeleted)
            assertFalse(repo2.observeContracts().first().first { it.id == gymContract.id }.isDeleted)

            db2.close()
            dbFile.delete()
        }
    }

    @Test
    fun test5And6_failedGoogleLoginOrGoogleSignOutNeverDeletesLocalData() {
        runBlocking {
            val context = ApplicationProvider.getApplicationContext<Context>()
            val db = FitnessLocalDatabase.createInMemory(context)
            val repo = FitnessRepository(localDao = db.fitnessDao(), remoteDb = null)

            repo.createMemberWithInitialContract(
                serviceType = ServiceType.GYM.code,
                fullName = "Phạm Văn D",
                phone = "0988776655",
                memberGroup = MemberGroup.NAM.code,
                durationMonths = 1L,
                startDate = "2026-05-01",
                endDate = "2026-05-31",
                totalSessions = 0L,
                packageValue = 300_000L,
                paidAmount = 300_000L,
                paymentMethod = PaymentMethod.CASH.code,
                cashAmount = 300_000L,
                transferAmount = 0L,
                paymentDate = "2026-05-01"
            ).getOrThrow()

            // Thử gọi đồng bộ Cloud khi chưa đăng nhập Google (phải trả về failure an toàn mà không xóa dữ liệu local)
            val syncWithoutLoginResult = repo.backupLocalToCloud()
            assertTrue(syncWithoutLoginResult.isFailure)

            // Dữ liệu local vẫn còn nguyên vẹn sau khi đồng bộ/đăng nhập thất bại hoặc đăng xuất
            val localMembers = repo.observeMembers().first()
            assertEquals(1, localMembers.size)
            assertEquals("Phạm Văn D", localMembers.first().fullName)

            db.close()
        }
    }

    @Test
    fun test7_backupAndRestoreIntegrityValidationAndFullLocalRestore() {
        runBlocking {
            val context = ApplicationProvider.getApplicationContext<Context>()
            val sourceDb = FitnessLocalDatabase.createInMemory(context)
            val sourceRepo = FitnessRepository(localDao = sourceDb.fitnessDao(), remoteDb = null)

            sourceRepo.createMemberWithInitialContract(
                serviceType = ServiceType.YOGA.code,
                fullName = "Hoàng Thị E",
                phone = "0911223344",
                memberGroup = MemberGroup.NONE.code,
                durationMonths = 2L,
                startDate = "2026-05-01",
                endDate = "2026-06-30",
                totalSessions = 0L,
                packageValue = 1_000_000L,
                paidAmount = 1_000_000L,
                paymentMethod = PaymentMethod.TRANSFER.code,
                cashAmount = 0L,
                transferAmount = 1_000_000L,
                paymentDate = "2026-05-01"
            ).getOrThrow()

            sourceRepo.createSingleTicket(
                ticketType = SingleTicketType.WEEKLY.code,
                saleDate = "2026-05-01",
                quantity = 1L,
                unitPrice = 200_000L,
                paymentMethod = PaymentMethod.CASH.code,
                cashAmount = 200_000L,
                transferAmount = 0L
            ).getOrThrow()

            // Xuất gói sao lưu từ cơ sở dữ liệu Local và kiểm tra tính toàn vẹn
            val backupBundle = sourceRepo.buildLocalBackupBundle().getOrThrow()
            assertTrue(backupBundle.validateIntegrity().isSuccess)

            val backupJson = backupBundle.toJsonString()
            assertTrue(backupJson.contains("recordCounts"))

            // Kiểm tra từ chối bản sao lưu bị hỏng (ID rỗng)
            val corruptedBundle = backupBundle.copy(
                members = listOf(MemberProfile(id = "", fullName = ""))
            )
            assertTrue(corruptedBundle.validateIntegrity().isFailure)

            // Khôi phục vào một cơ sở dữ liệu Local mới hoàn toàn
            val targetDb = FitnessLocalDatabase.createInMemory(context)
            val targetRepo = FitnessRepository(localDao = targetDb.fitnessDao(), remoteDb = null)

            val parsedBundle = BackupBundle.fromJsonString(backupJson)
            val restoreResult = targetRepo.restoreFromBackupBundle(parsedBundle)
            assertTrue(restoreResult.isSuccess)

            val restoredMembers = targetRepo.observeMembers().first()
            val restoredContracts = targetRepo.observeContracts().first()
            val restoredTickets = targetRepo.observeSingleTickets().first()

            assertEquals(1, restoredMembers.size)
            assertEquals("Hoàng Thị E", restoredMembers.first().fullName)
            assertEquals(1, restoredContracts.size)
            assertEquals(1_000_000L, restoredContracts.first().packageValue)
            assertEquals(1, restoredTickets.size)
            assertEquals(200_000L, restoredTickets.first().totalAmount)

            sourceDb.close()
            targetDb.close()
        }
    }
}
