package com.example

import com.example.domain.DateCalculator
import com.example.domain.RevenueAllocationEngine
import com.example.ui.buildMemberStatusText
import org.junit.Assert.assertEquals
import org.junit.Test

class ExampleRobolectricTest {

    @Test
    fun verifyMemberExpiryStatusFormatting() {
        assertEquals("Còn 91 ngày", buildMemberStatusText(91, true))
        assertEquals("Hết hạn hôm nay", buildMemberStatusText(0, true))
        assertEquals("Hết hạn 15 ngày", buildMemberStatusText(-15, true))
    }

    @Test
    fun verifyCancelledContractStopsFutureMonthRevenue() {
        val cancelledInput = RevenueAllocationEngine.ContractAllocationInput(
            contractId = "c_cancel",
            contractCode = "HDG-999",
            memberId = "m_cancel",
            memberName = "Lê Văn C",
            durationMonths = 3,
            startDateIso = "2026-10-01",
            endDateIso = DateCalculator.calculateEndDate("2026-10-01", 3),
            agreedValueVnd = 1_200_000L,
            isRenewal = false,
            isCancelled = true,
            cancelledDateIso = "2026-10-03",
            refundedAmountVnd = 1_000_000L // Retained = 200,000 VND
        )

        val octAllocation = RevenueAllocationEngine.allocateContractForMonth(cancelledInput, 2026, 10)
        val novAllocation = RevenueAllocationEngine.allocateContractForMonth(cancelledInput, 2026, 11)

        assertEquals(200_000L, octAllocation?.allocatedRevenueVnd)
        assertEquals(null, novAllocation)
    }
}
