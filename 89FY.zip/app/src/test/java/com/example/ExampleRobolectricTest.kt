package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.FitnessLocalDatabase
import com.example.data.model.BackupBundle
import com.example.data.model.MemberGroup
import com.example.data.model.MemberProfile
import com.example.data.model.PaymentMethod
import com.example.data.model.ServiceType
import com.example.data.model.SingleTicketType
import com.example.data.repository.FitnessRepository
import com.example.domain.FitnessCalculator
import com.example.domain.MemberSearchQueryType
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun test1_appNameAnd8MainMenusAvailableWithoutAuthentication() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("89 Fitness & Yoga", appName)

        val menus = com.example.ui.screens.MainMenuDestination.entries
        assertEquals(8, menus.size)
        assertEquals("1. GYM", menus[0].title)
        assertEquals("2. YOGA", menus[1].title)
        assertEquals("3. TẠO HỢP ĐỒNG", menus[2].title)
        assertEquals("4. DOANH THU", menus[3].title)
        assertEquals("5. THEO DÕI HỘI VIÊN", menus[4].title)
        assertEquals("6. QUẢN LÍ PT", menus[5].title)
        assertEquals("7. CÀI ĐẶT", menus[6].title)
        assertEquals("8. THÙNG RÁC", menus[7].title)
    }

    @Test
    fun test2And3_fullOfflineCrudAndPersistenceAcrossDatabaseReopenWithoutGoogleLogin() {
        runBlocking {
            val context = ApplicationProvider.getApplicationContext<Context>()
            val dbFile = File(context.cacheDir, "test_offline_persistence_${System.currentTimeMillis()}.db")

            val db1 = Room.databaseBuilder(context, FitnessLocalDatabase::class.java, dbFile.absolutePath)
                .allowMainThreadQueries()
                .build()
            val repo1 = FitnessRepository(localDao = db1.fitnessDao(), remoteDb = null)

            val (gymMember, gymContract) = repo1.createMemberWithInitialContract(
                serviceType = ServiceType.GYM.code,
                fullName = "Nguyễn Văn A",
                phone = "0901234567",
                memberGroup = MemberGroup.NAM.code,
                durationMonths = 3L,
                startDate = "2026-05-01",
                endDate = "2026-07-30",
                totalSessions = 0L,
                packageValue = 800_000L,
                paidAmount = 800_000L,
                paymentMethod = PaymentMethod.TRANSFER.code,
                cashAmount = 0L,
                transferAmount = 800_000L,
                paymentDate = "2026-05-01"
            ).getOrThrow()

            repo1.createMemberWithInitialContract(
                serviceType = ServiceType.YOGA.code,
                fullName = "Trần Thị B",
                phone = "0902345678",
                memberGroup = MemberGroup.NONE.code,
                durationMonths = 2L,
                startDate = "2026-05-01",
                endDate = "2026-06-30",
                totalSessions = 0L,
                packageValue = 1_000_000L,
                paidAmount = 1_000_000L,
                paymentMethod = PaymentMethod.CASH.code,
                cashAmount = 1_000_000L,
                transferAmount = 0L,
                paymentDate = "2026-05-01"
            ).getOrThrow()

            val (ptMember, ptContract) = repo1.createMemberWithInitialContract(
                serviceType = ServiceType.PT.code,
                fullName = "Lê Văn C",
                phone = "0903456789",
                memberGroup = MemberGroup.NONE.code,
                durationMonths = 2L,
                startDate = "2026-05-01",
                endDate = "2026-06-30",
                totalSessions = 12L,
                packageValue = 6_000_000L,
                paidAmount = 6_000_000L,
                paymentMethod = PaymentMethod.TRANSFER.code,
                cashAmount = 0L,
                transferAmount = 6_000_000L,
                paymentDate = "2026-05-01"
            ).getOrThrow()

            repo1.recordPtSession(
                member = ptMember,
                contract = ptContract,
                sessionDate = "2026-05-02",
                note = "Buổi tập ngực & tay sau"
            ).getOrThrow()

            repo1.createSingleTicket(
                ticketType = SingleTicketType.DAILY.code,
                saleDate = "2026-05-02",
                quantity = 2L,
                unitPrice = 50_000L,
                paymentMethod = PaymentMethod.CASH.code,
                cashAmount = 100_000L,
                transferAmount = 0L
            ).getOrThrow()

            val currentConfig = repo1.getOrCreateConfig()
            repo1.saveStudioConfig(currentConfig.copy(gymNam1M = 320_000L, isDarkMode = true))

            db1.close()

            val db2 = Room.databaseBuilder(context, FitnessLocalDatabase::class.java, dbFile.absolutePath)
                .allowMainThreadQueries()
                .build()
            val repo2 = FitnessRepository(localDao = db2.fitnessDao(), remoteDb = null)

            val persistedMembers = repo2.observeMembers().first()
            val persistedContracts = repo2.observeContracts().first()
            val persistedSessions = repo2.observePtSessions().first()
            val persistedTickets = repo2.observeSingleTickets().first()
            val persistedConfig = repo2.observeStudioConfig().first()

            assertEquals(3, persistedMembers.size)
            assertEquals(3, persistedContracts.size)
            assertEquals(1, persistedSessions.size)
            assertEquals(1, persistedTickets.size)
            assertEquals(320_000L, persistedConfig.gymNam1M)
            assertTrue(persistedConfig.isDarkMode)

            val cashflow = FitnessCalculator.computeMonthlyCashflow(
                year = 2026,
                month = 5,
                contracts = persistedContracts,
                singleTickets = persistedTickets
            )
            assertEquals(
                800_000L + 1_000_000L + 6_000_000L + 100_000L,
                cashflow.actualCashReceived + cashflow.actualTransferReceived
            )

            repo2.softDeleteMemberCascade(
                member = gymMember,
                relatedContracts = listOf(gymContract),
                relatedSessions = emptyList()
            ).getOrThrow()

            assertTrue(repo2.observeMembers().first().first { it.id == gymMember.id }.isDeleted)
            assertTrue(repo2.observeContracts().first().first { it.id == gymContract.id }.isDeleted)

            val deletedMember = repo2.observeMembers().first().first { it.id == gymMember.id }
            repo2.restoreMemberCascade(
                member = deletedMember,
                allContracts = repo2.observeContracts().first(),
                allSessions = repo2.observePtSessions().first()
            ).getOrThrow()

            assertFalse(repo2.observeMembers().first().first { it.id == gymMember.id }.isDeleted)
            assertFalse(repo2.observeContracts().first().first { it.id == gymContract.id }.isDeleted)

            db2.close()
            dbFile.delete()
        }
    }

    @Test
    fun test5And6_failedGoogleLoginOrGoogleSignOutNeverDeletesLocalData() {
        runBlocking {
            val context = ApplicationProvider.getApplicationContext<Context>()
            val db = FitnessLocalDatabase.createInMemory(context)
            val repo = FitnessRepository(localDao = db.fitnessDao(), remoteDb = null)

            repo.createMemberWithInitialContract(
                serviceType = ServiceType.GYM.code,
                fullName = "Phạm Văn D",
                phone = "0988776655",
                memberGroup = MemberGroup.NAM.code,
                durationMonths = 1L,
                startDate = "2026-05-01",
                endDate = "2026-05-31",
                totalSessions = 0L,
                packageValue = 300_000L,
                paidAmount = 300_000L,
                paymentMethod = PaymentMethod.CASH.code,
                cashAmount = 300_000L,
                transferAmount = 0L,
                paymentDate = "2026-05-01"
            ).getOrThrow()

            val syncWithoutLoginResult = repo.backupLocalToCloud()
            assertTrue(syncWithoutLoginResult.isFailure)

            val localMembers = repo.observeMembers().first()
            assertEquals(1, localMembers.size)
            assertEquals("Phạm Văn D", localMembers.first().fullName)

            db.close()
        }
    }

    @Test
    fun test7_backupAndRestoreIntegrityValidationAndFullLocalRestore() {
        runBlocking {
            val context = ApplicationProvider.getApplicationContext<Context>()
            val sourceDb = FitnessLocalDatabase.createInMemory(context)
            val sourceRepo = FitnessRepository(localDao = sourceDb.fitnessDao(), remoteDb = null)

            sourceRepo.createMemberWithInitialContract(
                serviceType = ServiceType.YOGA.code,
                fullName = "Hoàng Thị E",
                phone = "0911223344",
                memberGroup = MemberGroup.NONE.code,
                durationMonths = 2L,
                startDate = "2026-05-01",
                endDate = "2026-06-30",
                totalSessions = 0L,
                packageValue = 1_000_000L,
                paidAmount = 1_000_000L,
                paymentMethod = PaymentMethod.TRANSFER.code,
                cashAmount = 0L,
                transferAmount = 1_000_000L,
                paymentDate = "2026-05-01"
            ).getOrThrow()

            sourceRepo.createSingleTicket(
                ticketType = SingleTicketType.WEEKLY.code,
                saleDate = "2026-05-01",
                quantity = 1L,
                unitPrice = 200_000L,
                paymentMethod = PaymentMethod.CASH.code,
                cashAmount = 200_000L,
                transferAmount = 0L
            ).getOrThrow()

            val backupBundle = sourceRepo.buildLocalBackupBundle().getOrThrow()
            assertTrue(backupBundle.validateIntegrity().isSuccess)

            val backupJson = backupBundle.toJsonString()
            assertTrue(backupJson.contains("recordCounts"))

            val corruptedBundle = backupBundle.copy(
                members = listOf(MemberProfile(id = "", fullName = ""))
            )
            assertTrue(corruptedBundle.validateIntegrity().isFailure)

            val targetDb = FitnessLocalDatabase.createInMemory(context)
            val targetRepo = FitnessRepository(localDao = targetDb.fitnessDao(), remoteDb = null)

            val parsedBundle = BackupBundle.fromJsonString(backupJson)
            val restoreResult = targetRepo.restoreFromBackupBundle(parsedBundle)
            assertTrue(restoreResult.isSuccess)

            val restoredMembers = targetRepo.observeMembers().first()
            val restoredContracts = targetRepo.observeContracts().first()
            val restoredTickets = targetRepo.observeSingleTickets().first()

            assertEquals(1, restoredMembers.size)
            assertEquals("Hoàng Thị E", restoredMembers.first().fullName)
            assertEquals(1, restoredContracts.size)
            assertEquals(1_000_000L, restoredContracts.first().packageValue)
            assertEquals(1, restoredTickets.size)
            assertEquals(200_000L, restoredTickets.first().totalAmount)

            sourceDb.close()
            targetDb.close()
        }
    }

    @Test
    fun test8_mandatoryThreeBranchMemberSearchLogicMatchesAllPrdCases() {
        // Kiểm thử đủ 10 trường hợp trong bảng PRD Mục 14.1:
        assertEquals(MemberSearchQueryType.STT_ONLY, FitnessCalculator.classifyMemberSearchQuery("6").first)
        assertEquals(MemberSearchQueryType.STT_ONLY, FitnessCalculator.classifyMemberSearchQuery("16").first)
        assertEquals(MemberSearchQueryType.STT_ONLY, FitnessCalculator.classifyMemberSearchQuery("168").first)
        assertEquals(MemberSearchQueryType.STT_ONLY, FitnessCalculator.classifyMemberSearchQuery("1689").first)
        assertEquals(MemberSearchQueryType.PHONE_ONLY, FitnessCalculator.classifyMemberSearchQuery("16891").first)
        assertEquals(MemberSearchQueryType.PHONE_ONLY, FitnessCalculator.classifyMemberSearchQuery("09123").first)
        assertEquals(MemberSearchQueryType.NAME_ONLY, FitnessCalculator.classifyMemberSearchQuery("N").first)
        assertEquals(MemberSearchQueryType.NAME_ONLY, FitnessCalculator.classifyMemberSearchQuery("Ng").first)
        assertEquals(MemberSearchQueryType.NAME_ONLY, FitnessCalculator.classifyMemberSearchQuery("Nguyễn").first)
        assertEquals(MemberSearchQueryType.EMPTY, FitnessCalculator.classifyMemberSearchQuery("").first)

        // Kiểm tra tách biệt tuyệt đối giữa tìm STT (1..4 chữ số) và tìm SĐT (>= 5 chữ số):
        val memberA = MemberProfile(
            id = "m1",
            type = "GYM",
            stt = 16L,
            fullName = "Nguyễn Văn Tùng",
            phone = "0988777666"
        )
        val memberB = MemberProfile(
            id = "m2",
            type = "GYM",
            stt = 5L,
            fullName = "Trần Minh",
            phone = "0916123456" // chứa "16" trong SĐT nhưng STT là 5
        )
        val memberC = MemberProfile(
            id = "m3",
            type = "GYM",
            stt = 1689L,
            fullName = "Lê Hoàng",
            phone = "0905168912"
        )

        // Nhập "6", "16": Chỉ tìm theo STT (memberA và memberC khớp STT; memberB có "16" trong SĐT nhưng KHÔNG được khớp!)
        assertTrue(FitnessCalculator.matchesMemberSearchQuery(memberA, "6"))
        assertTrue(FitnessCalculator.matchesMemberSearchQuery(memberA, "16"))
        assertFalse(FitnessCalculator.matchesMemberSearchQuery(memberB, "16"))
        assertTrue(FitnessCalculator.matchesMemberSearchQuery(memberC, "168"))
        assertTrue(FitnessCalculator.matchesMemberSearchQuery(memberC, "1689"))

        // Nhập "16891" hoặc "09161": >= 5 chữ số -> Chỉ tìm theo SĐT!
        assertTrue(FitnessCalculator.matchesMemberSearchQuery(memberC, "16891"))
        assertTrue(FitnessCalculator.matchesMemberSearchQuery(memberB, "09161"))
        assertFalse(FitnessCalculator.matchesMemberSearchQuery(memberA, "09161"))

        // Nhập chữ cái: Tìm ngay theo Họ tên từ ký tự đầu tiên, không phân biệt hoa thường
        assertTrue(FitnessCalculator.matchesMemberSearchQuery(memberA, "N"))
        assertTrue(FitnessCalculator.matchesMemberSearchQuery(memberA, "ng"))
        assertTrue(FitnessCalculator.matchesMemberSearchQuery(memberA, "Nguyễn"))
        assertTrue(FitnessCalculator.matchesMemberSearchQuery(memberA, "tùng"))
        assertFalse(FitnessCalculator.matchesMemberSearchQuery(memberB, "Nguyễn"))

        // Khi ô tìm kiếm rỗng: trả về toàn bộ danh sách
        assertTrue(FitnessCalculator.matchesMemberSearchQuery(memberA, ""))
        assertTrue(FitnessCalculator.matchesMemberSearchQuery(memberB, "   "))
    }

    @Test
    fun test9_contractCreationSupportsDirectNewMemberAndExistingMemberRenewalPreservingStt() {
        runBlocking {
            val context = ApplicationProvider.getApplicationContext<Context>()
            val db = FitnessLocalDatabase.createInMemory(context)
            val repo = FitnessRepository(localDao = db.fitnessDao(), remoteDb = null)

            // A. Tạo hội viên mới trực tiếp (cấp STT1, HĐ1)
            val (newMember, firstContract) = repo.createMemberWithInitialContract(
                serviceType = "GYM",
                fullName = "Đỗ Gia Huy",
                phone = "0933445566",
                memberGroup = "NAM",
                durationMonths = 1L,
                startDate = "2026-05-01",
                endDate = "2026-05-31",
                totalSessions = 0L,
                packageValue = 300_000L,
                paidAmount = 300_000L,
                paymentMethod = "TRANSFER",
                cashAmount = 0L,
                transferAmount = 300_000L,
                paymentDate = "2026-05-01"
            ).getOrThrow()

            assertEquals(1L, newMember.stt)
            assertEquals("GYM-STT1-001", firstContract.contractCode)
            assertFalse(firstContract.isRenewal)

            // B. Gia hạn cho hội viên hiện có (giữ nguyên STT1, tăng mã HĐ lên 002)
            val renewalContract = repo.createRenewalContract(
                member = newMember,
                memberGroup = "NAM",
                durationMonths = 3L,
                startDate = "2026-06-01",
                endDate = "2026-08-31",
                totalSessions = 0L,
                packageValue = 800_000L,
                paidAmount = 800_000L,
                paymentMethod = "CASH",
                cashAmount = 800_000L,
                transferAmount = 0L,
                paymentDate = "2026-06-01"
            ).getOrThrow()

            assertEquals(newMember.id, renewalContract.memberId)
            assertEquals(1L, renewalContract.memberSttSnapshot)
            assertEquals("GYM-STT1-002", renewalContract.contractCode)
            assertTrue(renewalContract.isRenewal)

            val allMembers = repo.observeMembers().first()
            val allContracts = repo.observeContracts().first()
            assertEquals(1, allMembers.size)
            assertEquals(2, allContracts.size)

            db.close()
        }
    }

    @Test
    fun test10_contractEditingDurationDatesPriceAndRevenueIsolation() {
        runBlocking {
            val context = ApplicationProvider.getApplicationContext<Context>()
            val db = FitnessLocalDatabase.createInMemory(context)
            val repo = FitnessRepository(localDao = db.fitnessDao(), remoteDb = null)
            val config = repo.getOrCreateConfig()

            // Kiểm tra danh sách gói hợp lệ theo loại dịch vụ
            assertEquals(listOf(1, 2, 3, 12), FitnessCalculator.validDurationsForService("GYM"))
            assertEquals(listOf(1, 2, 3), FitnessCalculator.validDurationsForService("YOGA"))
            assertFalse(FitnessCalculator.validDurationsForService("YOGA").contains(12))

            // Tạo 2 hợp đồng GYM và 1 hợp đồng YOGA
            val (_, gymContract1) = repo.createMemberWithInitialContract(
                serviceType = "GYM",
                fullName = "Nguyễn Hoàng Nam",
                phone = "0901112222",
                memberGroup = "NAM",
                durationMonths = 1L,
                startDate = "2026-08-01",
                endDate = FitnessCalculator.calculateEndDate("2026-08-01", 1),
                totalSessions = 0L,
                packageValue = config.getGymPrice(MemberGroup.NAM, 1), // 300.000
                paidAmount = 300_000L,
                paymentMethod = "TRANSFER",
                cashAmount = 0L,
                transferAmount = 300_000L,
                paymentDate = "2026-08-01"
            ).getOrThrow()

            val (_, gymContractOther) = repo.createMemberWithInitialContract(
                serviceType = "GYM",
                fullName = "Lê Văn Khác",
                phone = "0909998888",
                memberGroup = "NAM",
                durationMonths = 1L,
                startDate = "2026-08-05",
                endDate = FitnessCalculator.calculateEndDate("2026-08-05", 1),
                totalSessions = 0L,
                packageValue = 300_000L,
                paidAmount = 300_000L,
                paymentMethod = "CASH",
                cashAmount = 300_000L,
                transferAmount = 0L,
                paymentDate = "2026-08-05"
            ).getOrThrow()

            val (_, yogaContract) = repo.createMemberWithInitialContract(
                serviceType = "YOGA",
                fullName = "Trần Thu Hà",
                phone = "0903334444",
                memberGroup = "NONE",
                durationMonths = 1L,
                startDate = "2026-11-09",
                endDate = FitnessCalculator.calculateEndDate("2026-11-09", 1),
                totalSessions = 0L,
                packageValue = config.getYogaPrice(1), // 550.000
                paidAmount = 550_000L,
                paymentMethod = "TRANSFER",
                cashAmount = 0L,
                transferAmount = 550_000L,
                paymentDate = "2026-11-09"
            ).getOrThrow()

            // Kịch bản 1 & 5: Sửa hợp đồng GYM từ 1 tháng lên 3 tháng, giữ nguyên paidAmount (300.000)
            val newDuration3M = 3
            val recalculatedEnd3M = FitnessCalculator.calculateEndDate(gymContract1.startDate, newDuration3M)
            val suggestedPrice3M = config.getGymPrice(MemberGroup.fromCode(gymContract1.memberGroup), newDuration3M)
            assertEquals("2026-10-31", recalculatedEnd3M)
            assertEquals(800_000L, suggestedPrice3M)

            val editedGym3M = gymContract1.copy(
                durationMonths = newDuration3M.toLong(),
                endDate = recalculatedEnd3M,
                packageValue = suggestedPrice3M
                // paidAmount, cashAmount, transferAmount, paymentMethod giữ nguyên
            )
            repo.updateContractRecord(editedGym3M).getOrThrow()

            val afterEdit3M = repo.observeContracts().first().first { it.id == gymContract1.id }
            assertEquals(3L, afterEdit3M.durationMonths)
            assertEquals("2026-10-31", afterEdit3M.endDate)
            assertEquals(800_000L, afterEdit3M.packageValue)
            assertEquals(300_000L, afterEdit3M.paidAmount) // Không tự động đổi paidAmount
            assertEquals(300_000L, afterEdit3M.transferAmount)

            // Kịch bản 2 & 6: Sửa hợp đồng GYM từ 3 tháng lên 12 tháng + chỉnh tay giá trị gói (2.800.000), giữ nguyên paidAmount
            val newDuration12M = 12
            val recalculatedEnd12M = FitnessCalculator.calculateEndDate(afterEdit3M.startDate, newDuration12M)
            val manualCustomPackageValue = 2_800_000L
            assertEquals("2027-07-31", recalculatedEnd12M)

            val editedGym12M = afterEdit3M.copy(
                durationMonths = newDuration12M.toLong(),
                endDate = recalculatedEnd12M,
                packageValue = manualCustomPackageValue
            )
            repo.updateContractRecord(editedGym12M).getOrThrow()

            val afterEdit12M = repo.observeContracts().first().first { it.id == gymContract1.id }
            assertEquals(12L, afterEdit12M.durationMonths)
            assertEquals("2027-07-31", afterEdit12M.endDate)
            assertEquals(2_800_000L, afterEdit12M.packageValue)
            assertEquals(300_000L, afterEdit12M.paidAmount) // Vẫn giữ nguyên số tiền đã thanh toán

            // Kịch bản 3 & 4: Sửa hợp đồng YOGA từ 1 tháng lên 2 tháng và đổi ngày đăng ký -> ngày hết hạn tự tính lại
            val newYogaDuration2M = 2
            val newYogaStartDate = "2026-11-15"
            val newYogaEndDate = FitnessCalculator.calculateEndDate(newYogaStartDate, newYogaDuration2M)
            val suggestedYoga2MPrice = config.getYogaPrice(newYogaDuration2M)
            assertEquals("2027-01-14", newYogaEndDate)
            assertEquals(1_000_000L, suggestedYoga2MPrice)

            val editedYoga2M = yogaContract.copy(
                durationMonths = newYogaDuration2M.toLong(),
                startDate = newYogaStartDate,
                endDate = newYogaEndDate,
                packageValue = suggestedYoga2MPrice
            )
            repo.updateContractRecord(editedYoga2M).getOrThrow()

            val afterYogaEdit = repo.observeContracts().first().first { it.id == yogaContract.id }
            assertEquals(2L, afterYogaEdit.durationMonths)
            assertEquals("2026-11-15", afterYogaEdit.startDate)
            assertEquals("2027-01-14", afterYogaEdit.endDate)
            assertEquals("15/11/2026", FitnessCalculator.formatDisplayDate(afterYogaEdit.startDate))
            assertEquals("14/01/2027", FitnessCalculator.formatDisplayDate(afterYogaEdit.endDate))
            assertEquals(1_000_000L, afterYogaEdit.packageValue)
            assertEquals(550_000L, afterYogaEdit.paidAmount)

            // Kịch bản 7, 8 & 12: Hủy thao tác sửa không ghi DB; chỉ hợp đồng được chọn mới cập nhật, hợp đồng khác giữ nguyên
            val untouchedOther = repo.observeContracts().first().first { it.id == gymContractOther.id }
            assertEquals(1L, untouchedOther.durationMonths)
            assertEquals("2026-08-05", untouchedOther.startDate)
            assertEquals(300_000L, untouchedOther.packageValue)
            assertEquals(300_000L, untouchedOther.paidAmount)

            db.close()
        }
    }

    @Test
    fun test11_vietnameseDatePickerFormattingAndTimezoneFreeDatePersistence() {
        // Kịch bản 9, 10, 11: Kiểm tra Việt hóa 100% DatePicker & không lệch ngày do múi giờ
        assertEquals(
            listOf("T2", "T3", "T4", "T5", "T6", "T7", "CN"),
            FitnessCalculator.vietnameseWeekdayShortLabels
        )
        assertEquals("Tháng 8 năm 2026", FitnessCalculator.formatVietnameseMonthYear(2026, 8))
        assertEquals("Tháng 11 năm 2026", FitnessCalculator.formatVietnameseMonthYear(2026, 11))

        // Kiểm tra ngày 09/11/2026 (Thứ Hai)
        assertEquals(0, FitnessCalculator.dayOfWeekMondayFirst(2026, 11, 9)) // 0 = Thứ Hai (T2)
        assertEquals("Thứ Hai", FitnessCalculator.vietnameseWeekdayFullName(2026, 11, 9))
        assertEquals("Thứ Hai, 09/11/2026", FitnessCalculator.formatVietnameseFullDate("2026-11-09"))
        assertEquals("09/11/2026", FitnessCalculator.formatDisplayDate("2026-11-09"))

        // Kiểm tra Chủ Nhật (15/11/2026)
        assertEquals(6, FitnessCalculator.dayOfWeekMondayFirst(2026, 11, 15)) // 6 = Chủ Nhật (CN)
        assertEquals("Chủ Nhật, 15/11/2026", FitnessCalculator.formatVietnameseFullDate("2026-11-15"))

        // Kiểm tra bảo toàn chuỗi ISO yyyy-MM-dd và tính ngày hết hạn chính xác tuyệt đối
        val selectedIso = String.format("%04d-%02d-%02d", 2026, 11, 9)
        assertEquals("2026-11-09", selectedIso)
        assertEquals("09/11/2026", FitnessCalculator.formatDisplayDate(selectedIso))
        assertEquals("2026-12-08", FitnessCalculator.calculateEndDate(selectedIso, 1))
        assertEquals("2027-01-08", FitnessCalculator.calculateEndDate(selectedIso, 2))
        assertEquals("2027-02-08", FitnessCalculator.calculateEndDate(selectedIso, 3))
        assertEquals("2027-11-08", FitnessCalculator.calculateEndDate(selectedIso, 12))
    }

    @Test
    fun test12_allocatedRevenueGymYogaPtAndSingleTicketAllMandatoryScenarios() {
        // Kiểm thử đầy đủ Mục 7 (Doanh thu GYM/YOGA 1..7 & PT 1..8)
        // Kịch bản GYM 1..4: Hội viên ABC có:
        // - Hợp đồng cũ (isRenewal = false): 01/09/2026 – 10/10/2026 (40 ngày hiệu lực, giao tháng 10 = 10 ngày), Giá = 400.000
        // - Hợp đồng gia hạn (isRenewal = true): 11/10/2026 – 20/11/2026 (41 ngày hiệu lực, giao tháng 10 = 21 ngày), Giá = 410.000
        val oldContractAbc = com.example.data.model.ContractRecord(
            id = "c_abc_old",
            contractCode = "GYM-STT1-001",
            memberId = "m_abc",
            memberSttSnapshot = 1L,
            memberNameSnapshot = "Hội viên ABC",
            serviceType = "GYM",
            isRenewal = false,
            startDate = "2026-09-01",
            endDate = "2026-10-10",
            packageValue = 400_000L,
            paidAmount = 400_000L,
            paymentMethod = "TRANSFER",
            transferAmount = 400_000L,
            paymentDate = "2026-09-01"
        )
        val renewalContractAbc = com.example.data.model.ContractRecord(
            id = "c_abc_renew",
            contractCode = "GYM-STT1-002",
            memberId = "m_abc",
            memberSttSnapshot = 1L,
            memberNameSnapshot = "Hội viên ABC",
            serviceType = "GYM",
            isRenewal = true,
            startDate = "2026-10-11",
            endDate = "2026-11-20",
            packageValue = 410_000L,
            paidAmount = 410_000L,
            paymentMethod = "CASH",
            cashAmount = 410_000L,
            paymentDate = "2026-10-11"
        )
        // Kịch bản GYM 5: Hợp đồng không giao với tháng 10/2026
        val outsidePeriodContract = com.example.data.model.ContractRecord(
            id = "c_outside",
            contractCode = "GYM-STT2-001",
            memberId = "m_2",
            memberSttSnapshot = 2L,
            memberNameSnapshot = "Hội viên Ngoài Kỳ",
            serviceType = "GYM",
            isRenewal = false,
            startDate = "2026-07-01",
            endDate = "2026-07-31",
            packageValue = 300_000L,
            paidAmount = 300_000L
        )
        // Kịch bản GYM 6: Hợp đồng bị xóa mềm
        val softDeletedContract = com.example.data.model.ContractRecord(
            id = "c_deleted",
            contractCode = "GYM-STT3-001",
            memberId = "m_3",
            memberSttSnapshot = 3L,
            memberNameSnapshot = "Hội viên Đã Xóa",
            serviceType = "GYM",
            isRenewal = false,
            startDate = "2026-10-01",
            endDate = "2026-10-31",
            packageValue = 300_000L,
            paidAmount = 300_000L,
            isDeleted = true
        )

        // Kịch bản PT 1..8:
        // - Hợp đồng PT1: gói 10 buổi, giá 5.000.000 -> mỗi buổi gộp = 500.000 -> 50% phòng tập = 250.000/buổi
        //   Có 3 buổi hoàn thành trong tháng 10/2026 (trong đó 1 bản ghi bị trùng ID để kiểm tra khử trùng), 1 buổi bị xóa mềm, 1 buổi tháng 09/2026
        val ptContract1 = com.example.data.model.ContractRecord(
            id = "c_pt_1",
            contractCode = "PT-STT1-001",
            memberId = "m_pt_1",
            memberSttSnapshot = 1L,
            memberNameSnapshot = "Khách PT Tích Cực",
            serviceType = "PT",
            totalSessions = 10L,
            usedSessions = 3L,
            startDate = "2026-09-15",
            endDate = "", // PT không có ngày hết hạn cố định
            packageValue = 5_000_000L,
            paidAmount = 5_000_000L,
            paymentMethod = "TRANSFER",
            transferAmount = 5_000_000L,
            paymentDate = "2026-09-15"
        )
        // - Hợp đồng PT2: khách không tập buổi nào trong tháng 10/2026
        val ptContractNoSessionInOct = com.example.data.model.ContractRecord(
            id = "c_pt_2",
            contractCode = "PT-STT2-001",
            memberId = "m_pt_2",
            memberSttSnapshot = 2L,
            memberNameSnapshot = "Khách PT Nghỉ Tập Tháng 10",
            serviceType = "PT",
            totalSessions = 12L,
            usedSessions = 1L,
            startDate = "2026-09-01",
            packageValue = 6_000_000L,
            paidAmount = 6_000_000L
        )
        // - Hợp đồng PT3: gói 2 buổi, đã tập hết 2 buổi vào tháng 09/2026 -> giả sử có thêm buổi thứ 3 dư thừa trong tháng 10 thì bị chặn trần
        val ptContractCompletedInSept = com.example.data.model.ContractRecord(
            id = "c_pt_3",
            contractCode = "PT-STT3-001",
            memberId = "m_pt_3",
            memberSttSnapshot = 3L,
            memberNameSnapshot = "Khách PT Đã Hết Buổi",
            serviceType = "PT",
            totalSessions = 2L,
            usedSessions = 2L,
            ptStatus = "COMPLETED",
            startDate = "2026-09-01",
            packageValue = 1_000_000L,
            paidAmount = 1_000_000L
        )

        val ptSessions = listOf(
            com.example.data.model.PtSessionRecord(id = "s1", contractId = "c_pt_1", memberId = "m_pt_1", memberSttSnapshot = 1L, memberNameSnapshot = "Khách PT Tích Cực", contractCodeSnapshot = "PT-STT1-001", sessionDate = "2026-10-02", note = "Buổi 1"),
            com.example.data.model.PtSessionRecord(id = "s1", contractId = "c_pt_1", memberId = "m_pt_1", memberSttSnapshot = 1L, memberNameSnapshot = "Khách PT Tích Cực", contractCodeSnapshot = "PT-STT1-001", sessionDate = "2026-10-02", note = "Buổi 1 bản sao trùng ID"),
            com.example.data.model.PtSessionRecord(id = "s2", contractId = "c_pt_1", memberId = "m_pt_1", memberSttSnapshot = 1L, memberNameSnapshot = "Khách PT Tích Cực", contractCodeSnapshot = "PT-STT1-001", sessionDate = "2026-10-10", note = "Buổi 2"),
            com.example.data.model.PtSessionRecord(id = "s3_del", contractId = "c_pt_1", memberId = "m_pt_1", memberSttSnapshot = 1L, memberNameSnapshot = "Khách PT Tích Cực", contractCodeSnapshot = "PT-STT1-001", sessionDate = "2026-10-15", note = "Buổi xóa mềm", isDeleted = true),
            com.example.data.model.PtSessionRecord(id = "s4_sep", contractId = "c_pt_2", memberId = "m_pt_2", memberSttSnapshot = 2L, memberNameSnapshot = "Khách PT Nghỉ Tập Tháng 10", contractCodeSnapshot = "PT-STT2-001", sessionDate = "2026-09-20", note = "Buổi tháng 9"),
            // Hợp đồng PT3 đã tập đủ 2 buổi trong tháng 9:
            com.example.data.model.PtSessionRecord(id = "s5_c3_1", contractId = "c_pt_3", memberId = "m_pt_3", sessionDate = "2026-09-05"),
            com.example.data.model.PtSessionRecord(id = "s5_c3_2", contractId = "c_pt_3", memberId = "m_pt_3", sessionDate = "2026-09-10"),
            com.example.data.model.PtSessionRecord(id = "s5_c3_over", contractId = "c_pt_3", memberId = "m_pt_3", sessionDate = "2026-10-05")
        )

        val summaryOct = FitnessCalculator.computeAllocatedMonthlySummary(
            year = 2026,
            month = 10,
            contracts = listOf(
                oldContractAbc,
                renewalContractAbc,
                outsidePeriodContract,
                softDeletedContract,
                ptContract1,
                ptContractNoSessionInOct,
                ptContractCompletedInSept
            ),
            ptSessions = ptSessions,
            singleTickets = emptyList()
        )

        // Hội viên ABC xuất hiện ở cả 2 báo cáo với đúng doanh thu phân bổ của từng hợp đồng:
        // - HĐ cũ (400.000 * 10 / 40 = 100.000) trong GYM_NEW_AND_ACTIVE
        // - HĐ gia hạn (410.000 * 21 / 41 = 210.000) trong GYM_RENEWAL
        assertEquals(1, summaryOct.gymNewAndActiveItems.size)
        assertEquals("GYM-STT1-001", summaryOct.gymNewAndActiveItems.first().codeOrLabel)
        assertEquals(100_000L, summaryOct.gymNewAndActiveTotal)

        assertEquals(1, summaryOct.gymRenewalItems.size)
        assertEquals("GYM-STT1-002", summaryOct.gymRenewalItems.first().codeOrLabel)
        assertEquals(210_000L, summaryOct.gymRenewalTotal)

        // PT: chỉ tính đúng 2 buổi hoàn thành hợp lệ của PT1 trong tháng 10 (5.000.000 / 10 * 2 * 50% = 500.000)
        assertEquals(1, summaryOct.gymPtItems.size)
        assertEquals("PT-STT1-001", summaryOct.gymPtItems.first().codeOrLabel)
        assertEquals(2L, summaryOct.gymPtItems.first().monthUnits)
        assertEquals(500_000L, summaryOct.gymPtTotal)
        assertEquals(2, summaryOct.ptSessionDetailsInMonth.size)

        // Tổng GYM = 100.000 + 210.000 + 500.000 = 810.000
        assertEquals(810_000L, summaryOct.gymGrandTotal)
    }

    @Test
    fun test13_cashflowReconciliationAndDiscrepancyDetectionWithoutMutatingData() {
        // Kiểm thử Mục 7 (Dòng tiền 1..6):
        // 1. Tiền mặt (300.000)
        // 2. Chuyển khoản (500.000)
        // 3. Kết hợp hợp lệ (TM 200.000 + CK 600.000 = 800.000)
        // 4. Thanh toán trong tháng khác tháng đăng ký (đăng ký tháng 09 nhưng paymentDate tháng 10 -> tính vào dòng tiền tháng 10)
        val validContracts = listOf(
            com.example.data.model.ContractRecord(
                id = "cf_1",
                contractCode = "GYM-STT1-001",
                memberNameSnapshot = "HV Tiền Mặt",
                serviceType = "GYM",
                startDate = "2026-10-01",
                endDate = "2026-10-31",
                packageValue = 300_000L,
                paidAmount = 300_000L,
                paymentMethod = "CASH",
                cashAmount = 300_000L,
                transferAmount = 0L,
                paymentDate = "2026-10-01"
            ),
            com.example.data.model.ContractRecord(
                id = "cf_2",
                contractCode = "YOGA-STT1-001",
                memberNameSnapshot = "HV Chuyển Khoản Khác Tháng ĐK",
                serviceType = "YOGA",
                startDate = "2026-09-25",
                endDate = "2026-10-24",
                packageValue = 500_000L,
                paidAmount = 500_000L,
                paymentMethod = "TRANSFER",
                cashAmount = 0L,
                transferAmount = 500_000L,
                paymentDate = "2026-10-02"
            ),
            com.example.data.model.ContractRecord(
                id = "cf_3",
                contractCode = "PT-STT1-001",
                memberNameSnapshot = "HV Kết Hợp",
                serviceType = "PT",
                totalSessions = 10L,
                startDate = "2026-10-05",
                packageValue = 800_000L,
                paidAmount = 800_000L,
                paymentMethod = "COMBINED",
                cashAmount = 200_000L,
                transferAmount = 600_000L,
                paymentDate = "2026-10-05"
            )
        )
        val validTicket = com.example.data.model.SingleTicketRecord(
            id = "t_1",
            ticketType = "DAILY",
            saleDate = "2026-10-06",
            quantity = 2L,
            unitPrice = 50_000L,
            totalAmount = 100_000L,
            paymentMethod = "CASH",
            cashAmount = 100_000L,
            transferAmount = 0L
        )

        val reconciledCashflow = FitnessCalculator.computeMonthlyCashflow(
            year = 2026,
            month = 10,
            contracts = validContracts,
            singleTickets = listOf(validTicket)
        )

        // Tổng thực thu = 300k + 500k + 800k + 100k = 1.700.000
        // Thực thu TM = 300k + 200k + 100k = 600.000
        // Thực thu CK = 500k + 600k = 1.100.000
        assertEquals(1_700_000L, reconciledCashflow.totalCashflow)
        assertEquals(600_000L, reconciledCashflow.actualCashReceived)
        assertEquals(1_100_000L, reconciledCashflow.actualTransferReceived)
        assertEquals(0L, reconciledCashflow.reconciliationDifference)
        assertTrue(reconciledCashflow.isReconciled)
        assertTrue(reconciledCashflow.discrepancies.isEmpty())

        // Kịch bản phát hiện lệch: Giao dịch COMBINED có paidAmount = 1.000.000 nhưng cashAmount = 300.000, transferAmount = 500.000 (lệch 200.000)
        // Hệ thống KHÔNG được tự ý sửa số liệu gốc mà phải cảnh báo chính xác giao dịch gây lệch!
        val mismatchedContract = com.example.data.model.ContractRecord(
            id = "cf_bad",
            contractCode = "GYM-STT99-001",
            memberNameSnapshot = "HV Dữ Liệu Lệch",
            serviceType = "GYM",
            startDate = "2026-10-10",
            endDate = "2026-11-09",
            packageValue = 1_000_000L,
            paidAmount = 1_000_000L,
            paymentMethod = "COMBINED",
            cashAmount = 300_000L,
            transferAmount = 500_000L,
            paymentDate = "2026-10-10"
        )

        val mismatchedCashflow = FitnessCalculator.computeMonthlyCashflow(
            year = 2026,
            month = 10,
            contracts = validContracts + mismatchedContract,
            singleTickets = listOf(validTicket)
        )

        assertFalse(mismatchedCashflow.isReconciled)
        assertEquals(2_700_000L, mismatchedCashflow.totalCashflow) // Giữ nguyên paidAmount gốc
        assertEquals(900_000L, mismatchedCashflow.actualCashReceived) // Giữ nguyên cashAmount gốc
        assertEquals(1_600_000L, mismatchedCashflow.actualTransferReceived) // Giữ nguyên transferAmount gốc
        assertEquals(200_000L, mismatchedCashflow.reconciliationDifference)
        assertEquals(1, mismatchedCashflow.discrepancies.size)
        assertEquals("c_cf_bad", mismatchedCashflow.discrepancies.first().transactionId)
        assertEquals(200_000L, mismatchedCashflow.discrepancies.first().difference)
    }

    @Test
    fun test14_pdfAndXlsxExportsMultiPageLongNamesAnd100PercentTotalReconciliation() {
        val context = ApplicationProvider.getApplicationContext<Context>()

        // Tạo tập dữ liệu lớn (65 hợp đồng) kèm tên hội viên dài và mã hợp đồng dài để kiểm thử PDF nhiều trang & XLSX
        val longName = "Nguyễn Hoàng Bảo Ngọc Huyền Trân Công Chúa Đại Việt"
        val longCode = "GYM-STT9999-HD0099-VIP-LONG"
        val contracts = (1..65).map { idx ->
            com.example.data.model.ContractRecord(
                id = "c_$idx",
                contractCode = if (idx == 1) longCode else "GYM-STT$idx-001",
                memberId = "m_$idx",
                memberSttSnapshot = idx.toLong(),
                memberNameSnapshot = if (idx == 1) longName else "Hội Viên Kiểm Thử Số $idx",
                serviceType = "GYM",
                isRenewal = idx % 3 == 0,
                startDate = "2026-10-01",
                endDate = "2026-10-31",
                packageValue = 310_000L,
                paidAmount = 310_000L,
                paymentMethod = if (idx % 2 == 0) "TRANSFER" else "CASH",
                cashAmount = if (idx % 2 == 0) 0L else 310_000L,
                transferAmount = if (idx % 2 == 0) 310_000L else 0L,
                paymentDate = "2026-10-05"
            )
        }

        val allocatedSummary = FitnessCalculator.computeAllocatedMonthlySummary(
            year = 2026,
            month = 10,
            contracts = contracts,
            ptSessions = emptyList(),
            singleTickets = emptyList()
        )
        val cashflowSummary = FitnessCalculator.computeMonthlyCashflow(
            year = 2026,
            month = 10,
            contracts = contracts,
            singleTickets = emptyList()
        )

        // 1. Xuất PDF báo cáo ít dòng (1 trang) và báo cáo 65 dòng (nhiều trang)
        val emptyYogaPdf = com.example.domain.ReportExporter.exportSingleAllocatedReportToPdf(
            context = context,
            reportType = com.example.domain.AllocatedReportType.YOGA_TOTAL,
            summary = allocatedSummary
        )
        val yogaPdfMeta = com.example.domain.ReportExporter.getPdfVerification(emptyYogaPdf)!!
        assertTrue(emptyYogaPdf.exists() && emptyYogaPdf.length() > 100L)
        assertEquals(1, yogaPdfMeta.pageCount)
        assertEquals(0L, yogaPdfMeta.grandTotalAmount)

        val multiPageGymPdf = com.example.domain.ReportExporter.exportSingleAllocatedReportToPdf(
            context = context,
            reportType = com.example.domain.AllocatedReportType.GYM_TOTAL,
            summary = allocatedSummary
        )
        val gymPdfMeta = com.example.domain.ReportExporter.getPdfVerification(multiPageGymPdf)!!
        assertTrue(multiPageGymPdf.exists() && multiPageGymPdf.length() > 1000L)
        assertTrue("PDF 65 dòng phải có từ 2 trang trở lên", gymPdfMeta.pageCount >= 2)
        assertEquals(65, gymPdfMeta.dataRowCount)
        assertEquals(allocatedSummary.gymGrandTotal, gymPdfMeta.grandTotalAmount)
        // Kiểm tra không bị cắt mất tên hội viên dài hoặc mã hợp đồng dài
        assertTrue(gymPdfMeta.allRenderedTexts.any { it.contains(longName) })
        assertTrue(gymPdfMeta.allRenderedTexts.contains(longCode))
        assertTrue(gymPdfMeta.allRenderedTexts.contains("Trang 1 / ${gymPdfMeta.pageCount}"))
        assertTrue(gymPdfMeta.allRenderedTexts.contains("Trang ${gymPdfMeta.pageCount} / ${gymPdfMeta.pageCount}"))

        // 2. Xuất XLSX chuẩn OpenXML cho báo cáo Doanh thu phân bổ GYM_TOTAL và kiểm tra cấu trúc + đối chiếu tổng
        val gymXlsx = com.example.domain.ReportExporter.exportSingleAllocatedReportToXlsx(
            context = context,
            reportType = com.example.domain.AllocatedReportType.GYM_TOTAL,
            summary = allocatedSummary
        )
        assertTrue(gymXlsx.exists() && gymXlsx.name.endsWith(".xlsx"))
        val inspectedGymXlsx = com.example.domain.XlsxWorkbookWriter.inspectWorkbook(gymXlsx)
        assertTrue(inspectedGymXlsx.entryNames.contains("[Content_Types].xml"))
        assertTrue(inspectedGymXlsx.entryNames.contains("xl/workbook.xml"))
        assertTrue(inspectedGymXlsx.entryNames.contains("xl/styles.xml"))
        assertEquals(listOf("Tổng quan", "Chi tiết hợp đồng", "Đối chiếu"), inspectedGymXlsx.sheetNames)

        val detailSheet = inspectedGymXlsx.sheets[1]
        assertTrue(detailSheet.textValues.contains(longName))
        assertTrue(detailSheet.textValues.contains(longCode))
        assertTrue(detailSheet.formulas.any { it.startsWith("SUM(J") })
        assertTrue(detailSheet.numericValues.contains(allocatedSummary.gymGrandTotal))
        // Đối chiếu 3 bên: App == PDF == XLSX
        assertEquals(allocatedSummary.gymGrandTotal, gymPdfMeta.grandTotalAmount)
        assertTrue(inspectedGymXlsx.sheets[2].textValues.contains("KHỚP ĐÚNG 100%"))

        // 3. Xuất PDF & XLSX cho Báo cáo Dòng tiền tháng và đối chiếu 3 bên
        val cashflowPdf = com.example.domain.ReportExporter.exportMonthlyCashflowToPdf(context, cashflowSummary)
        val cashflowPdfMeta = com.example.domain.ReportExporter.getPdfVerification(cashflowPdf)!!
        val cashflowXlsx = com.example.domain.ReportExporter.exportMonthlyCashflowToXlsx(context, cashflowSummary)
        val inspectedCashflowXlsx = com.example.domain.XlsxWorkbookWriter.inspectWorkbook(cashflowXlsx)

        assertEquals(listOf("Tổng quan", "Chi tiết giao dịch", "Đối chiếu TM & CK"), inspectedCashflowXlsx.sheetNames)
        assertEquals(cashflowSummary.totalCashflow, cashflowPdfMeta.grandTotalAmount)
        assertTrue(inspectedCashflowXlsx.sheets[0].numericValues.contains(cashflowSummary.totalCashflow))
        assertTrue(inspectedCashflowXlsx.sheets[1].numericValues.contains(cashflowSummary.actualCashReceived))
        assertTrue(inspectedCashflowXlsx.sheets[1].numericValues.contains(cashflowSummary.actualTransferReceived))

        // 4. Xuất XLSX cho PT và Vé lẻ để xác minh cấu trúc Sheet đặc thù
        val ptXlsx = com.example.domain.ReportExporter.exportSingleAllocatedReportToXlsx(
            context = context,
            reportType = com.example.domain.AllocatedReportType.GYM_PT,
            summary = allocatedSummary
        )
        assertEquals(
            listOf("Tổng quan", "Phân bổ theo HĐ PT", "Chi tiết buổi tập"),
            com.example.domain.XlsxWorkbookWriter.inspectWorkbook(ptXlsx).sheetNames
        )

        val ticketXlsx = com.example.domain.ReportExporter.exportSingleAllocatedReportToXlsx(
            context = context,
            reportType = com.example.domain.AllocatedReportType.GYM_SINGLE_TICKET,
            summary = allocatedSummary
        )
        assertEquals(
            listOf("Tổng quan", "Chi tiết vé lẻ"),
            com.example.domain.XlsxWorkbookWriter.inspectWorkbook(ticketXlsx).sheetNames
        )
    }
}



