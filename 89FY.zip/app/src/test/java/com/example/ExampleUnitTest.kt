package com.example

import com.example.domain.DateCalculator
import com.example.domain.RevenueAllocationEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Comprehensive Unit Tests verifying all mandatory financial & business rules in the
 * 89 FITNESS & YOGA PRD and Section 12 of the Upgrade PRD.
 */
class ExampleUnitTest {

    /**
     * Mandatory Test Case from PRD Section 9.3:
     * Contract 1:
     * - Value: 800,000 VND, 3 months, 15/07/2026 -> 15/10/2026 (92 days)
     * - Effective days in Oct 2026: 14 days -> 121,739 VND
     * Contract 2:
     * - Value: 300,000 VND, 1 month, 20/10/2026 -> 20/11/2026 (31 days)
     * - Effective days in Oct 2026: 12 days -> 116,129 VND
     * Total Allocated Revenue Oct 2026 = 237,868 VND.
     */
    @Test
    fun mandatoryOctober2026RevenueAllocationTest() {
        val c1End = DateCalculator.calculateEndDate("2026-07-15", 3)
        assertEquals("2026-10-15", c1End)
        assertEquals(92, DateCalculator.daysBetween("2026-07-15", c1End))

        val c2End = DateCalculator.calculateEndDate("2026-10-20", 1)
        assertEquals("2026-11-20", c2End)
        assertEquals(31, DateCalculator.daysBetween("2026-10-20", c2End))

        val c1 = RevenueAllocationEngine.ContractAllocationInput(
            contractId = "c1",
            contractCode = "HDG-001",
            memberId = "m1",
            memberName = "Nguyễn Văn A",
            durationMonths = 3,
            startDateIso = "2026-07-15",
            endDateIso = c1End,
            agreedValueVnd = 800_000L,
            isRenewal = false
        )

        val c2 = RevenueAllocationEngine.ContractAllocationInput(
            contractId = "c2",
            contractCode = "HDG-002",
            memberId = "m1",
            memberName = "Nguyễn Văn A",
            durationMonths = 1,
            startDateIso = "2026-10-20",
            endDateIso = c2End,
            agreedValueVnd = 300_000L,
            isRenewal = true
        )

        val (rows, totalOct2026) = RevenueAllocationEngine.calculateMonthlyContractReport(
            contracts = listOf(c1, c2),
            year = 2026,
            month = 10
        )

        assertEquals(2, rows.size)
        assertEquals(14, rows[0].effectiveDaysInMonth)
        assertEquals(121_739L, rows[0].allocatedRevenueVnd)
        assertEquals(12, rows[1].effectiveDaysInMonth)
        assertEquals(116_129L, rows[1].allocatedRevenueVnd)
        assertEquals(237_868L, totalOct2026)
    }

    /**
     * Section 12.1: Tests 28-day month, 29-day leap year month, 30-day month, 31-day month,
     * month transition, and year transition.
     */
    @Test
    fun contractDatesAcross28_29_30_31DaysAndYearRolloverTest() {
        // 28-day month (Feb 2026 non-leap year)
        assertEquals("2026-02-28", DateCalculator.calculateEndDate("2026-01-31", 1))
        assertEquals(28, DateCalculator.daysBetween("2026-01-31", "2026-02-28"))

        // 29-day month (Feb 2028 leap year)
        assertEquals("2028-02-29", DateCalculator.calculateEndDate("2028-01-31", 1))
        assertEquals(29, DateCalculator.daysBetween("2028-01-31", "2028-02-29"))

        // 30-day month (March 31 -> April 30)
        assertEquals("2026-04-30", DateCalculator.calculateEndDate("2026-03-31", 1))
        assertEquals(30, DateCalculator.daysBetween("2026-03-31", "2026-04-30"))

        // 31-day month (May 10 -> June 10 = 31 days)
        assertEquals("2026-06-10", DateCalculator.calculateEndDate("2026-05-10", 1))
        assertEquals(31, DateCalculator.daysBetween("2026-05-10", "2026-06-10"))

        // Year rollover (15/11/2026 + 3 months -> 15/02/2027)
        assertEquals("2027-02-15", DateCalculator.calculateEndDate("2026-11-15", 3))
        // 12-month package (01/01/2026 + 12 months -> 01/01/2027 = 365 days)
        assertEquals("2027-01-01", DateCalculator.calculateEndDate("2026-01-01", 12))
        assertEquals(365, DateCalculator.daysBetween("2026-01-01", "2027-01-01"))
    }

    /**
     * Section 12.1: Verifies early, on-time, and late renewal start date rules.
     */
    @Test
    fun renewalStartDateRulesTest() {
        val oldEnd = "2026-02-15"
        // Early renewal -> starts on old end date
        assertEquals("2026-02-15", DateCalculator.calculateRenewalStartDate(oldEnd, "2026-02-10"))
        // On-time renewal -> starts on old end date
        assertEquals("2026-02-15", DateCalculator.calculateRenewalStartDate(oldEnd, "2026-02-15"))
        // Late renewal -> starts on actual renewal date
        assertEquals("2026-02-20", DateCalculator.calculateRenewalStartDate(oldEnd, "2026-02-20"))
    }

    /**
     * Section 12.1 & Confirmed Decision 2:
     * When the user manually edits the end date, changing the start date preserves the manual end date,
     * and effective days + revenue allocation automatically update from the current startDateIso and endDateIso.
     */
    @Test
    fun manualEndDatePreservationAndEffectiveDaysUpdateTest() {
        val manualEndDate = "2026-11-30"
        val initialStartDate = "2026-11-01"
        assertEquals(29, DateCalculator.daysBetween(initialStartDate, manualEndDate))

        // User changes startDate to 2026-11-05 while manualEndDate is preserved as 2026-11-30
        val updatedStartDate = "2026-11-05"
        val updatedEffectiveDays = DateCalculator.daysBetween(updatedStartDate, manualEndDate)
        assertEquals(25, updatedEffectiveDays)

        val row = RevenueAllocationEngine.allocateContractForMonth(
            input = RevenueAllocationEngine.ContractAllocationInput(
                contractId = "c_manual",
                contractCode = "HDG-099",
                memberId = "m99",
                memberName = "Lê Thị B",
                durationMonths = 1,
                startDateIso = updatedStartDate,
                endDateIso = manualEndDate,
                agreedValueVnd = 300_000L,
                isRenewal = false
            ),
            year = 2026,
            month = 11
        )
        assertEquals(25, row?.totalEffectiveDays)
        assertEquals(25, row?.effectiveDaysInMonth)
        assertEquals(300_000L, row?.allocatedRevenueVnd)
    }

    /**
     * Section 12.3: Verifies contract cancellation & refund revenue adjustment:
     * Only the retained amount (agreedValue - refundedAmount) is allocated up to cancelledDateIso,
     * and subsequent months receive 0 allocated revenue.
     */
    @Test
    fun cancelledContractRefundStopsSubsequentMonthsRevenueTest() {
        val cancelledContract = RevenueAllocationEngine.ContractAllocationInput(
            contractId = "c_cancel",
            contractCode = "HDG-050",
            memberId = "m50",
            memberName = "Phạm Văn C",
            durationMonths = 3,
            startDateIso = "2026-07-01",
            endDateIso = "2026-10-01",
            agreedValueVnd = 750_000L,
            isRenewal = false,
            isCancelled = true,
            cancelledDateIso = "2026-07-16", // Active 15 days in July (01/07..15/07)
            refundedAmountVnd = 500_000L // Retained = 250,000 VND
        )

        val julyRow = RevenueAllocationEngine.allocateContractForMonth(cancelledContract, 2026, 7)
        assertEquals(250_000L, julyRow?.allocatedRevenueVnd)

        // August & September must be stopped (null / 0 VND)
        val augustRow = RevenueAllocationEngine.allocateContractForMonth(cancelledContract, 2026, 8)
        assertNull(augustRow)
        val septRow = RevenueAllocationEngine.allocateContractForMonth(cancelledContract, 2026, 9)
        assertNull(septRow)
    }

    /**
     * Section 12.4: Verifies PT 50% Gym share calculation based on actual sessions in month.
     */
    @Test
    fun ptRevenueFiftyPercentGymShareTest() {
        val ptInput = RevenueAllocationEngine.PtAllocationInput(
            ptContractId = "pt1",
            contractCode = "HDP-001",
            clientName = "Trần Văn PT",
            registerDateIso = "2026-10-01",
            totalSessions = 10,
            agreedValueVnd = 5_000_000L, // 50% Gym share = 2,500,000 VND -> 250,000 VND/session
            sessionsInTargetMonth = 4
        )
        val row = RevenueAllocationEngine.allocatePtForMonth(ptInput)
        assertEquals(1_000_000L, row?.gymAllocatedRevenueVnd)
        assertTrue((row?.gymAllocatedRevenueVnd ?: 0L) == 1_000_000L)
    }
}
