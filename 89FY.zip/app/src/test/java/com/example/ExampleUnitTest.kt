package com.example

import com.example.domain.DateCalculator
import com.example.domain.RevenueAllocationEngine
import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * Unit tests verifying all mandatory financial & business rules in the 89 FITNESS & YOGA PRD.
 */
class ExampleUnitTest {

    /**
     * Mandatory Test Case from PRD Section 9.3:
     * Contract 1:
     * - Value: 800,000 VND
     * - Duration: 3 months
     * - Start Date: 15/07/2026 ("2026-07-15")
     * - End Date: 15/10/2026 ("2026-10-15")
     * - Total effective days: 92 days
     * - Effective days in Oct 2026: 14 days (01/10..14/10)
     * - Allocated Oct 2026: 800,000 / 92 * 14 = 121,739.13 -> 121,739 VND
     *
     * Contract 2:
     * - Value: 300,000 VND
     * - Duration: 1 month
     * - Start Date: 20/10/2026 ("2026-10-20")
     * - End Date: 20/11/2026 ("2026-11-20")
     * - Total effective days: 31 days
     * - Effective days in Oct 2026: 12 days (20/10..31/10)
     * - Allocated Oct 2026: 300,000 / 31 * 12 = 116,129.03 -> 116,129 VND
     *
     * Total Allocated Revenue Oct 2026 = 121,739 + 116,129 = 237,868 VND.
     */
    @Test
    fun mandatoryOctober2026RevenueAllocationTest() {
        val c1End = DateCalculator.calculateEndDate("2026-07-15", 3)
        assertEquals("2026-10-15", c1End)
        assertEquals(92, DateCalculator.daysBetween("2026-07-15", c1End))

        val c2End = DateCalculator.calculateEndDate("2026-10-20", 1)
        assertEquals("2026-11-20", c2End)
        assertEquals(31, DateCalculator.daysBetween("2026-10-20", c2End))

        val c1 = RevenueAllocationEngine.ContractAllocationInput(
            contractId = "c1",
            contractCode = "HDG-001",
            memberId = "m1",
            memberName = "Nguyễn Văn A",
            durationMonths = 3,
            startDateIso = "2026-07-15",
            endDateIso = c1End,
            agreedValueVnd = 800_000L,
            isRenewal = false
        )

        val c2 = RevenueAllocationEngine.ContractAllocationInput(
            contractId = "c2",
            contractCode = "HDG-002",
            memberId = "m1",
            memberName = "Nguyễn Văn A",
            durationMonths = 1,
            startDateIso = "2026-10-20",
            endDateIso = c2End,
            agreedValueVnd = 300_000L,
            isRenewal = true
        )

        val (rows, totalOct2026) = RevenueAllocationEngine.calculateMonthlyContractReport(
            contracts = listOf(c1, c2),
            year = 2026,
            month = 10
        )

        assertEquals(2, rows.size)
        assertEquals(14, rows[0].effectiveDaysInMonth)
        assertEquals(121_739L, rows[0].allocatedRevenueVnd)
        assertEquals(12, rows[1].effectiveDaysInMonth)
        assertEquals(116_129L, rows[1].allocatedRevenueVnd)
        assertEquals(237_868L, totalOct2026)
    }

    /**
     * Verifies renewal rules (Section 5.4):
     * Old contract expires on 15/02/2026.
     * - Renew on 10/02/2026 (early): starts on 15/02/2026
     * - Renew on 15/02/2026 (on-time): starts on 15/02/2026
     * - Renew on 20/02/2026 (late): starts on 20/02/2026
     */
    @Test
    fun renewalStartDateRulesTest() {
        val oldEnd = "2026-02-15"
        assertEquals("2026-02-15", DateCalculator.calculateRenewalStartDate(oldEnd, "2026-02-10"))
        assertEquals("2026-02-15", DateCalculator.calculateRenewalStartDate(oldEnd, "2026-02-15"))
        assertEquals("2026-02-20", DateCalculator.calculateRenewalStartDate(oldEnd, "2026-02-20"))
    }

    /**
     * Verifies end-of-month clamping (29, 30, 31) and contract freeze day addition.
     */
    @Test
    fun endOfMonthClampingAndFreezeTest() {
        // 31/01/2026 + 1 month -> 28/02/2026 (non-leap year)
        assertEquals("2026-02-28", DateCalculator.calculateEndDate("2026-01-31", 1))
        // 31/01/2028 + 1 month -> 29/02/2028 (leap year)
        assertEquals("2028-02-29", DateCalculator.calculateEndDate("2028-01-31", 1))
        // With 5 frozen days added to 15/02/2026 -> 20/02/2026
        assertEquals("2026-02-20", DateCalculator.calculateEndDate("2026-01-15", 1, extraFrozenDays = 5))
    }

    /**
     * Verifies PT 50% Gym share calculation based on actual sessions in month (Section 6.5).
     */
    @Test
    fun ptRevenueFiftyPercentGymShareTest() {
        val ptInput = RevenueAllocationEngine.PtAllocationInput(
            ptContractId = "pt1",
            contractCode = "HDP-001",
            clientName = "Trần Văn PT",
            registerDateIso = "2026-10-01",
            totalSessions = 10,
            agreedValueVnd = 5_000_000L, // 50% Gym share = 2,500,000 VND -> 250,000 VND/session
            sessionsInTargetMonth = 4
        )
        val row = RevenueAllocationEngine.allocatePtForMonth(ptInput)
        assertEquals(1_000_000L, row?.gymAllocatedRevenueVnd)
    }
}
