package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.domain.FitnessCalculator
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class FitnessRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun createMemberAndContract_authenticatedOwner_succeedsAndEmitsInFlow() = runBlocking {
        signInTestUser(ALICE_EMAIL)
        val repo = FitnessRepository(firestore)

        val result = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.createMemberWithInitialContract(
                serviceType = "GYM",
                fullName = "Nguyễn Văn Hùng",
                phone = "0909123456",
                memberGroup = "NAM",
                durationMonths = 1L,
                startDate = "2026-10-15",
                endDate = FitnessCalculator.calculateEndDate("2026-10-15", 1),
                totalSessions = 0L,
                packageValue = 300_000L,
                paidAmount = 300_000L,
                paymentMethod = "TRANSFER",
                cashAmount = 0L,
                transferAmount = 300_000L,
                paymentDate = "2026-10-15"
            )
        }
        assertTrue("Expected success, got ${result.exceptionOrNull()}", result.isSuccess)
        val (member, contract) = result.getOrThrow()
        assertTrue(contract.contractCode.startsWith("GYM-STT"))

        val emittedMembers = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observeMembers().first { list -> list.any { it.id == member.id } }
        }
        assertTrue(emittedMembers.any { it.id == member.id && it.fullName == "Nguyễn Văn Hùng" })
    }

    @Test
    fun getMemberById_crossUserAccess_failsWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val aliceRepo = FitnessRepository(firestore)
        val (member, _) = withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.createMemberWithInitialContract(
                serviceType = "YOGA",
                fullName = "Trần Thị Mai",
                phone = "0912345678",
                memberGroup = "NONE",
                durationMonths = 1L,
                startDate = "2026-11-01",
                endDate = "2026-11-30",
                totalSessions = 0L,
                packageValue = 500_000L,
                paidAmount = 500_000L,
                paymentMethod = "TRANSFER",
                cashAmount = 0L,
                transferAmount = 500_000L,
                paymentDate = "2026-11-01"
            ).getOrThrow()
        }

        signInTestUser(BOB_EMAIL)
        try {
            withTimeout(DEFAULT_TIMEOUT_MS) {
                firestore.collection("users").document(aliceUid)
                    .collection("members").document(member.id)
                    .get().await()
            }
            fail("Expected FirebaseFirestoreException PERMISSION_DENIED for cross-user access")
        } catch (e: Exception) {
            val fsEx = e.unwrapFirestoreException()
            assertNotNull("Expected FirebaseFirestoreException, got $e", fsEx)
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx?.code)
        }
    }

    @Test
    fun observeMembers_unauthenticatedUser_fails() = runBlocking {
        auth.signOut()
        val repo = FitnessRepository(firestore)
        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repo.observeMembers().first()
            }
            fail("Expected unauthenticated access to fail")
        } catch (e: Exception) {
            assertTrue(e is IllegalStateException || e.unwrapFirestoreException()?.code == FirebaseFirestoreException.Code.PERMISSION_DENIED)
        }
    }

    private companion object {
        const val ALICE_EMAIL = "alice@fitness89.test"
        const val BOB_EMAIL = "bob@fitness89.test"
        const val DEFAULT_TIMEOUT_MS = 8000L
        const val FLOW_TIMEOUT_MS = 5000L
    }
}
