const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user cannot read or write members", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).collection("members").get()
  );
});

test("Authenticated owner can create and read valid MemberProfile", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date();
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("members").doc("mem_1").set({
      userId: ALICE_UID,
      type: "GYM",
      stt: 1,
      fullName: "Nguyen Van A",
      phone: "0901234567",
      memberGroup: "NAM",
      nextContractSeq: 2,
      isDeleted: false,
      deletedAtEpoch: 0,
      deletedBatchId: "",
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("members").where("userId", "==", ALICE_UID).get()
  );
});

test("Authenticated user cannot read or write another user's MemberProfile", async () => {
  const now = new Date();
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await ctx.firestore().collection("users").doc(BOB_UID).collection("members").doc("mem_bob").set({
      userId: BOB_UID,
      type: "YOGA",
      stt: 1,
      fullName: "Tran Thi B",
      phone: "0912345678",
      memberGroup: "NONE",
      nextContractSeq: 1,
      isDeleted: false,
      deletedAtEpoch: 0,
      deletedBatchId: "",
      createdAt: now,
      updatedAt: now,
    });
  });

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(
    aliceDb.collection("users").doc(BOB_UID).collection("members").doc("mem_bob").get()
  );
});

test("Shadow update with ghost field or stt mutation is rejected", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date();
  const ref = aliceDb.collection("users").doc(ALICE_UID).collection("members").doc("mem_1");
  await assertSucceeds(
    ref.set({
      userId: ALICE_UID,
      type: "GYM",
      stt: 1,
      fullName: "Nguyen Van A",
      phone: "0901234567",
      memberGroup: "NAM",
      nextContractSeq: 1,
      isDeleted: false,
      deletedAtEpoch: 0,
      deletedBatchId: "",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Ghost field rejected
  await assertFails(
    ref.update({
      fullName: "Nguyen Van A Updated",
      ghostField: true,
      updatedAt: now,
    })
  );

  // Immutable stt rejected
  await assertFails(
    ref.update({
      stt: 99,
      updatedAt: now,
    })
  );
});
