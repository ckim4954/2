# 01 — Tổng quan ứng dụng

## 1. Tám menu chính
1. GYM
2. YOGA
3. TẠO HỢP ĐỒNG
4. DOANH THU
5. THEO DÕI HỘI VIÊN
6. QUẢN LÍ PT
7. CÀI ĐẶT
8. THÙNG RÁC

```mermaid
flowchart TD
 H["89 FITNESS & YOGA"] --> G["1. GYM"]
 H --> Y["2. YOGA"]
 H --> C["3. TẠO HỢP ĐỒNG"]
 H --> R["4. DOANH THU"]
 H --> T["5. THEO DÕI HỘI VIÊN"]
 H --> P["6. QUẢN LÍ PT"]
 H --> S["7. CÀI ĐẶT"]
 H --> X["8. THÙNG RÁC"]
```

## 2. Giao diện và quy tắc chung
- Giao diện nhất quán, gọn, dễ đọc, tối ưu điện thoại; GYM xanh lá, YOGA tím.
- Tên hội viên phải hiển thị đầy đủ, không cắt cụt.
- Tìm kiếm, lọc, sắp xếp, xuất báo cáo không sửa dữ liệu gốc.
- Trường ngày dùng date picker/lịch ngày-tháng-năm.
- Dữ liệu đã tạo có thể chỉnh sửa phù hợp. Khi thêm mới/chỉnh sửa phải có bước xem lại và xác nhận trước khi lưu.
- Xóa phải xác nhận và chuyển vào Thùng rác. Chỉ xóa vĩnh viễn trong Thùng rác, cũng phải xác nhận.
- Thanh toán: tiền mặt, chuyển khoản, kết hợp; mặc định chuyển khoản. Kết hợp phải lưu riêng hai khoản và kiểm tra tổng bằng số tiền thanh toán.
- Hợp đồng cũ giữ nguyên dữ liệu tại thời điểm tạo; thay đổi bảng giá không làm thay đổi hợp đồng cũ.

## 3. Hồ sơ và STT
- GYM, YOGA, PT có dãy STT độc lập, tự tăng.
- Một người có thể có hồ sơ GYM, YOGA, PT riêng; mỗi loại có STT riêng.
- Gia hạn không tạo hồ sơ mới, không đổi STT; tạo hợp đồng mới.
- Hợp đồng liên kết với ID hồ sơ ổn định, không chỉ dựa vào tên.
- Lọc/sắp xếp/xóa mềm/khôi phục không được làm thay đổi STT.

## 4. Mã hợp đồng
Cấu trúc: `<LOẠI>-STT<n>-<số thứ tự hợp đồng của hồ sơ>`.
Ví dụ: `GYM-STT100-001`, `GYM-STT100-002`, `YOGA-STT88-001`, `PT-STT10-001`.
Mã hợp đồng bất biến. Mỗi lần gia hạn tăng số thứ tự hợp đồng.

## 5. Bảng giá đã chốt

### GYM
| Nhóm | 1 tháng | 2 tháng | 3 tháng | 12 tháng |
|---|---:|---:|---:|---:|
| Nam | 300.000 | 550.000 | 800.000 | 3.000.000 |
| Nữ | 250.000 | 450.000 | 700.000 | 2.800.000 |
| Trẻ em | 300.000 | 500.000 | 700.000 | 2.500.000 |

### YOGA
| Thời hạn | Giá |
|---|---:|
| 1 tháng | 500.000 |
| 2 tháng | 1.000.000 |
| 3 tháng | 1.500.000 |

Đơn vị giá: VND. PT không có bảng giá cố định đã cung cấp; giá trị gói PT do người dùng nhập.

## 6. Dữ liệu cơ bản
Hồ sơ GYM/YOGA/PT: STT, họ tên, số điện thoại.
Hợp đồng GYM/YOGA: gói, ngày đăng ký, ngày hết hạn, giá trị gói, số tiền thanh toán, doanh thu phân bổ tháng, phương thức thanh toán, số tiền mặt/chuyển khoản nếu kết hợp.
Hợp đồng PT: số buổi tùy chỉnh, giá trị gói, ngày đăng ký, số tiền thanh toán, phương thức thanh toán; không có ngày hết hạn cố định theo tháng.

## 7. Phạm vi chưa xác định
Hoàn tiền, hủy hợp đồng, công nợ, chi phí, làm tròn số phân bổ, xung đột đồng bộ nhiều thiết bị và một số quy tắc kiểm toán chưa được chốt. Không tự thêm.
