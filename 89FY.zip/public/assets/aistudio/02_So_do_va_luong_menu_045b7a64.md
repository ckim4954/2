# 02 — Sơ đồ và luồng 8 menu

# MENU 1 — GYM
Mục đích: quản lý mọi hồ sơ GYM từng đăng ký, còn hạn và hết hạn. Tổng số là số hồ sơ, không phải số hợp đồng.

Màn hình:
- Tiêu đề GYM, tổng số hồ sơ, xuất Excel/PDF.
- Tìm kiếm một dòng theo STT/tên/điện thoại.
- Nút mũi tên mở tùy chọn, nút thêm (+).
- Thẻ: trên trái `STT — Họ tên`; trên phải số ngày còn/quá hạn; dưới trái ngày hết hạn; dưới phải nút Gia hạn.
- Còn hạn xanh; hết hạn/hết hạn hôm nay đỏ; tên đầy đủ, không cắt.

Năm nhóm tùy chọn:
1. Sắp xếp hội viên.
2. Lọc theo thời hạn.
3. Lọc theo nhóm hội viên.
4. Lọc theo ngày đăng ký.
5. Tùy chọn hiển thị.

Sắp xếp: STT tăng/giảm; tên A–Z/Z–A; ngày đăng ký mới nhất/cũ nhất; ngày hết hạn gần nhất/xa nhất; còn hạn trước/hết hạn trước.
Lọc thời hạn: tất cả, còn hạn, hết hạn, hết hạn hôm nay, sắp hết hạn.
Lọc nhóm: tất cả, nam, nữ, trẻ em.
Lọc ngày đăng ký: hôm nay, 7 ngày gần nhất, 30 ngày gần nhất, tháng này, khoảng ngày tùy chọn.
Tùy chọn hiển thị chỉ đổi phần nhìn, không sửa dữ liệu.

Chi tiết hội viên gồm thông tin cá nhân; hợp đồng hiện tại; lịch sử hợp đồng. Mở hợp đồng lịch sử phải xem đúng dữ liệu của hợp đồng đó: mã, STT, tên, điện thoại, gói, ngày đăng ký/hết hạn, giá trị, số tiền thanh toán, doanh thu phân bổ, phương thức và tách tiền mặt/chuyển khoản nếu kết hợp. Gia hạn tạo hợp đồng mới, không ghi đè.

```mermaid
flowchart TD
 A["Trang chủ"] --> B["GYM"]
 B --> C["Danh sách mọi hồ sơ"]
 C --> D["Tìm kiếm / Sắp xếp / Lọc"]
 C --> E["Thêm hội viên"]
 C --> F["Chọn hội viên"]
 C --> G["Gia hạn"]
 F --> H["Chi tiết hội viên"]
 H --> I["Thông tin cá nhân"]
 H --> J["Hợp đồng hiện tại"]
 H --> K["Lịch sử hợp đồng"]
 K --> L["Chi tiết hợp đồng"]
 G --> M["Tạo hợp đồng gia hạn mới"]
```

# MENU 2 — YOGA
Cấu trúc như GYM, màu tím, STT riêng, tìm kiếm, xuất Excel/PDF, thẻ hội viên, chi tiết, hợp đồng hiện tại và lịch sử. Không có lọc nhóm nam/nữ/trẻ em. Danh sách gồm mọi hồ sơ từng đăng ký.

```mermaid
flowchart TD
 A["Trang chủ"] --> B["YOGA"]
 B --> C["Danh sách hồ sơ YOGA"]
 C --> D["Tìm kiếm / Sắp xếp / Lọc"]
 C --> E["Thêm hội viên"]
 C --> F["Chọn hội viên"]
 F --> G["Chi tiết: hồ sơ / hợp đồng hiện tại / lịch sử"]
 C --> H["Gia hạn: tạo hợp đồng mới, giữ STT"]
```

# MENU 3 — TẠO HỢP ĐỒNG
Có đúng 4 lựa chọn: GYM, YOGA, PT, VÉ LẺ. Không tách thành hai ô “đăng ký mới” và “gia hạn”. Tìm kiếm trước, hệ thống nhận diện hồ sơ mới/cũ.

## GYM
Không hiển thị danh sách mặc định. Tìm theo STT/tên/điện thoại. Nếu có hồ sơ: hiện thông tin và lịch sử, người dùng chọn gia hạn; giữ hồ sơ/STT, tạo hợp đồng mới. Nếu không có: tạo hồ sơ mới, cấp STT GYM tiếp theo, tạo hợp đồng đầu tiên. Form gồm hồ sơ, nhóm giá, gói, ngày đăng ký/hết hạn, giá trị gói, số tiền thanh toán, doanh thu phân bổ, thanh toán. Ngày dùng date picker. Xác nhận trước lưu.

```mermaid
flowchart TD
 A["Tạo hợp đồng"] --> B["GYM"] --> C["Tìm kiếm"]
 C --> D{"Có hồ sơ?"}
 D -->|Có| E["Hiện hồ sơ và lịch sử"] --> F["Gia hạn: giữ STT, tạo hợp đồng mới"]
 D -->|Không| G["Tạo hồ sơ + hợp đồng đầu tiên"] --> H["Cấp STT mới"]
 F --> I["Kiểm tra và xác nhận"]
 H --> I --> J["Lưu"]
```

## YOGA
Tương tự GYM: tìm kiếm trước, không có danh sách mặc định; hồ sơ cũ giữ STT và tạo hợp đồng mới; hồ sơ mới được cấp STT YOGA; giá dùng bảng YOGA 1/2/3 tháng; xác nhận trước lưu.

## PT
Tìm hồ sơ hoặc tạo mới, cấp STT PT. Hợp đồng gồm số buổi tùy chỉnh, giá trị gói, ngày đăng ký, số tiền thanh toán, phương thức thanh toán; không có hạn tháng cố định. Mỗi hội viên chỉ có tối đa một hợp đồng PT đang hiệu lực tại một thời điểm. Gia hạn giữ hồ sơ/STT, tạo hợp đồng mới.

```mermaid
flowchart TD
 A["Tạo hợp đồng PT"] --> B["Tìm hồ sơ PT"]
 B --> C{"Đã có hồ sơ?"}
 C -->|Không| D["Tạo hồ sơ, cấp STT PT"]
 C -->|Có| E["Mở hồ sơ"]
 D --> F["Nhập gói buổi và giá trị"]
 E --> G{"Có hợp đồng đang hiệu lực?"}
 G -->|Có| H["Không tạo hợp đồng song song"]
 G -->|Không| F
 F --> I["Xem lại và xác nhận"] --> J["Lưu hợp đồng"]
```

## VÉ LẺ
Chọn vé ngày/tuần; ngày bán; số lượng mặc định 1 với nút +/-; đơn giá; tổng tự tính; phương thức thanh toán; lưu. Tổng = số lượng × đơn giá. Không tạo hồ sơ, STT hoặc lịch sử hợp đồng khách hàng.

# MENU 4 — DOANH THU
Có đúng 3 nhánh: DOANH THU PHÂN BỔ; DOANH THU DÒNG TIỀN THÁNG; XUẤT BÁO CÁO.

## Doanh thu phân bổ — 8 báo cáo
GYM có 5:
1. Doanh thu phân bổ GYM — Còn hạn và đăng ký mới.
2. Doanh thu phân bổ GYM — Gia hạn.
3. Doanh thu phân bổ GYM — PT.
4. Doanh thu phân bổ GYM — Vé lẻ.
5. Tổng doanh thu phân bổ GYM.

YOGA có 3:
1. Doanh thu phân bổ YOGA — Còn hạn và đăng ký mới.
2. Doanh thu phân bổ YOGA — Gia hạn.
3. Tổng doanh thu phân bổ YOGA.

Tổng GYM = GYM còn hạn/đăng ký mới + GYM gia hạn + PT phần phòng tập + vé lẻ.
Tổng YOGA = YOGA còn hạn/đăng ký mới + YOGA gia hạn.
Chọn tháng/năm báo cáo. Phân loại theo từng hợp đồng, không theo trạng thái hiện tại của hồ sơ. Một hội viên có thể có hợp đồng ở nhiều nhóm theo thời gian; mỗi hợp đồng chỉ thuộc đúng một nhóm.

```mermaid
flowchart TD
 A["Doanh thu"] --> B["Doanh thu phân bổ"] --> C["Chọn tháng/năm"]
 C --> D["GYM: 4 báo cáo thành phần + tổng"]
 C --> E["YOGA: 2 báo cáo thành phần + tổng"]
```

## Doanh thu dòng tiền tháng
Là tiền thực nhận trong tháng, theo ngày thực nhận, không phải doanh thu phân bổ. Chọn tháng/năm; xem tổng tiền nhận; phân loại GYM/YOGA/PT/vé lẻ; phân loại tiền mặt/chuyển khoản/kết hợp; xem giao dịch chi tiết. Không đếm trùng. Chưa yêu cầu quản lý chi phí, công nợ, phải thu hoặc hoàn tiền.

## Xuất báo cáo
Đúng 8 báo cáo nêu trên. Người dùng chọn một báo cáo riêng, chọn tháng/năm, rồi chọn một trong ba thao tác riêng: PDF, Excel, Chia sẻ nhanh. Chia sẻ mở Android Share Sheet (Zalo, Gmail...). Chỉ chia sẻ báo cáo đã chọn, không có một nút xuất cả 8 báo cáo.

```mermaid
flowchart TD
 A["Doanh thu"] --> B["Xuất báo cáo"] --> C["Chọn 1 trong 8 báo cáo"]
 C --> D["Chọn tháng/năm"]
 D --> E["PDF"]
 D --> F["Excel"]
 D --> G["Chia sẻ nhanh"] --> H["Android Share Sheet"]
```

# MENU 5 — THEO DÕI HỘI VIÊN
Phải chọn GYM hoặc YOGA trước. Sau đó chỉ có 3 loại danh sách: người còn hạn; người hết hạn; sắp hết hạn trong 7 ngày. Chỉ tạo danh sách sau khi chọn loại; không tự sinh khi mở menu; không có danh sách tất cả; có tìm kiếm trong danh sách đã tạo. Đã bỏ công nợ.

```mermaid
flowchart TD
 A["Theo dõi hội viên"] --> B["Chọn loại thẻ"]
 B --> C["GYM"]
 B --> D["YOGA"]
 C --> E["Chọn một loại danh sách"]
 D --> E
 E --> F["Còn hạn"]
 E --> G["Hết hạn"]
 E --> H["Sắp hết hạn trong 7 ngày"]
 F --> I["Tạo danh sách + tìm kiếm"]
 G --> I
 H --> I
```

# MENU 6 — QUẢN LÍ PT
Có 3 nhóm:
1. Quản lí hội viên PT: hồ sơ, thông tin cá nhân, tìm kiếm, chỉnh sửa.
2. Quản lí hợp đồng PT: hợp đồng hiện tại, lịch sử hợp đồng, số buổi, gia hạn.
3. Quản lí buổi tập: ghi nhận buổi tập theo hội viên/hợp đồng hiện tại, theo dõi số buổi đã tập/còn lại.

Quy tắc: mỗi hội viên chỉ có tối đa một hợp đồng PT hiệu lực tại một thời điểm; gia hạn tạo hợp đồng mới; mỗi hội viên tối đa một buổi PT/ngày.

```mermaid
flowchart TD
 A["Quản lí PT"] --> B["Hội viên PT"]
 A --> C["Hợp đồng PT"]
 A --> D["Buổi tập"]
 B --> E["Tìm kiếm / chọn hồ sơ"]
 E --> F["Thông tin hội viên"]
 C --> G["Hợp đồng hiện tại / lịch sử"]
 G --> H["Gia hạn khi đủ điều kiện"]
 H --> I["Tạo hợp đồng mới"]
 D --> J["Chọn hội viên"]
 J --> K["Kiểm tra hợp đồng hiện tại"]
 K --> L["Ghi nhận buổi tập"]
 L --> M["Cập nhật đã tập / còn lại"]
```

# MENU 7 — CÀI ĐẶT
Có đúng 3 mục:

1. **Bảng giá:** 4 khung viền/màu: GYM nam xanh lá, GYM nữ hồng, trẻ em cam, YOGA tím. Cho phép chỉnh sửa giá, xác nhận trước lưu. Giá mới chỉ áp dụng hợp đồng mới; hợp đồng cũ giữ giá lịch sử.
2. **Giao diện sáng/tối:** chuyển đổi toàn ứng dụng, ghi nhớ lựa chọn.
3. **Đồng bộ — Sao lưu — Khôi phục:**
   - Offline: xuất file sao lưu, chọn file nhập, khôi phục.
   - Online: kết nối tài khoản Gmail/Google, đồng bộ online, khôi phục từ bản sao lưu online, hiển thị trạng thái.
   - Khôi phục phải cảnh báo và xác nhận; không ghi đè khi chưa xác nhận. Đăng nhập không đồng nghĩa sao lưu thành công.

```mermaid
flowchart TD
 A["Cài đặt"] --> B["Bảng giá"]
 A --> C["Giao diện sáng/tối"]
 A --> D["Đồng bộ - Sao lưu - Khôi phục"]
 D --> E["Offline: xuất/nhập file"]
 D --> F["Online: kết nối Google"]
 F --> G["Đồng bộ"]
 F --> H["Khôi phục"]
```

# MENU 8 — THÙNG RÁC
Có đúng 8 danh mục:
1. Hội viên GYM.
2. Hội viên YOGA.
3. Hợp đồng GYM.
4. Hợp đồng YOGA.
5. Hồ sơ PT.
6. Hợp đồng PT.
7. Vé lẻ.
8. Dữ liệu khác.

Xóa ở menu thông thường là xóa mềm vào đúng danh mục. Có thể khôi phục. Xóa vĩnh viễn chỉ trong Thùng rác và phải xác nhận. Phải bảo toàn quan hệ hồ sơ-hợp đồng; khôi phục phải phục hồi liên kết chính xác.

```mermaid
flowchart TD
 A["Xóa ở module"] --> B["Xác nhận"]
 B --> C["Chuyển vào đúng danh mục Thùng rác"]
 C --> D["Thùng rác"]
 D --> E["Khôi phục"]
 D --> F["Xóa vĩnh viễn"]
 F --> G["Xác nhận xóa vĩnh viễn"]
```
