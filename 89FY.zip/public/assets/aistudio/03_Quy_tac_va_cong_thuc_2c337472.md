# 03 — Quy tắc nghiệp vụ và công thức

## 1. GYM/YOGA — thời hạn
- Ngày bắt đầu và ngày hết hạn đều tính vào thời hạn.
- Nếu ngày đăng ký là 29/30/31 và tháng đích không có ngày tương ứng, dùng ngày cuối tháng đích; không cộng bù ngày.
- Khoảng trống giữa các hợp đồng không có doanh thu phân bổ.

## 2. Công thức doanh thu phân bổ GYM/YOGA
Với từng hợp đồng:
`Doanh thu phân bổ tháng = Giá trị hợp đồng / Tổng số ngày hiệu lực × Số ngày hiệu lực giao với tháng báo cáo`.
Tính riêng từng hợp đồng rồi cộng. Ngày đầu/cuối đều tính. Không phân bổ ngày trống. Mỗi hợp đồng thuộc đúng một nhóm báo cáo.

Ví dụ tháng 11/2026:
- HĐ1: 250.000đ, 15/10–14/11, 31 ngày; phần tháng 11 là 14 ngày (01–14/11).
- HĐ2: 250.000đ, 20/11–19/12, 30 ngày; phần tháng 11 là 11 ngày (20–30/11).
- 15–19/11 là khoảng trống.
- Phân bổ = 250.000/31×14 + 250.000/30×11 ≈ 204.569,89đ.
Chính sách làm tròn chi tiết chưa chốt.

## 3. PT
- Một hội viên tối đa một hợp đồng PT đang hiệu lực tại một thời điểm.
- Gói PT có số buổi tùy chỉnh; không có hạn tháng cố định.
- Tối đa một buổi PT/người/ngày.
- Mỗi buổi ghi nhận gắn với hợp đồng hiện tại; cập nhật số buổi đã dùng và còn lại.
- Gia hạn giữ hồ sơ/STT, tạo hợp đồng mới.

Công thức:
`PT gộp phân bổ = Giá trị gói / Tổng số buổi gói × Số buổi thực tế trong tháng`.
`Phần phòng tập = PT gộp phân bổ × 50%`.
Ví dụ: 3.000.000/20 = 150.000đ/buổi; 6 buổi = 900.000đ; phần phòng tập = 450.000đ.
Chỉ báo cáo phần 50% phòng tập; không tạo báo cáo riêng hoặc hiển thị phần của Hà Đức.

## 4. Vé lẻ
- Vé ngày và vé tuần cùng thuộc VÉ LẺ.
- Không có hồ sơ khách/STT/hợp đồng hội viên.
- Tổng tiền = số lượng × đơn giá.
- Doanh thu phân bổ theo số vé bán × đơn giá trong kỳ.

## 5. Doanh thu phân bổ và dòng tiền
- Doanh thu phân bổ: phân bổ giá trị dịch vụ vào tháng theo ngày hiệu lực hoặc số buổi thực tế.
- Dòng tiền tháng: tiền thực nhận trong tháng, theo ngày nhận tiền.
- Hai khái niệm không thay thế nhau.
- Dòng tiền phân loại GYM/YOGA/PT/vé lẻ và tiền mặt/chuyển khoản/kết hợp.
- Không đếm trùng thanh toán.
- Không tự thêm chi phí, công nợ, phải thu hoặc hoàn tiền.

## 6. Tổng doanh thu
`Tổng GYM = GYM còn hạn/đăng ký mới + GYM gia hạn + PT phần phòng tập + vé lẻ`.
`Tổng YOGA = YOGA còn hạn/đăng ký mới + YOGA gia hạn`.

## 7. Thanh toán
- Phương thức: tiền mặt, chuyển khoản, kết hợp; mặc định chuyển khoản.
- Nếu kết hợp: tiền mặt + chuyển khoản phải bằng số tiền thanh toán.
- Không ghi nhận trùng giao dịch.

## 8. Chỉnh sửa, xác nhận, xóa
- Dữ liệu tạo ra có thể chỉnh sửa phù hợp.
- Tạo mới/chỉnh sửa phải xem lại và xác nhận trước khi lưu.
- Xóa phải xác nhận, chuyển vào Thùng rác.
- Xóa vĩnh viễn chỉ trong Thùng rác và phải xác nhận.
- Sửa hồ sơ không ghi đè lịch sử hợp đồng.
- Không làm sai lệch quan hệ hồ sơ-hợp đồng-buổi tập-doanh thu.

## 9. Sao lưu
- Offline: xuất file, nhập file, khôi phục.
- Online: kết nối Google/Gmail, đồng bộ và khôi phục.
- Khôi phục phải cảnh báo, xác nhận, không ghi đè trước khi xác nhận.
- Phải báo trạng thái đồng bộ thực tế.
- Nơi lưu trữ, xác thực, mã hóa, xung đột và hợp nhất dữ liệu cần thiết kế/ xác nhận.
