# 04 — Giao diện, cài đặt và checklist nghiệm thu

## 1. Yêu cầu giao diện
- Ưu tiên điện thoại, rõ ràng, gọn, dễ đọc.
- GYM xanh lá; YOGA tím.
- Bảng giá có khung viền và màu riêng: nam xanh lá, nữ hồng, trẻ em cam, YOGA tím.
- Tên hội viên không cắt cụt.
- Tìm kiếm gọn một dòng.
- Giao diện sáng/tối áp dụng toàn app và ghi nhớ lựa chọn.
- Ngày dùng date picker.
- Biểu mẫu có bước xác nhận trước lưu.
- Thanh toán mặc định chuyển khoản; hỗ trợ tiền mặt/chuyển khoản/kết hợp.

## 2. Checklist nghiệm thu

### Toàn ứng dụng
- [ ] Có đúng 8 menu chính.
- [ ] Không tự ý thêm menu cấp cao.
- [ ] Dữ liệu thêm/sửa có xác nhận.
- [ ] Xóa mềm vào Thùng rác; xóa vĩnh viễn có xác nhận.
- [ ] STT không đổi do lọc/sắp xếp/xóa mềm/khôi phục.
- [ ] Ngày dùng date picker.

### GYM/YOGA
- [ ] Danh sách gồm mọi hồ sơ từng đăng ký.
- [ ] Tổng đếm hồ sơ, không đếm hợp đồng.
- [ ] Tìm STT/tên/điện thoại.
- [ ] Tên đầy đủ, hiển thị hạn dùng, nút gia hạn.
- [ ] Chi tiết có hồ sơ, hợp đồng hiện tại, lịch sử.
- [ ] Gia hạn tạo hợp đồng mới, giữ STT.
- [ ] Lịch sử hợp đồng không bị thay đổi khi sửa hồ sơ.
- [ ] YOGA không có bộ lọc nam/nữ/trẻ em.

### Tạo hợp đồng
- [ ] Có đúng 4 lựa chọn GYM/YOGA/PT/VÉ LẺ.
- [ ] GYM/YOGA tìm kiếm trước, không hiển thị danh sách mặc định.
- [ ] Nhận diện hồ sơ cũ/mới.
- [ ] Hồ sơ cũ giữ STT; hồ sơ mới cấp STT mới đúng loại.
- [ ] PT dùng số buổi tùy chỉnh, không hạn tháng cố định.
- [ ] Không có hai hợp đồng PT hiệu lực cùng lúc cho một người.
- [ ] Vé lẻ không tạo hồ sơ khách.
- [ ] Có xác nhận trước lưu.

### Doanh thu
- [ ] Có 3 nhánh phân bổ/dòng tiền/xuất báo cáo.
- [ ] Đúng 5 báo cáo GYM + 3 báo cáo YOGA.
- [ ] Mỗi báo cáo có PDF, Excel, chia sẻ riêng.
- [ ] Chỉ xuất/chia sẻ báo cáo được chọn.
- [ ] Ngày hiệu lực tính cả ngày đầu/cuối.
- [ ] Khoảng trống không được phân bổ.
- [ ] PT chỉ tính 50% phần phòng tập.
- [ ] Vé lẻ = số lượng × đơn giá.
- [ ] Dòng tiền theo ngày thực nhận, tách khỏi phân bổ.
- [ ] Không đếm trùng.

### Theo dõi hội viên
- [ ] Chọn GYM/YOGA trước.
- [ ] Chỉ 3 loại: còn hạn, hết hạn, sắp hết hạn 7 ngày.
- [ ] Không tự tạo danh sách khi mở.
- [ ] Không có danh sách tất cả.
- [ ] Có tìm kiếm.
- [ ] Không có công nợ.

### Quản lí PT
- [ ] Có hồ sơ, hợp đồng, buổi tập.
- [ ] STT PT độc lập.
- [ ] Một hợp đồng hiệu lực tối đa tại một thời điểm.
- [ ] Tối đa một buổi/người/ngày.
- [ ] Cập nhật buổi đã tập/còn lại.

### Cài đặt
- [ ] Đúng 3 mục: bảng giá, sáng/tối, đồng bộ-sao lưu-khôi phục.
- [ ] Giá GYM/YOGA chính xác theo bảng.
- [ ] Sửa giá cần xác nhận.
- [ ] Giá hợp đồng cũ không đổi.
- [ ] Offline xuất/nhập file.
- [ ] Online kết nối Google, đồng bộ và khôi phục.
- [ ] Khôi phục có cảnh báo/xác nhận.

### Thùng rác
- [ ] Đúng 8 danh mục.
- [ ] Xóa mềm chuyển đúng danh mục.
- [ ] Khôi phục giữ liên kết.
- [ ] Xóa vĩnh viễn chỉ từ Thùng rác, có xác nhận.

## 3. Những điểm cần người dùng xác nhận trước khi code
1. Chính sách làm tròn doanh thu phân bổ.
2. Quy tắc hủy hợp đồng, hoàn tiền hoặc điều chỉnh thanh toán nếu cần.
3. Cách xử lý khi xóa hồ sơ có hợp đồng/buổi tập liên quan.
4. Dùng Google Drive hay phương thức lưu trữ nào cho sao lưu online; xử lý khi nhiều thiết bị sửa cùng dữ liệu.
5. Quyền sửa/hủy buổi tập đã ghi nhận và dấu vết kiểm toán.
6. Trạng thái chính xác của hợp đồng PT khi hết buổi và điều kiện chuyển sang không còn hiệu lực.

Gemini phải hỏi người dùng, không tự quyết định các điểm trên.
